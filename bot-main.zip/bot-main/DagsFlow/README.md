### Quickstart

0. Prepare and activate an virtual environment. DagsFlow requires `python>=3.11.*`
1. Clone the project to your local machine
2. Go to `.\DagsFlow`, then run `pip install -r requirements.txt`
3. Once installation is completed, in the same directory, run `dagster dev`. Wait a couple minutes until you see message: `Serving dagster-webserver on http://127.0.0.1:3000 in process XXXXX`
4. Open your browser and navigate to `localhost:3000`. You should see something like this: 

![](docs/successul-ui.png)

5. Create an `.env` file at root folder (where this `README.md` is located) with necessary credentials. 


### Deployment

1. Make sure your new change is run correctly on your local development environment
    - Later, we can start adding unit test (in DagsFlow_test) for proper CICD flow
2. Create a new branch
3. Create a pull request
4. Merge into master after reviewing carefully all the changes. You can request other team members to look at commits.
    - Step 3,4,5 can be done in a single step if you push directly to `master`. ***THIS IS NOT PROPER PROCEDURE. DO THIS AT YOUR OWN RISK***
5. GitHub Runner will pick up the change and deploy new code to server
6. Go to `https:\\<link-to-dagster>\locations`

![](docs/load-new-defs.png)

7. Click Reload to load new code definition