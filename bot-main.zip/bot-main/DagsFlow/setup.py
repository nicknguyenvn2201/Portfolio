from setuptools import find_packages, setup

setup(
    name="DagsFlow",
    packages=find_packages(exclude=["DagsFlow_tests"]),
    python_requires="==3.11.*",
    install_requires=["dagster", "dagster-cloud", "kaleido==0.1.*"],
    extras_require={"dev": ["dagit", "pytest"]},
)
