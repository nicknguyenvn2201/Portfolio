from dagster import ConfigurableResource, get_dagster_logger
from telebot import TeleBot
from typing import BinaryIO, Union, Optional
import requests.exceptions as rq_ecp
from time import sleep
from random import randint
import os

logger = get_dagster_logger()


class TelegramBot(ConfigurableResource):
    bot_token: str

    def send_message(
        self, chat_id: int, text: str, parse_mode: Optional[str] = None
    ) -> None:
        bot = TeleBot(self.bot_token)
        tries = 0
        while tries <= 3:
            try:
                bot.send_message(chat_id, text, parse_mode, timeout=60)
                break
            except rq_ecp.ReadTimeout:
                logger.warning(f"Sending message failed with ReadTimeout. Retrying...")
                sleep(randint(3, 10))
                bot.send_message(chat_id, text, parse_mode, timeout=60)
                tries += 1

    def send_photo(
        self,
        chat_id: int,
        photo: bytes,
        caption: Optional[str] = None,
        parse_mode: Optional[str] = None,
    ) -> None:
        bot = TeleBot(self.bot_token)
        tries = 0
        while tries <= 3:
            try:
                bot.send_photo(chat_id, photo, caption, parse_mode, timeout=60)
                break
            except rq_ecp.ReadTimeout:
                logger.warning(f"Sending photo failed with ReadTimeout. Retrying...")
                sleep(randint(3, 10))
                bot.send_photo(chat_id, photo, caption, parse_mode, timeout=60)
                tries += 1

    def get_bot(self) -> TeleBot:
        return TeleBot(self.bot_token)


class TelegramChat(ConfigurableResource):
    all_chat_id: dict[str, int]

    def get_id(self, chat_name: str) -> int:
        return int(
            self.all_chat_id.get(chat_name, os.getenv("DEFAULT_TELEGRAM_CHAT_ID"))
        )
