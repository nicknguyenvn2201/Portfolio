import os
import requests as rq
from dagster import (
    ConfigurableResource,
    InitResourceContext,
    ConfigurableIOManager,
    get_dagster_logger,
)
from pydantic import PrivateAttr
import requests as rq
from dagster import Any
import io
from contextlib import contextmanager
from typing import Literal, Self

logger = get_dagster_logger()


class UploadSession:
    upload_url: str
    final_response: dict

    def __init__(
        self,
        url: str,
        headers: dict,
        behaviour: Literal["fail", "replace", "rename"] = "fail",
    ) -> None:
        self.behaviour = behaviour
        self.url = url
        self.headers = headers

    def __enter__(self) -> Self:
        data = {
            "item": {"@microsoft.graph.conflictBehavior": self.behaviour},
            "deferCommit": True,
        }
        response = rq.post(
            url=self.url + ":/createUploadSession", headers=self.headers, json=data
        )
        response_json = response.json()
        if "uploadUrl" not in response_json:
            raise ConnectionRefusedError(
                f"Create upload session failed. Server response: {response_json}"
            )
        self.upload_url = response_json["uploadUrl"]
        return self

    def upload(self, file: io.BytesIO, chunk_size_mb: int = 5):
        file_size = file.getbuffer().nbytes
        chunk_size = chunk_size_mb * 1024 * 1024
        file.seek(0)
        while True:
            chunk = file.read(chunk_size)
            if not chunk:
                return response.json()
            headers = self.headers | {
                "Content-Length": str(len(chunk)),
                "Content-Range": f"bytes {file.tell() - len(chunk)}-{file.tell()-1}/{file_size}",
            }
            response = rq.put(self.upload_url, headers=headers, data=chunk)
            if response.status_code != 202:
                raise RuntimeError(
                    f"Failed to upload a chunk. Server response: {response.json()}"
                )

    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_type is not None:
            logger.error("Uploading failed. Rolling back session...")
            rq.delete(self.upload_url)
        headers = self.headers | {
            "Content-Length": "0",
        }
        final_response = rq.post(url=self.upload_url, headers=headers)
        self.final_response = final_response.json()


class MSGraphClient(ConfigurableResource):
    tenant_id: str
    client_id: str
    client_secret: str

    _header: dict = PrivateAttr()

    def setup_for_execution(self, context: InitResourceContext) -> None:
        headers = {"Content-Type": "application/x-www-form-urlencoded"}
        data = {
            "grant_type": "client_credentials",
            "client_id": self.client_id,
            "scope": "https://graph.microsoft.com/.default",
            "client_secret": self.client_secret,
        }
        resp = rq.post(
            f"""https://login.microsoftonline.com/{self.tenant_id}/oauth2/v2.0/token""",
            headers=headers,
            data=data,
        )
        resp_json = resp.json()
        self._header = {"Authorization": "Bearer " + resp_json["access_token"]}


class MSSiteClient(MSGraphClient):
    site_id: str = None
    site_name: str = None

    def setup_for_execution(self, context: InitResourceContext) -> None:
        super().setup_for_execution(context)
        if not (self.site_id or self.site_name):
            raise ValueError("Must specify either site_id or site_name")
        if not self.site_id:
            self.site_id = self.get_site_id()

    def get_site_id(self) -> str:
        if self.site_id:
            return self.site_id
        headers = self._header
        response = rq.get(
            f"""https://graph.microsoft.com/v1.0/sites/neyucom.sharepoint.com:/sites/{self.site_name}:/""",
            headers=headers,
        ).json()
        host_name, site_id, web_id = response["id"].split(",")
        return site_id

    def get_item_content(self, item_id: str = None, path_to_item: str = None) -> bytes:
        headers = self._header
        if item_id:
            url = f"""https://graph.microsoft.com/v1.0/sites/{self.site_id}/drive/items/{item_id}:/content"""
        elif path_to_item:
            url = f"""https://graph.microsoft.com/v1.0/sites/{self.site_id}/drive/root:/{path_to_item}:/content"""
        else:
            raise ValueError("Either item_id or path_to_item must be specified")
        return rq.get(
            url=url,
            headers=headers,
        ).content

    def get_item_metadata(self, item_id: str = None, path_to_item: str = None) -> bytes:
        headers = self._header
        if item_id:
            url = f"""https://graph.microsoft.com/v1.0/sites/{self.site_id}/drive/items/{item_id}"""
        elif path_to_item:
            url = f"""https://graph.microsoft.com/v1.0/sites/{self.site_id}/drive/root:/{path_to_item}"""
        else:
            raise ValueError("Either item_id or path_to_item must be specified")
        return rq.get(
            url=url,
            headers=headers,
        ).json()

    def download_item_by_id(self, item_id: str) -> (dict, bytes):
        metadata = self.get_item_metadata(item_id=item_id)
        content = self.get_item_content(item_id=item_id)
        return metadata, content

    def download_item_by_path(self, path_to_item: str) -> (dict, bytes):
        metadata = self.get_item_metadata(path_to_item=path_to_item)
        content = self.get_item_content(path_to_item=path_to_item)
        return metadata, content

    def upload_item(
        self,
        file: io.BytesIO,
        file_path: str,
        behaviour: Literal["fail", "replace", "rename"] = "replace",
    ) -> rq.Response:
        # Create an upload session
        with UploadSession(
            url=f"https://graph.microsoft.com/v1.0/sites/{self.site_id}/drive/items/root:/{file_path}",
            headers=self._header,
            behaviour=behaviour,
        ) as session:
            session.upload(file)
        final_response = session.final_response
        return final_response
