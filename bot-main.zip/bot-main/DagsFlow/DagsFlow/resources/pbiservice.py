import os
import requests as rq
from dagster import (
    ConfigurableResource,
    InitResourceContext,
    file_relative_path,
    get_dagster_logger,
)
from pydantic import PrivateAttr
import requests as rq
from pathlib import Path
from subprocess import Popen, PIPE, STDOUT
from typing import Optional

logger = get_dagster_logger()

shell_folder_path = Path(file_relative_path(__file__, "./shell_scripts"))


def _parse_response(response: rq.Response) -> list[dict]:
    if response.ok:
        return response.json()
    logger.error(
        f"""Request return status {response.status_code}.\n
Detail: {response.text}
"""
    )
    raise ValueError("Invalid response from Power Bi API Service")


class PBIClient(ConfigurableResource):
    """
    Require PowerShell 7 and above
    """

    username: str
    password: str
    host: str = r"https://api.powerbi.com/v1.0/myorg/"

    _headers: dict[str] = PrivateAttr()

    def setup_for_execution(self, context: InitResourceContext) -> str:
        script_file = shell_folder_path / "get_pbi_token.ps1"
        with Popen(
            [
                "pwsh",
                str(script_file),
                "-username",
                self.username,
                "-password",
                self.password,
            ],
            stdout=PIPE,
            stderr=STDOUT,
        ) as stream:
            api_token = stream.stdout.read().decode("utf-8").strip()
            if "Bearer" not in api_token:
                raise ValueError(
                    f"Reponse not return a bearer token. Got instead: {api_token}"
                )
            self._headers = {"Authorization": api_token}

    def get_token(self):
        return self._api_token

    def get_all_workspaces(
        self,
        filter: Optional[str] = None,
        skip: Optional[int] = None,
        top: Optional[int] = None,
    ) -> list[dict]:
        params = {"$filter": filter, "$skip": skip, "$top": top}
        response = rq.get(
            self.host + "/groups",
            headers=self._headers,
            params=params,
        )
        return _parse_response(response)["value"]

    def get_workspace(self, workspace_id: str) -> dict:
        response = rq.get(
            self.host + f"groups/{workspace_id}",
            headers=self._headers,
        )
        return _parse_response(response)

    def get_report(self, report_id: str) -> dict:
        response = rq.get(
            self.host + f"reports/{report_id}",
            headers=self._headers,
        )
        return _parse_response(response)

    def get_reports_in_workspace(self, workspace_id: str) -> dict:
        response = rq.get(
            self.host + f"groups/{workspace_id}/reports",
            headers=self._headers,
        )
        return _parse_response(response)["value"]

    def get_dataset_in_workspace(self, workspace_id: str, dataset_id: str) -> dict:
        response = rq.get(
            self.host + f"groups/{workspace_id}/datasets/{dataset_id}",
            headers=self._headers,
        )
        return _parse_response(response)

    def get_dataset(self, dataset_id: str) -> dict:
        response = rq.get(
            self.host + f"datasets/{dataset_id}",
            headers=self._headers,
        )
        return _parse_response(response)

    def get_refresh_history(
        self, dataset_id: str, top: Optional[int] = None
    ) -> list[dict]:
        params = {"$top": top}
        response = rq.get(
            self.host + f"datasets/{dataset_id}/refreshes",
            headers=self._headers,
            params=params,
        )
        return _parse_response(response)["value"]

    def get_refresh_schedule(self, dataset_id: str) -> list[dict]:
        response = rq.get(
            self.host + f"datasets/{dataset_id}/refreshSchedule",
            headers=self._headers,
        )
        return _parse_response(response)
