[CmdletBinding()]
param (
    [Parameter(Position = 0)]
    [String]
    $username,

    [Parameter(Position = 1)]
    [String]
    $password

)

$user = $username
$pass = $password | ConvertTo-SecureString -AsPlainText -Force # need to hide this in production code
$cred = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $user, $pass

Connect-PowerBIServiceAccount -Credential $cred | Out-Null
Get-PowerBIAccessToken -AsString