from dagster import ConfigurableResource, InitResourceContext
from pydantic import PrivateAttr
import requests as rq
import psycopg as pg
from contextlib import contextmanager


class PostgresConnection(ConfigurableResource):
    libpq_conn: str
    _conn: pg.Connection = PrivateAttr()

    # this cause deadlock if used with connectorx, but keep it since this is a useful patern
    # @contextmanager
    # def yield_for_execution(self, context: InitResourceContext):
    #     with pg.connect(self.libpq_conn) as conn:
    #         self._conn = conn
    #         yield self

    def get_connection(self) -> pg.Connection:
        return pg.connect(self.libpq_conn)

    def as_libpq_string(self) -> str:
        return self.libpq_conn

    def as_uri_string(self) -> str:
        uri_dict = self.as_dict()
        return f"postgresql://{uri_dict['user']}:{uri_dict['password']}@{uri_dict['host']}:{uri_dict['port']}/{uri_dict['dbname']}"

    def as_dict(self) -> dict:
        return dict((pair.split("=") for pair in self.libpq_conn.split(" ")))
