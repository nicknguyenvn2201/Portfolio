with
    cte_raw as (
        select
            roi.lead_date::date as createdate,
            extract('week' from lead_date + interval '1 day') as lead_week,
            extract('month' from lead_date) as lead_month,
            extract('week' from current_date + interval '1 day') as current_week,
            (date_trunc('week', lead_date + interval '1 day') - interval '1 day')::date
            as week_start,
            (
                date_trunc('week', current_date + interval '1 day') - interval '1 day'
            )::date as week_start_current,
            left(roi.geo, 2) as geo,
            coalesce(trim(dstfc.fin_camp), roi.cam_lead) category,
            roi.cam_lead,
            roi.network,
            roi.product_name,
            roi.pub,
            total_lead,
            roi.approved,
            payout,
            max_po,
            validated,
            delivered,
            amt_validated
        from base_layer.ads_roi_global roi
        left join
            base_layer.dim_sale_to_fin_camp dstfc
            on left(roi.geo, 2) = trim(dstfc.country_code)
            and roi.cam_lead = trim(dstfc.sale_camp)
    ),
    data as (
        select
            *,
            case
                when geo = 'ID'
                then week_start >= (week_start_current - 21)
                when geo in ('VN', 'MY')
                then week_start >= (week_start_current - 14)
                when geo in ('TH', 'PH')
                then week_start >= (week_start_current - 7)
                else false
            end as inrangeforecast
        from cte_raw
    ),
    data_forecast1 as (
        select data.*
        from data
        where
            not inrangeforecast
            and (
                (
                    data.geo = 'VN'
                    and createdate <= week_start_current - 15
                    and createdate >= week_start_current - 35
                )
                or (
                    data.geo in ('ID', 'ID2')
                    and createdate <= week_start_current - 22
                    and createdate >= week_start_current - 42
                )
                or (
                    data.geo = 'TH'
                    and data.category = 'Fresh Hair'
                    and createdate <= '2022-08-31'
                    and createdate >= '2022-08-01'
                )
                or (
                    data.geo = 'TH'
                    and data.category <> 'Fresh Hair'
                    and createdate <= week_start_current - 22
                    and createdate >= week_start_current - 42
                )
                or (
                    data.geo = 'PH'
                    and createdate <= week_start_current - 22
                    and createdate >= week_start_current - 42
                )  -- -- 22.06.2023
                or (
                    data.geo = 'MY'
                    and createdate <= week_start_current - 15
                    and createdate >= week_start_current - 35
                )
            )
    ),
    data_forecast2 as (
        select data.*
        from data
        where
            not inrangeforecast
            and data.geo = 'ID'
            and createdate <= '2022-12-10'
            and createdate >= '2022-11-20'  -- -- 09.01.2023		
    ),
    data_forecast3 as (
        select data.*
        from data
        where
            not inrangeforecast
            and data.geo = 'TH'
            and createdate <= '2022-12-24'
            and createdate >= '2022-12-04'  -- - W49.50.51				---- 09.01.2023
    ),
    full_data_forecast1 as (
        select
            data_forecast.geo,
            data_forecast.category,
            data_forecast.product_name,
            data_forecast.network,
            data_forecast.pub,
            sum(validated) as validated,
            sum(delivered) as delivered,
            case
                when sum(validated) = 0
                then 0
                else sum(delivered) / sum(validated)::float
            end as dr_forecast
        from data_forecast1 data_forecast
        group by
            data_forecast.geo,
            data_forecast.category,
            data_forecast.product_name,
            data_forecast.network,
            data_forecast.pub
    ),
    full_data_forecast2 as (
        select
            data_forecast.geo,
            data_forecast.category,
            data_forecast.product_name,
            data_forecast.network,
            data_forecast.pub,
            sum(validated) as validated,
            sum(delivered) as delivered,
            case
                when sum(validated) = 0
                then 0
                else sum(delivered) / sum(validated)::float
            end as dr_forecast
        from data_forecast2 data_forecast
        group by
            data_forecast.geo,
            data_forecast.category,
            data_forecast.product_name,
            data_forecast.network,
            data_forecast.pub
    ),
    full_data_forecast3 as (
        select
            data_forecast.geo,
            data_forecast.category,
            data_forecast.product_name,
            data_forecast.network,
            data_forecast.pub,
            sum(validated) as validated,
            sum(delivered) as delivered,
            case
                when sum(validated) = 0
                then 0
                else sum(delivered) / sum(validated)::float
            end as dr_forecast
        from data_forecast3 data_forecast
        group by
            data_forecast.geo,
            data_forecast.category,
            data_forecast.product_name,
            data_forecast.network,
            data_forecast.pub
    ),
    full_data_forecast as (
        select
            coalesce(a.geo, b.geo, c.geo) geo,
            coalesce(a.category, b.category, c.category) category,
            coalesce(a.product_name, b.product_name, c.product_name) product_name,
            coalesce(a.network, b.network, c.network) network,
            coalesce(a.pub, b.pub, c.pub) pub,
            a.validated as validated,
            a.delivered as delivered,
            a.dr_forecast as dr_forecast,
            b.validated as validated2,
            b.delivered as delivered2,
            b.dr_forecast as dr_forecast2,
            c.validated as validated3,
            c.delivered as delivered3,
            c.dr_forecast as dr_forecast3
        from full_data_forecast1 a
        full outer join
            full_data_forecast2 b
            on a.geo = b.geo
            and a.category = b.category
            and a.product_name = b.product_name
            and a.network = b.network
            and a.pub = b.pub
        full outer join
            full_data_forecast3 c
            on a.geo = c.geo
            and a.category = c.category
            and a.product_name = c.product_name
            and a.network = c.network
            and a.pub = c.pub
    -- where coalesce(a.geo, b.geo) in ('TH', 'TH2')
    ),
    full_data_forecast_by_network as (
        select
            geo,
            category,
            product_name,
            network,
            sum(validated) as validated_by_network,
            sum(validated2) as validated_by_network2,
            sum(validated3) as validated_by_network3,
            sum(delivered) as delivered_by_network,
            sum(delivered2) as delivered_by_network2,
            sum(delivered3) as delivered_by_network3,
            case
                when sum(validated) = 0
                then 0
                else sum(delivered) / sum(validated)::float
            end as dr_forecast_by_network,
            case
                when sum(validated2) = 0
                then 0
                else sum(delivered2) / sum(validated2)::float
            end as dr_forecast_by_network2,
            case
                when sum(validated3) = 0
                then 0
                else sum(delivered3) / sum(validated3)::float
            end as dr_forecast_by_network3
        from full_data_forecast
        group by geo, category, product_name, network
    ),
    full_data_forecast_by_offer as (
        select
            geo,
            category,
            product_name,
            sum(validated) as validated_by_offer,
            sum(delivered) as delivered_by_offer,
            case
                when sum(validated) = 0
                then 0
                else sum(delivered) / sum(validated)::float
            end as dr_forecast_by_offer,
            sum(validated2) as validated_by_offer2,
            sum(delivered2) as delivered_by_offer2,
            case
                when sum(validated2) = 0
                then 0
                else sum(delivered2) / sum(validated2)::float
            end as dr_forecast_by_offer2,
            sum(validated3) as validated_by_offer3,
            sum(delivered3) as delivered_by_offer3,
            case
                when sum(validated3) = 0
                then 0
                else sum(delivered3) / sum(validated3)::float
            end as dr_forecast_by_offer3
        from full_data_forecast
        group by geo, category, product_name
    ),
    full_data_forecast_by_cat as (
        select
            geo,
            category,
            sum(validated) as validated_by_cat,
            sum(delivered) as delivered_by_cat,
            case
                when sum(validated) = 0
                then 0
                else sum(delivered) / sum(validated)::float
            end as dr_forecast_by_cat,
            sum(validated2) as validated_by_cat2,
            sum(delivered2) as delivered_by_cat2,
            case
                when sum(validated2) = 0
                then 0
                else sum(delivered2) / sum(validated2)::float
            end as dr_forecast_by_cat2,
            sum(validated3) as validated_by_cat3,
            sum(delivered3) as delivered_by_cat3,
            case
                when sum(validated3) = 0
                then 0
                else sum(delivered3) / sum(validated3)::float
            end as dr_forecast_by_cat3
        from full_data_forecast
        group by geo, category
    )
select
    raw.geo,
    raw.cam_lead category,
    raw.product_name,
    raw.network,
    case
        when raw.pub is null then 'No PubID' when raw.pub = '' then 'blank' else raw.pub
    end as pub,
    a.validated,
    a.delivered,
    a.dr_forecast,
    b.validated_by_network,
    b.delivered_by_network,
    b.dr_forecast_by_network,
    c.validated_by_offer,
    c.delivered_by_offer,
    c.dr_forecast_by_offer,
    d.validated_by_cat,
    d.delivered_by_cat,
    d.dr_forecast_by_cat,
    case
        when raw.product_name = 'bonivita-my'
        then dr_forecast_by_cat
        when raw.product_name = 'megaburn390cpl-id'
        then 0.8
        else
            case
                when a.validated > 30
                then a.dr_forecast
                else
                    case
                        when b.validated_by_network > 30
                        then b.dr_forecast_by_network
                        else
                            case
                                when c.validated_by_offer > 30
                                then c.dr_forecast_by_offer
                                else dr_forecast_by_cat
                            end
                    end
            end
    end dr_forecast_final,
    a.validated2,
    a.delivered2,
    a.dr_forecast2,
    b.validated_by_network2,
    b.delivered_by_network2,
    b.dr_forecast_by_network2,
    c.validated_by_offer2,
    c.delivered_by_offer2,
    c.dr_forecast_by_offer2,
    d.validated_by_cat2,
    d.delivered_by_cat2,
    d.dr_forecast_by_cat2,
    case
        when a.validated2 > 30
        then a.dr_forecast2
        else
            case
                when b.validated_by_network2 > 30
                then b.dr_forecast_by_network2
                else
                    case
                        when c.validated_by_offer2 > 30
                        then c.dr_forecast_by_offer2
                        else dr_forecast_by_cat2
                    end
            end
    end as dr_forecast_final2,
    a.validated3,
    a.delivered3,
    a.dr_forecast3,
    b.validated_by_network3,
    b.delivered_by_network3,
    b.dr_forecast_by_network3,
    c.validated_by_offer3,
    c.delivered_by_offer3,
    c.dr_forecast_by_offer3,
    d.validated_by_cat3,
    d.delivered_by_cat3,
    d.dr_forecast_by_cat3,
    case
        when a.validated3 > 30
        then a.dr_forecast3
        else
            case
                when b.validated_by_network3 > 30
                then b.dr_forecast_by_network3
                else
                    case
                        when c.validated_by_offer3 > 30
                        then c.dr_forecast_by_offer3
                        else dr_forecast_by_cat3
                    end
            end
    end as dr_forecast_final3
from
    (
        select distinct geo, cam_lead, category, network, product_name, pub from cte_raw
    ) raw
left join
    full_data_forecast a
    on raw.geo = a.geo
    and raw.category = a.category
    and raw.product_name = a.product_name
    and raw.network = a.network
    and raw.pub = a.pub
left join
    full_data_forecast_by_network b
    on raw.geo = b.geo
    and raw.category = b.category
    and raw.product_name = b.product_name
    and raw.network = b.network
left join
    full_data_forecast_by_offer c
    on raw.geo = c.geo
    and raw.category = c.category
    and raw.product_name = c.product_name
left join full_data_forecast_by_cat d on raw.geo = d.geo and raw.category = d.category