import pandas as pd
import os
from dagster import (
    Config,
    get_dagster_logger,
    asset,
    AssetExecutionContext,
    MetadataValue,
    define_asset_job,
    DailyPartitionsDefinition,
    ScheduleDefinition,
    AssetSelection
)
import io
import psycopg as pg
from DagsFlow.assets.utls import func
from typing import Iterator
import requests as rq
from datetime import date
from datetime import timedelta
from pandas import DataFrame
import pyarrow as pa
from DagsFlow.assets.utls.func import (
    add_blocking_checks_to_asset,
    create_load_to_postgres_asset_db_master,
    create_download_from_sharepoint_asset_base_layer,
)
import psycopg2

logger = get_dagster_logger()


oltp01_conn = os.getenv("PG_LIBPQ_CONN_CONFIG")

class sync_data_master_fully_v3(Config):
    sql_query_truncate_cl_fresh_v3: str = "TRUNCATE dareport.cl_fresh_temp_v3;"
    sql_query_insert_cl_fresh_v3: str = '''insert into dareport.cl_fresh_temp_v3 
    select 
     cl_fresh.geo,
            cl_fresh.lead_id,
            cl_fresh.org_id,
            cl_fresh.cp_id,
            cl_fresh.lead_status,
            cl_fresh.createdate,
            cl_fresh.modifydate,
            cl_fresh.name,
            cl_fresh.phone,
            agc_id,
            agc_code,
            cl_fresh.affiliate_id,
            cl_fresh.prod_name,
            cl_fresh.first_call_status,
            cl_fresh.first_call_time,
            cl_fresh.lead_type,
            cl_fresh.subid1,
            cl_fresh.postback_status,
            cl_fresh.total_call,
            cl_fresh.actual_call,
            cl_fresh.click_id,
            cl_fresh.province,
            cl_fresh.district,
            cl_fresh.subdistrict,
            cl_fresh.assigned,
            first_call_click 
     from public.cl_fresh where modifydate >= now() - interval '30 hour' '''
    sql_query_truncate_od_sale_order_v3: str = "TRUNCATE dareport.od_sale_order_temp_v3;"
    sql_query_insert_od_sale_order_v3: str = "insert into dareport.od_sale_order_temp_v3 select * from public.od_sale_order where modifydate >= now() - interval '30 hour';"

    sql_query_truncate_od_do_new_v3: str = "TRUNCATE dareport.od_do_new_temp_v3;"
    sql_query_insert_od_do_new_v3: str = "insert into dareport.od_do_new_temp_v3 select * from public.od_do_new where updatedate >= now() - interval '30 hour';"

    sql_query_truncate_data_master_raw_temp: str = "TRUNCATE dareport.data_master_raw_temp;"
    sql_query_truncate_data_master_agg_temp: str = "TRUNCATE dareport.data_master_agg_temp;"


@asset(group_name="data_master_full_v3")
def truncate_table_cl_fresh_temp_v3(config: sync_data_master_fully_v3):
    conn_details = psycopg2.connect(oltp01_conn)
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_truncate_cl_fresh_v3)
    conn_details.commit()
    cursor.close()
    conn_details.close()

@asset(group_name="data_master_full_v3", deps=[truncate_table_cl_fresh_temp_v3])
def insert_new_data_table_cl_fresh_temp_v3(config: sync_data_master_fully_v3):
    conn_details = psycopg2.connect(oltp01_conn)
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_insert_cl_fresh_v3)
    conn_details.commit()
    cursor.close()
    conn_details.close()

@asset(group_name="data_master_full_v3")
def truncate_table_od_sale_order_temp_v3(config: sync_data_master_fully_v3):
    conn_details = psycopg2.connect(oltp01_conn)
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_truncate_od_sale_order_v3)
    conn_details.commit()
    cursor.close()
    conn_details.close()

@asset(group_name="data_master_full_v3", deps=[truncate_table_od_sale_order_temp_v3])
def insert_new_data_table_od_sale_order_temp_v3(config: sync_data_master_fully_v3):
    conn_details = psycopg2.connect(oltp01_conn)
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_insert_od_sale_order_v3)
    conn_details.commit()
    cursor.close()
    conn_details.close()

@asset(group_name="data_master_full_v3")
def truncate_table_od_do_new_temp_v3(config: sync_data_master_fully_v3):
    conn_details = psycopg2.connect(oltp01_conn)
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_truncate_od_do_new_v3)
    conn_details.commit()
    cursor.close()
    conn_details.close()

@asset(group_name="data_master_full_v3", deps=[truncate_table_od_do_new_temp_v3])
def insert_new_data_table_od_do_new_temp_v3(config: sync_data_master_fully_v3):
    conn_details = psycopg2.connect(oltp01_conn)
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_insert_od_do_new_v3)
    conn_details.commit()
    cursor.close()
    conn_details.close()

@asset(group_name="data_master_full_v3", deps=[insert_new_data_table_cl_fresh_temp_v3, insert_new_data_table_od_sale_order_temp_v3, insert_new_data_table_od_do_new_temp_v3])
def truncate_data_table_data_master_raw_temp(config: sync_data_master_fully_v3):
    conn_details = psycopg2.connect(oltp01_conn)
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_truncate_data_master_raw_temp)
    conn_details.commit()
    cursor.close()
    conn_details.close()

@asset(group_name="data_master_full_v3", deps = [truncate_data_table_data_master_raw_temp])
def create_data_master_raw_temp(context: AssetExecutionContext) -> None:
    templater = func.SqlStore()
    with pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG")) as connection:
        with connection.cursor() as cursor:
            insert_statement = templater.get("data_master_raw_temp").render()
            logger.info("Start insert into target table")
            cursor.execute(insert_statement)
            logger.info("Completed insert into target table")

@asset(group_name="data_master_full_v3", deps = [create_data_master_raw_temp])
def truncate_data_master_raw_full_v3(context: AssetExecutionContext) -> None:
    templater = func.SqlStore()
    with pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG")) as connection:
        with connection.cursor() as cursor:
            insert_statement = templater.get("truncate_data_master_raw_v3").render()
            logger.info("Start truncate into target table")
            cursor.execute(insert_statement)
            logger.info("Completed truncate into target table")

@asset(group_name="data_master_full_v3", deps=[truncate_data_master_raw_full_v3])
def load_data_master_raw_full_v3(context: AssetExecutionContext) -> None:
    templater = func.SqlStore()
    with pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG")) as connection:
        with connection.cursor() as cursor:
            insert_statement = templater.get("data_master_raw_v3").render()
            logger.info("Start inserting into target table")
            cursor.execute(insert_statement)
            logger.info("Completed inserting into target table")

@asset(group_name="data_master_full_v3", deps = [load_data_master_raw_full_v3])
def truncate_data_master_agg_temp(config: sync_data_master_fully_v3):
    conn_details = psycopg2.connect(oltp01_conn)
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_truncate_data_master_agg_temp)
    conn_details.commit()
    cursor.close()
    conn_details.close()

@asset(group_name="data_master_full_v3", deps = [truncate_data_master_agg_temp])
def create_data_master_agg_temp(context: AssetExecutionContext) -> None:
    templater = func.SqlStore()
    with pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG")) as connection:
        with connection.cursor() as cursor:
            insert_statement = templater.get("data_master_agg_temp").render()
            logger.info("Start truncate into target table")
            cursor.execute(insert_statement)
            logger.info("Completed truncate into target table")

@asset(group_name="data_master_full_v3", deps = [create_data_master_agg_temp])
def truncate_data_master_agg_v3(context: AssetExecutionContext) -> None:
    templater = func.SqlStore()
    with pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG")) as connection:
        with connection.cursor() as cursor:
            insert_statement = templater.get("truncate_data_master_agg_v3").render()
            logger.info("Start truncate into target table")
            cursor.execute(insert_statement)
            logger.info("Completed truncate into target table")

@asset(group_name="data_master_full_v3", deps=[truncate_data_master_agg_v3])
def load_data_master_agg_v3(context: AssetExecutionContext) -> None:
    templater = func.SqlStore()
    with pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG")) as connection:
        with connection.cursor() as cursor:
            insert_statement = templater.get("data_master_agg_v3").render()
            logger.info("Start inserting into target table")
            cursor.execute(insert_statement)
            logger.info("Completed inserting into target table")


sync_data_master_full_v3 = define_asset_job(
    name="sync_data_master_full_v3",
    selection=AssetSelection.groups("data_master_full_v3"),
)

sync_data_master_full_v3_schedule = ScheduleDefinition(
    job=sync_data_master_full_v3,
    cron_schedule= "0 2 * * *", 
    execution_timezone="Asia/Bangkok",
)


