from dagster import (
    asset,
    AssetExecutionContext,
    MetadataValue,
    define_asset_job,
    ScheduleDefinition,
    get_dagster_logger,
    AssetsDefinition,
    MaterializeResult,
)
import psycopg as pg
from DagsFlow.resources.postgres import PostgresConnection
from DagsFlow.assets.utls.sql import SqlStore
from DagsFlow.assets.utls.func import (
    check_if_table_exist_base_layer,
    get_table_indexes_base_layer,
)
from DagsFlow.assets import user_input as user_input_assets
from DagsFlow.assets.affscale_api import ods_affscale_conversion
from DagsFlow.assets.pub_ads_roi import load_pub_ads_roi_to_postgres
from DagsFlow.assets.exchangerate_api import load_exchange_rate_data
from pathlib import Path
from typing import Optional, Iterable
from dagster._core.definitions.asset_dep import CoercibleToAssetDep

logger = get_dagster_logger()
PATH_TO_SQL_STORE = Path(__file__).parent / "materialized_view_sql"


def _refresh_materialize_view_mart_bd(
    cursor: pg.Cursor, view_name: str, with_data: bool = False
) -> int:
    if with_data:
        sql_refresh = f"""
refresh materialized view concurrently {view_name} with data
"""
    else:
        sql_refresh = f"""
refresh materialized view {view_name}
"""
    sql_count = f"""
select count(*) from {view_name}
"""
    logger.info(f"Refreshing materialized view {view_name}")
    cursor.execute(sql_refresh)
    logger.info(f"Completed refreshing materialized view {view_name}")
    row_count = cursor.execute(sql_count).fetchone()[0]
    return int(row_count)


def create_refreshable_table_asset_mart_bd(
    schema_name: str,
    table_name: str,
    description: str = "",
    incremental_query: str = "",
    sql_store: SqlStore = SqlStore(PATH_TO_SQL_STORE),
    deps: Optional[Iterable[CoercibleToAssetDep]] = None,
):
    select_view_query = sql_store.get(table_name).render()
    view_name = f"_dagster_staging__{table_name}"

    @asset(
        name=table_name,
        compute_kind="postgres",
        metadata={
            "View Name": MetadataValue.text(view_name),
            "Raw SQL": MetadataValue.md(
                f"""**Raw SQL:**
```
{select_view_query}
```
"""
            ),
        },
        group_name="pg_materialized_view_mart_bd",
        description=description,
        deps=deps,
    )
    def _asset(
        context: AssetExecutionContext,
        oltp03_conn: PostgresConnection,
    ) -> MaterializeResult:
        with oltp03_conn.get_connection() as connection:
            with connection.cursor() as cursor:
                is_table_exist = check_if_table_exist_base_layer(
                    cursor, schema_name, table_name
                )
                create_view_query = f"""create or replace view {schema_name}.{view_name} as ({select_view_query})"""
                cursor.execute(create_view_query)
                logger.info("Staging view created or replaced")
                if is_table_exist:
                    logger.info("Table found. Deleting and inserting new data...")
                    delete_query = f"""delete from {schema_name}.{table_name}"""
                    cursor.execute(delete_query)
                    logger.info("Completed deleting old data")
                    indexes = get_table_indexes_base_layer(
                        cursor, schema_name, table_name
                    )
                    for index_name, index_def in indexes:
                        cursor.execute(f'drop index "{index_name}"')
                    logger.info("Dropped all indexes for better insertion")
                else:
                    logger.info("Table not found. Creating and inserting new data...")
                    create_table_query = f"""create table {schema_name}.{table_name} as select * from {schema_name}.{view_name}"""
                    cursor.execute(create_table_query)
                insert_query = f"""insert into {schema_name}.{table_name} select * from {schema_name}.{view_name}"""
                cursor.execute(insert_query)
                logger.info("Completed inserting new data")
                if is_table_exist:
                    for index_name, index_def in indexes:
                        cursor.execute(index_def)
                    logger.info("Completed recreating indexes")
                row_count = cursor.execute(
                    f"""select count(*) from {schema_name}.{table_name}"""
                ).fetchone()[0]
        return MaterializeResult(
            metadata={
                "Row Count": MetadataValue.int(int(row_count)),
            }
        )

    return _asset


def create_refresh_mv_asset_mart_bd(
    materialized_view_name: str,
    asset_name: str = None,
    with_data: bool = False,
    deps: Optional[Iterable[CoercibleToAssetDep]] = None,
):
    @asset(
        name=f"materialized_view_{asset_name or materialized_view_name}",
        compute_kind="postgres",
        group_name="pg_materialized_view_mart_bd",
        deps=deps,
    )
    def _asset(context: AssetExecutionContext, oltp03_conn: PostgresConnection):
        with oltp03_conn.get_connection() as connection:
            with connection.cursor() as cursor:
                row_count = _refresh_materialize_view_mart_bd(
                    cursor, materialized_view_name, with_data
                )
                context.add_output_metadata({"Row Count": MetadataValue.int(row_count)})

    return _asset


def create_refresh_schedule_mart_bd(
    assets: list[AssetsDefinition], schedules: list[str], name: str = None
) -> ScheduleDefinition:
    if not name:
        name = str(assets[0].key[0][0])
    asset_job = define_asset_job(
        name="refresh_" + name + "_job_mart_bd",
        selection=assets,
    )
    return ScheduleDefinition(
        job=asset_job,
        name="refresh_" + name + "_schedule_mart_bd",
        cron_schedule=schedules,
        execution_timezone="Asia/Bangkok",
    )


bd_master_mart_bd = create_refreshable_table_asset_mart_bd("mart_bd", "bd_master")

bd_master_schedule_mart_bd = create_refresh_schedule_mart_bd(
    [bd_master_mart_bd],
    ["0 6,8,10,14,18,20 * * *", "30 12 * * *"],  # ["30 0 * * *"],
    "bd_master",
)
