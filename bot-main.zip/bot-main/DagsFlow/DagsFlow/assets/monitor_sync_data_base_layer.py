from dagster import (
    asset,
    ScheduleDefinition,
    define_asset_job,
    AssetSelection,
)
import pandas as pd
from DagsFlow.assets.utls.func import (
    extract_from_dwh,
)
from DagsFlow.resources import telegram
import pandas as pd
from DagsFlow.resources.postgres import PostgresConnection


@asset(group_name="monitor_sync_data_base_layer")
def monitor_data_sync_base_layer_phare_01(
    telebot_data: telegram.TelegramBot,
    telegram_chat: telegram.TelegramChat,
    oltp03_conn: PostgresConnection
):
    
    check_query = """ select n.nspname as table_schema, 
    c.relname as table_name, 
    c.reltuples as table_rows, 
    current_timestamp  as last_modify_time 
    from pg_class c 
    join pg_namespace n on n.oid = c.relnamespace 
    where c.relkind = 'r' 
    and n.nspname = 'base_layer'
    and c.relname Like '%dim%'
    order by c.reltuples desc  """
    df = extract_from_dwh(check_query, oltp03_conn)
    chat_id = telegram_chat.get_id("DATA_DB_MASTER")
    telebot_data.send_message(
        chat_id,
        f"""@Jake_Nguyen @tinh_nguyen1904 All table in BASE LAYER has been updated with new data with row numbers:
```{df.to_string(index=False)}```
""",
        parse_mode="MarkdownV2",
    )

@asset(group_name="monitor_sync_data_base_layer",  deps=[monitor_data_sync_base_layer_phare_01])
def monitor_data_sync_base_layer_phare_02(
    telebot_data: telegram.TelegramBot,
    telegram_chat: telegram.TelegramChat,
    oltp03_conn: PostgresConnection
):
    
    check_query = """ select n.nspname as table_schema, 
    c.relname as table_name, 
    c.reltuples as table_rows, 
    current_timestamp  as last_modify_time 
    from pg_class c 
    join pg_namespace n on n.oid = c.relnamespace 
    where c.relkind = 'r' 
    and n.nspname = 'base_layer'
    and c.relname not Like '%dim%'
    order by c.reltuples desc  """
    df = extract_from_dwh(check_query, oltp03_conn)
    chat_id = telegram_chat.get_id("DATA_DB_MASTER")
    telebot_data.send_message(
        chat_id,
        f"""@Jake_Nguyen @tinh_nguyen1904 All table in BASE LAYER has been updated with new data with row numbers:
```{df.to_string(index=False)}```
""",
        parse_mode="MarkdownV2",
    )

monitor_sync_data_base_layer_job = define_asset_job(
    name="monitoring_sync_data_base_layer",
    selection=AssetSelection.groups("monitor_sync_data_base_layer"),
)

monitor_sync_or_user_schedule = ScheduleDefinition(
    job=monitor_sync_data_base_layer_job,
    cron_schedule="35 * * * *",
    execution_timezone="Asia/Bangkok",
)
