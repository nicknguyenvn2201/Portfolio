[CmdletBinding()]
param (
    [Parameter(Position = 0)]
    [System.String]
    $StartDate = (Get-Date).AddDays(-8).ToString("yyyy,MM,dd"),

    [Parameter(Position = 1)]
    [System.String]
    $EndDate = (Get-Date).AddDays(-1).ToString("yyyy,MM,dd")
)

$user = $Env:PBI_USERNAME
$pass = $Env:PBI_PASSWORD | ConvertTo-SecureString -AsPlainText -Force # need to hide this in production code
$cred = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $user, $pass

Connect-PowerBIServiceAccount -Credential $cred | Out-Null

# stole from here https://www.fourmoo.com/2021/10/08/using-powershell-to-run-power-bi-dax-queries-and-extract-data-to-csv/

$requestUrl = "datasets/b02f58e7-120f-4393-a112-c07f2fb22235/executeQueries"

$requestBody = @"
{
    "queries":
        [
            {"query": "

            // DAX Query
            DEFINE
                VAR __DS0FilterTable = 
                    FILTER(
                        KEEPFILTERS(VALUES('tms'[lead_date])),
                        AND('tms'[lead_date] >= DATE($StartDate), 'tms'[lead_date] <= DATE($EndDate))
                    )
            
                VAR __ValueFilterDM0 = 
                    FILTER(
                        KEEPFILTERS(
                            SUMMARIZECOLUMNS(
                                'tms'[network],
                                'tms'[product_name],
                                'Max po tracking'[gp1],
                                'Max po tracking'[gm1],
                                'Max po tracking'[gp2],
                                'Max po tracking'[gm2],
                                'Max po tracking'[max_po],
                                'tms'[geo],
                                __DS0FilterTable,
                                \"GP1_act\", 'GM measure'[GP1_act],
                                \"GM1_act\", 'GM measure'[GM1_act],
                                \"GP2_act\", 'GM measure'[GP2_act],
                                \"GM2_act\", 'GM measure'[GM2_act],
                                \"Max_PO2\", 'tms'[Max PO],
                                \"pgap_max_po\", 'GM measure'[pgap max po],
                                \"pgap_gm1\", 'GM measure'[pgap gm1],
                                \"pgap_gm2\", 'GM measure'[pgap gm2],
                                \"Averagegm1\", IGNORE(CALCULATE(AVERAGE('Max po tracking'[gm1]))),
                                \"gm2_trigger_rule\", IGNORE('tms'[gm2 trigger rule])
                            )
                        ),
                        [gm2_trigger_rule] = 1
                    )
            
                VAR __DS0Core = 
                    SUMMARIZECOLUMNS(
                        'tms'[network],
                        'tms'[product_name],
                        'Max po tracking'[gp1],
                        'Max po tracking'[gm1],
                        'Max po tracking'[gp2],
                        'Max po tracking'[gm2],
                        'Max po tracking'[max_po],
                        'tms'[geo],
                        __DS0FilterTable,
                        __ValueFilterDM0,
                        \"GM1_act\", 'GM measure'[GM1_act],
                        \"GP1_act\", 'GM measure'[GP1_act],
                        \"GP2_act\", 'GM measure'[GP2_act],
                        \"GM2_act\", 'GM measure'[GM2_act],
                        \"Max_PO2\", 'tms'[Max PO],
                        \"pgap_max_po\", 'GM measure'[pgap max po],
                        \"pgap_gm1\", 'GM measure'[pgap gm1],
                        \"pgap_gm2\", 'GM measure'[pgap gm2],
                        \"Averagegm1\", IGNORE(CALCULATE(AVERAGE('Max po tracking'[gm1]))),
                        \"gm2_trigger_rule\", IGNORE('tms'[gm2 trigger rule])
                    )
            
            EVALUATE
                __DS0Core

                "
            }
        ],
        "serializerSettings": {
            "includeNulls": true
  },
}
"@ 
# Creating the Result Variable by passing through the DAX Query to the Power BI PowerShell Module
Invoke-PowerBIRestMethod -Method POST -Url $requestUrl -Body $requestBody