select *
from od_do_new
where createdate >= current_date - 6
