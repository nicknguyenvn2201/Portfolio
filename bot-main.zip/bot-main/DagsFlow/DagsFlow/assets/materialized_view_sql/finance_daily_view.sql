with
    raw as (
        select
            case when d.geo <> 'VNID' then left(d.geo::text, 2) else d.geo::text end as geo,
            d.cp_id,
            d.agc_code,
            concat(a.so_id, '_', a.geo) as soid,
            concat(e.do_id, '_', e.geo) as doid,
            concat(e.do_code, '_', e.geo) as docode,
            concat(d.lead_id, '_', d.geo) as leadid,
            CASE
	            WHEN lower(d.prod_name::text) ~~ '%cpl%'::text and lower(d.lead_status::text) != ANY (ARRAY['trash'::text, 'duplicated'::text])
	            THEN 1::bigint
	            ELSE 0::bigint
	        END AS cpl_lead,
            a.creation_date,
            d.prod_name as offer_product,
            e.package_name,
            coalesce(osi.product1, d.prod_name::text) as product1,
            prod.product_no1,
            prod.quantity_no1,
            prod.product_no2,
            prod.quantity_no2,
            prod.product_no3,
            prod.quantity_no3,
            prod.product_no4,
            prod.quantity_no4,
            coalesce(prod.quantity_no1, 0)
            + coalesce(prod.quantity_no2, 0)
            + coalesce(prod.quantity_no3, 0)
            + coalesce(prod.quantity_no4, 0) as total_quantity,
            a.amount,
            coalesce(o.shortname, d.agc_code) as sourcename,
            case
                when d.subid1::text = ''::text
                then 'blank'::character varying
                when d.subid1 is null
                then 'No PubID'::character varying
                when
                    (
                        d.affiliate_id::text = any(
                            array[
                                'EW'::character varying::text,
                                'AT'::character varying::text,
                                'ADT'::character varying::text,
                                'ABT'::character varying::text,
                                'ARB'::character varying::text,
                                'CSL'::character varying::text,
                                'MKR'::character varying::text,
                                'XXX'::character varying::text,
                                'PFC'::character varying::text,
                                'ORG'::character varying::text,
                                'ORG2'::character varying::text,
                                'PIB'::character varying::text,
                                'MH'::character varying::text,
                                'MP'::character varying::text,
                                'IGO'::character varying::text,
                                'VIC'::character varying::text,
                                'ODS'::character varying::text,
                                'DAT'::character varying::text,
                                'VAL'::character varying::text,
                                'MIR'::character varying::text,
                                'NGN'::character varying::text,
                                'WIL'::character varying::text,
                                'PD'::character varying::text,
                                'CTR'::character varying::text,
                                'U_DOMA'::character varying::text,
                                'ABG'::character varying::text
                            ]
                        )
                    )
                    or d.affiliate_id::text = 'U_RUS'::text
                    and d.org_id = 10
                then 'No PubID'::character varying
                else
                    case
                        when
                            coalesce(o.shortname, d.agc_code)::text = any(
                                array[
                                    'AFS'::character varying::text,
                                    'OFP'::character varying::text
                                ]
                            )
                        then coalesce(d.subid1, 'No PubID'::character varying)
                        else d.affiliate_id
                    end
            end as pub,
            d.affiliate_id,
            p.user_name as agname,
            e.lastmile_return_code,
            case
                when d.geo::text = any(array['TH'::text, 'TH2'::text])
                then l.shortname
                else l.name
            end as province,
            case
                when d.geo::text = any(array['TH'::text, 'TH2'::text])
                then m.shortname
                else m.name
            end as district,
            case
                when d.geo::text = any(array['TH'::text, 'TH2'::text])
                then n.shortname
                else m.name
            end as subdistrict,
            f.shortname as ffmname,
            j.warehouse_shortname as warehousename,
            k.shortname as lastmilename,
            reg.region_shortname as region,
            cat."FIN camp" as fin_camp,
            case
                a.payment_method
                when 1
                then 'COD'::text
                when 2
                then 'Banking Tranfer'::text
                else null::text
            end as paymentmethod,
            case
                when starts_with(d.geo::text, 'ID'::text)
                then
                    case
                        when lower(p.user_name::text) like '%bk%'::text
                        then 'TLS'::text
                        else 'CIT'::text
                    end
                when
                    d.geo::text
                    = any(array['VN'::text, 'VN2'::text, 'VN3'::text, 'VN4'::text, 'VNID'::text])
                then
                    case
                        when
                            p.user_type::text = 'agent'::text
                            and lower(p.user_name::text) like '%cit%'::text
                        then 'CIT'::text
                        when
                            p.user_type::text = 'agent'::text
                            and lower(p.user_name::text) like '%agentmilk%'::text
                        then 'MILK'::text
                        when
                            p.user_type::text = 'agent'::text
                            and lower(p.user_name::text) not like '%cit%'::text
                            and lower(p.user_name::text) not like '%agentmilk%'::text
                            and lower(p.user_name::text) not like '%test%'::text
                            and lower(p.user_name::text) not like '%virtual%'::text
                            and lower(p.user_name::text) not like '%son%'::text
                        then 'TLS'::text
                        when lower(p.user_name::text) = 'system'::text
                        then 'system'::text
                        else 'Others'::text
                    end
                when d.geo::text = any(array['TH'::text, 'TH2'::text])
                then
                    case
                        when lower(p.user_name::text) like 'r%'::text
                        then 'CIT'::text
                        when lower(p.user_name::text) like 'a%'::text
                        then 'TLS'::text
                        else null::text
                    end
                when d.geo::text = 'MY'::text
                then
                    case
                        when lower(p.user_name::text) like 'r%'::text
                        then 'CIT'::text
                        when lower(p.user_name::text) like 'a%'::text
                        then 'TLS'::text
                        else null::text
                    end
                else null::text
            end as agent_type,
            g.name as leadstatus,
            d.user_defin_05 as reason,
            h.name as orderstatus,
            a.status as od_status_id,
            b.name as deliverystatus,
            case
                when h.name is null
                then null::text
                when
                    lower(b.name::text) = any(
                        array[
                            'cancel'::text,
                            'cancelled'::text,
                            'reject'::text,
                            'returning'::text,
                            'returned'::text
                        ]
                    )
                then 'reject'::text
                when lower(b.name::text) = 'delivered'::text
                then 'delivered'::text
                when h.name::text <> all(array['validated'::text, 'delay'::text])
                then null::text
                else 'intransit'::text
            end as status_fn,
            d.lead_type as leadtype,
            case
                when d.lead_type::text = 'A'::text
                then 'Fresh'::text
                else 'Resell'::text
            end as leadtypename,
            q.name as sale_camp,
            case
                when d.lead_type::text = 'A'::text
                then d.createdate::date
                else a.createdate::date
            end as date_used,
            current_date - case
                when d.lead_type::text = 'A'::text
                then d.createdate::date
                else a.createdate::date
            end
            - 1 as aging,
            d.createdate as lead_date,
            a.createdate as so_date,
            e.createdate as do_createdate,
            rcp.user_name as agent_rescue,
            rs.name as rescue_status,
            rss.name as rescue_reason,
            oac.payout,
            oac.max_po,
            rrj.createdate as rescue_createdate,
            case
                when
                    (
                        d.geo::text
                        = any(array['VN'::text, 'VN2'::text, 'VN3'::text, 'VN4'::text, 'VNID'])
                    )
                    and d.week_start >= (d.week_start_current - 14)
                then 1
                else
                    case
                        when
                            starts_with(d.geo::text, 'ID'::text)
                            and d.week_start >= (d.week_start_current - 21)
                        then 1
                        else
                            case
                                when
                                    d.geo::text = 'TH'::text
                                    and d.week_start >= (d.week_start_current - 7)
                                then 1
                                else
                                    case
                                        when
                                            d.geo::text = 'MY'::text
                                            and d.week_start
                                            >= (d.week_start_current - 14)
                                        then 1
                                        else
                                            case
                                                when
                                                    d.geo::text = 'TH2'::text
                                                    and d.week_start
                                                    >= (d.week_start_current - 7)
                                                then 1
                                                else 0
                                            end
                                    end
                            end
                    end
            end as inrangeforecast_fr,
            case
                when
                    (
                        d.geo::text
                        = any(array['VN'::text, 'VN2'::text, 'VN3'::text, 'VN4'::text, 'VNID'::text])
                    )
                    and d.week_start >= (d.week_start_current - 15)
                then 1
                else
                    case
                        when
                            starts_with(d.geo::text, 'ID'::text)
                            and d.week_start >= (d.week_start_current - 28)
                        then 1
                        else
                            case
                                when
                                    d.geo::text = 'TH'::text
                                    and d.week_start >= (d.week_start_current - 17)
                                then 1
                                else
                                    case
                                        when
                                            d.geo::text = 'MY'::text
                                            and d.week_start
                                            >= (d.week_start_current - 15)
                                        then 1
                                        else
                                            case
                                                when
                                                    d.geo::text = 'TH2'::text
                                                    and d.week_start
                                                    >= (d.week_start_current - 17)
                                                then 1
                                                else 0
                                            end
                                    end
                            end
                    end
            end as inrangeforecast_rs,
            d.postback_status,
            case when lower(d.postback_status::text) = 'approved' then 1::bigint 
            	else 0::bigint
            	end as approved_postback
        from
            (
                select
                    cl_fresh.geo,
                    cl_fresh.org_id,
                    cl_fresh.lead_id,
                    cl_fresh.prod_id,
                    cl_fresh.prod_name,
                    cl_fresh.lead_status,
                    cl_fresh.lead_type,
                    cl_fresh.agc_id,
                    cl_fresh.province,
                    cl_fresh.district,
                    cl_fresh.subdistrict,
                    cl_fresh.subid1,
                    cl_fresh.user_defin_05,
                    cl_fresh.callinglist_id,
                    cl_fresh.agc_code,
                    cl_fresh.comment,
                    cl_fresh.assigned,
                    cl_fresh.createdate,
                    cl_fresh.modifydate,
                    cl_fresh.cp_id,
                    cl_fresh.affiliate_id,
                    cl_fresh.click_id,
                    cl_fresh.postback_status,
                    (
                        date_trunc(
                            'week'::text, cl_fresh.createdate + '1 day'::interval
                        )
                        - '1 day'::interval
                    )::date as week_start,
                    (
                        date_trunc('week'::text, current_date + '1 day'::interval)
                        - '1 day'::interval
                    )::date as week_start_current
                from cl_fresh
                where
                    lower(cl_fresh.name::text) not like '%test%'::text
                    and case
                        when
                            cl_fresh.lead_status = 4
                            or cl_fresh.lead_status = 5
                            and cl_fresh.assigned = 0
                        then 1
                        else 0
                    end
                    <> 1
                    and cl_fresh.modifydate::date >= '2024-01-01'::date
            ) d
        left join
            (
                select
                    a_1.so_id,
                    a_1.org_id,
                    a_1.geo,
                    a_1.cp_id,
                    a_1.lead_id,
                    a_1.amount,
                    a_1.payment_method,
                    a_1.status,
                    a_1.createdate,
                    a_1.creation_date,
                    a_1.validated_rn,
                    a_1.rn,
                    a_1.final_rn
                from
                    (
                        select
                            oso.so_id,
                            oso.org_id,
                            oso.geo,
                            oso.cp_id,
                            oso.lead_id,
                            oso.amount,
                            oso.payment_method,
                            oso.status,
                            oso.createdate,
                            oso.creation_date,
                            sum(
                                case
                                    when oso.status = any(array[43, 357])
                                    then 1
                                    else null::integer
                                end
                            ) over (partition by oso.lead_id) as validated_rn,
                            row_number() over (
                                partition by oso.lead_id order by oso.createdate desc
                            ) as rn,
                            case
                                when
                                    row_number() over (
                                        partition by oso.lead_id
                                        order by oso.createdate desc
                                    )
                                    = 1
                                    and sum(
                                        case
                                            when oso.status = any(array[43, 357])
                                            then 1
                                            else null::integer
                                        end
                                    ) over (partition by oso.lead_id)
                                    > 0
                                    and (oso.status <> all(array[43, 357]))
                                then 2::bigint
                                when
                                    row_number() over (
                                        partition by oso.lead_id
                                        order by oso.createdate desc
                                    )
                                    <> 1
                                    and (oso.status = any(array[43, 357]))
                                then 1::bigint
                                else
                                    row_number() over (
                                        partition by oso.lead_id
                                        order by oso.createdate desc
                                    )
                            end as final_rn
                        from od_sale_order oso
                        where oso.status <> 46
--                        and createdate::date >= '2024-04-01'::date
                    ) a_1
                where a_1.final_rn = 1
            ) a
            on a.lead_id = d.lead_id
            and a.geo::text = d.geo::text
        left join (
        select * 
        from od_do_new 
--        where createdate::date >= '2024-04-01'::date
        ) e on a.so_id = e.so_id and a.geo::text = e.geo::text
        left join bp_partner f on e.ffm_id = f.pn_id and e.geo::text = f.geo::text
        left join
            bp_warehouse j
            on e.warehouse_id = j.warehouse_id
            and e.geo::text = j.geo::text
        left join bp_partner k on e.carrier_id = k.pn_id and e.geo::text = k.geo::text
        left join bp_partner o on d.agc_id = o.pn_id and d.geo::text = o.geo::text
        left join
            (
                select
                    rrj_1.geo,
                    rrj_1.id,
                    rrj_1.org_id,
                    rrj_1.do_id,
                    rrj_1.do_code,
                    rrj_1.ffm_code,
                    rrj_1.so_id,
                    rrj_1.tracking_code,
                    rrj_1.ffm_id,
                    rrj_1.lastmile_id,
                    rrj_1.customer_id,
                    rrj_1.customer_name,
                    rrj_1.customer_phone,
                    rrj_1.customer_address,
                    rrj_1.package_products,
                    rrj_1.amountcod,
                    rrj_1.do_status,
                    rrj_1.ffm_status,
                    rrj_1.ffm_return_code,
                    rrj_1.ffm_reason,
                    rrj_1.ffm_reason_detail,
                    rrj_1.lastmile_status,
                    rrj_1.lastmile_return_code,
                    rrj_1.lastmile_reason,
                    rrj_1.lastmile_reason_detail,
                    rrj_1.agent_id,
                    rrj_1.assigned,
                    rrj_1.priority,
                    rrj_1.job_status,
                    rrj_1.job_sub_status,
                    rrj_1.job_reason,
                    rrj_1.job_sub_reason,
                    rrj_1.job_comment,
                    rrj_1.user_note,
                    rrj_1.total_call,
                    rrj_1.day_call,
                    rrj_1.createby,
                    rrj_1.createdate,
                    rrj_1.updateby,
                    rrj_1.updatedate,
                    rrj_1.status,
                    rrj_1.jobstatus_id,
                    rrj_1.fist_update_date,
                    rrj_1.fist_assigned_date,
                    rrj_1.next_call_time,
                    rrj_1.is_pre_delivery,
                    rrj_1.is_pre_delivered_before,
                    rrj_1.job_type
                from rc_rescue_job rrj_1
                where rrj_1.job_type = 1
            ) rrj
            on rrj.so_id = a.so_id
            and rrj.geo::text = a.geo::text
        left join
            or_user rcp on rrj.assigned = rcp.user_id and rrj.geo::text = rcp.geo::text
        left join
            (
                select
                    cf_synonym.geo, cf_synonym.type, cf_synonym.name, cf_synonym.value
                from cf_synonym
                where cf_synonym.type::text = 'lead status'::text
            ) g
            on d.lead_status = g.value
            and d.geo::text = g.geo::text
        left join
            (
                select
                    cf_synonym.geo, cf_synonym.type, cf_synonym.name, cf_synonym.value
                from cf_synonym
                where cf_synonym.type::text = 'sale order status'::text
            ) h
            on a.status = h.value
            and a.geo::text = h.geo::text
        left join
            (
                select
                    cf_synonym.geo, cf_synonym.type, cf_synonym.name, cf_synonym.value
                from cf_synonym
                where cf_synonym.type::text = 'delivery order status'::text
            ) b
            on e.status = b.value
            and e.geo::text = b.geo::text
        left join
            (
                select
                    cf_synonym.geo, cf_synonym.type, cf_synonym.name, cf_synonym.value
                from cf_synonym
                where cf_synonym.type::text = 'rescue status'::text
            ) rs
            on rrj.job_sub_status = rs.value
            and rrj.geo::text = rs.geo::text
        left join
            (
                select
                    cf_synonym.geo, cf_synonym.type, cf_synonym.name, cf_synonym.value
                from cf_synonym
                where cf_synonym.type::text = 'rescue reason'::text
            ) rss
            on rrj.job_sub_reason = rss.value
            and rrj.geo::text = rss.geo::text
        left join or_user p on p.user_id = d.assigned and p.geo::text = d.geo::text
        left join
            lc_province l
            on l.prv_id::character varying::text = d.province::character varying::text
            and l.geo::text = d.geo::text
        left join
            lc_region reg on l.region_id = reg.region_id and l.geo::text = reg.geo::text
        left join
            lc_district m
            on m.dt_id::character varying::text = d.district::character varying::text
            and m.geo::text = d.geo::text
        left join
            lc_subdistrict n
            on n.sdt_id::character varying::text
            = d.subdistrict::character varying::text
            and n.geo::text = d.geo::text
        left join cp_campaign q on q.cp_id = d.cp_id and q.geo::text = d.geo::text
        left join
            cl_calling_list r
            on r.callinglist_id = d.callinglist_id
            and r.geo::text = d.geo::text
        left join pd_product pd on d.prod_id = pd.prod_id and d.geo::text = pd.geo::text
        left join
            (
                select oac_1.max_po, oac_1.payout, oac_1.transaction_id
                from ods_affscale_conversion oac_1
            ) oac
            on oac.transaction_id = d.click_id::text
            and d.lead_type::text = 'A'::text
        left join
            cdm_dim_product_cat cat
            on cat.product_name = d.prod_name::text
            and cat.geo = d.geo::text
        left join
            (
                with
                    temp_so as (
                        select
                            osi_1.oi_id,
                            osi_1.so_id,
                            osi_1.geo,
                            osi_1.quantity,
                            osi_1.item_no,
                            osi_1.prod_id,
                            pp.name as product_name,
                            row_number() over (
                                partition by osi_1.so_id, osi_1.geo
                                order by osi_1.quantity desc
                            ) as item_no_new
                        from od_so_item osi_1
                        left join
                            pd_product pp
                            on osi_1.prod_id = pp.prod_id
                            and osi_1.geo::text = pp.geo::text
                    )
                select
                    temp_so.so_id,
                    temp_so.geo,
                    max(
                        case
                            when temp_so.item_no_new = 1
                            then temp_so.product_name
                            else null::character varying
                        end::text
                    ) as product1,
                    sum(temp_so.quantity) as no_quantity,
                    count(distinct temp_so.prod_id) as no_product
                from temp_so
                group by temp_so.so_id, temp_so.geo
                order by temp_so.so_id desc
            ) osi
            on a.so_id = osi.so_id
            and a.geo::text = osi.geo::text
        left join
            (
                select
                    osi_1.geo,
                    osi_1.so_id,
                    max(osi_1.createdate) as createdate,
                    max(
                        case
                            when osi_1.item_no = 1
                            then pp.name
                            else null::character varying
                        end::text
                    ) as product_no1,
                    max(
                        case
                            when osi_1.item_no = 1
                            then osi_1.quantity
                            else null::integer
                        end
                    ) as quantity_no1,
                    max(
                        case
                            when osi_1.item_no = 2
                            then pp.name
                            else null::character varying
                        end::text
                    ) as product_no2,
                    max(
                        case
                            when osi_1.item_no = 2
                            then osi_1.quantity
                            else null::integer
                        end
                    ) as quantity_no2,
                    max(
                        case
                            when osi_1.item_no = 3
                            then pp.name
                            else null::character varying
                        end::text
                    ) as product_no3,
                    max(
                        case
                            when osi_1.item_no = 3
                            then osi_1.quantity
                            else null::integer
                        end
                    ) as quantity_no3,
                    max(
                        case
                            when osi_1.item_no = 4
                            then pp.name
                            else null::character varying
                        end::text
                    ) as product_no4,
                    max(
                        case
                            when osi_1.item_no = 4
                            then osi_1.quantity
                            else null::integer
                        end
                    ) as quantity_no4
                from od_so_item osi_1
                left join
                    pd_product pp
                    on osi_1.prod_id = pp.prod_id
                    and osi_1.geo::text = pp.geo::text
                group by osi_1.geo, osi_1.so_id
            ) prod
            on e.so_id = prod.so_id
            and e.geo::text = prod.geo::text
        where lower(q.name::text) not like '%test%'::text or q.name is null
    ),
    rev_group_daily as (
        select
            raw_1.geo,
            raw_1.date_used,
            sum(
                case
                    when
                        lower(raw_1.leadstatus::text) = 'approved'::text
                        and (
                            lower(raw_1.orderstatus::text)
                            = any(array['validated'::text, 'delay'::text])
                        )
                    then raw_1.amount
                    else null::numeric
                end
            ) as daily_rev
        from raw raw_1
        group by raw_1.geo, raw_1.date_used
    ),
    rev_group as (
        select
            raw_1.geo,
            date_part('month'::text, raw_1.date_used) as month,
            sum(
                case
                    when lower(raw_1.deliverystatus::text) = 'delivered'::text
                    then raw_1.amount::double precision / der_1.exchange
                    when lower(raw_1.deliverystatus::text) is null
                    then null::double precision
                    else 0::double precision
                end
            ) as rev_by_geo
        from raw raw_1
        left join
            dim_exchange_rate der_1
            on case when raw_1.geo = 'VNID' then 'VN' else raw_1.geo end = der_1.geo
            and raw_1.date_used >= der_1.started_date
            and raw_1.date_used <= der_1.ending_date
        group by raw_1.geo, (date_part('month'::text, raw_1.date_used))
    ),
    rev_all_geos as (
        select
            date_part('month'::text, raw_1.date_used) as month,
            sum(
                case
                    when lower(raw_1.deliverystatus::text) = 'delivered'::text
                    then raw_1.amount::double precision / der_1.exchange
                    when lower(raw_1.deliverystatus::text) is null
                    then null::double precision
                    else 0::double precision
                end
            ) as rev_all_geos
        from raw raw_1
        left join
            dim_exchange_rate der_1
            on case when raw_1.geo = 'VNID' then 'VN' else raw_1.geo end = der_1.geo
            and raw_1.date_used >= der_1.started_date
            and raw_1.date_used <= der_1.ending_date
        group by (date_part('month'::text, raw_1.date_used))
    )
select
    raw.geo,
    raw.lead_date,
    raw.leadid,
    raw.cpl_lead,
    case when raw.cpl_lead > 0 then raw.cpl_lead
         when raw.date_used >= '2023-07-01' then approved_postback
         when lower(raw.orderstatus::text) = any(array['validated'::text, 'delay'::text]) then 1::bigint  --  validated
         else 0::bigint 
    end as validated_final,
    raw.leadtypename,
    raw.offer_product,
    raw.package_name,
    raw.product1,
    raw.sale_camp,
    raw.fin_camp,
    raw.product_no1,
    raw.quantity_no1,
    raw.product_no2,
    raw.quantity_no2,
    raw.product_no3,
    raw.quantity_no3,
    raw.product_no4,
    raw.quantity_no4,
    raw.total_quantity,
    case
        when raw.leadtype::text = 'A'::text then raw.affiliate_id else raw.sourcename
    end as source,
    raw.pub,
    case
        when lower(raw.orderstatus::text) = 'trash'::text
        then 0::double precision
        when lower(raw.offer_product::text) like '%cpl%'::text
        then raw.payout
        when lower(raw.postback_status::text) = 'approved'::text
--        when lower(raw.orderstatus::text) = any(array['validated'::text, 'delay'::text])
        then raw.payout
        else 0::double precision
    end as mkt_cost_usd,
    case
        when lower(raw.orderstatus::text) = 'trash'::text
        then 0::double precision
        when lower(raw.offer_product::text) like '%cpl%'::text
        then raw.payout * der.exchange
        when lower(raw.postback_status::text) = 'approved'::text
--        when lower(raw.orderstatus::text) = any(array['validated'::text, 'delay'::text])
        then raw.payout * der.exchange
        else 0::double precision
    end as mkt_cost,
    case
        when lower(raw.orderstatus::text) = 'trash'::text
        then 0::double precision
        when lower(raw.offer_product::text) like '%cpl%'::text
        then raw.payout * der.exchange
        when lower(raw.postback_status::text) = 'approved'::text
--        when lower(raw.orderstatus::text) = any(array['validated'::text, 'delay'::text])
        then raw.max_po * der.exchange
        else 0::double precision
    end as max_po,
    raw.so_date,
    raw.agname,
    raw.agent_type,
    raw.leadstatus,
    raw.do_createdate as validated_date,
    raw.date_used,
    raw.aging,
    raw.warehousename,
    date_part(
        'days'::text,
        date_trunc('month'::text, raw.date_used::timestamp with time zone)
        + '1 mon -1 days'::interval
    ) as days_in_month,
    raw.orderstatus,
    raw.do_createdate,
    raw.soid,
    raw.ffmname,
    raw.lastmilename,
    raw.region,
    raw.province,
    raw.district,
    raw.subdistrict,
    raw.paymentmethod,
    raw.rescue_createdate,
    raw.agent_rescue,
    raw.rescue_status,
    raw.lastmile_return_code,
    raw.deliverystatus,
    raw.status_fn,
    der.exchange,
    raw.reason as lead_reason,
    raw.rescue_reason,
    case
        when
            lower(raw.leadstatus::text) = 'approved'::text
            and (
                lower(raw.orderstatus::text)
                = any(array['validated'::text, 'delay'::text])
            )
        then raw.amount
        else null::numeric
    end as revenue_act,
    case
        when der.exchange = 0::double precision
        then 0::double precision
        when lower(raw.deliverystatus::text) is null
        then null::double precision
        else raw.amount::double precision / der.exchange
    end as revenue_act_usd,
    rgd.daily_rev,
    case
        when der.exchange = 0::double precision
        then 0::double precision
        else rgd.daily_rev::double precision / der.exchange
    end as daily_rev_usd,
    rg.rev_by_geo,
    rag.rev_all_geos,
    case
        when rag.rev_all_geos = 0::double precision
        then 0::double precision
        else rg.rev_by_geo / rag.rev_all_geos
    end as rev_portion,
    case
        when raw.leadtypename = 'Resell'::text
        then
            case
                when lower(raw.status_fn) = 'delivered'::text
                then 1::double precision
                when lower(raw.status_fn) = 'intransit'::text
                then itdr.ins_to_del
                when
                    lower(raw.status_fn) is null
                    and (
                        lower(raw.orderstatus::text)
                        = any(array['validated'::text, 'delay'::text])
                    )
                then itdr.ins_to_del
                when lower(raw.status_fn) is null
                then null::double precision
                else 0::double precision
            end
        when raw.leadtypename = 'Fresh'::text
        then
            case
                when lower(raw.status_fn) = 'delivered'::text
                then 1::double precision
                when lower(raw.status_fn) = 'intransit'::text
                then itdf.ins_to_del
                when
                    lower(raw.status_fn) is null
                    and (
                        lower(raw.orderstatus::text)
                        = any(array['validated'::text, 'delay'::text])
                    )
                then itdf.ins_to_del
                when lower(raw.status_fn) is null
                then null::double precision
                else 0::double precision
            end
        else null::double precision
    end as dr,
    raw.postback_status,
    raw.approved_postback
from raw
left join rev_group_daily rgd on raw.geo = rgd.geo and raw.date_used = rgd.date_used
left join
    rev_group rg
    on raw.geo = rg.geo
    and date_part('month'::text, raw.date_used) = rg.month
left join rev_all_geos rag on date_part('month'::text, raw.date_used) = rag.month
left join
    dim_exchange_rate der
    on case when raw.geo = 'VNID' then 'VN' else raw.geo end = der.geo
    and raw.date_used >= der.started_date
    and raw.date_used <= der.ending_date
left join
    ins_to_del_resell itdr
    on raw.geo = itdr.geo
    and raw.aging = itdr.aging
    and raw.sale_camp::text = itdr.campaign
    and raw.product1 = itdr.product
left join
    ins_to_del_fresh itdf
    on raw.geo = itdf.geo
    and raw.aging = itdf.aging
    and raw.sale_camp::text = itdf.campaign
    and raw.offer_product::text = itdf.product
    and raw.affiliate_id::text = itdf.pub