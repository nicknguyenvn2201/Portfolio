-- dareport.bd_master source

CREATE MATERIALIZED VIEW dareport.bd_master
WITH(autovacuum_enabled=true)
TABLESPACE pg_default
AS WITH rockbay AS (
         SELECT cl_fresh_1.createdate,
            cl_fresh_1.lead_id,
            cl_fresh_1.geo,
                CASE
                    WHEN cl_fresh_1.geo::text ^@ 'TH'::text THEN 'TH'::character varying
                    WHEN cl_fresh_1.geo::text ^@ 'VN'::text THEN 'VN'::character varying
                    WHEN cl_fresh_1.geo::text ^@ 'ID'::text THEN 'ID'::character varying
                    WHEN cl_fresh_1.geo::text ^@ 'MY'::text THEN 'MY'::character varying
                    WHEN cl_fresh_1.geo::text ^@ 'PH'::text THEN 'PH'::character varying
                    ELSE cl_fresh_1.geo
                END::text AS country_code,
            cl_fresh_1.postback_status,
            cl_fresh_1.click_id,
            cl_fresh_1.prod_name,
            'AFS'::text AS agc_code,
            cl_fresh_1.lead_type,
            cl_fresh_1.lead_status,
            cl_fresh_1.agc_id,
            cl_fresh_1.org_id,
            cl_fresh_1.cp_id,
            cl_fresh_1.affiliate_id,
            cl_fresh_1.subid1,
            cl_fresh_1.province,
            cl_fresh_1.actual_call
           FROM rkb.cl_fresh cl_fresh_1
          WHERE cl_fresh_1.postback_status::text = 'approved'::text AND cl_fresh_1.lead_type::text = 'A'::text AND lower(cl_fresh_1.name::text) !~~ '%test%'::text AND cl_fresh_1.createdate >= '2022-01-01 00:00:00'::timestamp without time zone AND
                CASE
                    WHEN cl_fresh_1.lead_status = 4 OR cl_fresh_1.lead_status = 5 AND cl_fresh_1.assigned = 0 THEN 1
                    ELSE 0
                END <> 1
        ), keitaro AS (
         SELECT afs.transaction_id,
            ktr.cost AS traffic_cost
           FROM fact_keitaro_data ktr
             JOIN fct_affscale_network_conversion afs ON ktr.sub_id = afs.aff_click_id
        ), cte_raw AS (
         SELECT cl_fresh.createdate::date AS createdate,
                CASE
                    WHEN cl_fresh.createdate::date < '2024-06-01'::date AND cl_fresh.geo::text = 'VNID'::text THEN 16
                    WHEN cl_fresh.geo::text ^@ 'VN'::text THEN 4
                    WHEN cl_fresh.geo::text ^@ 'ID'::text THEN 9
                    WHEN cl_fresh.geo::text ^@ 'MY'::text THEN 11
                    WHEN cl_fresh.geo::text ^@ 'PH'::text THEN 14
                    WHEN cl_fresh.geo::text ^@ 'TH'::text THEN 10
                    ELSE cl_fresh.org_id
                END AS geo_id,
            date_part('week'::text, cl_fresh.createdate + '1 day'::interval) AS lead_week,
            date_part('month'::text, cl_fresh.createdate) AS lead_month,
            date_part('year'::text, cl_fresh.createdate) AS lead_year,
                CASE
                    WHEN cl_fresh.createdate::date = '2022-01-01'::date THEN 4::double precision
                    WHEN cl_fresh.createdate::date = '2021-10-01'::date OR cl_fresh.createdate::date = '2021-10-02'::date THEN 3::double precision
                    WHEN cl_fresh.createdate::date = '2022-04-01'::date OR cl_fresh.createdate::date = '2022-04-02'::date THEN 1::double precision
                    ELSE date_part('quarter'::text, cl_fresh.createdate)
                END AS lead_quarter,
            date_part('week'::text, CURRENT_DATE + '1 day'::interval) AS current_week,
            (date_trunc('week'::text, cl_fresh.createdate + '1 day'::interval) - '1 day'::interval)::date AS week_start,
            (date_trunc('week'::text, CURRENT_DATE + '1 day'::interval) - '1 day'::interval)::date AS week_start_current,
            cl_fresh.lead_id,
            cl_fresh.lead_type,
            cl_fresh.geo,
            cl_fresh.country_code,
                CASE
                    WHEN cl_fresh.prod_name IS NULL THEN 'No offer'::character varying
                    ELSE cl_fresh.prod_name
                END AS offer,
            COALESCE(
                CASE
                    WHEN COALESCE(p.shortname, cl_fresh.agc_code)::text = ANY (ARRAY['AFS'::character varying::text, 'OFP'::character varying::text]) THEN cl_fresh.affiliate_id
                    ELSE COALESCE(p.shortname, cl_fresh.agc_code, 'LOYAL CUSTOMER'::character varying)
                END, 'No network'::character varying) AS network,
                CASE
                    WHEN COALESCE(p.shortname, cl_fresh.agc_code)::text = ANY (ARRAY['AFS'::character varying::text, 'OFP'::character varying::text]) THEN cl_fresh.subid1
                    ELSE cl_fresh.affiliate_id
                END AS sub,
            cl_fresh.lead_status,
            cf_lead.lead_status AS cf_lead_status,
            cf_so.lead_status AS cf_so_lead_status,
            oso.amount AS oso_amount,
                CASE oso.payment_method
                    WHEN 1 THEN 'COD'::text
                    WHEN 2 THEN 'Bank tranfer'::text
                    ELSE NULL::text
                END AS paymentmethod,
            osi.quantity,
            cf_do.lead_status AS cf_do_lead_status,
            cl_fresh.postback_status,
                CASE
                    WHEN lower(cl_fresh.prod_name::text) ~~ '%vip%'::text THEN cc.name
                    WHEN lower(cl_fresh.prod_name::text) ~~ '%prosta%id'::text THEN 'Fresh HC'::character varying
                    WHEN lower(cl_fresh.prod_name::text) ~~ '%duramax%th'::text THEN 'Fresh ME'::character varying
                    ELSE cc.name
                END AS sale_campaign,
            cl_fresh.agc_id,
            pn.shortname AS carrier,
            oac.payout,
            oac.max_po,
            oac.advertiser,
            cl_fresh.province AS province_id,
            rate.exchange AS exchange_rate,
            cl_fresh.actual_call,
            ktr.traffic_cost
           FROM ( SELECT cl_fresh_1.createdate,
                    cl_fresh_1.lead_id,
                    cl_fresh_1.geo,
                        CASE
                            WHEN cl_fresh_1.geo::text ^@ 'TH'::text THEN 'TH'::character varying
                            WHEN cl_fresh_1.geo::text ^@ 'VN'::text THEN 'VN'::character varying
                            WHEN cl_fresh_1.geo::text ^@ 'ID'::text THEN 'ID'::character varying
                            WHEN cl_fresh_1.geo::text ^@ 'MY'::text THEN 'MY'::character varying
                            WHEN cl_fresh_1.geo::text ^@ 'PH'::text THEN 'PH'::character varying
                            ELSE cl_fresh_1.geo
                        END::text AS country_code,
                    cl_fresh_1.postback_status,
                    cl_fresh_1.click_id,
                    cl_fresh_1.prod_name,
                    cl_fresh_1.agc_code,
                    cl_fresh_1.org_id,
                    cl_fresh_1.lead_type,
                    cl_fresh_1.lead_status,
                    cl_fresh_1.agc_id,
                    cl_fresh_1.cp_id,
                    cl_fresh_1.affiliate_id,
                    cl_fresh_1.subid1,
                    cl_fresh_1.province,
                    cl_fresh_1.actual_call
                   FROM cl_fresh_temp cl_fresh_1
                  WHERE cl_fresh_1.lead_type::text = 'A'::text AND lower(cl_fresh_1.name::text) !~~ '%test%'::text AND cl_fresh_1.createdate >= (CURRENT_DATE - 1000) AND
                        CASE
                            WHEN cl_fresh_1.lead_status = 4 OR cl_fresh_1.lead_status = 5 AND cl_fresh_1.assigned = 0 THEN 1
                            ELSE 0
                        END <> 1
                UNION ALL
                 SELECT rockbay.createdate,
                    rockbay.lead_id,
                    rockbay.geo,
                    rockbay.country_code,
                    rockbay.postback_status,
                    rockbay.click_id,
                    rockbay.prod_name,
                    rockbay.agc_code,
                    rockbay.org_id,
                    rockbay.lead_type,
                    rockbay.lead_status,
                    rockbay.agc_id,
                    rockbay.cp_id,
                    rockbay.affiliate_id,
                    rockbay.subid1,
                    rockbay.province,
                    rockbay.actual_call
                   FROM rockbay) cl_fresh
             LEFT JOIN ( SELECT a_1.so_id,
                    a_1.org_id,
                    a_1.geo,
                    a_1.cp_id,
                    a_1.lead_id,
                    a_1.amount,
                    a_1.payment_method,
                    a_1.status,
                    a_1.createdate,
                    a_1.creation_date,
                    a_1.validated_rn,
                    a_1.rn,
                    a_1.final_rn
                   FROM ( SELECT oso_1.so_id,
                            oso_1.org_id,
                            oso_1.geo,
                            oso_1.cp_id,
                            oso_1.lead_id,
                            oso_1.amount,
                            oso_1.payment_method,
                            oso_1.status,
                            oso_1.createdate,
                            oso_1.creation_date,
                            sum(
                                CASE
                                    WHEN oso_1.status = ANY (ARRAY[43, 357]) THEN 1
                                    ELSE NULL::integer
                                END) OVER (PARTITION BY oso_1.lead_id) AS validated_rn,
                            row_number() OVER (PARTITION BY oso_1.lead_id ORDER BY oso_1.createdate DESC) AS rn,
                                CASE
                                    WHEN row_number() OVER (PARTITION BY oso_1.lead_id ORDER BY oso_1.createdate DESC) = 1 AND sum(
                                    CASE
WHEN oso_1.status = ANY (ARRAY[43, 357]) THEN 1
ELSE NULL::integer
                                    END) OVER (PARTITION BY oso_1.lead_id) > 0 AND (oso_1.status <> ALL (ARRAY[43, 357])) THEN 2::bigint
                                    WHEN row_number() OVER (PARTITION BY oso_1.lead_id ORDER BY oso_1.createdate DESC) <> 1 AND (oso_1.status = ANY (ARRAY[43, 357])) THEN 1::bigint
                                    ELSE row_number() OVER (PARTITION BY oso_1.lead_id ORDER BY oso_1.createdate DESC)
                                END AS final_rn
                           FROM od_sale_order_temp oso_1
                          WHERE oso_1.status <> 46) a_1
                  WHERE a_1.final_rn = 1) oso ON cl_fresh.lead_id = oso.lead_id AND oso.geo::text = cl_fresh.geo::text
             LEFT JOIN od_do_new_temp odn ON odn.so_id = oso.so_id AND oso.geo::text = odn.geo::text
             LEFT JOIN ( SELECT od_so_item.geo,
                    od_so_item.so_id,
                    sum(od_so_item.quantity) AS quantity
                   FROM od_so_item
                  GROUP BY od_so_item.geo, od_so_item.so_id) osi ON oso.so_id = osi.so_id AND oso.geo::text = osi.geo::text
             LEFT JOIN ( SELECT cs.geo,
                    cs.synonym_id,
                    cs.type,
                    cs.name,
                    cs.value,
                    cs.dscr,
                    cs.type_id,
                    cs.localized_name,
                    cs.name AS lead_status
                   FROM cf_synonym cs
                  WHERE cs.type::text = 'lead status'::text) cf_lead ON cl_fresh.lead_status = cf_lead.value AND cl_fresh.geo::text = cf_lead.geo::text
             LEFT JOIN ( SELECT cs.geo,
                    cs.synonym_id,
                    cs.type,
                    cs.name,
                    cs.value,
                    cs.dscr,
                    cs.type_id,
                    cs.localized_name,
                    cs.name AS lead_status
                   FROM cf_synonym cs
                  WHERE cs.type::text = 'sale order status'::text) cf_so ON oso.status = cf_so.value AND cl_fresh.geo::text = cf_so.geo::text
             LEFT JOIN ( SELECT cs.geo,
                    cs.synonym_id,
                    cs.type,
                    cs.name,
                    cs.value,
                    cs.dscr,
                    cs.type_id,
                    cs.localized_name,
                    cs.name AS lead_status
                   FROM cf_synonym cs
                  WHERE cs.type::text = 'delivery order status'::text) cf_do ON odn.status = cf_do.value AND cl_fresh.geo::text = cf_do.geo::text
             LEFT JOIN bp_partner p ON cl_fresh.agc_id = p.pn_id AND p.geo::text = cl_fresh.geo::text
             LEFT JOIN bp_partner pn ON pn.pn_id = odn.carrier_id AND pn.geo::text = odn.geo::text
             LEFT JOIN cp_campaign cc ON cl_fresh.cp_id = cc.cp_id AND cl_fresh.geo::text = cc.geo::text
             LEFT JOIN keitaro ktr ON ktr.transaction_id = cl_fresh.click_id::text
             LEFT JOIN ( SELECT oac_1.createdate,
                    oac_1.lead_id,
                    oac_1.affiliate,
                    oac_1.sub_id1,
                    oac_1.offer,
                    oac_1.max_po,
                    oac_1.payout,
                    oac_1.profit,
                    oac_1.transaction_id,
                    oac_1.geo,
                    oac_1.advertiser
                   FROM ods_affscale_conversion oac_1) oac ON cl_fresh.click_id::text = oac.transaction_id
             LEFT JOIN dim_exchange_rate rate ON rate.geo = "left"(cl_fresh.geo::text, 2) AND cl_fresh.createdate::date >= rate.started_date::date AND cl_fresh.createdate::date <= rate.ending_date::date
          WHERE cl_fresh.lead_type::text = 'A'::text AND (lower(cc.name::text) <> 'cptest'::text AND lower(cc.name::text) <> 'cp_test'::text OR cc.name IS NULL)
        ), cte_lead_traffics AS (
         SELECT lead_traffics.affiliate_id AS network,
            lead_traffics.traffic,
            lead_traffics.applied_from_date::date AS started_date,
            lead_traffics.applied_to_date::date AS ending_date
           FROM lead_traffics
          WHERE lead_traffics.applied_from_date::date <= lead_traffics.applied_to_date::date
        ), cte_ar_mrps AS (
         SELECT ar_mrps.affiliate_id AS network,
            ar_mrps.org_id,
            ar_mrps.offer_id AS product_name,
                CASE
                    WHEN lower(ar_mrps.sub_id) = '*'::text THEN ''::text
                    WHEN lower(ar_mrps.sub_id) = ''::text THEN 'blank'::text
                    ELSE ar_mrps.sub_id
                END AS sub_id,
            ar_mrps.ar_mrp,
            ar_mrps.applied_from_date::date AS started_date,
            ar_mrps.applied_to_date::date AS ending_date,
                CASE
                    WHEN lower(ar_mrps.sub_id) = '*'::text THEN concat(ar_mrps.affiliate_id, '_', ar_mrps.offer_id)
                    WHEN lower(ar_mrps.sub_id) = ''::text THEN concat(ar_mrps.affiliate_id, '_', 'blank', '_', ar_mrps.offer_id)
                    ELSE concat(ar_mrps.affiliate_id, '_', ar_mrps.sub_id, '_', ar_mrps.offer_id)
                END AS target_key
           FROM ar_mrps
        ), cte_lead_mrps AS (
         SELECT lead_mrps.affiliate_id AS network,
            lead_mrps.org_id,
            lead_mrps.offer_id AS product_name,
                CASE
                    WHEN lower(lead_mrps.sub_id) = '*'::text THEN ''::text
                    WHEN lower(lead_mrps.sub_id) = ''::text THEN 'blank'::text
                    ELSE lead_mrps.sub_id
                END AS sub_id,
            lead_mrps.lead_mrp,
            lead_mrps.applied_from_date::date AS started_date,
            lead_mrps.applied_to_date::date AS ending_date,
                CASE
                    WHEN lower(lead_mrps.sub_id) = '*'::text THEN concat(lead_mrps.affiliate_id, '_', lead_mrps.offer_id)
                    WHEN lower(lead_mrps.sub_id) = ''::text THEN concat(lead_mrps.affiliate_id, '_', 'blank', '_', lead_mrps.offer_id)
                    ELSE concat(lead_mrps.affiliate_id, '_', lead_mrps.sub_id, '_', lead_mrps.offer_id)
                END AS target_key
           FROM lead_mrps
        ), cte_group_raw AS (
         SELECT cte_raw.createdate,
            cte_raw.lead_week,
            cte_raw.lead_month,
            cte_raw.lead_year,
            cte_raw.current_week,
            cte_raw.week_start,
            cte_raw.week_start_current,
            cte_raw.geo,
            cte_raw.country_code,
            cte_raw.offer,
            cte_raw.network,
            cte_raw.province_id,
            cte_raw.advertiser,
            dim_pc."FIN camp" AS category,
                CASE
                    WHEN (cte_raw.network::text = ANY (ARRAY['EW'::character varying::text, 'AT'::character varying::text, 'ADT'::character varying::text, 'ABT'::character varying::text, 'ARB'::character varying::text, 'CSL'::character varying::text, 'MKR'::character varying::text, 'XXX'::character varying::text, 'PFC'::character varying::text, 'ORG'::character varying::text, 'ORG2'::character varying::text, 'PIB'::character varying::text, 'MH'::character varying::text, 'MP'::character varying::text, 'IGO'::character varying::text, 'VIC'::character varying::text, 'ODS'::character varying::text, 'DAT'::character varying::text, 'VAL'::character varying::text, 'MIR'::character varying::text, 'NGN'::character varying::text, 'WIL'::character varying::text, 'PD'::character varying::text, 'CTR'::character varying::text, 'U_DOMA'::character varying::text, 'ABG'::character varying::text])) OR cte_raw.network::text = 'U_RUS'::text AND cte_raw.geo::text = 'TH'::text OR cte_raw.sub IS NULL THEN 'No PubID'::character varying
                    WHEN cte_raw.sub::text = ''::text THEN 'blank'::character varying
                    ELSE cte_raw.sub
                END AS pub,
            cte_raw.sale_campaign,
            cte_raw.carrier,
            cte_raw.agc_id,
            cte_raw.paymentmethod,
            sum(cte_raw.quantity) AS validated_qty,
            gm.tax_rate,
            gm.tele_rate,
            gm.commission_rate,
            gm.bd_comm_rate,
            uc.unit_cost,
            lc.ffm_fee,
            lc.lm_fee,
            lc.return_rate,
            lc.cod_rate,
            lc.portion,
                CASE
                    WHEN cddlt.bd_manager IS NULL THEN 'Others'::text
                    ELSE cddlt.bd_manager
                END AS manager,
            cdadtv."AOV_TARGET",
            dfudt."AOV_MRP" AS aov_target_2,
            cdadtv."DR_TARGET",
            cdadtv."Daily_approved_Target",
            cdart.estimate_daily_lead AS target_tracking_estimate_daily_lead,
            cdart.daily_approved_lead AS target_tracking_daily_approved_lead,
            cdart.daily_delivered_lead AS target_tracking_daily_delivered_lead,
            cdart.aff_revenue_target,
            cdartbg.aff_revenue_target_by_geo,
            COALESCE(dim_mkt_1.mkt_expense_target, dim_mkt.mkt_expense_target, dim_mkt_2.mkt_expense_target) AS mkt_expense_target,
                CASE
                    WHEN cte_raw.geo::text ^@ 'VN'::text AND cte_raw.week_start >= (cte_raw.week_start_current - 14) THEN 1
                    WHEN cte_raw.geo::text ^@ 'ID'::text AND cte_raw.week_start >= (cte_raw.week_start_current - 21) THEN 1
                    WHEN cte_raw.geo::text ^@ 'TH'::text AND cte_raw.week_start >= (cte_raw.week_start_current - 7) THEN 1
                    WHEN cte_raw.geo::text ^@ 'PH'::text AND cte_raw.week_start >= (cte_raw.week_start_current - 7) THEN 1
                    WHEN cte_raw.geo::text ^@ 'MY'::text AND cte_raw.week_start >= (cte_raw.week_start_current - 14) THEN 1
                    ELSE 0
                END AS inrangeforecast,
            count(DISTINCT cte_raw.lead_id) AS total_lead,
            count(DISTINCT
                CASE
                    WHEN lower(cte_raw.cf_lead_status::text) = ANY (ARRAY['trash'::text, 'duplicated'::text]) THEN cte_raw.lead_id
                    ELSE NULL::bigint
                END) AS trash,
            count(DISTINCT
                CASE
                    WHEN cte_raw.lead_status = 2 THEN cte_raw.lead_id
                    ELSE NULL::bigint
                END) AS approved,
            count(DISTINCT
                CASE
                    WHEN cte_raw.lead_status = ANY (ARRAY[2, 3, 8, 9, 14]) THEN cte_raw.lead_id
                    ELSE 0::bigint
                END) AS e_approved,
            count(DISTINCT
                CASE
                    WHEN cte_raw.lead_status = 2 AND (cte_raw.postback_status IS NULL OR cte_raw.postback_status::text = 'approved'::text) THEN cte_raw.lead_id
                    ELSE NULL::bigint
                END) AS approved_pb,
            count(DISTINCT
                CASE
                    WHEN cte_raw.lead_status = 3 THEN cte_raw.lead_id
                    ELSE NULL::bigint
                END) AS rejected,
            count(DISTINCT
                CASE
                    WHEN cte_raw.lead_status = ANY (ARRAY[2, 3, 8, 9, 14]) THEN cte_raw.lead_id
                    ELSE NULL::bigint
                END) AS contactable,
            count(DISTINCT
                CASE
                    WHEN cte_raw.lead_status = ANY (ARRAY[6, 7, 10, 11]) THEN cte_raw.lead_id
                    ELSE NULL::bigint
                END) AS uncall,
            count(DISTINCT
                CASE
                    WHEN cte_raw.lead_status = 2 AND (lower(cte_raw.cf_so_lead_status::text) = ANY (ARRAY['validated'::text, 'delay'::text])) THEN cte_raw.lead_id
                    ELSE NULL::bigint
                END) AS validated,
            count(DISTINCT
                CASE
                    WHEN cte_raw.postback_status::text = 'approved'::text THEN cte_raw.lead_id
                    ELSE NULL::bigint
                END) AS total_approved_postback,
            count(DISTINCT
                CASE
                    WHEN (lower(cte_raw.cf_so_lead_status::text) = ANY (ARRAY['validated'::text, 'delay'::text])) AND (cte_raw.postback_status::text = ANY (ARRAY['pending_postback'::character varying::text, 'pending_pb'::character varying::text])) THEN cte_raw.lead_id
                    ELSE NULL::bigint
                END) AS total_pending_postback,
            sum(
                CASE
                    WHEN cte_raw.lead_status = 2 AND (lower(cte_raw.cf_so_lead_status::text) = ANY (ARRAY['validated'::text, 'delay'::text])) THEN cte_raw.oso_amount
                    ELSE NULL::numeric
                END) AS amt_validated,
            sum(
                CASE
                    WHEN cte_raw.lead_status = 2 AND (lower(cte_raw.cf_so_lead_status::text) = ANY (ARRAY['validated'::text, 'delay'::text])) AND (cte_raw.postback_status IS NULL OR cte_raw.postback_status::text = 'approved'::text) THEN cte_raw.oso_amount
                    ELSE NULL::numeric
                END) AS amt_validated_pb,
            count(DISTINCT
                CASE
                    WHEN cte_raw.lead_status = 2 AND (lower(cte_raw.cf_so_lead_status::text) = ANY (ARRAY['validated'::text, 'delay'::text])) AND (lower(cte_raw.cf_do_lead_status::text) = ANY (ARRAY['delivered'::text, 'refund'::text])) THEN cte_raw.lead_id
                    ELSE NULL::bigint
                END) AS delivered,
            sum(
                CASE
                    WHEN lower(cte_raw.cf_do_lead_status::text) = ANY (ARRAY['returned'::text, 'delivered'::text, 'returning'::text, 'cancel'::text, 'refund'::text]) THEN 1
                    ELSE 0
                END) AS finalized_do,
            count(DISTINCT
                CASE
                    WHEN cte_raw.lead_status = 2 AND (lower(cte_raw.cf_so_lead_status::text) = ANY (ARRAY['validated'::text, 'delay'::text])) AND (lower(cte_raw.cf_do_lead_status::text) = ANY (ARRAY['delivered'::text, 'refund'::text])) AND (cte_raw.postback_status IS NULL OR cte_raw.postback_status::text = 'approved'::text) THEN cte_raw.lead_id
                    ELSE NULL::bigint
                END) AS delivered_pb,
            sum(
                CASE
                    WHEN cte_raw.lead_status = 2 AND (lower(cte_raw.cf_so_lead_status::text) = ANY (ARRAY['validated'::text, 'delay'::text])) AND (lower(cte_raw.cf_do_lead_status::text) = ANY (ARRAY['delivered'::text, 'refund'::text])) THEN cte_raw.oso_amount
                    ELSE NULL::numeric
                END) AS amt_delivered,
            sum(
                CASE
                    WHEN cte_raw.lead_status = 2 AND (lower(cte_raw.cf_so_lead_status::text) = ANY (ARRAY['validated'::text, 'delay'::text])) AND (lower(cte_raw.cf_do_lead_status::text) = ANY (ARRAY['delivered'::text, 'refund'::text])) AND (cte_raw.postback_status IS NULL OR cte_raw.postback_status::text = 'approved'::text) THEN cte_raw.oso_amount
                    ELSE NULL::numeric
                END) AS amt_delivered_pb,
            count(DISTINCT
                CASE
                    WHEN cte_raw.lead_status = 2 AND (lower(cte_raw.cf_so_lead_status::text) = ANY (ARRAY['validated'::text, 'delay'::text])) AND (lower(cte_raw.cf_do_lead_status::text) <> ALL (ARRAY['refund'::text, 'delivered'::text, 'returned'::text, 'cancel'::text])) THEN cte_raw.lead_id
                    ELSE NULL::bigint
                END) AS unfinish,
            count(DISTINCT
                CASE
                    WHEN cte_raw.lead_status = 2 AND (lower(cte_raw.cf_so_lead_status::text) = ANY (ARRAY['validated'::text, 'delay'::text])) AND (lower(cte_raw.cf_do_lead_status::text) <> ALL (ARRAY['refund'::text, 'delivered'::text, 'returned'::text, 'cancel'::text])) AND (cte_raw.postback_status IS NULL OR cte_raw.postback_status::text = 'approved'::text) THEN cte_raw.lead_id
                    ELSE NULL::bigint
                END) AS unfinish_pb,
            sum(
                CASE
                    WHEN cte_raw.lead_status = 2 AND (lower(cte_raw.cf_so_lead_status::text) = ANY (ARRAY['validated'::text, 'delay'::text])) AND (lower(cte_raw.cf_do_lead_status::text) <> ALL (ARRAY['refund'::text, 'delivered'::text, 'returned'::text, 'cancel'::text])) THEN cte_raw.oso_amount
                    ELSE NULL::numeric
                END) AS amt_unfinish,
            sum(
                CASE
                    WHEN cte_raw.lead_status = 2 AND (lower(cte_raw.cf_so_lead_status::text) = ANY (ARRAY['validated'::text, 'delay'::text])) AND (lower(cte_raw.cf_do_lead_status::text) <> ALL (ARRAY['refund'::text, 'delivered'::text, 'returned'::text, 'cancel'::text])) AND (cte_raw.postback_status IS NULL OR cte_raw.postback_status::text = 'approved'::text) THEN cte_raw.oso_amount
                    ELSE NULL::numeric
                END) AS amt_unfinish_pb,
            avg(cte_raw.payout) AS payout,
            avg(cte_raw.max_po) AS max_po,
            sum(cte_raw.traffic_cost) AS traffic_cost,
            avg(cte_raw.actual_call) AS avg_call,
            avg(
                CASE
                    WHEN cte_raw.lead_status = ANY (ARRAY[6, 7, 10, 11]) THEN cte_raw.actual_call
                    ELSE 0
                END) AS avg_num_uncall,
            sum(cte_raw.actual_call) AS total_actual_call,
            sum(
                CASE
                    WHEN cte_raw.lead_status = ANY (ARRAY[6, 7, 10, 11]) THEN cte_raw.actual_call
                    ELSE 0
                END) AS total_actual_uncall,
            cte_raw.exchange_rate,
                CASE
                    WHEN tf.traffic = ''::text OR tf.traffic IS NULL THEN 'No Traffic'::text
                    ELSE tf.traffic
                END AS traffic_source,
            COALESCE(am.ar_mrp, am_2.ar_mrp) AS ar_target_mrp,
            lm.lead_mrp,
            lm.started_date AS lead_mrp_started_date,
            lm.ending_date AS lead_mrp_ending_date,
            lm_2.lead_mrp AS pub_lead_mrp,
            lm_2.started_date AS pub_lead_mrp_started_date,
            lm_2.ending_date AS pub_lead_mrp_ending_date
           FROM cte_raw
             LEFT JOIN cdm_dim_ar_mrp_target_by_date dim_at ON
                CASE
                    WHEN cte_raw.sub::text = ''::text THEN concat(cte_raw.network, '_', 'blank', '_', cte_raw.offer)
                    ELSE concat(cte_raw.network, '_', cte_raw.sub, '_', cte_raw.offer)
                END = dim_at.target_key AND cte_raw.createdate >= dim_at.started_date::date AND cte_raw.createdate <= dim_at.ending_date::date
             LEFT JOIN cdm_dim_ar_mrp_target_by_date dim_at_2 ON concat(cte_raw.network, '_', cte_raw.offer) = dim_at_2.target_key AND cte_raw.createdate >= dim_at_2.started_date::date AND cte_raw.createdate <= dim_at_2.ending_date::date
             LEFT JOIN cte_lead_traffics tf ON cte_raw.network::text = tf.network AND cte_raw.createdate >= tf.started_date AND cte_raw.createdate <= tf.ending_date
             LEFT JOIN cte_ar_mrps am ON am.org_id = cte_raw.geo_id AND
                CASE
                    WHEN cte_raw.sub::text = ''::text THEN concat(cte_raw.network, '_', 'blank', '_', cte_raw.offer)
                    ELSE concat(cte_raw.network, '_', cte_raw.sub, '_', cte_raw.offer)
                END = am.target_key AND cte_raw.createdate >= am.started_date AND cte_raw.createdate <= am.ending_date
             LEFT JOIN cte_ar_mrps am_2 ON am_2.org_id = cte_raw.geo_id AND concat(cte_raw.network, '_', cte_raw.offer) = am_2.target_key AND cte_raw.createdate >= am_2.started_date AND cte_raw.createdate <= am_2.ending_date
             LEFT JOIN cte_lead_mrps lm ON lm.org_id = cte_raw.geo_id AND
                CASE
                    WHEN cte_raw.sub::text = ''::text THEN concat(cte_raw.network, '_', 'blank', '_', cte_raw.offer)
                    ELSE concat(cte_raw.network, '_', cte_raw.sub, '_', cte_raw.offer)
                END = lm.target_key AND cte_raw.createdate >= lm.started_date AND cte_raw.createdate <= lm.ending_date
             LEFT JOIN cte_lead_mrps lm_2 ON lm_2.org_id = cte_raw.geo_id AND concat(cte_raw.network, '_', cte_raw.offer) = lm_2.target_key AND cte_raw.createdate >= lm_2.started_date AND cte_raw.createdate <= lm_2.ending_date
             LEFT JOIN dim_bd_daily_lead_target cddlt ON lower(cddlt.network) = lower(cte_raw.network::text) AND cddlt.week_num_target::double precision = cte_raw.lead_week AND cddlt.target_year::double precision =
                CASE
                    WHEN cte_raw.lead_week = 1::double precision AND (date_part('day'::text, cte_raw.createdate) = ANY (ARRAY[29::double precision, 30::double precision, 31::double precision])) THEN cte_raw.lead_year + 1::double precision
                    ELSE cte_raw.lead_year
                END
             LEFT JOIN ( SELECT dim_mkt_exp_target.geo,
                    dim_mkt_exp_target.product_name,
                    dim_mkt_exp_target.category,
                    dim_mkt_exp_target.network,
                    dim_mkt_exp_target."Pub",
                    dim_mkt_exp_target.mkt_expense_target,
                    dim_mkt_exp_target.week_num_target,
                    dim_mkt_exp_target.started_date,
                    dim_mkt_exp_target.ending_date,
                    dim_mkt_exp_target."Rank",
                    dim_mkt_exp_target.last_update,
                        CASE
                            WHEN dim_mkt_exp_target.network IS NOT NULL AND dim_mkt_exp_target."Pub" IS NOT NULL THEN concat(dim_mkt_exp_target.product_name, '_', dim_mkt_exp_target.network, '_', dim_mkt_exp_target."Pub")
                            ELSE 'no_key'::text
                        END AS key_1,
                        CASE
                            WHEN dim_mkt_exp_target.network IS NULL AND dim_mkt_exp_target."Pub" IS NULL AND dim_mkt_exp_target.product_name IS NOT NULL THEN dim_mkt_exp_target.product_name
                            ELSE 'no_key'::text
                        END AS key_2,
                        CASE
                            WHEN dim_mkt_exp_target.network IS NULL AND dim_mkt_exp_target."Pub" IS NULL AND dim_mkt_exp_target.product_name IS NULL THEN dim_mkt_exp_target.geo
                            ELSE 'no_key'::text
                        END AS key_3
                   FROM dim_mkt_exp_target) dim_mkt ON lower(cte_raw.offer::text) = lower(dim_mkt.key_2) AND cte_raw.createdate >= dim_mkt.started_date::date AND cte_raw.createdate <= dim_mkt.ending_date::date
             LEFT JOIN ( SELECT dim_mkt_exp_target.geo,
                    dim_mkt_exp_target.product_name,
                    dim_mkt_exp_target.category,
                    dim_mkt_exp_target.network,
                    dim_mkt_exp_target."Pub",
                    dim_mkt_exp_target.mkt_expense_target,
                    dim_mkt_exp_target.week_num_target,
                    dim_mkt_exp_target.started_date,
                    dim_mkt_exp_target.ending_date,
                    dim_mkt_exp_target."Rank",
                    dim_mkt_exp_target.last_update,
                        CASE
                            WHEN dim_mkt_exp_target.network IS NOT NULL AND dim_mkt_exp_target."Pub" IS NOT NULL THEN concat(dim_mkt_exp_target.product_name, '_', dim_mkt_exp_target.network, '_', dim_mkt_exp_target."Pub")
                            ELSE 'no_key'::text
                        END AS key_1,
                        CASE
                            WHEN dim_mkt_exp_target.network IS NULL AND dim_mkt_exp_target."Pub" IS NULL AND dim_mkt_exp_target.product_name IS NOT NULL THEN dim_mkt_exp_target.product_name
                            ELSE 'no_key'::text
                        END AS key_2,
                        CASE
                            WHEN dim_mkt_exp_target.network IS NULL AND dim_mkt_exp_target."Pub" IS NULL AND dim_mkt_exp_target.product_name IS NULL THEN dim_mkt_exp_target.geo
                            ELSE 'no_key'::text
                        END AS key_3
                   FROM dim_mkt_exp_target) dim_mkt_1 ON lower(concat(cte_raw.offer, '_', cte_raw.network, '_', cte_raw.sub)) = lower(dim_mkt_1.key_1) AND cte_raw.createdate >= dim_mkt_1.started_date::date AND cte_raw.createdate <= dim_mkt_1.ending_date::date
             LEFT JOIN ( SELECT dim_mkt_exp_target.geo,
                    dim_mkt_exp_target.product_name,
                    dim_mkt_exp_target.category,
                    dim_mkt_exp_target.network,
                    dim_mkt_exp_target."Pub",
                    dim_mkt_exp_target.mkt_expense_target,
                    dim_mkt_exp_target.week_num_target,
                    dim_mkt_exp_target.started_date,
                    dim_mkt_exp_target.ending_date,
                    dim_mkt_exp_target."Rank",
                    dim_mkt_exp_target.last_update,
                        CASE
                            WHEN dim_mkt_exp_target.network IS NOT NULL AND dim_mkt_exp_target."Pub" IS NOT NULL THEN concat(dim_mkt_exp_target.product_name, '_', dim_mkt_exp_target.network, '_', dim_mkt_exp_target."Pub")
                            ELSE 'no_key'::text
                        END AS key_1,
                        CASE
                            WHEN dim_mkt_exp_target.network IS NULL AND dim_mkt_exp_target."Pub" IS NULL AND dim_mkt_exp_target.product_name IS NOT NULL THEN dim_mkt_exp_target.product_name
                            ELSE 'no_key'::text
                        END AS key_2,
                        CASE
                            WHEN dim_mkt_exp_target.network IS NULL AND dim_mkt_exp_target."Pub" IS NULL AND dim_mkt_exp_target.product_name IS NULL THEN dim_mkt_exp_target.geo
                            ELSE 'no_key'::text
                        END AS key_3
                   FROM dim_mkt_exp_target) dim_mkt_2 ON cte_raw.country_code = dim_mkt_2.key_3 AND cte_raw.createdate >= dim_mkt_2.started_date::date AND cte_raw.createdate <= dim_mkt_2.ending_date::date
             LEFT JOIN cdm_dim_product_cat dim_pc ON lower(cte_raw.offer::text) = lower(dim_pc.product_name) AND lower(cte_raw.country_code) = lower(dim_pc.geo)
             LEFT JOIN dim_bd_aov_dr_target cdadtv ON lower(cte_raw.country_code) = lower(cdadtv."GEO") AND lower(dim_pc."FIN camp") = lower(cdadtv."CATEGORY") AND cdadtv.week_num_target::double precision = cte_raw.lead_week AND cdadtv.target_year::double precision = cte_raw.lead_year
             LEFT JOIN dim_follow_up_deal_target dfudt ON cte_raw.country_code = dfudt."Geo" AND cte_raw.offer::text = dfudt."Offer" AND cte_raw.network::text = dfudt."Pub" AND cte_raw.createdate >= dfudt."Start date" AND cte_raw.createdate <= dfudt."end date"
             LEFT JOIN dim_bd_aff_revenue_target cdart ON cdart.week_num_target::double precision = cte_raw.lead_week AND cdart.target_year::double precision = cte_raw.lead_year AND lower(cddlt.bd_manager) = lower(cdart.bd_manager)
             LEFT JOIN dim_bd_aff_revenue_target_by_geo cdartbg ON cdartbg.week_num_target::double precision = cte_raw.lead_week AND cdartbg.target_year::double precision = cte_raw.lead_year AND lower(cdartbg.bd_manager) = lower(cddlt.bd_manager) AND lower(cte_raw.country_code) = lower(cdartbg.geo)
             LEFT JOIN dim_bd_lead_level_by_date cdllbd ON cdllbd.network = cte_raw.network::text AND cte_raw.createdate >= cdllbd."Started_date" AND cte_raw.createdate <= cdllbd."Ending_date"
             LEFT JOIN dim_bd_gm_input gm ON gm.geo = cte_raw.country_code AND cte_raw.createdate >= gm.started_date::date AND cte_raw.createdate <= gm.ending_date::date
             LEFT JOIN dim_bd_unit_cost uc ON btrim(lower(uc.offer)) = lower(cte_raw.offer::text) AND uc.geo = cte_raw.country_code AND cte_raw.createdate >= uc.started_date::date AND cte_raw.createdate <= uc.ending_date::date
             LEFT JOIN dim_bd_log_cost lc ON lc.geo = cte_raw.country_code AND cte_raw.createdate >= lc.started_date::date AND cte_raw.createdate <= lc.ending_date::date
          GROUP BY cte_raw.createdate, cte_raw.lead_week, cte_raw.lead_month, cte_raw.advertiser, cte_raw.lead_year, cte_raw.current_week, cte_raw.week_start, cte_raw.week_start_current, cte_raw.geo, cte_raw.country_code, cte_raw.offer, cte_raw.network, cte_raw.province_id, cte_raw.agc_id, dim_pc."FIN camp", (
                CASE
                    WHEN (cte_raw.network::text = ANY (ARRAY['EW'::character varying::text, 'AT'::character varying::text, 'ADT'::character varying::text, 'ABT'::character varying::text, 'ARB'::character varying::text, 'CSL'::character varying::text, 'MKR'::character varying::text, 'XXX'::character varying::text, 'PFC'::character varying::text, 'ORG'::character varying::text, 'ORG2'::character varying::text, 'PIB'::character varying::text, 'MH'::character varying::text, 'MP'::character varying::text, 'IGO'::character varying::text, 'VIC'::character varying::text, 'ODS'::character varying::text, 'DAT'::character varying::text, 'VAL'::character varying::text, 'MIR'::character varying::text, 'NGN'::character varying::text, 'WIL'::character varying::text, 'PD'::character varying::text, 'CTR'::character varying::text, 'U_DOMA'::character varying::text, 'ABG'::character varying::text])) OR cte_raw.network::text = 'U_RUS'::text AND cte_raw.geo::text = 'TH'::text OR cte_raw.sub IS NULL THEN 'No PubID'::character varying
                    WHEN cte_raw.sub::text = ''::text THEN 'blank'::character varying
                    ELSE cte_raw.sub
                END), cte_raw.sale_campaign, cte_raw.paymentmethod, tf.traffic, (COALESCE(am.ar_mrp, am_2.ar_mrp)), lm.lead_mrp, lm_2.lead_mrp, lm.started_date, lm_2.started_date, lm.ending_date, lm_2.ending_date, cddlt.bd_manager, (COALESCE(dim_mkt_1.mkt_expense_target, dim_mkt.mkt_expense_target, dim_mkt_2.mkt_expense_target)), (
                CASE
                    WHEN cte_raw.geo::text ^@ 'VN'::text AND cte_raw.week_start >= (cte_raw.week_start_current - 14) THEN 1
                    WHEN cte_raw.geo::text ^@ 'ID'::text AND cte_raw.week_start >= (cte_raw.week_start_current - 21) THEN 1
                    WHEN cte_raw.geo::text ^@ 'TH'::text AND cte_raw.week_start >= (cte_raw.week_start_current - 7) THEN 1
                    WHEN cte_raw.geo::text ^@ 'PH'::text AND cte_raw.week_start >= (cte_raw.week_start_current - 7) THEN 1
                    WHEN cte_raw.geo::text ^@ 'MY'::text AND cte_raw.week_start >= (cte_raw.week_start_current - 14) THEN 1
                    ELSE 0
                END), cte_raw.exchange_rate, cdadtv."AOV_TARGET", dfudt."AOV_MRP", cdadtv."DR_TARGET", cdadtv."Daily_approved_Target", cdart.estimate_daily_lead, cdart.daily_approved_lead, cdart.daily_delivered_lead, cdart.aff_revenue_target, cdartbg.aff_revenue_target_by_geo, cte_raw.carrier, gm.tax_rate, gm.tele_rate, gm.commission_rate, gm.bd_comm_rate, uc.unit_cost, lc.ffm_fee, lc.lm_fee, lc.return_rate, lc.cod_rate, lc.portion
        ), cte_bd_level_mapping AS (
         SELECT a.manager,
            b.manager AS "Team"
           FROM dim_bd_team_level_input a
             LEFT JOIN ( SELECT dbtli.bd_level_1,
                    dbtli.manager
                   FROM dim_bd_team_level_input dbtli) b ON a.bd_level_2 = b.bd_level_1
        ), cte_group_cal_aov AS (
         SELECT cte_group_raw.createdate,
            cte_group_raw.lead_week,
            cte_group_raw.lead_month,
            cte_group_raw.lead_year,
            cte_group_raw.current_week,
            cte_group_raw.week_start,
            cte_group_raw.week_start_current,
            cte_group_raw.geo,
            cte_group_raw.country_code,
            cte_group_raw.country_code AS geo_2,
            cte_group_raw.offer,
            cte_group_raw.network,
            cte_group_raw.advertiser,
            cte_group_raw.province_id,
            cte_group_raw.category,
            cte_group_raw.pub,
            cte_group_raw.sale_campaign,
            cte_group_raw.carrier,
            cte_group_raw.agc_id,
            cte_group_raw.paymentmethod,
            cte_group_raw.validated_qty,
            cte_group_raw.tax_rate,
            cte_group_raw.tele_rate,
            cte_group_raw.commission_rate,
            cte_group_raw.bd_comm_rate,
            cte_group_raw.unit_cost,
            cte_group_raw.ffm_fee,
            cte_group_raw.lm_fee,
            cte_group_raw.return_rate,
            cte_group_raw.cod_rate,
            cte_group_raw.portion,
                CASE
                    WHEN cte_group_raw.manager IS NULL THEN 'Others'::text
                    ELSE cte_group_raw.manager
                END AS manager,
                CASE
                    WHEN cte_group_raw.manager = 'Others'::text OR cte_group_raw.manager IS NULL THEN 'Others'::text
                    ELSE cblm."Team"
                END AS "Team",
            cte_group_raw."AOV_TARGET",
            cte_group_raw.aov_target_2,
            cte_group_raw."DR_TARGET",
            cte_group_raw."Daily_approved_Target",
            cte_group_raw.target_tracking_estimate_daily_lead,
            cte_group_raw.target_tracking_daily_approved_lead,
            cte_group_raw.target_tracking_daily_delivered_lead,
            cte_group_raw.aff_revenue_target,
            cte_group_raw.aff_revenue_target_by_geo,
            cte_group_raw.ar_target_mrp,
            cte_group_raw.lead_mrp,
            cte_group_raw.lead_mrp_started_date,
            cte_group_raw.lead_mrp_ending_date,
            cte_group_raw.pub_lead_mrp,
            cte_group_raw.pub_lead_mrp_started_date,
            cte_group_raw.pub_lead_mrp_ending_date,
            cte_group_raw.mkt_expense_target,
            cte_group_raw.inrangeforecast,
            cte_group_raw.total_lead,
            cte_group_raw.trash,
            cte_group_raw.approved,
            cte_group_raw.e_approved,
            cte_group_raw.approved_pb,
            cte_group_raw.rejected,
            cte_group_raw.contactable,
            cte_group_raw.uncall,
            cte_group_raw.validated,
            cte_group_raw.total_approved_postback,
            cte_group_raw.total_pending_postback,
            cte_group_raw.amt_validated,
            cte_group_raw.amt_validated_pb,
            cte_group_raw.delivered,
            cte_group_raw.finalized_do,
            cte_group_raw.delivered_pb,
            cte_group_raw.amt_delivered,
            cte_group_raw.amt_delivered_pb,
            cte_group_raw.unfinish,
            cte_group_raw.unfinish_pb,
            cte_group_raw.amt_unfinish,
            cte_group_raw.amt_unfinish_pb,
            cte_group_raw.payout,
            cte_group_raw.max_po,
            cte_group_raw.traffic_cost,
            cte_group_raw.avg_call,
            cte_group_raw.avg_num_uncall,
            cte_group_raw.total_actual_call,
            cte_group_raw.total_actual_uncall,
            cte_group_raw.exchange_rate,
            cte_group_raw.traffic_source,
                CASE
                    WHEN cte_group_raw.total_lead = 0 THEN 0::double precision
                    ELSE cte_group_raw.trash::double precision / cte_group_raw.total_lead::double precision
                END AS tr,
                CASE
                    WHEN cte_group_raw.total_lead = 0 THEN 0::double precision
                    ELSE cte_group_raw.validated::double precision / cte_group_raw.total_lead::double precision
                END AS ar_qa,
                CASE
                    WHEN cte_group_raw.total_lead = 0 THEN 0::double precision
                    ELSE cte_group_raw.total_approved_postback::double precision / cte_group_raw.total_lead::double precision
                END AS ar_qc,
                CASE
                    WHEN cte_group_raw.validated = 0 THEN 0::double precision
                    ELSE cte_group_raw.delivered::double precision / cte_group_raw.validated::double precision
                END AS dr,
                CASE
                    WHEN cte_group_raw.total_approved_postback = 0 THEN 0::double precision
                    ELSE cte_group_raw.delivered_pb::double precision / cte_group_raw.total_approved_postback::double precision
                END AS dr_pb,
            cte_group_raw.max_po - cte_group_raw.payout AS gap_po,
                CASE
                    WHEN cte_group_raw.validated = 0 THEN 0::double precision
                    ELSE cte_group_raw.amt_validated::double precision / (cte_group_raw.validated::double precision * cte_group_raw.exchange_rate)
                END AS aov,
                CASE
                    WHEN cte_group_raw.total_approved_postback = 0 THEN 0::double precision
                    ELSE cte_group_raw.amt_validated_pb::double precision / (cte_group_raw.total_approved_postback::double precision * cte_group_raw.exchange_rate)
                END AS aov_pb,
                CASE
                    WHEN cte_group_raw.validated = 0 THEN 0::double precision
                    ELSE cte_group_raw.amt_validated::double precision / cte_group_raw.exchange_rate
                END AS amt_validated_usd,
                CASE
                    WHEN cte_group_raw.total_approved_postback = 0 THEN 0::double precision
                    ELSE cte_group_raw.amt_validated_pb::double precision / cte_group_raw.exchange_rate
                END AS amt_validated_pb_usd,
                CASE
                    WHEN cte_group_raw.delivered = 0 THEN 0::double precision
                    ELSE cte_group_raw.amt_delivered::double precision / (cte_group_raw.delivered::double precision * cte_group_raw.exchange_rate)
                END AS aov_delivered,
                CASE
                    WHEN cte_group_raw.delivered_pb = 0 THEN 0::double precision
                    ELSE cte_group_raw.amt_delivered_pb::double precision / (cte_group_raw.delivered_pb::double precision * cte_group_raw.exchange_rate)
                END AS aov_delivered_pb,
                CASE
                    WHEN cte_group_raw.delivered = 0 THEN 0::double precision
                    ELSE cte_group_raw.amt_delivered::double precision / cte_group_raw.exchange_rate
                END AS amt_delivered_usd,
                CASE
                    WHEN cte_group_raw.delivered_pb = 0 THEN 0::double precision
                    ELSE cte_group_raw.amt_delivered_pb::double precision / cte_group_raw.exchange_rate
                END AS amt_delivered_pb_usd,
                CASE
                    WHEN cte_group_raw.validated = 0 OR cte_group_raw.total_lead = 0 THEN 0::double precision
                    ELSE cte_group_raw.delivered::double precision * cte_group_raw.max_po
                END AS aff_revenue,
                CASE
                    WHEN cte_group_raw.total_approved_postback = 0 OR cte_group_raw.total_lead = 0 THEN 0::double precision
                    ELSE cte_group_raw.delivered_pb::double precision * cte_group_raw.max_po
                END AS aff_revenue_pb,
                CASE
                    WHEN cte_group_raw.validated = 0 THEN 0::double precision
                    WHEN cte_group_raw.validated > 0 AND cte_group_raw.inrangeforecast = 1 THEN COALESCE(ddfm.dr_forecast, cddfbd.dr_forecast_final)
                    WHEN cte_group_raw.validated > 0 AND cte_group_raw.inrangeforecast = 0 THEN cte_group_raw.delivered::double precision / cte_group_raw.validated::double precision
                    ELSE NULL::double precision
                END AS dr_final,
            COALESCE(
                CASE
                    WHEN cte_group_raw.inrangeforecast = 1 THEN cddfbd.dr_forecast_final
                    ELSE
                    CASE
                        WHEN cte_group_raw.total_approved_postback = 0 THEN 0::double precision
                        ELSE cte_group_raw.delivered_pb::double precision / cte_group_raw.total_approved_postback::double precision
                    END
                END,
                CASE
                    WHEN cte_group_raw.total_approved_postback = 0 THEN 0::double precision
                    ELSE cte_group_raw.delivered_pb::double precision / cte_group_raw.total_approved_postback::double precision
                END) AS dr_final_pb
           FROM cte_group_raw
             LEFT JOIN cdm_dim_dr_forecast_by_date cddfbd ON cte_group_raw.country_code = cddfbd.geo AND cte_group_raw.sale_campaign::text = cddfbd.category AND cte_group_raw.offer::text = cddfbd.product_name AND cte_group_raw.network::text = cddfbd.network AND cte_group_raw.pub::text = cddfbd.pub
             LEFT JOIN cte_bd_level_mapping cblm ON cte_group_raw.manager = cblm.manager
             LEFT JOIN dim_dr_manual_forecast ddfm ON cte_group_raw.country_code = ddfm.country_code AND cte_group_raw.network::text = ddfm.network AND cte_group_raw.offer::text = ddfm.offer AND cte_group_raw.createdate >= ddfm."from" AND cte_group_raw.createdate <= ddfm."to"
        )
 SELECT cte_group_cal_aov.createdate,
    cte_group_cal_aov.lead_week,
    cte_group_cal_aov.lead_month,
    cte_group_cal_aov.lead_year,
    cte_group_cal_aov.current_week,
    cte_group_cal_aov.week_start,
    cte_group_cal_aov.week_start_current,
    cte_group_cal_aov.geo,
        CASE
            WHEN cte_group_cal_aov.createdate >= '2024-06-01'::date AND cte_group_cal_aov.geo::text ^@ 'VN'::text THEN 'VN'::text
            ELSE cte_group_cal_aov.geo::text
        END AS geo_bd,
    cte_group_cal_aov.country_code,
    cte_group_cal_aov.approved_pb,
    cte_group_cal_aov.total_approved_postback,
    cte_group_cal_aov.total_pending_postback,
    cte_group_cal_aov.offer,
    cte_group_cal_aov.geo_2,
    cte_group_cal_aov.network,
    cte_group_cal_aov.province_id,
    cte_group_cal_aov.advertiser,
    cte_group_cal_aov.category,
    cte_group_cal_aov.pub,
    cte_group_cal_aov.sale_campaign,
    cte_group_cal_aov.carrier,
    cte_group_cal_aov.agc_id,
    cte_group_cal_aov.paymentmethod,
    cte_group_cal_aov.validated_qty,
    cte_group_cal_aov.tax_rate,
    cte_group_cal_aov.tele_rate,
    cte_group_cal_aov.commission_rate,
    cte_group_cal_aov.bd_comm_rate,
    cte_group_cal_aov.unit_cost,
    cte_group_cal_aov.ffm_fee,
    cte_group_cal_aov.lm_fee,
    cte_group_cal_aov.return_rate,
    cte_group_cal_aov.cod_rate,
    cte_group_cal_aov.portion,
    cte_group_cal_aov.manager,
    cte_group_cal_aov."Team",
    cte_group_cal_aov."AOV_TARGET",
    cte_group_cal_aov.aov_target_2,
    cte_group_cal_aov."DR_TARGET",
    cte_group_cal_aov."Daily_approved_Target",
    cte_group_cal_aov.target_tracking_estimate_daily_lead,
    cte_group_cal_aov.target_tracking_daily_approved_lead,
    cte_group_cal_aov.target_tracking_daily_delivered_lead,
    cte_group_cal_aov.aff_revenue_target,
    cte_group_cal_aov.aff_revenue_target_by_geo,
    cte_group_cal_aov.ar_target_mrp,
    cte_group_cal_aov.lead_mrp,
    cte_group_cal_aov.lead_mrp_started_date,
    cte_group_cal_aov.lead_mrp_ending_date,
    cte_group_cal_aov.pub_lead_mrp,
    cte_group_cal_aov.pub_lead_mrp_started_date,
    cte_group_cal_aov.pub_lead_mrp_ending_date,
    cte_group_cal_aov.mkt_expense_target,
    cte_group_cal_aov.inrangeforecast,
    cte_group_cal_aov.total_lead,
    cte_group_cal_aov.trash,
    cte_group_cal_aov.approved,
    cte_group_cal_aov.e_approved,
    cte_group_cal_aov.rejected,
    cte_group_cal_aov.contactable,
    cte_group_cal_aov.uncall,
    cte_group_cal_aov.validated,
        CASE
            WHEN lower(cte_group_cal_aov.offer::text) ~~ '%cpl%'::text THEN cte_group_cal_aov.total_lead - cte_group_cal_aov.trash
            ELSE NULL::bigint
        END AS cpl_lead,
    cte_group_cal_aov.amt_validated,
    cte_group_cal_aov.amt_validated_pb,
    cte_group_cal_aov.delivered,
    cte_group_cal_aov.finalized_do,
    cte_group_cal_aov.delivered_pb,
    cte_group_cal_aov.amt_delivered,
    cte_group_cal_aov.amt_delivered_pb,
    cte_group_cal_aov.unfinish,
    cte_group_cal_aov.unfinish_pb,
    cte_group_cal_aov.amt_unfinish,
    cte_group_cal_aov.amt_unfinish_pb,
    cte_group_cal_aov.payout,
    cte_group_cal_aov.max_po,
    cte_group_cal_aov.traffic_cost,
    cte_group_cal_aov.avg_call,
    cte_group_cal_aov.avg_num_uncall,
    cte_group_cal_aov.total_actual_call,
    cte_group_cal_aov.total_actual_uncall,
    cte_group_cal_aov.exchange_rate,
    cte_group_cal_aov.traffic_source,
    cte_group_cal_aov.tr,
    cte_group_cal_aov.ar_qa,
    cte_group_cal_aov.ar_qc,
    cte_group_cal_aov.dr,
    cte_group_cal_aov.dr_pb,
    cte_group_cal_aov.gap_po,
    cte_group_cal_aov.aov,
    cte_group_cal_aov.aov_pb,
    cte_group_cal_aov.amt_validated_usd,
    cte_group_cal_aov.amt_validated_pb_usd,
    cte_group_cal_aov.aov_delivered,
    cte_group_cal_aov.aov_delivered_pb,
    cte_group_cal_aov.amt_delivered_usd,
    cte_group_cal_aov.amt_delivered_pb_usd,
    cte_group_cal_aov.aff_revenue,
    cte_group_cal_aov.aff_revenue_pb,
    cte_group_cal_aov.dr_final,
    cte_group_cal_aov.dr_final_pb,
    cte_group_cal_aov.mkt_expense_target * cte_group_cal_aov.aov * cte_group_cal_aov.validated::double precision * cte_group_cal_aov.dr_final / (1::double precision + cte_group_cal_aov.tax_rate) - cte_group_cal_aov.payout * cte_group_cal_aov.validated::double precision AS gap_val,
    cte_group_cal_aov.total_lead::double precision * cte_group_cal_aov.ar_qa * cte_group_cal_aov.dr_final * cte_group_cal_aov.max_po AS aff_revenue_fc
   FROM cte_group_cal_aov cte_group_cal_aov
WITH DATA;

-- View indexes:
CREATE UNIQUE INDEX bd_master_createdate_lead_week_lead_month_lead_year_current_idx ON dareport.bd_master USING btree (createdate, lead_week, lead_month, lead_year, current_week, week_start, week_start_current, geo, country_code, offer, network, province_id, advertiser, category, pub, sale_campaign, carrier, agc_id, paymentmethod, exchange_rate, traffic_source, manager, "Team", lead_mrp, lead_mrp_started_date, lead_mrp_ending_date);
