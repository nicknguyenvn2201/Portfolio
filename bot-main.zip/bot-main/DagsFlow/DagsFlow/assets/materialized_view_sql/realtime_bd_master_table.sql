select *
from realtime_bd_master
