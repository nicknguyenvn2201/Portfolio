-- dareport.agent_performance_data source

CREATE MATERIALIZED VIEW dareport.agent_performance_data
TABLESPACE pg_default
AS WITH agent_cte AS (
         SELECT cf.geo,
            cf.user_name,
                CASE
                    WHEN cf.geo::text ^@ 'TH'::text OR cf.geo::text ^@ 'MY'::text THEN "substring"(split_part(cf.user_name, '@'::text, 1), 2)::character varying::text
                    ELSE cf.user_name
                END AS agent_name,
            cf.team
           FROM dim_agent_team cf
          WHERE "left"(cf.geo::text, 2) = ANY (ARRAY['MY'::text, 'TH'::text])
        ), agent_cte2 AS (
         SELECT cf.geo,
            ou.user_name,
                CASE
                    WHEN cf.geo::text ^@ 'TH'::text OR cf.geo::text ^@ 'MY'::text THEN "substring"(split_part(ou.user_name::text, '@'::text, 1), 2)::character varying
                    ELSE ou.user_name
                END AS agent_name,
            count(*) AS count
           FROM cl_fresh cf
             JOIN or_user ou ON cf.geo::text = ou.geo::text AND cf.assigned = ou.user_id AND ou.user_type::text = 'agent'::text AND cf.lead_type::text = 'A'::text
          WHERE "left"(cf.geo::text, 2) = ANY (ARRAY['MY'::text, 'TH'::text])
          GROUP BY cf.geo, ou.user_name
        ), cte_ar_mrps AS (
         SELECT ar_mrps.affiliate_id AS network,
            ar_mrps.org_id,
            ar_mrps.offer_id AS product_name,
                CASE
                    WHEN lower(ar_mrps.sub_id) = '*'::text THEN ''::text
                    WHEN lower(ar_mrps.sub_id) = ''::text THEN 'blank'::text
                    ELSE ar_mrps.sub_id
                END AS sub_id,
            ar_mrps.ar_mrp,
            ar_mrps.applied_from_date::date AS started_date,
            ar_mrps.applied_to_date::date AS ending_date,
                CASE
                    WHEN lower(ar_mrps.sub_id) = '*'::text THEN concat(ar_mrps.affiliate_id, '_', ar_mrps.offer_id)
                    WHEN lower(ar_mrps.sub_id) = ''::text THEN concat(ar_mrps.affiliate_id, '_', 'blank', '_', ar_mrps.offer_id)
                    ELSE concat(ar_mrps.affiliate_id, '_', ar_mrps.sub_id, '_', ar_mrps.offer_id)
                END AS target_key
           FROM ar_mrps
        ), team_info AS (
         SELECT ou.geo,
            ou.user_id,
            ou.user_name AS agent_name,
            ot.name AS team,
            df.type
           FROM or_team ot
             LEFT JOIN or_team_member otm ON ot.id = otm.team_id AND ot.geo::text = otm.geo::text
             LEFT JOIN or_user ou ON otm.user_id = ou.user_id AND otm.geo::text = ou.geo::text AND ou.user_type::text = 'agent'::text
             LEFT JOIN dim_finance_agent_type df ON "left"(ou.geo::text, 2) = df.country_code AND ou.user_name::text = df.agent_name
        ), fresh_cte AS (
         SELECT cf.geo,
            cf.org_id,
            cf.lead_week,
            cf.lead_month,
            cf.lead_year,
            cf.week_start,
            cf.week_start_current,
            cf.country_code,
            ou.user_name AS agent_name,
            ti.team,
            ti.type,
            cc.name AS cp_name,
            cf.affiliate_id AS network,
            cf.prod_name AS offer,
            cf.pub,
            cf.createdate::date AS createdate,
            daar.rpl AS rpl_target,
            daar.max_cap,
            daar.optimum_cap,
            dadam.dr_target AS dr_mrp,
            dadam.aov_target AS aov_mrp,
                CASE
                    WHEN cf.country_code = 'VN'::text AND cf.week_start >= (cf.week_start_current - 14) THEN 1
                    WHEN cf.country_code = 'ID'::text AND cf.week_start >= (cf.week_start_current - 21) THEN 1
                    WHEN cf.country_code = 'TH'::text AND cf.week_start >= (cf.week_start_current - 7) THEN 1
                    WHEN cf.country_code = 'IN'::text AND cf.week_start >= (cf.week_start_current - 7) THEN 1
                    WHEN cf.country_code = 'PH'::text AND cf.week_start >= (cf.week_start_current - 7) THEN 1
                    WHEN cf.country_code = 'MY'::text AND cf.week_start >= (cf.week_start_current - 14) THEN 1
                    ELSE 0
                END AS inrangeforecast,
            sum(
                CASE
                    WHEN cf.lead_status = ANY (ARRAY[2, 3, 9, 8, 14]) THEN 1
                    ELSE 0
                END) AS contactable_leads,
            sum(
                CASE
                    WHEN cf.lead_status = 5 THEN 1
                    ELSE 0
                END) AS trash,
            sum(
                CASE
                    WHEN cf.lead_status = 1 THEN 1
                    ELSE 0
                END) AS new_lead,
            count(DISTINCT cf.lead_id) AS leads,
            sum(
                CASE
                    WHEN cf.postback_status::text = 'approved'::text THEN 1
                    ELSE 0
                END) AS total_approved_postback,
            sum(
                CASE
                    WHEN oso.status = ANY (ARRAY[43, 357]) THEN 1
                    ELSE 0
                END) AS validated,
            sum(
                CASE
                    WHEN oso.status = ANY (ARRAY[43, 357]) THEN oso.amount
                    ELSE 0::numeric
                END) AS validated_amount,
            sum(0) AS resell_act_revenue,
            sum(
                CASE
                    WHEN odn.status = 59 THEN 1
                    ELSE 0
                END) AS delivered,
            sum(
                CASE
                    WHEN odn.status = ANY (ARRAY[53, 59, 61, 56]) THEN 1
                    ELSE 0
                END) AS finalized_do,
            avg(oac.payout) AS payout
           FROM ( SELECT cl_fresh.geo,
                    cl_fresh.click_id,
                    cl_fresh.org_id,
                    cl_fresh.lead_status,
                    date_part('week'::text, cl_fresh.createdate + '1 day'::interval) AS lead_week,
                    date_part('month'::text, cl_fresh.createdate) AS lead_month,
                    date_part('year'::text, cl_fresh.createdate) AS lead_year,
                        CASE
                            WHEN cl_fresh.createdate::date = '2022-01-01'::date THEN 4::double precision
                            WHEN cl_fresh.createdate::date = '2021-10-01'::date OR cl_fresh.createdate::date = '2021-10-02'::date THEN 3::double precision
                            WHEN cl_fresh.createdate::date = '2022-04-01'::date OR cl_fresh.createdate::date = '2022-04-02'::date THEN 1::double precision
                            ELSE date_part('quarter'::text, cl_fresh.createdate)
                        END AS lead_quarter,
                    date_part('week'::text, CURRENT_DATE + '1 day'::interval) AS current_week,
                    (date_trunc('week'::text, cl_fresh.createdate + '1 day'::interval) - '1 day'::interval)::date AS week_start,
                    (date_trunc('week'::text, CURRENT_DATE + '1 day'::interval) - '1 day'::interval)::date AS week_start_current,
                    "left"(cl_fresh.geo::text, 2) AS country_code,
                    cl_fresh.affiliate_id,
                    cl_fresh.lead_id,
                    cl_fresh.assigned,
                    cl_fresh.createdate,
                    cl_fresh.cp_id,
                    cl_fresh.postback_status,
                    cl_fresh.prod_name,
                    cl_fresh.lead_type,
                    cl_fresh.subid1 AS pub
                   FROM cl_fresh
                  WHERE cl_fresh.createdate >= (CURRENT_DATE - 90) AND cl_fresh.lead_type::text = 'A'::text AND
                        CASE
                            WHEN cl_fresh.lead_status = 4 OR cl_fresh.lead_status = 5 AND cl_fresh.assigned = 0 THEN 1
                            ELSE 0
                        END = 0) cf
             LEFT JOIN team_info ti ON cf.geo::text = ti.geo::text AND cf.assigned = ti.user_id
             LEFT JOIN cp_campaign cc ON cf.geo::text = cc.geo::text AND cf.cp_id = cc.cp_id
             LEFT JOIN ods_affscale_conversion oac ON cf.click_id::text = oac.transaction_id
             LEFT JOIN ( SELECT od_sale_order.id,
                    od_sale_order.so_id,
                    od_sale_order.org_id,
                    od_sale_order.geo,
                    od_sale_order.cp_id,
                    od_sale_order.ag_id,
                    od_sale_order.lead_id,
                    od_sale_order.amount,
                    od_sale_order.payment_method,
                    od_sale_order.status,
                    od_sale_order.createby,
                    od_sale_order.createdate,
                    od_sale_order.modifyby,
                    od_sale_order.modifydate,
                    od_sale_order.created_at,
                    od_sale_order.updated_at,
                    od_sale_order.creation_date,
                    od_sale_order.reason,
                    od_sale_order.qa_note,
                    od_sale_order.validate_by,
                    od_sale_order.lead_phone,
                    od_sale_order.customer_phone,
                    od_sale_order.discount_cash_2,
                    od_sale_order.lead_name,
                    od_sale_order.amount_deposit,
                    od_sale_order.list_price,
                    od_sale_order.discount_level,
                    od_sale_order.discount_type_1,
                    od_sale_order.unit_1,
                    od_sale_order.discount_cash_1,
                    od_sale_order.discount_percent_1,
                    od_sale_order.discount_type_2,
                    od_sale_order.unit_2,
                    od_sale_order.discount_percent_2,
                    od_sale_order.discount_type_3,
                    od_sale_order.unit_3,
                    od_sale_order.discount_cash_3,
                    od_sale_order.discount_percent_3,
                    od_sale_order.discount_type_4,
                    od_sale_order.unit_4,
                    od_sale_order.discount_cash_4,
                    od_sale_order.discount_percent_4,
                    od_sale_order.is_validated,
                    od_sale_order.appointment_date,
                    od_sale_order.qty_total,
                    od_sale_order.qty_saleable,
                    od_sale_order.amount_postpaid,
                    od_sale_order.delivery_package_code
                   FROM od_sale_order
                  WHERE od_sale_order.status <> 46) oso ON cf.geo::text = oso.geo::text AND cf.lead_id = oso.lead_id
             LEFT JOIN od_do_new odn ON oso.geo::text = odn.geo::text AND odn.so_id = oso.so_id
             LEFT JOIN dim_agent_mrp_rpl daar ON daar.geo = cf.country_code AND lower(daar.camp) = lower(cc.name::text) AND cf.createdate >= daar."from" AND cf.createdate <= daar."to"
             LEFT JOIN dim_bod_target_input dadam ON dadam.country_code = cf.country_code AND date(date_trunc('month'::text, cf.createdate)) = dadam.year_month
             LEFT JOIN or_user ou ON cf.geo::text = ou.geo::text AND cf.assigned = ou.user_id AND ou.user_type::text = 'agent'::text
          GROUP BY cf.geo, cf.org_id, cf.lead_week, cf.lead_month, cf.lead_year, cf.week_start, cf.week_start_current, cf.country_code, ou.user_name, ti.team, ti.type, cc.name, cf.affiliate_id, cf.prod_name, cf.pub, (cf.createdate::date), daar.armrp, daar.rpl, daar.max_cap, daar.optimum_cap, dadam.dr_target, dadam.aov_target
        ), resell_cte AS (
         SELECT oso.geo,
            oso.lead_week,
            oso.lead_month,
            oso.lead_year,
            oso.week_start,
            oso.week_start_current,
            "left"(oso.geo::text, 2) AS country_code,
            dat.user_name AS agent_name,
            ti.team,
            ti.type,
            cc.name AS cp_name,
            ''::text AS network,
            ''::text AS offer,
            ''::text AS pub,
            oso.createdate::date AS createdate,
            0 AS rpl_target,
            0 AS max_cap,
            0 AS optimum_cap,
            0 AS dr_mrp,
            0 AS aov_mrp,
            0 AS inrangeforecast,
            0 AS contactable_leads,
            0 AS trash,
            0 AS new_lead,
            0 AS leads,
            0 AS total_approved_postback,
            0 AS validated,
            sum(0) AS validated_amount,
            sum(
                CASE
                    WHEN odn.status = 59 THEN oso.amount
                    ELSE 0::numeric
                END) AS resell_act_revenue,
            0 AS delivered,
            0 AS finalized_do,
            0 AS payout
           FROM ( SELECT od_sale_order.id,
                    od_sale_order.so_id,
                    od_sale_order.org_id,
                    od_sale_order.geo,
                    od_sale_order.cp_id,
                    date_part('week'::text, od_sale_order.createdate + '1 day'::interval) AS lead_week,
                    date_part('month'::text, od_sale_order.createdate) AS lead_month,
                    date_part('year'::text, od_sale_order.createdate) AS lead_year,
                        CASE
                            WHEN od_sale_order.createdate::date = '2022-01-01'::date THEN 4::double precision
                            WHEN od_sale_order.createdate::date = '2021-10-01'::date OR od_sale_order.createdate::date = '2021-10-02'::date THEN 3::double precision
                            WHEN od_sale_order.createdate::date = '2022-04-01'::date OR od_sale_order.createdate::date = '2022-04-02'::date THEN 1::double precision
                            ELSE date_part('quarter'::text, od_sale_order.createdate)
                        END AS lead_quarter,
                    date_part('week'::text, CURRENT_DATE + '1 day'::interval) AS current_week,
                    (date_trunc('week'::text, od_sale_order.createdate + '1 day'::interval) - '1 day'::interval)::date AS week_start,
                    (date_trunc('week'::text, CURRENT_DATE + '1 day'::interval) - '1 day'::interval)::date AS week_start_current,
                    od_sale_order.ag_id,
                    od_sale_order.lead_id,
                    od_sale_order.amount,
                    od_sale_order.payment_method,
                    od_sale_order.status,
                    od_sale_order.createby,
                    od_sale_order.createdate,
                    od_sale_order.modifyby,
                    od_sale_order.modifydate,
                    od_sale_order.created_at,
                    od_sale_order.updated_at,
                    od_sale_order.creation_date,
                    od_sale_order.reason,
                    od_sale_order.qa_note,
                    od_sale_order.validate_by,
                    od_sale_order.lead_phone,
                    od_sale_order.customer_phone,
                    od_sale_order.discount_cash_2,
                    od_sale_order.lead_name,
                    od_sale_order.amount_deposit,
                    od_sale_order.list_price,
                    od_sale_order.discount_level,
                    od_sale_order.discount_type_1,
                    od_sale_order.unit_1,
                    od_sale_order.discount_cash_1,
                    od_sale_order.discount_percent_1,
                    od_sale_order.discount_type_2,
                    od_sale_order.unit_2,
                    od_sale_order.discount_percent_2,
                    od_sale_order.discount_type_3,
                    od_sale_order.unit_3,
                    od_sale_order.discount_cash_3,
                    od_sale_order.discount_percent_3,
                    od_sale_order.discount_type_4,
                    od_sale_order.unit_4,
                    od_sale_order.discount_cash_4,
                    od_sale_order.discount_percent_4,
                    od_sale_order.is_validated,
                    od_sale_order.appointment_date,
                    od_sale_order.qty_total,
                    od_sale_order.qty_saleable,
                    od_sale_order.amount_postpaid,
                    od_sale_order.delivery_package_code
                   FROM od_sale_order
                  WHERE od_sale_order.createdate >= (CURRENT_DATE - 200) AND od_sale_order.status <> 46) oso
             LEFT JOIN cl_fresh cf ON cf.geo::text = oso.geo::text AND cf.lead_id = oso.lead_id
             LEFT JOIN team_info ti ON cf.geo::text = ti.geo::text AND cf.assigned = ti.user_id
             LEFT JOIN cp_campaign cc ON cf.geo::text = cc.geo::text AND cf.cp_id = cc.cp_id
             LEFT JOIN od_do_new odn ON oso.geo::text = odn.geo::text AND odn.so_id = oso.so_id
             LEFT JOIN ( SELECT dim_agent_team.geo,
                    dim_agent_team.user_id,
                    dim_agent_team.user_name,
                    dim_agent_team.team
                   FROM dim_agent_team) dat ON dat.geo::text = cf.geo::text AND dat.user_id = cf.assigned
          WHERE cf.lead_type::text <> 'A'::text AND cf.geo::text <> 'PH'::text AND (dat.team = 'Fresh Resell'::text OR dat.team IS NULL)
          GROUP BY oso.geo, oso.lead_week, oso.lead_month, oso.lead_year, oso.week_start, oso.week_start_current, ("left"(oso.geo::text, 2)), dat.user_name, ti.team, ti.type, cc.name, ''::text, (oso.createdate::date), 0::integer
        ), final_ AS (
         SELECT fresh_cte.geo,
                CASE
                    WHEN fresh_cte.geo::text = 'VNID'::text THEN 16
                    WHEN fresh_cte.geo::text ^@ 'VN'::text THEN 4
                    WHEN fresh_cte.geo::text ^@ 'ID'::text THEN 9
                    WHEN fresh_cte.geo::text ^@ 'MY'::text THEN 11
                    WHEN fresh_cte.geo::text ^@ 'PH'::text THEN 14
                    WHEN fresh_cte.geo::text ^@ 'TH'::text THEN 10
                    ELSE fresh_cte.org_id
                END AS geo_id,
                CASE
                    WHEN fresh_cte.geo::text = 'VNID'::text THEN fresh_cte.geo::text
                    ELSE fresh_cte.country_code
                END AS geo_2,
            fresh_cte.lead_week,
            fresh_cte.lead_month,
            fresh_cte.lead_year,
            fresh_cte.week_start,
            fresh_cte.week_start_current,
            fresh_cte.country_code,
            fresh_cte.agent_name,
            fresh_cte.team,
            fresh_cte.type,
            fresh_cte.cp_name,
            fresh_cte.network,
            fresh_cte.offer,
            fresh_cte.pub,
            fresh_cte.createdate,
            fresh_cte.rpl_target,
            fresh_cte.max_cap,
            fresh_cte.optimum_cap,
            fresh_cte.dr_mrp,
            fresh_cte.aov_mrp,
            fresh_cte.inrangeforecast,
            fresh_cte.contactable_leads,
            fresh_cte.trash,
            fresh_cte.new_lead,
            fresh_cte.leads,
            fresh_cte.total_approved_postback,
            fresh_cte.validated,
            fresh_cte.validated_amount,
            fresh_cte.resell_act_revenue,
            fresh_cte.delivered,
            fresh_cte.finalized_do,
            fresh_cte.payout
           FROM fresh_cte
        UNION
         SELECT resell_cte.geo,
            0 AS geo_id,
            NULL::text AS geo_2,
            resell_cte.lead_week,
            resell_cte.lead_month,
            resell_cte.lead_year,
            resell_cte.week_start,
            resell_cte.week_start_current,
            resell_cte.country_code,
            resell_cte.agent_name,
            resell_cte.team,
            resell_cte.type,
            resell_cte.cp_name,
            resell_cte.network,
            resell_cte.offer,
            resell_cte.pub,
            resell_cte.createdate,
            resell_cte.rpl_target,
            resell_cte.max_cap,
            resell_cte.optimum_cap,
            resell_cte.dr_mrp,
            resell_cte.aov_mrp,
            resell_cte.inrangeforecast,
            resell_cte.contactable_leads,
            resell_cte.new_lead,
            resell_cte.trash,
            resell_cte.leads,
            resell_cte.total_approved_postback,
            resell_cte.validated,
            resell_cte.validated_amount,
            resell_cte.resell_act_revenue,
            resell_cte.delivered,
            resell_cte.finalized_do,
            resell_cte.payout
           FROM resell_cte
        ), cte_final AS (
         SELECT
                CASE
                    WHEN f.validated = 0 THEN 0::double precision
                    WHEN f.validated > 0 AND f.inrangeforecast = 1 THEN COALESCE(ddfm.dr_forecast, cddfbd.dr_forecast_final)
                    WHEN f.validated > 0 AND f.inrangeforecast = 0 THEN f.delivered::double precision / f.validated::double precision
                    ELSE NULL::double precision
                END AS dr_final,
            f.geo,
            f.lead_week,
            f.lead_month,
            f.lead_year,
                CASE
                    WHEN f.createdate = '2022-01-01'::date THEN 'W52-2021'::text
                    ELSE (('W'::text || f.lead_week) || '-'::text) || f.lead_year
                END AS "Week",
            (f.lead_month || '-'::text) || f.lead_year AS "Month",
                CASE
                    WHEN f.lead_week < 10::double precision THEN (f.lead_year::text || '0'::text) || f.lead_week::text
                    ELSE f.lead_year::text || f.lead_week::text
                END AS lead_week_year,
                CASE
                    WHEN f.lead_month < 10::double precision THEN (f.lead_year::text || '0'::text) || f.lead_month::text
                    ELSE f.lead_year::text || f.lead_month::text
                END AS lead_month_year,
            f.week_start,
            f.week_start_current,
            f.country_code,
            COALESCE(f.agent_name, 'other'::character varying) AS agent_name,
            f.team,
            f.type,
            f.cp_name,
            f.network,
            f.offer,
            f.pub,
            f.createdate,
            f.rpl_target,
            f.max_cap,
            f.optimum_cap,
            f.dr_mrp,
            f.aov_mrp,
            f.inrangeforecast,
            f.contactable_leads,
            f.trash,
            f.new_lead,
            f.leads,
            f.total_approved_postback,
            f.validated,
            f.validated_amount,
            f.resell_act_revenue,
            f.delivered,
            f.finalized_do,
            f.payout,
            rate.exchange AS exchange_rate,
            dt."AR_QA" AS deal_armrp,
            dt."AOV_MRP" AS deal_aov_mrp,
            0.0::double precision AS deal_spl_target,
            dt."DR_MRP" AS deal_dr_mrp,
            COALESCE(am.ar_mrp, am_2.ar_mrp) AS ar_target_mrp
           FROM final_ f
             LEFT JOIN dim_dr_manual_forecast ddfm ON f.geo_2 = ddfm.country_code AND f.network::text = ddfm.network AND f.offer::text = ddfm.offer AND f.createdate >= ddfm."from" AND f.createdate <= ddfm."to"
             LEFT JOIN cdm_dim_dr_forecast_by_date cddfbd ON f.country_code = cddfbd.geo AND f.cp_name::text = cddfbd.category AND f.offer::text = cddfbd.product_name AND f.network::text = cddfbd.network AND f.pub::text = cddfbd.pub
             LEFT JOIN dim_exchange_rate rate ON rate.geo = f.country_code AND f.createdate >= rate.started_date::date AND f.createdate <= rate.ending_date::date
             LEFT JOIN dim_follow_up_deal_target dt ON
                CASE
                    WHEN f.geo::text = 'VNID'::text THEN f.geo::text
                    ELSE f.country_code
                END = dt."Geo" AND dt."Pub" = f.network::text AND lower(dt."Offer") = f.offer::text AND f.createdate >= dt."Start date" AND f.createdate <= dt."end date"
             LEFT JOIN cte_ar_mrps am ON am.org_id = f.geo_id AND
                CASE
                    WHEN f.pub::text = ''::text THEN concat(f.network, '_', 'blank', '_', f.offer)
                    ELSE concat(f.network, '_', f.pub, '_', f.offer)
                END = am.target_key AND f.createdate >= am.started_date AND f.createdate <= am.ending_date
             LEFT JOIN cte_ar_mrps am_2 ON am_2.org_id = f.geo_id AND concat(f.network, '_', f.offer) = am_2.target_key AND f.createdate >= am_2.started_date AND f.createdate <= am_2.ending_date
        )
 SELECT cte_final.dr_final,
    cte_final.geo,
    cte_final.lead_week,
    cte_final.lead_month,
    cte_final.lead_year,
    cte_final."Week",
    cte_final."Month",
    cte_final.lead_week_year,
    cte_final.lead_month_year,
    cte_final.week_start,
    cte_final.week_start_current,
    cte_final.country_code,
    cte_final.agent_name,
    cte_final.team,
    cte_final.type,
    cte_final.cp_name,
    cte_final.network,
    cte_final.offer,
    cte_final.pub,
    cte_final.createdate,
    cte_final.rpl_target,
    cte_final.max_cap,
    cte_final.optimum_cap,
    cte_final.dr_mrp,
    cte_final.aov_mrp,
    cte_final.inrangeforecast,
    cte_final.contactable_leads,
    cte_final.trash,
    cte_final.new_lead,
    cte_final.leads,
    cte_final.total_approved_postback,
    cte_final.validated,
    cte_final.validated_amount,
    cte_final.resell_act_revenue,
    cte_final.delivered,
    cte_final.finalized_do,
    cte_final.payout,
    cte_final.exchange_rate,
    cte_final.deal_armrp,
    cte_final.deal_aov_mrp,
    cte_final.deal_spl_target,
    cte_final.deal_dr_mrp,
    cte_final.ar_target_mrp
   FROM cte_final
WITH DATA;
