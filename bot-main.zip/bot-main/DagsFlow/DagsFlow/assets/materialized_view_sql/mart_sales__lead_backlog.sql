with
    find_cases_in_last_8_day as (
        select
            geo,
            lead_product_name,
            campaign_name,
            case
                when extract(hour from lead_date) >= 22
                then lead_date::date + interval '1' day
                else lead_date::date
            end as effective_date
        from "tms_central"."dareport"."fact__lead_sales_delivery"
        where
            lead_type = 'A'
            and lead_date >= now()::date - interval '8' day
            and not (
                extract(hour from lead_date) >= 7 and extract(hour from lead_date) < 22
            )
    )
select
    geo,
    effective_date::date,
    campaign_name as "Campaign",
    lead_product_name as "Product",
    count(*) as lead_count
from find_cases_in_last_8_day
group by 1, 2, 3, 4
