with
    __dbt__cte__stg_fact__item as (

        select *
        from "tms_central"."public"."od_so_item"
        where item_no is not null and createdate is not null
    ),
    __dbt__cte__base_fact__item as (
        with
            product as (select * from "tms_central"."public"."pd_product"),
            denorm_with_product as (
                select
                    item.geo,
                    item.oi_id,
                    item.so_id,
                    item.prod_id,
                    product.name as product_name,
                    lpad(item.item_no::text, 2, '0') as item_no,
                    item.quantity as item_quantity,
                    item.price as item_price,
                    item.amount as total_amount,
                    createdate as row_created_time
                from __dbt__cte__stg_fact__item as item
                left join
                    product on item.geo = product.geo and item.prod_id = product.prod_id
            )
        select *
        from denorm_with_product
    ),
    __dbt__cte__stg_dim__product_cost as (
        select
            left(upper(geo), 2) as fin_geo,
            upper(product) as fin_name,
            start_date,
            ending_date,
            unit_cost_local_currenncy as unit_cost_local_cur
        from "tms_central"."dareport"."dim_production_cost"
    ),
    item as (select * from __dbt__cte__base_fact__item as fact_item),
    big_fact as (
        select * from "tms_central"."dareport"."fact__lead_sales_delivery" as fact
    ),
    name_map as (
        select
            upper(left(geo, 2)) as fin_geo,
            offer as tms_name,
            upper(product_name) as fin_name
        from "tms_central"."dareport"."dim_finance_product_salescamp"
        group by 1, 2, 3
    ),
    cost_map as (select * from __dbt__cte__stg_dim__product_cost),
    fact_with_cost as (
        select
            item.*,
            lead_id,
            names.fin_name as fin_name,
            so_date,
            costs_sales.unit_cost_local_cur
            as unit_cost_local_cur_by_sales_created_time,
            lead_date,
            costs_lead.unit_cost_local_cur as unit_cost_local_cur_by_lead_created_time
        from item
        left join big_fact on item.geo = big_fact.geo and item.so_id = big_fact.so_id
        left join
            name_map as names
            on starts_with(item.geo, names.fin_geo)
            and item.product_name = names.tms_name
        left join
            cost_map as costs_sales
            on names.fin_geo = costs_sales.fin_geo
            and names.fin_name = costs_sales.fin_name
            and big_fact.so_date::date
            between costs_sales.start_date and costs_sales.ending_date
        left join
            cost_map as costs_lead
            on names.fin_geo = costs_lead.fin_geo
            and names.fin_name = costs_lead.fin_name
            and big_fact.lead_date::date
            between costs_lead.start_date and costs_lead.ending_date
    )
select *
from fact_with_cost
