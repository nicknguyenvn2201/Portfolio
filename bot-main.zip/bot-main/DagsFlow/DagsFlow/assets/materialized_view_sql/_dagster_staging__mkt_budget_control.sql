-- dareport."_dagster_staging__mkt_budget_control" source

CREATE OR REPLACE VIEW dareport."_dagster_staging__mkt_budget_control"
AS WITH cte_ar_mrps AS (
         SELECT ar_mrps.affiliate_id AS network,
            ar_mrps.offer_id AS product_name,
                CASE
                    WHEN lower(ar_mrps.sub_id) = '*'::text THEN ''::text
                    WHEN lower(ar_mrps.sub_id) = ''::text THEN 'blank'::text
                    ELSE ar_mrps.sub_id
                END AS sub_id,
            ar_mrps.ar_mrp,
            ar_mrps.applied_from_date::date AS started_date,
            ar_mrps.applied_to_date::date AS ending_date,
                CASE
                    WHEN lower(ar_mrps.sub_id) = '*'::text THEN concat(ar_mrps.affiliate_id, '_', ar_mrps.offer_id)
                    WHEN lower(ar_mrps.sub_id) = ''::text THEN concat(ar_mrps.affiliate_id, '_', 'blank', '_', ar_mrps.offer_id)
                    ELSE concat(ar_mrps.affiliate_id, '_', ar_mrps.sub_id, '_', ar_mrps.offer_id)
                END AS target_key
           FROM ar_mrps
        ), base AS (
         SELECT row_number() OVER (PARTITION BY lead_mrps.affiliate_id, lead_mrps.offer_id, lead_mrps.sub_id ORDER BY lead_mrps.applied_to_date DESC) AS rn,
            lead_mrps.affiliate_id AS network,
            lead_mrps.offer_id AS product_name,
                CASE
                    WHEN lower(lead_mrps.sub_id) = '*'::text THEN ''::text
                    WHEN lower(lead_mrps.sub_id) = ''::text THEN 'blank'::text
                    ELSE lead_mrps.sub_id
                END AS sub_id,
            lead_mrps.lead_mrp,
            lead_mrps.applied_from_date::date AS started_date,
            lead_mrps.applied_to_date::date AS ending_date,
                CASE
                    WHEN lead_mrps.applied_to_date::date < (date_trunc('month'::text, now()) + '1 mon -1 days'::interval) THEN 1
                    ELSE 0
                END AS flag,
            date_part('day'::text, date_trunc('month'::text, now()) + '1 mon -1 days'::interval - now()) AS interval_,
                CASE
                    WHEN lower(lead_mrps.sub_id) = '*'::text THEN concat(lead_mrps.affiliate_id, '_', lead_mrps.offer_id)
                    WHEN lower(lead_mrps.sub_id) = ''::text THEN concat(lead_mrps.affiliate_id, '_', 'blank', '_', lead_mrps.offer_id)
                    ELSE concat(lead_mrps.affiliate_id, '_', lead_mrps.sub_id, '_', lead_mrps.offer_id)
                END AS target_key
           FROM lead_mrps
        ), transform_cte AS (
         SELECT base.network,
            base.product_name,
            generate_series(base.started_date::timestamp with time zone, base.ending_date::timestamp with time zone, '1 day'::interval) AS lead_mrp_date,
            base.lead_mrp
           FROM base
          WHERE base.sub_id = ''::text AND base.flag = 1
          ORDER BY base.network, base.product_name, base.started_date
        ), l7d AS (
         SELECT transform_cte.network,
            transform_cte.product_name,
            avg(transform_cte.lead_mrp) AS lead_mrp_last_7d
           FROM transform_cte
          WHERE transform_cte.lead_mrp_date >= (CURRENT_DATE - 6) AND transform_cte.lead_mrp_date <= CURRENT_DATE
          GROUP BY transform_cte.network, transform_cte.product_name
        ), cte_lead_mrps AS (
         SELECT b.lead_mrp_last_7d,
            a_1.rn,
            a_1.network,
            a_1.product_name,
            a_1.sub_id,
            a_1.lead_mrp,
            a_1.started_date,
            a_1.ending_date,
            a_1.flag,
            a_1.interval_,
            a_1.target_key,
                CASE
                    WHEN a_1.rn = 1 AND a_1.ending_date >= (CURRENT_DATE - 6) THEN COALESCE(a_1.lead_mrp, b.lead_mrp_last_7d)::double precision * a_1.interval_
                    ELSE 0::double precision
                END AS remaining_lead_mrp_target
           FROM base a_1
             LEFT JOIN l7d b ON a_1.network = b.network AND a_1.product_name = b.product_name AND a_1.ending_date >= (CURRENT_DATE - 6) AND a_1.flag = 1 AND a_1.rn = 1
        ), roi_cte AS (
         SELECT date_part('day'::text, now() - roi_1.createdate::timestamp with time zone) - 1::double precision AS aging,
            roi_1.lead_year,
            roi_1.createdate AS lead_date,
            roi_1.network,
            roi_1.pub,
            roi_1.sale_campaign AS cam_lead,
            roi_1.offer AS product_name,
            roi_1.total_lead,
            roi_1.trash,
            roi_1.approved,
            roi_1.validated,
            roi_1.amt_validated,
            roi_1.delivered,
            roi_1.finalized_do,
            roi_1.amt_delivered,
            roi_1.unfinish,
            roi_1.amt_unfinish,
            roi_1.payout,
            roi_1.max_po,
            roi_1.geo,
            roi_1.cpl_lead,
            roi_1.total_approved_postback,
            roi_1.total_pending_postback,
            roi_1.country_code,
            gm.tax_rate,
            gm.tele_rate,
            gm.commission_rate,
            gm.bd_comm_rate,
            uc.unit_cost,
            lc.ffm_fee,
            lc.lm_fee,
            lc.return_rate,
            lc.cod_rate,
            lc.portion,
            date_part('week'::text, roi_1.createdate + '1 day'::interval) AS lead_week,
            date_part('month'::text, roi_1.createdate + '1 day'::interval) AS lead_month,
            COALESCE(dim_mkt_1.mkt_expense_target, dim_mkt.mkt_expense_target, dim_mkt_2.mkt_expense_target) AS mkt_expense_target,
            COALESCE(am.ar_mrp, am_2.ar_mrp) AS ar_target,
            lm_2.lead_mrp,
            lm_2.remaining_lead_mrp_target,
            lm_2.started_date,
            lm_2.ending_date,
            concat(roi_1.network, '_', roi_1.offer) AS concat,
            dim_at_2.target_key,
            rate.exchange,
                CASE
                    WHEN roi_1.offer::text ~~ '%rosta%X%'::text THEN 'prostaniX -'::text::character varying
                    ELSE roi_1.offer
                END AS product_fn,
                CASE
                    WHEN roi_1.geo::text ^@ 'VN'::text AND (date_trunc('week'::text, roi_1.createdate + '1 day'::interval) - '1 day'::interval)::date >= ((date_trunc('week'::text, CURRENT_DATE + '1 day'::interval) - '1 day'::interval)::date - 14) THEN 1
                    WHEN roi_1.geo::text ^@ 'ID'::text AND (date_trunc('week'::text, roi_1.createdate + '1 day'::interval) - '1 day'::interval)::date >= ((date_trunc('week'::text, CURRENT_DATE + '1 day'::interval) - '1 day'::interval)::date - 21) AND (date_trunc('week'::text, roi_1.createdate + '1 day'::interval) - '1 day'::interval)::date >= '2023-01-08'::date THEN 1
                    WHEN roi_1.geo::text ^@ 'TH'::text AND (date_trunc('week'::text, roi_1.createdate + '1 day'::interval) - '1 day'::interval)::date >= ((date_trunc('week'::text, CURRENT_DATE + '1 day'::interval) - '1 day'::interval)::date - 7) THEN 1
                    WHEN roi_1.geo::text ^@ 'MY'::text AND (date_trunc('week'::text, roi_1.createdate + '1 day'::interval) - '1 day'::interval)::date >= ((date_trunc('week'::text, CURRENT_DATE + '1 day'::interval) - '1 day'::interval)::date - 14) THEN 1
                    WHEN roi_1.geo::text ^@ 'PH'::text AND (date_trunc('week'::text, roi_1.createdate + '1 day'::interval) - '1 day'::interval)::date >= ((date_trunc('week'::text, CURRENT_DATE + '1 day'::interval) - '1 day'::interval)::date - 7) THEN 1
                    ELSE 0
                END AS inrangeforecast
           FROM ( SELECT bd_master_filter.createdate,
                    bd_master_filter.lead_week,
                    bd_master_filter.lead_month,
                    bd_master_filter.lead_year,
                    bd_master_filter.current_week,
                    bd_master_filter.week_start,
                    bd_master_filter.week_start_current,
                    bd_master_filter.geo,
                    bd_master_filter.geo_bd,
                    bd_master_filter.country_code,
                    bd_master_filter.approved_pb,
                    bd_master_filter.total_approved_postback,
                    bd_master_filter.total_pending_postback,
                    bd_master_filter.offer,
                    bd_master_filter.geo_2,
                    bd_master_filter.network,
                    bd_master_filter.province_id,
                    bd_master_filter.advertiser,
                    bd_master_filter.category,
                    bd_master_filter.pub,
                    bd_master_filter.sale_campaign,
                    bd_master_filter.carrier,
                    bd_master_filter.agc_id,
                    bd_master_filter.paymentmethod,
                    bd_master_filter.validated_qty,
                    bd_master_filter.tax_rate,
                    bd_master_filter.tele_rate,
                    bd_master_filter.commission_rate,
                    bd_master_filter.bd_comm_rate,
                    bd_master_filter.unit_cost,
                    bd_master_filter.ffm_fee,
                    bd_master_filter.lm_fee,
                    bd_master_filter.return_rate,
                    bd_master_filter.cod_rate,
                    bd_master_filter.portion,
                    bd_master_filter.manager,
                    bd_master_filter."Team",
                    bd_master_filter."AOV_TARGET",
                    bd_master_filter.aov_target_2,
                    bd_master_filter."DR_TARGET",
                    bd_master_filter."Daily_approved_Target",
                    bd_master_filter.target_tracking_estimate_daily_lead,
                    bd_master_filter.target_tracking_daily_approved_lead,
                    bd_master_filter.target_tracking_daily_delivered_lead,
                    bd_master_filter.aff_revenue_target,
                    bd_master_filter.aff_revenue_target_by_geo,
                    bd_master_filter.ar_target_mrp,
                    bd_master_filter.lead_mrp,
                    bd_master_filter.lead_mrp_started_date,
                    bd_master_filter.lead_mrp_ending_date,
                    bd_master_filter.pub_lead_mrp,
                    bd_master_filter.pub_lead_mrp_started_date,
                    bd_master_filter.pub_lead_mrp_ending_date,
                    bd_master_filter.mkt_expense_target,
                    bd_master_filter.inrangeforecast,
                    bd_master_filter.total_lead,
                    bd_master_filter.trash,
                    bd_master_filter.approved,
                    bd_master_filter.e_approved,
                    bd_master_filter.rejected,
                    bd_master_filter.contactable,
                    bd_master_filter.uncall,
                    bd_master_filter.validated,
                    bd_master_filter.cpl_lead,
                    bd_master_filter.amt_validated,
                    bd_master_filter.amt_validated_pb,
                    bd_master_filter.delivered,
                    bd_master_filter.finalized_do,
                    bd_master_filter.delivered_pb,
                    bd_master_filter.amt_delivered,
                    bd_master_filter.amt_delivered_pb,
                    bd_master_filter.unfinish,
                    bd_master_filter.unfinish_pb,
                    bd_master_filter.amt_unfinish,
                    bd_master_filter.amt_unfinish_pb,
                    bd_master_filter.payout,
                    bd_master_filter.max_po,
                    bd_master_filter.traffic_cost,
                    bd_master_filter.avg_call,
                    bd_master_filter.avg_num_uncall,
                    bd_master_filter.total_actual_call,
                    bd_master_filter.total_actual_uncall,
                    bd_master_filter.exchange_rate,
                    bd_master_filter.traffic_source,
                    bd_master_filter.tr,
                    bd_master_filter.ar_qa,
                    bd_master_filter.ar_qc,
                    bd_master_filter.dr,
                    bd_master_filter.dr_pb,
                    bd_master_filter.gap_po,
                    bd_master_filter.aov,
                    bd_master_filter.aov_pb,
                    bd_master_filter.amt_validated_usd,
                    bd_master_filter.amt_validated_pb_usd,
                    bd_master_filter.aov_delivered,
                    bd_master_filter.aov_delivered_pb,
                    bd_master_filter.amt_delivered_usd,
                    bd_master_filter.amt_delivered_pb_usd,
                    bd_master_filter.aff_revenue,
                    bd_master_filter.aff_revenue_pb,
                    bd_master_filter.dr_final,
                    bd_master_filter.dr_final_pb,
                    bd_master_filter.gap_val,
                    bd_master_filter.aff_revenue_fc
                   FROM bd_master_filter
                  WHERE bd_master_filter.createdate >= '2024-01-01'::date) roi_1
             LEFT JOIN ( SELECT dim_mkt_exp_target.geo,
                    dim_mkt_exp_target.product_name,
                    dim_mkt_exp_target.category,
                    dim_mkt_exp_target.network,
                    dim_mkt_exp_target."Pub",
                    dim_mkt_exp_target.mkt_expense_target,
                    dim_mkt_exp_target.week_num_target,
                    dim_mkt_exp_target.started_date,
                    dim_mkt_exp_target.ending_date,
                    dim_mkt_exp_target."Rank",
                    dim_mkt_exp_target.last_update,
                        CASE
                            WHEN dim_mkt_exp_target.network IS NOT NULL AND dim_mkt_exp_target."Pub" IS NOT NULL THEN concat(dim_mkt_exp_target.product_name, '_', dim_mkt_exp_target.network, '_', dim_mkt_exp_target."Pub")
                            ELSE 'no_key'::text
                        END AS key_1,
                        CASE
                            WHEN dim_mkt_exp_target.network IS NULL AND dim_mkt_exp_target."Pub" IS NULL AND dim_mkt_exp_target.product_name IS NOT NULL THEN dim_mkt_exp_target.product_name
                            ELSE 'no_key'::text
                        END AS key_2,
                        CASE
                            WHEN dim_mkt_exp_target.network IS NULL AND dim_mkt_exp_target."Pub" IS NULL AND dim_mkt_exp_target.product_name IS NULL THEN dim_mkt_exp_target.geo
                            ELSE 'no_key'::text
                        END AS key_3
                   FROM dim_mkt_exp_target) dim_mkt ON lower(roi_1.offer::text) = lower(dim_mkt.key_2) AND roi_1.createdate >= dim_mkt.started_date::date AND roi_1.createdate <= dim_mkt.ending_date::date
             LEFT JOIN ( SELECT dim_mkt_exp_target.geo,
                    dim_mkt_exp_target.product_name,
                    dim_mkt_exp_target.category,
                    dim_mkt_exp_target.network,
                    dim_mkt_exp_target."Pub",
                    dim_mkt_exp_target.mkt_expense_target,
                    dim_mkt_exp_target.week_num_target,
                    dim_mkt_exp_target.started_date,
                    dim_mkt_exp_target.ending_date,
                    dim_mkt_exp_target."Rank",
                    dim_mkt_exp_target.last_update,
                        CASE
                            WHEN dim_mkt_exp_target.network IS NOT NULL AND dim_mkt_exp_target."Pub" IS NOT NULL THEN concat(dim_mkt_exp_target.product_name, '_', dim_mkt_exp_target.network, '_', dim_mkt_exp_target."Pub")
                            ELSE 'no_key'::text
                        END AS key_1,
                        CASE
                            WHEN dim_mkt_exp_target.network IS NULL AND dim_mkt_exp_target."Pub" IS NULL AND dim_mkt_exp_target.product_name IS NOT NULL THEN dim_mkt_exp_target.product_name
                            ELSE 'no_key'::text
                        END AS key_2,
                        CASE
                            WHEN dim_mkt_exp_target.network IS NULL AND dim_mkt_exp_target."Pub" IS NULL AND dim_mkt_exp_target.product_name IS NULL THEN dim_mkt_exp_target.geo
                            ELSE 'no_key'::text
                        END AS key_3
                   FROM dim_mkt_exp_target) dim_mkt_1 ON lower(concat(roi_1.offer, '_', roi_1.network, '_', roi_1.pub)) = lower(dim_mkt_1.key_1) AND roi_1.createdate >= dim_mkt_1.started_date::date AND roi_1.createdate <= dim_mkt_1.ending_date::date
             LEFT JOIN ( SELECT dim_mkt_exp_target.geo,
                    dim_mkt_exp_target.product_name,
                    dim_mkt_exp_target.category,
                    dim_mkt_exp_target.network,
                    dim_mkt_exp_target."Pub",
                    dim_mkt_exp_target.mkt_expense_target,
                    dim_mkt_exp_target.week_num_target,
                    dim_mkt_exp_target.started_date,
                    dim_mkt_exp_target.ending_date,
                    dim_mkt_exp_target."Rank",
                    dim_mkt_exp_target.last_update,
                        CASE
                            WHEN dim_mkt_exp_target.network IS NOT NULL AND dim_mkt_exp_target."Pub" IS NOT NULL THEN concat(dim_mkt_exp_target.product_name, '_', dim_mkt_exp_target.network, '_', dim_mkt_exp_target."Pub")
                            ELSE 'no_key'::text
                        END AS key_1,
                        CASE
                            WHEN dim_mkt_exp_target.network IS NULL AND dim_mkt_exp_target."Pub" IS NULL AND dim_mkt_exp_target.product_name IS NOT NULL THEN dim_mkt_exp_target.product_name
                            ELSE 'no_key'::text
                        END AS key_2,
                        CASE
                            WHEN dim_mkt_exp_target.network IS NULL AND dim_mkt_exp_target."Pub" IS NULL AND dim_mkt_exp_target.product_name IS NULL THEN dim_mkt_exp_target.geo
                            ELSE 'no_key'::text
                        END AS key_3
                   FROM dim_mkt_exp_target) dim_mkt_2 ON
                CASE
                    WHEN roi_1.geo::text ^@ 'TH'::text THEN 'TH'::character varying
                    WHEN roi_1.geo::text ^@ 'VN'::text THEN 'VN'::character varying
                    WHEN roi_1.geo::text ^@ 'ID'::text THEN 'ID'::character varying
                    ELSE roi_1.geo
                END::text = dim_mkt_2.key_3 AND roi_1.createdate >= dim_mkt_2.started_date::date AND roi_1.createdate <= dim_mkt_2.ending_date::date
             LEFT JOIN cdm_dim_ar_mrp_target_by_date dim_at ON
                CASE
                    WHEN roi_1.pub::text = 'No PubID'::text THEN concat(roi_1.network, '_', roi_1.offer)
                    ELSE concat(roi_1.network, '_', roi_1.pub, '_', roi_1.offer)
                END = dim_at.target_key AND roi_1.createdate >= dim_at.started_date::date AND roi_1.createdate <= dim_at.ending_date::date
             LEFT JOIN cdm_dim_ar_mrp_target_by_date dim_at_2 ON concat(roi_1.network, '_', roi_1.offer) = dim_at_2.target_key AND roi_1.createdate >= dim_at_2.started_date::date AND roi_1.createdate <= dim_at_2.ending_date::date
             LEFT JOIN cte_ar_mrps am ON
                CASE
                    WHEN roi_1.pub::text = ''::text THEN concat(roi_1.network, '_', 'blank', '_', roi_1.offer)
                    ELSE concat(roi_1.network, '_', roi_1.pub, '_', roi_1.offer)
                END = am.target_key AND roi_1.createdate >= am.started_date AND roi_1.createdate <= am.ending_date
             LEFT JOIN cte_ar_mrps am_2 ON concat(roi_1.network, '_', roi_1.offer) = am_2.target_key AND roi_1.createdate >= am_2.started_date AND roi_1.createdate <= am_2.ending_date
             LEFT JOIN cte_lead_mrps lm_1 ON
                CASE
                    WHEN roi_1.pub::text = ''::text THEN concat(roi_1.network, '_', 'blank', '_', roi_1.offer)
                    ELSE concat(roi_1.network, '_', roi_1.pub, '_', roi_1.offer)
                END = lm_1.target_key AND roi_1.createdate >= lm_1.started_date AND roi_1.createdate <= lm_1.ending_date
             LEFT JOIN cte_lead_mrps lm_2 ON concat(roi_1.network, '_', roi_1.offer) = lm_2.target_key AND roi_1.createdate >= lm_2.started_date AND roi_1.createdate <= lm_2.ending_date
             LEFT JOIN dim_exchange_rate rate ON rate.geo =
                CASE
                    WHEN roi_1.geo::text ^@ 'TH'::text THEN 'TH'::character varying
                    WHEN roi_1.geo::text ^@ 'VN'::text THEN 'VN'::character varying
                    WHEN roi_1.geo::text ^@ 'ID'::text THEN 'ID'::character varying
                    ELSE roi_1.geo
                END::text AND roi_1.createdate >= rate.started_date AND roi_1.createdate <= rate.ending_date
             LEFT JOIN dim_bd_gm_input gm ON gm.geo =
                CASE
                    WHEN roi_1.geo::text ^@ 'TH'::text THEN 'TH'::character varying
                    WHEN roi_1.geo::text ^@ 'VN'::text THEN 'VN'::character varying
                    WHEN roi_1.geo::text ^@ 'ID'::text THEN 'ID'::character varying
                    ELSE roi_1.geo
                END::text AND roi_1.createdate >= gm.started_date::date AND roi_1.createdate <= gm.ending_date::date
             LEFT JOIN dim_bd_unit_cost uc ON btrim(lower(uc.offer)) = lower(roi_1.offer::text) AND uc.geo =
                CASE
                    WHEN roi_1.geo::text ^@ 'TH'::text THEN 'TH'::character varying
                    WHEN roi_1.geo::text ^@ 'VN'::text THEN 'VN'::character varying
                    WHEN roi_1.geo::text ^@ 'ID'::text THEN 'ID'::character varying
                    ELSE roi_1.geo
                END::text AND roi_1.createdate >= uc.started_date::date AND roi_1.createdate <= uc.ending_date::date
             LEFT JOIN dim_bd_log_cost lc ON lc.geo =
                CASE
                    WHEN roi_1.geo::text ^@ 'TH'::text THEN 'TH'::character varying
                    WHEN roi_1.geo::text ^@ 'VN'::text THEN 'VN'::character varying
                    WHEN roi_1.geo::text ^@ 'ID'::text THEN 'ID'::character varying
                    ELSE roi_1.geo
                END::text AND roi_1.createdate >= lc.started_date::date AND roi_1.createdate <= lc.ending_date::date
        ), cte_drfc_aging AS (
         SELECT fd.geo,
            fd.lead_date::date AS lead_date,
            fd.source,
            fd.offer_product,
            fd.sale_camp,
            count(DISTINCT
                CASE
                    WHEN fd.orderstatus::text = ANY (ARRAY['validated'::character varying::text, 'delay'::character varying::text]) THEN fd.leadid
                    ELSE NULL::text
                END) AS validated,
            sum(fd.dr) AS delivered_fc_aging,
                CASE
                    WHEN sum(fd.dr) = 0::double precision OR count(DISTINCT
                    CASE
                        WHEN fd.orderstatus::text = ANY (ARRAY['validated'::character varying::text, 'delay'::character varying::text]) THEN fd.leadid
                        ELSE NULL::text
                    END) = 0 THEN 0::double precision
                    ELSE sum(fd.dr) / count(DISTINCT
                    CASE
                        WHEN fd.orderstatus::text = ANY (ARRAY['validated'::character varying::text, 'delay'::character varying::text]) THEN fd.leadid
                        ELSE NULL::text
                    END)::double precision
                END AS dr_forecast_aging
           FROM finance_daily_view fd
          WHERE fd.leadtypename = 'Fresh'::text AND fd.aging <=
                CASE
                    WHEN fd.geo = 'VN'::text THEN 22
                    WHEN fd.geo = 'ID'::text THEN 28
                    WHEN fd.geo = 'TH'::text THEN 17
                    WHEN fd.geo = 'PH'::text THEN 17
                    WHEN fd.geo = 'MY'::text THEN 15
                    ELSE NULL::integer
                END
          GROUP BY (fd.lead_date::date), fd.source, fd.offer_product, fd.sale_camp, fd.geo
        ), final AS (
         SELECT dlcrp."Lead Target",
            dlcrp."Validated target",
            dlcrp."DR target",
            dlcrp."AOV target",
            dlcrp."Revenue target",
            dlcrp."Lead cost Plan",
            roi.aging,
            roi.lead_date,
            roi.lead_year,
            roi.remaining_lead_mrp_target,
            roi.network,
            roi.pub,
            roi.cam_lead,
            roi.product_name,
            roi.total_lead,
            roi.trash,
            roi.approved,
            roi.validated,
            roi.amt_validated,
            roi.delivered,
            roi.finalized_do,
            roi.amt_delivered,
            roi.unfinish,
            roi.amt_unfinish,
            roi.payout,
            roi.max_po,
                CASE
                    WHEN roi.geo::text = 'ID2'::text THEN 'ID'::character varying
                    ELSE roi.geo
                END AS geo,
            roi.country_code,
            roi.cpl_lead,
            roi.tax_rate,
            roi.tele_rate,
            roi.commission_rate,
            roi.bd_comm_rate,
            roi.unit_cost,
            roi.ffm_fee,
            roi.lm_fee,
            roi.return_rate,
            roi.cod_rate,
            roi.portion,
            roi.lead_week,
            roi.lead_month,
            roi.mkt_expense_target,
            roi.ar_target,
            roi.lead_mrp,
            roi.started_date,
            roi.ending_date,
            roi.concat,
            roi.target_key,
            roi.exchange,
            roi.product_fn,
            roi.inrangeforecast,
            NULL::text AS latest_ar_target,
            COALESCE(ddfm.dr_forecast, COALESCE(
                CASE
                    WHEN roi.inrangeforecast = 3 THEN cddfbd.dr_forecast_final3
                    ELSE
                    CASE
                        WHEN roi.inrangeforecast = 2 THEN cddfbd.dr_forecast_final2
                        ELSE
                        CASE
                            WHEN roi.inrangeforecast = 1 THEN cddfbd.dr_forecast_final
                            ELSE
                            CASE
                                WHEN roi.validated = 0 THEN 0::double precision
                                ELSE roi.delivered::double precision / roi.validated::double precision
                            END
                        END
                    END
                END,
                CASE
                    WHEN roi.validated = 0 THEN 0::double precision
                    ELSE roi.delivered::double precision / roi.validated::double precision
                END)) AS dr_final,
            drfca.delivered_fc_aging,
            drfca.dr_forecast_aging,
            mbp.spl_plan,
            mbp.lead_cost_budget,
            mbp.mkt_budget,
            mbd.spl_plan AS spl_plan_def,
            mbd.lead_cost_budget AS lead_cost_budget_def,
            mbd.mkt_budget AS mkt_budget_def,
                CASE
                    WHEN va.affiliate_id IS NOT NULL THEN 1
                    ELSE 0
                END AS vip_pub,
            df."AR Forecast",
            df."AOV Forecast",
            df."DR_Forecast",
            df."SPL Forecast",
            df."%Lead cost FC",
            df."%GM1 FC",
            df."%GM2 FC",
            dt."Lead MRP" AS deal_lead_mrp,
            dt."AR_MRP" AS deal_armrp,
            dt."AOV_MRP" AS deal_aov_mrp,
            dt."SPL target" AS deal_spl_target,
            dt."DR_MRP" AS deal_dr_mrp,
            dt."%Lead cost MRP" AS deal_lead_cost_mrp,
            dt."%GM1 MRP" AS deal_gm1_mrp,
            dt."%GM2 MRP" AS deal_gm2_mrp,
                CASE
                    WHEN btrim(dt."Type") ^@ 'CPL'::text THEN 'CPL'::text
                    ELSE 'CPA'::text
                END AS deal_type,
            sfpsc.cost_usd,
            dfblc.logistics_cost_per_validated_order_usd,
            dmbtc.lead_target AS camp_lead_target,
            dmbtc.spl_target AS camp_spl_target,
            dmbtc.percentage_lead_cost_target AS camp_percentage_lead_cost_target,
            dmbtg.lead_target AS geo_lead_target,
            dmbtg.spl_target AS geo_spl_target,
            dmbtg.percentage_lead_cost_target AS geo_percentage_lead_cost_target,
            dmbto.lead_target AS offer_lead_target,
            dmbto.spl_target AS offer_spl_target,
            dmbto.percentage_lead_cost_target AS offer_percentage_lead_cost_target,
            dfgt.lead_cost_target AS geo_lead_cost_target,
            dfgt.ar_qa_plan AS geo_ar_qa_plan,
            dfgt.dr_mrp AS geo_dr_mrp,
            dfgt.aov_mrp AS geo_aov_mrp,
            dfct.lead_cost_target AS camp_lead_cost_target,
            dfct.ar_qa_plan AS camp_ar_qa_plan,
            dfct.dr_mrp AS camp_dr_mrp,
            dfct.aov_mrp AS camp_aov_mrp,
            dfot.lead_cost_target AS offer_lead_cost_target,
            dfot.ar_qa_plan AS offer_ar_qa_plan,
            dfot.dr_mrp AS offer_dr_mrp,
            dfot.aov_mrp AS offer_aov_mrp,
            dct.spl_mrp,
            roi.total_approved_postback
           FROM roi_cte roi
             LEFT JOIN ( SELECT DISTINCT cdm_dim_dr_forecast_by_date.geo,
                    cdm_dim_dr_forecast_by_date.category,
                    cdm_dim_dr_forecast_by_date.product_name,
                    cdm_dim_dr_forecast_by_date.network,
                    cdm_dim_dr_forecast_by_date.pub,
                    cdm_dim_dr_forecast_by_date.validated,
                    cdm_dim_dr_forecast_by_date.delivered,
                    cdm_dim_dr_forecast_by_date.dr_forecast,
                    cdm_dim_dr_forecast_by_date.validated_by_network,
                    cdm_dim_dr_forecast_by_date.delivered_by_network,
                    cdm_dim_dr_forecast_by_date.dr_forecast_by_network,
                    cdm_dim_dr_forecast_by_date.validated_by_offer,
                    cdm_dim_dr_forecast_by_date.delivered_by_offer,
                    cdm_dim_dr_forecast_by_date.dr_forecast_by_offer,
                    cdm_dim_dr_forecast_by_date.validated_by_cat,
                    cdm_dim_dr_forecast_by_date.delivered_by_cat,
                    cdm_dim_dr_forecast_by_date.dr_forecast_by_cat,
                    cdm_dim_dr_forecast_by_date.dr_forecast_final,
                    cdm_dim_dr_forecast_by_date.validated2,
                    cdm_dim_dr_forecast_by_date.delivered2,
                    cdm_dim_dr_forecast_by_date.dr_forecast2,
                    cdm_dim_dr_forecast_by_date.validated_by_network2,
                    cdm_dim_dr_forecast_by_date.delivered_by_network2,
                    cdm_dim_dr_forecast_by_date.dr_forecast_by_network2,
                    cdm_dim_dr_forecast_by_date.validated_by_offer2,
                    cdm_dim_dr_forecast_by_date.delivered_by_offer2,
                    cdm_dim_dr_forecast_by_date.dr_forecast_by_offer2,
                    cdm_dim_dr_forecast_by_date.validated_by_cat2,
                    cdm_dim_dr_forecast_by_date.delivered_by_cat2,
                    cdm_dim_dr_forecast_by_date.dr_forecast_by_cat2,
                    cdm_dim_dr_forecast_by_date.dr_forecast_final2,
                    cdm_dim_dr_forecast_by_date.validated3,
                    cdm_dim_dr_forecast_by_date.delivered3,
                    cdm_dim_dr_forecast_by_date.dr_forecast3,
                    cdm_dim_dr_forecast_by_date.validated_by_network3,
                    cdm_dim_dr_forecast_by_date.delivered_by_network3,
                    cdm_dim_dr_forecast_by_date.dr_forecast_by_network3,
                    cdm_dim_dr_forecast_by_date.validated_by_offer3,
                    cdm_dim_dr_forecast_by_date.delivered_by_offer3,
                    cdm_dim_dr_forecast_by_date.dr_forecast_by_offer3,
                    cdm_dim_dr_forecast_by_date.validated_by_cat3,
                    cdm_dim_dr_forecast_by_date.delivered_by_cat3,
                    cdm_dim_dr_forecast_by_date.dr_forecast_by_cat3,
                    cdm_dim_dr_forecast_by_date.dr_forecast_final3
                   FROM cdm_dim_dr_forecast_by_date) cddfbd ON
                CASE
                    WHEN roi.geo::text ^@ 'TH'::text THEN 'TH'::character varying
                    WHEN roi.geo::text ^@ 'VN'::text THEN 'VN'::character varying
                    WHEN roi.geo::text ^@ 'ID'::text THEN 'ID'::character varying
                    ELSE roi.geo
                END::text = cddfbd.geo AND roi.cam_lead::text = cddfbd.category AND roi.product_name::text = cddfbd.product_name AND roi.network::text = cddfbd.network AND roi.pub::text = cddfbd.pub
             LEFT JOIN cte_drfc_aging drfca ON
                CASE
                    WHEN roi.lead_date >= '2022-09-26'::date AND roi.geo::text = 'TH2'::text THEN 'TH'::text::character varying
                    WHEN roi.lead_date >= '2023-01-01'::date AND roi.geo::text = 'VN2'::text THEN 'VN'::text::character varying
                    WHEN roi.geo::text = 'ID2'::text THEN 'ID'::text::character varying
                    ELSE roi.geo
                END::text = drfca.geo AND roi.lead_date = drfca.lead_date AND roi.cam_lead::text = drfca.sale_camp::text AND roi.product_name::text = drfca.offer_product::text AND roi.network::text = drfca.source::text
             LEFT JOIN mkt_budget_plan mbp ON roi.cam_lead::text = mbp.sales_camp AND roi.network::text = mbp.network AND roi.product_name::text = mbp.product_name AND roi.lead_date >= mbp.from_date::date AND roi.lead_date <= mbp.to_date::date
             LEFT JOIN mkt_budget_default mbd ON
                CASE
                    WHEN roi.geo::text ^@ 'TH'::text THEN 'TH'::character varying
                    WHEN roi.geo::text ^@ 'VN'::text THEN 'VN'::character varying
                    WHEN roi.geo::text ^@ 'ID'::text THEN 'ID'::character varying
                    ELSE roi.geo
                END::text = mbd.geo AND roi.cam_lead::text = mbd.sales_camp AND roi.lead_date >= mbd.from_date::date AND roi.lead_date <= mbd.to_date::date
             LEFT JOIN vip_affiliates va ON roi.network::text = va.affiliate_id AND roi.product_name::text = va.offer_id AND roi.lead_date >= va.applied_from_date::date AND roi.lead_date <= va.applied_to_date::date
             LEFT JOIN dim_follow_up_deal_target dt ON dt."Pub" = roi.network::text AND lower(dt."Offer") = lower(roi.product_name::text) AND roi.lead_date >= dt."Start date" AND roi.lead_date <= dt."end date"
             LEFT JOIN dim_follow_up_deal_forecast df ON df."Pub" = roi.network::text AND lower(df."Offer") = lower(roi.product_name::text) AND roi.lead_date >= df."Start date" AND roi.lead_date <= df."end date"
             LEFT JOIN dim_lead_cost_rev_plan dlcrp ON dlcrp."Pub" = roi.network::text AND dlcrp."Offer" = roi.product_name::text AND dlcrp."Month"::double precision = roi.lead_month AND dlcrp."Year"::double precision = roi.lead_year
             LEFT JOIN stg_fin__pretty_salary_cost sfpsc ON sfpsc.salary_cost_type = 'ibs'::text AND roi.network::text = sfpsc.network::text AND roi.product_name::text = sfpsc.offer::text AND roi.lead_date = sfpsc.lead_date AND roi.cam_lead::text = sfpsc.sale_campaign::text
             LEFT JOIN dim_finance_bd_logistics_cost dfblc ON roi.country_code = dfblc.country_code AND roi.lead_date >= dfblc.start_date AND roi.lead_date <= dfblc.end_date
             LEFT JOIN dim_mkt_budget_target_camp dmbtc ON roi.cam_lead::text = dmbtc.camp AND roi.country_code = dmbtc.geo AND roi.lead_date >= dmbtc.from_date AND roi.lead_date <= dmbtc.to_date
             LEFT JOIN dim_mkt_budget_target_geo dmbtg ON roi.country_code = dmbtg.geo AND roi.lead_date >= dmbtg.from_date AND roi.lead_date <= dmbtg.to_date
             LEFT JOIN dim_mkt_budget_target_offer dmbto ON roi.product_name::text = dmbto.offer AND roi.lead_date >= dmbto.from_date AND roi.lead_date <= dmbto.to_date
             LEFT JOIN dim_finance_geo_target dfgt ON roi.lead_year = dfgt.year_::double precision AND roi.country_code = dfgt.country_code AND dfgt.month_::double precision = roi.lead_month
             LEFT JOIN dim_finance_camp_target dfct ON roi.lead_year = dfct.year_::double precision AND roi.country_code = dfct.country_code AND dfct.month_::double precision = roi.lead_month AND dfct.sales_camp = roi.cam_lead::text
             LEFT JOIN dim_finance_offer_target dfot ON roi.lead_year = dfot.year_::double precision AND dfot.month_::double precision = roi.lead_month AND dfot.offer = roi.product_name::text
             LEFT JOIN dim_cpl_target dct ON dct.pub = roi.network::text AND dct.offer = roi.product_name::text AND roi.lead_date >= dct.from_date AND roi.lead_date <= dct.to_date
             LEFT JOIN dim_dr_manual_forecast ddfm ON roi.network::text = ddfm.network AND roi.product_name::text = ddfm.offer AND roi.lead_date >= ddfm."from" AND roi.lead_date <= ddfm."to"
        ), ranked_cte_act AS (
         SELECT row_number() OVER (PARTITION BY (mpt.report_date::date), mpt.geo, mpt.offer, mpt.network, mpt.sale_campaign ORDER BY mpt.report_date DESC) AS rn,
            mpt.id,
            mpt.report_id,
            mpt.report_date,
            mpt.created_time,
            mpt.geo,
            mpt.offer,
            mpt.network,
            mpt.sale_campaign,
            mpt.total_lead,
            mpt.lead_validated,
            mpt.lead_delivered,
            mpt.lead_cost,
            mpt.production_cost,
            mpt.production_cost_forecast,
            mpt.tele_cost,
            mpt.logistics_cost,
            mpt.agent_cost,
            mpt.lead_mrp,
            mpt.amt_validated,
            mpt.revenue,
            mpt.lead_commission_cost,
            mpt.gp1,
            mpt.gp2,
            mpt.dr,
            mpt.aov,
            mpt.gm1,
            mpt.gm2,
            mpt.mkt_budget_type,
            mpt.mkt_budget,
            mpt.group1,
            mpt.group2,
            mpt.buffer_base,
            mpt.buffer,
            mpt.final_mkt_budget,
            mpt.max_po_acceptance
           FROM actual_max_po_tracking mpt
        ), final_act AS (
         SELECT ranked_cte_act.report_date::date - 6 AS start_date,
            ranked_cte_act.report_date::date AS end_date,
            ranked_cte_act.rn,
            ranked_cte_act.id,
            ranked_cte_act.report_id,
            ranked_cte_act.report_date,
            ranked_cte_act.created_time,
            ranked_cte_act.geo,
            ranked_cte_act.offer,
            ranked_cte_act.network,
            ranked_cte_act.sale_campaign,
            ranked_cte_act.total_lead,
            ranked_cte_act.lead_validated,
            ranked_cte_act.lead_delivered,
            ranked_cte_act.lead_cost,
            ranked_cte_act.production_cost,
            ranked_cte_act.production_cost_forecast,
            ranked_cte_act.tele_cost,
            ranked_cte_act.logistics_cost,
            ranked_cte_act.agent_cost,
            ranked_cte_act.lead_mrp,
            ranked_cte_act.amt_validated,
            ranked_cte_act.revenue,
            ranked_cte_act.lead_commission_cost,
            ranked_cte_act.gp1,
            ranked_cte_act.gp2,
            ranked_cte_act.dr,
            ranked_cte_act.aov,
            ranked_cte_act.gm1,
            ranked_cte_act.gm2,
            ranked_cte_act.mkt_budget_type,
            ranked_cte_act.mkt_budget,
            ranked_cte_act.group1,
            ranked_cte_act.group2,
            ranked_cte_act.buffer_base,
            ranked_cte_act.buffer,
            ranked_cte_act.final_mkt_budget,
            ranked_cte_act.max_po_acceptance
           FROM ranked_cte_act
        ), ranked_cte AS (
         SELECT row_number() OVER (PARTITION BY (mpt.report_date::date), mpt.geo, mpt.offer, mpt.network, mpt.sale_campaign ORDER BY mpt.report_date DESC) AS rn,
            mpt.id,
            mpt.report_id,
            mpt.created_time,
            mpt.geo,
            mpt.offer,
            mpt.network,
            mpt.sale_campaign,
            mpt.total_lead,
            mpt.lead_validated,
            mpt.lead_delivered,
            mpt.lead_cost,
            mpt.production_cost,
            mpt.production_cost_forecast,
            mpt.tele_cost,
            mpt.logistics_cost,
            mpt.agent_cost,
            mpt.lead_mrp,
            mpt.amt_validated,
            mpt.revenue,
            mpt.lead_commission_cost,
            mpt.gp1,
            mpt.gp2,
            mpt.dr,
            mpt.aov,
            mpt.gm1,
            mpt.gm2,
            mpt.mkt_budget_type,
            mpt.mkt_budget,
            mpt.group1,
            mpt.group2,
            mpt.buffer_base,
            mpt.buffer,
            mpt.final_mkt_budget,
            mpt.max_po_acceptance,
            mpt.report_date
           FROM max_po_tracking mpt
        ), final_ AS (
         SELECT ranked_cte.report_date::date - 6 AS start_date,
            ranked_cte.report_date::date AS end_date,
            ranked_cte.rn,
            ranked_cte.id,
            ranked_cte.report_id,
            ranked_cte.created_time,
            ranked_cte.geo,
            ranked_cte.offer,
            ranked_cte.network,
            ranked_cte.sale_campaign,
            ranked_cte.total_lead,
            ranked_cte.lead_validated,
            ranked_cte.lead_delivered,
            ranked_cte.lead_cost,
            ranked_cte.production_cost,
            ranked_cte.production_cost_forecast,
            ranked_cte.tele_cost,
            ranked_cte.logistics_cost,
            ranked_cte.agent_cost,
            ranked_cte.lead_mrp,
            ranked_cte.amt_validated,
            ranked_cte.revenue,
            ranked_cte.lead_commission_cost,
            ranked_cte.gp1,
            ranked_cte.gp2,
            ranked_cte.dr,
            ranked_cte.aov,
            ranked_cte.gm1,
            ranked_cte.gm2,
            ranked_cte.mkt_budget_type,
            ranked_cte.mkt_budget,
            ranked_cte.group1,
            ranked_cte.group2,
            ranked_cte.buffer_base,
            ranked_cte.buffer,
            ranked_cte.final_mkt_budget,
            ranked_cte.max_po_acceptance,
            ranked_cte.report_date
           FROM ranked_cte
          WHERE ranked_cte.rn = 1
        ), max_po AS (
         SELECT fc.start_date,
            fc.end_date,
            fc.rn,
            fc.id,
            fc.report_id,
            fc.created_time,
            COALESCE(fc.geo, act.geo) AS geo,
            COALESCE(fc.offer, act.offer) AS offer,
            COALESCE(fc.network, act.network) AS network,
            COALESCE(fc.sale_campaign, act.sale_campaign) AS sale_campaign,
            fc.total_lead,
            fc.lead_validated,
            fc.lead_delivered,
            fc.lead_cost,
            fc.production_cost,
            fc.production_cost_forecast,
            fc.tele_cost,
            fc.logistics_cost,
            fc.agent_cost,
            fc.lead_mrp,
            fc.amt_validated,
            fc.revenue,
            fc.lead_commission_cost,
            fc.gp1,
            fc.gp2,
            fc.dr,
            fc.aov,
            fc.gm1,
            fc.gm2,
            fc.mkt_budget_type,
            fc.mkt_budget,
            fc.group1,
            fc.group2,
            fc.buffer_base,
            fc.buffer,
            fc.final_mkt_budget,
            fc.max_po_acceptance,
            COALESCE(act.report_date, fc.report_date) AS report_date,
            act.total_lead AS act_total_lead,
            act.lead_validated AS act_lead_validated,
            act.gp1 AS act_gp1,
            act.gp2 AS act_gp2,
            act.dr AS act_dr,
            act.aov AS act_aov,
            act.gm1 AS act_gm1,
            act.gm2 AS act_gm2,
            act.max_po_acceptance AS act_max_po_acceptance
           FROM final_ fc
             FULL JOIN final_act act ON fc.end_date = act.end_date AND fc.network::text = act.network::text AND fc.offer::text = act.offer::text AND fc.sale_campaign::text = act.sale_campaign::text
        ), a AS (
         SELECT mkt."Lead Target",
            mkt."Validated target",
            mkt."DR target",
            mkt."AOV target",
            mkt."Revenue target",
            mkt."Lead cost Plan",
            mkt.aging,
            mkt.lead_date,
            mkt.lead_year,
            mkt.remaining_lead_mrp_target,
            mkt.network,
            mkt.pub,
            mkt.cam_lead,
            mkt.product_name,
            mkt.total_lead,
            mkt.trash,
            mkt.approved,
            mkt.validated,
            mkt.amt_validated,
            mkt.delivered,
            mkt.finalized_do,
            mkt.amt_delivered,
            mkt.unfinish,
            mkt.amt_unfinish,
            mkt.payout,
            mkt.max_po,
            mkt.geo,
            mkt.country_code,
            mkt.cpl_lead,
            mkt.tax_rate,
            mkt.tele_rate,
            mkt.commission_rate,
            mkt.bd_comm_rate,
            mkt.unit_cost,
            mkt.ffm_fee,
            mkt.lm_fee,
            mkt.return_rate,
            mkt.cod_rate,
            mkt.portion,
            mkt.lead_week,
            mkt.lead_month,
            mkt.mkt_expense_target,
            mkt.ar_target,
            mkt.lead_mrp,
            mkt.started_date,
            mkt.ending_date,
            mkt.concat,
            mkt.target_key,
            mkt.exchange,
            mkt.product_fn,
            mkt.inrangeforecast,
            mkt.latest_ar_target,
            mkt.dr_final,
            mkt.delivered_fc_aging,
            mkt.dr_forecast_aging,
            mkt.spl_plan,
            mkt.lead_cost_budget,
            mkt.mkt_budget,
            mkt.spl_plan_def,
            mkt.lead_cost_budget_def,
            mkt.mkt_budget_def,
            mkt.vip_pub,
            mkt."AR Forecast",
            mkt."AOV Forecast",
            mkt."DR_Forecast",
            mkt."SPL Forecast",
            mkt."%Lead cost FC",
            mkt."%GM1 FC",
            mkt."%GM2 FC",
            mkt.deal_lead_mrp,
            mkt.deal_armrp,
            mkt.deal_aov_mrp,
            mkt.deal_spl_target,
            mkt.deal_dr_mrp,
            mkt.deal_lead_cost_mrp,
            mkt.deal_gm1_mrp,
            mkt.deal_gm2_mrp,
            mkt.deal_type,
            mkt.cost_usd,
            mkt.logistics_cost_per_validated_order_usd,
            mkt.camp_lead_target,
            mkt.camp_spl_target,
            mkt.camp_percentage_lead_cost_target,
            mkt.geo_lead_target,
            mkt.geo_spl_target,
            mkt.geo_percentage_lead_cost_target,
            mkt.offer_lead_target,
            mkt.offer_spl_target,
            mkt.offer_percentage_lead_cost_target,
            mkt.geo_lead_cost_target,
            mkt.geo_ar_qa_plan,
            mkt.geo_dr_mrp,
            mkt.geo_aov_mrp,
            mkt.camp_lead_cost_target,
            mkt.camp_ar_qa_plan,
            mkt.camp_dr_mrp,
            mkt.camp_aov_mrp,
            mkt.offer_lead_cost_target,
            mkt.offer_ar_qa_plan,
            mkt.offer_dr_mrp,
            mkt.offer_aov_mrp,
            mkt.spl_mrp,
            mkt.total_approved_postback,
            mkt.total_lead_mrp,
            mkt.do_done,
            mkt.join_key,
            mkt.geo_2,
                CASE
                    WHEN mkt.do_done::numeric > 0.9 THEN mkt.delivered::double precision
                    ELSE mkt.validated::double precision * mkt.dr_final
                END AS delivered_final,
            date_trunc('week'::text, date_trunc('week'::text, mkt.lead_date::timestamp with time zone) - '3 days'::interval) - '1 day'::interval AS week_start,
            date_trunc('week'::text, date_trunc('week'::text, mkt.lead_date::timestamp with time zone) - '3 days'::interval) + '5 days'::interval AS week_end,
            date_trunc('week'::text, date_trunc('week'::text, mkt.lead_date::timestamp with time zone) - '3 days'::interval) - '8 days'::interval AS week_start_2,
            date_trunc('week'::text, date_trunc('week'::text, mkt.lead_date::timestamp with time zone) - '3 days'::interval) + '-2 days'::interval AS week_end_2,
            date_trunc('week'::text, date_trunc('week'::text, mkt.lead_date::timestamp with time zone) - '3 days'::interval) - '15 days'::interval AS week_start_3,
            date_trunc('week'::text, date_trunc('week'::text, mkt.lead_date::timestamp with time zone) - '3 days'::interval) + '-9 days'::interval AS week_end_3,
            date_trunc('week'::text, date_trunc('week'::text, mkt.lead_date::timestamp with time zone) - '3 days'::interval) - '22 days'::interval AS week_start_4,
            date_trunc('week'::text, date_trunc('week'::text, mkt.lead_date::timestamp with time zone) - '3 days'::interval) + '-16 days'::interval AS week_end_4,
            mp.max_po_acceptance AS ak_fc_max_po,
            mp.act_max_po_acceptance AS ak_act_max_po,
            dfudt."Type"
           FROM ( SELECT final."Lead Target",
                    final."Validated target",
                    final."DR target",
                    final."AOV target",
                    final."Revenue target",
                    final."Lead cost Plan",
                    final.aging,
                    final.lead_date,
                    final.lead_year,
                    final.remaining_lead_mrp_target,
                    final.network,
                    final.pub,
                    final.cam_lead,
                    final.product_name,
                    final.total_lead,
                    final.trash,
                    final.approved,
                    final.validated,
                    final.amt_validated,
                    final.delivered,
                    final.finalized_do,
                    final.amt_delivered,
                    final.unfinish,
                    final.amt_unfinish,
                    final.payout,
                    final.max_po,
                    final.geo,
                    final.country_code,
                    final.cpl_lead,
                    final.tax_rate,
                    final.tele_rate,
                    final.commission_rate,
                    final.bd_comm_rate,
                    final.unit_cost,
                    final.ffm_fee,
                    final.lm_fee,
                    final.return_rate,
                    final.cod_rate,
                    final.portion,
                    final.lead_week,
                    final.lead_month,
                    final.mkt_expense_target,
                    final.ar_target,
                    final.lead_mrp,
                    final.started_date,
                    final.ending_date,
                    final.concat,
                    final.target_key,
                    final.exchange,
                    final.product_fn,
                    final.inrangeforecast,
                    final.latest_ar_target,
                    final.dr_final,
                    final.delivered_fc_aging,
                    final.dr_forecast_aging,
                    final.spl_plan,
                    final.lead_cost_budget,
                    final.mkt_budget,
                    final.spl_plan_def,
                    final.lead_cost_budget_def,
                    final.mkt_budget_def,
                    final.vip_pub,
                    final."AR Forecast",
                    final."AOV Forecast",
                    final."DR_Forecast",
                    final."SPL Forecast",
                    final."%Lead cost FC",
                    final."%GM1 FC",
                    final."%GM2 FC",
                    final.deal_lead_mrp,
                    final.deal_armrp,
                    final.deal_aov_mrp,
                    final.deal_spl_target,
                    final.deal_dr_mrp,
                    final.deal_lead_cost_mrp,
                    final.deal_gm1_mrp,
                    final.deal_gm2_mrp,
                    final.deal_type,
                    final.cost_usd,
                    final.logistics_cost_per_validated_order_usd,
                    final.camp_lead_target,
                    final.camp_spl_target,
                    final.camp_percentage_lead_cost_target,
                    final.geo_lead_target,
                    final.geo_spl_target,
                    final.geo_percentage_lead_cost_target,
                    final.offer_lead_target,
                    final.offer_spl_target,
                    final.offer_percentage_lead_cost_target,
                    final.geo_lead_cost_target,
                    final.geo_ar_qa_plan,
                    final.geo_dr_mrp,
                    final.geo_aov_mrp,
                    final.camp_lead_cost_target,
                    final.camp_ar_qa_plan,
                    final.camp_dr_mrp,
                    final.camp_aov_mrp,
                    final.offer_lead_cost_target,
                    final.offer_ar_qa_plan,
                    final.offer_dr_mrp,
                    final.offer_aov_mrp,
                    final.spl_mrp,
                    final.total_approved_postback,
                        CASE
                            WHEN final.ar_target IS NULL THEN NULL::bigint
                            ELSE final.total_lead
                        END AS total_lead_mrp,
                        CASE
                            WHEN final.validated > 0 THEN final.finalized_do / final.validated
                            ELSE 0::bigint
                        END AS do_done,
                    (((final.lead_date || final.geo::text) || final.network::text) || final.product_name::text) || final.cam_lead::text AS join_key,
                        CASE
                            WHEN final.geo::text = 'VN2'::text THEN 'VN'::character varying
                            ELSE final.geo
                        END AS geo_2
                   FROM final) mkt
             LEFT JOIN max_po mp ON mkt.lead_date = mp.report_date AND mkt.country_code = mp.geo::text AND mkt.product_name::text = mp.offer::text AND mkt.network::text = mp.network::text AND mp.sale_campaign::text = mkt.cam_lead::text
             LEFT JOIN dim_follow_up_deal_target dfudt ON mkt.product_name::text = dfudt."Offer" AND mkt.network::text = dfudt."Pub" AND mkt.lead_date >= dfudt."Start date" AND mkt.lead_date <= dfudt."end date"
        )
 SELECT a."Lead Target",
    a."Validated target",
    a."DR target",
    a."AOV target",
    a."Revenue target",
    a."Lead cost Plan",
    a.aging,
    a.lead_date,
    a.lead_year,
    a.remaining_lead_mrp_target,
    a.network,
    a.pub,
    a.cam_lead,
    a.product_name,
    a.total_lead,
    a.trash,
    a.approved,
    a.validated,
    a.amt_validated,
    a.delivered,
    a.finalized_do,
    a.amt_delivered,
    a.unfinish,
    a.amt_unfinish,
    a.payout,
    a.max_po,
    a.geo,
    a.country_code,
    a.cpl_lead,
    a.tax_rate,
    a.tele_rate,
    a.commission_rate,
    a.bd_comm_rate,
    a.unit_cost,
    a.ffm_fee,
    a.lm_fee,
    a.return_rate,
    a.cod_rate,
    a.portion,
    a.lead_week,
    a.lead_month,
    a.mkt_expense_target,
    a.ar_target,
    a.lead_mrp,
    a.started_date,
    a.ending_date,
    a.concat,
    a.target_key,
    a.exchange,
    a.product_fn,
    a.inrangeforecast,
    a.latest_ar_target,
    a.dr_final,
    a.delivered_fc_aging,
    a.dr_forecast_aging,
    a.spl_plan,
    a.lead_cost_budget,
    a.mkt_budget,
    a.spl_plan_def,
    a.lead_cost_budget_def,
    a.mkt_budget_def,
    a.vip_pub,
    a."AR Forecast",
    a."AOV Forecast",
    a."DR_Forecast",
    a."SPL Forecast",
    a."%Lead cost FC",
    a."%GM1 FC",
    a."%GM2 FC",
    a.deal_lead_mrp,
    a.deal_armrp,
    a.deal_aov_mrp,
    a.deal_spl_target,
    a.deal_dr_mrp,
    a.deal_lead_cost_mrp,
    a.deal_gm1_mrp,
    a.deal_gm2_mrp,
    a.deal_type,
    a.cost_usd,
    a.logistics_cost_per_validated_order_usd,
    a.camp_lead_target,
    a.camp_spl_target,
    a.camp_percentage_lead_cost_target,
    a.geo_lead_target,
    a.geo_spl_target,
    a.geo_percentage_lead_cost_target,
    a.offer_lead_target,
    a.offer_spl_target,
    a.offer_percentage_lead_cost_target,
    a.geo_lead_cost_target,
    a.geo_ar_qa_plan,
    a.geo_dr_mrp,
    a.geo_aov_mrp,
    a.camp_lead_cost_target,
    a.camp_ar_qa_plan,
    a.camp_dr_mrp,
    a.camp_aov_mrp,
    a.offer_lead_cost_target,
    a.offer_ar_qa_plan,
    a.offer_dr_mrp,
    a.offer_aov_mrp,
    a.spl_mrp,
    a.total_approved_postback,
    a.total_lead_mrp,
    a.do_done,
    a.join_key,
    a.geo_2,
    a.delivered_final,
    a.week_start,
    a.week_end,
    a.week_start_2,
    a.week_end_2,
    a.week_start_3,
    a.week_end_3,
    a.week_start_4,
    a.week_end_4,
    a.ak_fc_max_po,
    a.ak_act_max_po,
    a."Type",
    cm."COM cost",
    lm."LM cost",
    ffm."FFM cost",
    cod."COD cost",
    bd."standard agent cost",
    bd."% agent cost trash",
    uni.unit_cost_lc,
    uni.offer,
    tel."TEL cost",
    rtn."RTN cost"
   FROM a
     LEFT JOIN ( SELECT dim_commision_cost.geo,
            generate_series(dim_commision_cost.started_date::timestamp without time zone, dim_commision_cost.started_date::timestamp without time zone + '1 day'::interval * (date_part('day'::text, dim_commision_cost.ending_date::timestamp without time zone - dim_commision_cost.started_date::timestamp without time zone) + 1::double precision), '1 day'::interval) AS date_list,
            dim_commision_cost.fresh AS "COM cost"
           FROM dim_commision_cost) cm ON a.country_code = cm.geo AND a.lead_date = cm.date_list
     LEFT JOIN ( SELECT dim_lm_cost.geo,
            generate_series(dim_lm_cost.started_date::timestamp without time zone, dim_lm_cost.started_date::timestamp without time zone + '1 day'::interval * (date_part('day'::text, dim_lm_cost.ending_date::timestamp without time zone - dim_lm_cost.started_date::timestamp without time zone) + 1::double precision), '1 day'::interval) AS date_list,
            dim_lm_cost.order_local_cur AS "LM cost"
           FROM dim_lm_cost) lm ON a.country_code = lm.geo AND a.lead_date = lm.date_list
     LEFT JOIN ( SELECT dim_ffm_cost.geo,
            generate_series(dim_ffm_cost.started_date::timestamp without time zone, dim_ffm_cost.started_date::timestamp without time zone + '1 day'::interval * (date_part('day'::text, dim_ffm_cost.ending_date::timestamp without time zone - dim_ffm_cost.started_date::timestamp without time zone) + 1::double precision), '1 day'::interval) AS date_list,
            dim_ffm_cost.order_local_cur AS "FFM cost"
           FROM dim_ffm_cost) ffm ON a.country_code = ffm.geo AND a.lead_date = ffm.date_list
     LEFT JOIN ( SELECT dim_log_cod.geo,
            generate_series(dim_log_cod.started_date::timestamp without time zone, dim_log_cod.started_date::timestamp without time zone + '1 day'::interval * (date_part('day'::text, dim_log_cod.ending_date::timestamp without time zone - dim_log_cod.started_date::timestamp without time zone) + 1::double precision), '1 day'::interval) AS date_list,
            dim_log_cod.cod AS "COD cost"
           FROM dim_log_cod) cod ON a.country_code = cod.geo AND a.lead_date = cod.date_list
     LEFT JOIN ( SELECT dim_tel_cost.geo,
            generate_series(dim_tel_cost.started_date::timestamp without time zone, dim_tel_cost.started_date::timestamp without time zone + '1 day'::interval * (date_part('day'::text, dim_tel_cost.ending_date::timestamp without time zone - dim_tel_cost.started_date::timestamp without time zone) + 1::double precision), '1 day'::interval) AS date_list,
            avg(dim_tel_cost.lead_local_cur::double precision) AS "TEL cost"
           FROM dim_tel_cost
          GROUP BY dim_tel_cost.geo, (generate_series(dim_tel_cost.started_date::timestamp without time zone, dim_tel_cost.started_date::timestamp without time zone + '1 day'::interval * (date_part('day'::text, dim_tel_cost.ending_date::timestamp without time zone - dim_tel_cost.started_date::timestamp without time zone) + 1::double precision), '1 day'::interval))) tel ON a.country_code = tel.geo AND a.lead_date = tel.date_list
     LEFT JOIN ( SELECT dim_log_rtn.geo,
            generate_series(dim_log_rtn.started_date::timestamp without time zone, dim_log_rtn.started_date::timestamp without time zone + '1 day'::interval * (date_part('day'::text, dim_log_rtn.ending_date::timestamp without time zone - dim_log_rtn.started_date::timestamp without time zone) + 1::double precision), '1 day'::interval) AS date_list,
            avg(dim_log_rtn.rtn::double precision) AS "RTN cost"
           FROM dim_log_rtn
          GROUP BY dim_log_rtn.geo, (generate_series(dim_log_rtn.started_date::timestamp without time zone, dim_log_rtn.started_date::timestamp without time zone + '1 day'::interval * (date_part('day'::text, dim_log_rtn.ending_date::timestamp without time zone - dim_log_rtn.started_date::timestamp without time zone) + 1::double precision), '1 day'::interval))) rtn ON a.country_code = rtn.geo AND a.lead_date = rtn.date_list
     LEFT JOIN ( SELECT dim_bd_agent_cost.started_date,
            dim_bd_agent_cost.ending_date,
            generate_series(dim_bd_agent_cost.started_date, dim_bd_agent_cost.started_date + (((date_part('day'::text, dim_bd_agent_cost.ending_date - dim_bd_agent_cost.started_date) + 1::double precision) || ' days'::text)::interval), '1 day'::interval) AS date_list,
            dim_bd_agent_cost.geo,
            dim_bd_agent_cost.sale_campaign,
            dim_bd_agent_cost.agent_cost_2 AS "standard agent cost",
            dim_bd_agent_cost.agent_cost_3 AS "% agent cost trash",
            dim_bd_agent_cost.per_agent_cost_trash
           FROM dim_bd_agent_cost) bd ON a.country_code = bd.geo AND a.lead_date = bd.date_list AND a.cam_lead::text = bd.sale_campaign
     LEFT JOIN ( SELECT osi.geo_2 AS geo,
            cl.createdate::date AS createdate,
            cl.prod_name AS offer,
            cl.affiliate_id AS pub,
            cl.subid1 AS sub,
            sum(osi.unit_cost) AS unit_cost_lc
           FROM ( SELECT fact__item_with_cost.geo,
                        CASE
                            WHEN fact__item_with_cost.geo::text ^@ 'ID'::text THEN 'ID'::character varying
                            ELSE fact__item_with_cost.geo
                        END AS geo_2,
                    fact__item_with_cost.lead_id,
                    fact__item_with_cost.so_id,
                    sum(fact__item_with_cost.unit_cost_local_cur_by_lead_created_time * fact__item_with_cost.item_quantity::double precision) AS unit_cost
                   FROM fact__item_with_cost
                  WHERE fact__item_with_cost.lead_date >= '2024-01-01 00:00:00'::timestamp without time zone
                  GROUP BY fact__item_with_cost.geo, (
                        CASE
                            WHEN fact__item_with_cost.geo::text ^@ 'ID'::text THEN 'ID'::character varying
                            ELSE fact__item_with_cost.geo
                        END), fact__item_with_cost.lead_id, fact__item_with_cost.so_id) osi
             JOIN ( SELECT od_sale_order.id,
                    od_sale_order.so_id,
                    od_sale_order.org_id,
                    od_sale_order.geo,
                    od_sale_order.cp_id,
                    od_sale_order.ag_id,
                    od_sale_order.lead_id,
                    od_sale_order.amount,
                    od_sale_order.payment_method,
                    od_sale_order.status,
                    od_sale_order.createby,
                    od_sale_order.createdate,
                    od_sale_order.modifyby,
                    od_sale_order.modifydate,
                    od_sale_order.created_at,
                    od_sale_order.updated_at,
                    od_sale_order.creation_date,
                    od_sale_order.reason,
                    od_sale_order.qa_note,
                    od_sale_order.validate_by,
                    od_sale_order.lead_phone,
                    od_sale_order.customer_phone,
                    od_sale_order.discount_cash_2,
                    od_sale_order.lead_name,
                    od_sale_order.amount_deposit,
                    od_sale_order.list_price,
                    od_sale_order.discount_level,
                    od_sale_order.discount_type_1,
                    od_sale_order.unit_1,
                    od_sale_order.discount_cash_1,
                    od_sale_order.discount_percent_1,
                    od_sale_order.discount_type_2,
                    od_sale_order.unit_2,
                    od_sale_order.discount_percent_2,
                    od_sale_order.discount_type_3,
                    od_sale_order.unit_3,
                    od_sale_order.discount_cash_3,
                    od_sale_order.discount_percent_3,
                    od_sale_order.discount_type_4,
                    od_sale_order.unit_4,
                    od_sale_order.discount_cash_4,
                    od_sale_order.discount_percent_4,
                    od_sale_order.is_validated,
                    od_sale_order.appointment_date,
                    od_sale_order.qty_total,
                    od_sale_order.qty_saleable,
                    od_sale_order.amount_postpaid,
                    od_sale_order.delivery_package_code,
                    od_sale_order.__deleted_at
                   FROM od_sale_order
                  WHERE od_sale_order.createdate >= '2024-01-01 00:00:00'::timestamp without time zone) oso ON oso.so_id = osi.so_id AND oso.geo::text = osi.geo::text AND (oso.status = ANY (ARRAY[43, 357]))
             JOIN ( SELECT od_do_new.id,
                    od_do_new.org_id,
                    od_do_new.do_id,
                    od_do_new.geo,
                    od_do_new.so_id,
                    od_do_new.ffm_id,
                    od_do_new.warehouse_id,
                    od_do_new.carrier_id,
                    od_do_new.customer_id,
                    od_do_new.firstdelivertime,
                    od_do_new.tracking_code,
                    od_do_new.ffm_code,
                    od_do_new.package_name,
                    od_do_new.package_description,
                    od_do_new.package_id,
                    od_do_new.amountcod,
                    od_do_new.status,
                    od_do_new.createby,
                    od_do_new.createdate,
                    od_do_new.updateby,
                    od_do_new.updatedate,
                    od_do_new.created_at,
                    od_do_new.updated_at,
                    od_do_new.do_code,
                    od_do_new.closetime,
                    od_do_new.error_message,
                    od_do_new.customer_name,
                    od_do_new.customer_phone,
                    od_do_new.lastmile_return_code,
                    od_do_new.customer_address,
                    od_do_new.delivery_package_code,
                    od_do_new.packed_time,
                    od_do_new.picked_time,
                    od_do_new.__deleted_at,
                    od_do_new.returntime
                   FROM od_do_new
                  WHERE od_do_new.createdate >= '2024-01-01 00:00:00'::timestamp without time zone) odn ON osi.so_id = odn.so_id AND osi.geo::text = odn.geo::text AND odn.status = 59
             JOIN ( SELECT cl_fresh.createdate,
                    cl_fresh.lead_id,
                    cl_fresh.geo,
                        CASE
                            WHEN cl_fresh.prod_name IS NULL THEN 'No offer'::character varying
                            ELSE cl_fresh.prod_name
                        END AS offer,
                    cl_fresh.prod_name,
                    cl_fresh.lead_type,
                    cl_fresh.lead_status,
                        CASE
                            WHEN lower(cl_fresh.prod_name::text) ~~ '%prosta%id'::text THEN 472
                            WHEN lower(cl_fresh.prod_name::text) ~~ '%duramax%th'::text THEN 567
                            ELSE cl_fresh.cp_id
                        END AS cp_id,
                    cl_fresh.affiliate_id,
                        CASE
                            WHEN (cl_fresh.affiliate_id::text = ANY (ARRAY['EW'::character varying, 'AT'::character varying, 'ADT'::character varying, 'ABT'::character varying, 'ARB'::character varying, 'CSL'::character varying, 'MKR'::character varying, 'XXX'::character varying, 'PFC'::character varying, 'ORG'::character varying, 'ORG2'::character varying, 'PIB'::character varying, 'MH'::character varying, 'MP'::character varying, 'IGO'::character varying, 'VIC'::character varying, 'ODS'::character varying, 'DAT'::character varying, 'VAL'::character varying, 'MIR'::character varying, 'NGN'::character varying, 'WIL'::character varying, 'PD'::character varying, 'CTR'::character varying, 'U_DOMA'::character varying, 'ABG'::character varying]::text[])) OR cl_fresh.affiliate_id::text = 'U_RUS'::text AND cl_fresh.geo::text = 'TH'::text OR cl_fresh.subid1 IS NULL THEN 'No PubID'::character varying
                            WHEN cl_fresh.subid1::text = ''::text THEN 'blank'::character varying
                            ELSE cl_fresh.subid1
                        END AS subid1,
                    cl_fresh.assigned,
                    lower(cl_fresh.name::text) AS cust_name
                   FROM cl_fresh
                  WHERE cl_fresh.lead_type::text = 'A'::text AND cl_fresh.createdate >= '2024-01-01 00:00:00'::timestamp without time zone) cl ON cl.lead_id = osi.lead_id AND cl.geo::text = osi.geo::text
          GROUP BY osi.geo_2, (cl.createdate::date), cl.prod_name, cl.affiliate_id, cl.subid1) uni ON a.geo::text = uni.geo::text AND a.lead_date = uni.createdate AND a.network::text = uni.pub::text AND a.pub::text = uni.sub::text AND a.product_name::text = uni.offer::text;
