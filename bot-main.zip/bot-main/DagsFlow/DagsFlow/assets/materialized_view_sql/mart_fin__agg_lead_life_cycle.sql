with
    base_table as (
        select * from "tms_central"."dareport"."mart_fin__raw_lead_life_cycle"
    ),
    validated_quantity as (
        select small_fact.geo, small_fact.lead_id, sum(item_quantity) as validated_qty
        from "tms_central"."dareport"."fact__item_with_cost" as small_fact
        inner join
            "tms_central"."dareport"."fact__lead_sales_delivery" as big_fact
            on small_fact.geo = big_fact.geo
            and small_fact.lead_id = big_fact.lead_id
            and big_fact.so_status in ('validated', 'delay')
        group by 1, 2
    ),
    join_validated_quantity_with_base as (
        select base.*, validated_qty as f0_pcs
        from base_table as base
        left join
            validated_quantity as val_qty
            on base.f0_geo = val_qty.geo
            and base.f0_lead_id = val_qty.lead_id
    ),
    aggregate_dim as (
        select
            f0_network as f0_pub,
            f_type,
            fn_createdate - previous_lead_date as fn_distance_to_previous_f,
            f0_offer,
            f0_lead_status,
            f0_so_status as f0_order_status,
            f0_do_status as f0_delivery_status,
            fn_lead_status as fn_lead_status,
            fn_so_status as fn_order_status,
            fn_do_status as fn_delivery_status,
            f0_campaign_name as f0_sales_campaign,
            f0_pub as f0_subid,
            f0_agent,
            f0_createdate as f0_create_date,
            f0_geo as f0_geo,
            f0_pcs,
            count(distinct fn_lead_id) as fn_lead_count,
            sum(fn_sales_amount) as fn_revenue_sum
        from join_validated_quantity_with_base
        group by 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16
    )
select *
from aggregate_dim
