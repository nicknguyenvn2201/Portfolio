with
    base_fact as (
        select
            fact.geo,
            lead_id,
            fact.so_id,
            agent_name,
            lead_type,
            lead_date,
            campaign_name,
            pub,
            lead_product_name,
            lead_status,
            so_status,
            do_status,
            network,
            coalesce(lead_fresh_id, lead_id) as lead_fresh_id,
            coalesce(lead_fresh_geo, fact.geo) as lead_fresh_geo,
            sales_amount
        from "tms_central"."dareport"."fact__lead_sales_delivery" as fact
        where
            lead_date >= ' 2023-01-01'
            --and not (lead_type = 'M' and (lead_fresh_id is null or lead_fresh_id = 0))
    ),
    self_join_to_find_child_lead as (
        select
            fn.*,
            row_number() over (
                partition by fn.lead_fresh_geo, fn.lead_fresh_id
                order by fn.lead_date asc
            )
            - 1 as f_type
        from base_fact as fn
        left join
            base_fact as f0
            on f0.geo = fn.lead_fresh_geo
            and f0.lead_id = fn.lead_fresh_id
    ),
    rename_column as (
        select
            f_type,
            lead_fresh_geo as f0_geo,
            lead_fresh_id as f0_lead_id,
            geo as fn_geo,
            lead_id as fn_lead_id,
            agent_name as fn_agent,
            lead_date::date as fn_createdate,
            campaign_name as fn_campaign_name,
            network as fn_network,
            pub as fn_pub,
            sales_amount as fn_sales_amount,
            lead_product_name as fn_offer,
            lead_status as fn_lead_status,
            so_status as fn_so_status,
            do_status as fn_do_status
        from self_join_to_find_child_lead
    ),
    calculate_windows as (
        select
            *,
            first_value(fn_agent) over (
                partition by f0_geo, f0_lead_id order by fn_createdate
            ) as f0_agent,
            min(fn_createdate) over (
                partition by f0_geo, f0_lead_id order by fn_createdate
            ) as f0_createdate,
            first_value(fn_campaign_name) over (
                partition by f0_geo, f0_lead_id order by fn_createdate
            ) as f0_campaign_name,
            first_value(fn_network) over (
                partition by f0_geo, f0_lead_id order by fn_createdate
            ) as f0_network,
            first_value(fn_pub) over (
                partition by f0_geo, f0_lead_id order by fn_createdate
            ) as f0_pub,
            first_value(fn_sales_amount) over (
                partition by f0_geo, f0_lead_id order by fn_createdate
            ) as f0_sales_amount,
            first_value(fn_offer) over (
                partition by f0_geo, f0_lead_id order by fn_createdate
            ) as f0_offer,
            first_value(fn_lead_status) over (
                partition by f0_geo, f0_lead_id order by fn_createdate
            ) as f0_lead_status,
            first_value(fn_so_status) over (
                partition by f0_geo, f0_lead_id order by fn_createdate
            ) as f0_so_status,
            first_value(fn_do_status) over (
                partition by f0_geo, f0_lead_id order by fn_createdate
            ) as f0_do_status,
            max(fn_createdate::date) over (
                partition by f0_geo, f0_lead_id
                order by fn_createdate
                rows between unbounded preceding and 1 preceding
            ) as previous_lead_date
        from rename_column
    )
select *
from calculate_windows
