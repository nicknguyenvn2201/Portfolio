select createdate,
modifydate,
total_call,
lead_id,
geo,
assigned,
cp_id,
lead_status
from cl_fresh 
where createdate >= current_date
or modifydate >= current_date
