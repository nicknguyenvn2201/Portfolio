-- fact_fin_rockbay_lead
-- [Global]_[Finance]_Lead Report 
WITH cte_cl_fresh AS (
         SELECT cl.createdate::date AS createdate,
         		cl.modifydate::date as modifydate,
                CASE
                    WHEN cl.prod_name IS NULL THEN 'No offer'::character varying
                    ELSE cl.prod_name
                END AS offer,
            cl.lead_id,
            cl.geo,
            cl.lead_type,
            cl.lead_status,
            cl.lead_status_name,
            cl.affiliate_id,
            cl.subid1,
            cl.postback_status,
            cl.click_id,
            cust_name,
                CASE
                    WHEN cl.lead_status = 4 OR cl.lead_status = 5 AND cl.assigned = 0 THEN 1
                    ELSE 0
                END AS filters
           FROM ( SELECT cl_fresh.createdate,
           			cl_fresh.modifydate ,
                    cl_fresh.lead_id,
                    cl_fresh.geo,
                    cl_fresh.prod_name,
                    cl_fresh.lead_type,
                    cl_fresh.lead_status,
                    cs."name" as lead_status_name,
                    cl_fresh.affiliate_id,
                    cl_fresh.subid1,
                    cl_fresh.assigned,
                    cl_fresh.postback_status,
                    cl_fresh.click_id,
                    lower(cl_fresh.name::text) AS cust_name,
                    cl_fresh.cp_id
--                    cc.name as sale_campaign
                   FROM rkb.cl_fresh cl_fresh
                   left join (select * from public.cf_synonym where type = 'lead status' and geo = 'VN4' ) cs 
                   on cl_fresh.lead_status = cs.value
--                   LEFT JOIN ( select distinct from public.cp_campaign) cc ON cl_fresh.cp_id = cc.cp_id AND cl_fresh.geo::text = cc.geo::text
                  WHERE 
                  	-- cl_fresh.createdate >= (CURRENT_DATE - 7) AND 
                  		cl_fresh.lead_type::text = 'A'::text
--                  		and cl_fresh.cp_id is not null
                  ) cl
          WHERE cl.cust_name !~~ '%test%'::text
        )
, cte_afs as (
select advertiser_user_id,"advertiser.value", transaction_id, payout, revenue
from dareport.fct_affscale_network_conversion fanc 
)  
select 
		afs.advertiser_user_id, 
		afs."advertiser.value" as adv_name, 
		cf.lead_id,
		cf.lead_status,
		cf.lead_status_name,
		cf.cust_name as lead_name, 
		cf.offer as product_name,
		cf.createdate,
		cf.modifydate, 
		afs.payout,
		afs.revenue as max_po,
		afs.transaction_id,
		cf.affiliate_id as network,
		cf.subid1,
		now() as last_refresh
from cte_cl_fresh cf
left join cte_afs afs
on cf.click_id = afs.transaction_id