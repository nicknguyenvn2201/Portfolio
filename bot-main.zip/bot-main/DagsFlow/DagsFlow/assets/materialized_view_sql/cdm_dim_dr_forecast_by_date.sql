-- 03.05.2024
WITH 
	rockbay AS (
         SELECT cl_fresh_1.createdate,
            cl_fresh_1.lead_id,
            cl_fresh_1.geo,
            cl_fresh_1.prod_name,
            'AFS'::text AS agc_code,
            cl_fresh_1.lead_type,
            cl_fresh_1.lead_status,
            cl_fresh_1.agc_id,
            cl_fresh_1.cp_id,
            cl_fresh_1.affiliate_id,
            cl_fresh_1.subid1
           FROM rkb.cl_fresh cl_fresh_1
          WHERE cl_fresh_1.postback_status::text = 'approved'::text AND cl_fresh_1.lead_type::text = 'A'::text AND lower(cl_fresh_1.name::text) !~~ '%test%'::text AND cl_fresh_1.createdate >= (current_date - 122) AND
                CASE
                    WHEN cl_fresh_1.lead_status = 4 OR cl_fresh_1.lead_status = 5 AND cl_fresh_1.assigned = 0 THEN 1
                    ELSE 0
                END <> 1
        ), 
        cte_cl_fresh AS (
         SELECT cl_fresh_1.createdate,
            cl_fresh_1.lead_id,
            cl_fresh_1.geo,
            cl_fresh_1.prod_name,
            cl_fresh_1.agc_code,
            cl_fresh_1.lead_type,
            cl_fresh_1.lead_status,
            cl_fresh_1.agc_id,
            cl_fresh_1.cp_id,
            cl_fresh_1.affiliate_id,
            cl_fresh_1.subid1
           FROM cl_fresh cl_fresh_1
          WHERE cl_fresh_1.lead_type::text = 'A'::text AND lower(cl_fresh_1.name::text) !~~ '%test%'::text AND cl_fresh_1.createdate >= (current_date - 122) AND
                CASE
                    WHEN cl_fresh_1.lead_status = 4 OR cl_fresh_1.lead_status = 5 AND cl_fresh_1.assigned = 0 THEN 1
                    ELSE 0
                END <> 1
        ), cte_init AS (
         SELECT cc_fresh.createdate::date AS createdate,
            cc_fresh.lead_id,
            cc_fresh.lead_type,
            cc_fresh.geo,
                CASE
                    WHEN cc_fresh.prod_name IS NULL THEN 'No offer'::character varying
                    ELSE cc_fresh.prod_name
                END AS offer,
            COALESCE(
                CASE
                    WHEN COALESCE(p.shortname, cc_fresh.agc_code)::text = ANY (ARRAY['AFS'::character varying::text, 'OFP'::character varying::text]) THEN cc_fresh.affiliate_id
                    ELSE COALESCE(p.shortname, cc_fresh.agc_code, 'LOYAL CUSTOMER'::character varying)
                END, 'No network'::character varying) AS network,
                CASE
                    WHEN COALESCE(p.shortname, cc_fresh.agc_code)::text = ANY (ARRAY['AFS'::character varying::text, 'OFP'::character varying::text]) THEN cc_fresh.subid1
                    ELSE cc_fresh.affiliate_id
                END AS sub,
            cc_fresh.lead_status,
            cf_lead.lead_status AS cf_lead_status,
            cf_so.lead_status AS cf_so_lead_status,
            cf_do.lead_status AS cf_do_lead_status,
                CASE
                    WHEN lower(cc_fresh.prod_name::text) ~~ '%vip%'::text THEN cc.name
                    WHEN lower(cc_fresh.prod_name::text) ~~ '%prosta%id'::text THEN 'Fresh HC'::character varying
                    WHEN lower(cc_fresh.prod_name::text) ~~ '%duramax%th'::text THEN 'Fresh ME'::character varying
                    ELSE cc.name
                END AS sale_campaign
           FROM ( SELECT cte_cl_fresh.createdate,
                    cte_cl_fresh.lead_id,
                    cte_cl_fresh.geo,
                    cte_cl_fresh.prod_name,
                    cte_cl_fresh.agc_code,
                    cte_cl_fresh.lead_type,
                    cte_cl_fresh.lead_status,
                    cte_cl_fresh.agc_id,
                    cte_cl_fresh.cp_id,
                    cte_cl_fresh.affiliate_id,
                    cte_cl_fresh.subid1
                   FROM cte_cl_fresh
                UNION
                 SELECT rockbay.createdate,
                    rockbay.lead_id,
                    rockbay.geo,
                    rockbay.prod_name,
                    rockbay.agc_code,
                    rockbay.lead_type,
                    rockbay.lead_status,
                    rockbay.agc_id,
                    rockbay.cp_id,
                    rockbay.affiliate_id,
                    rockbay.subid1
                   FROM rockbay
                 ) cc_fresh
             LEFT JOIN ( SELECT a_1.so_id,
                    a_1.org_id,
                    a_1.geo,
                    a_1.cp_id,
                    a_1.lead_id,
                    a_1.amount,
                    a_1.payment_method,
                    a_1.status,
                    a_1.createdate,
                    a_1.creation_date,
                    a_1.validated_rn,
                    a_1.rn,
                    a_1.final_rn
                   FROM ( SELECT oso_1.so_id,
                            oso_1.org_id,
                            oso_1.geo,
                            oso_1.cp_id,
                            oso_1.lead_id,
                            oso_1.amount,
                            oso_1.payment_method,
                            oso_1.status,
                            oso_1.createdate,
                            oso_1.creation_date,
                            sum(
                                CASE
                                    WHEN oso_1.status = ANY (ARRAY[43, 357]) THEN 1
                                    ELSE NULL::integer
                                END) OVER (PARTITION BY oso_1.lead_id) AS validated_rn,
                            row_number() OVER (PARTITION BY oso_1.lead_id ORDER BY oso_1.createdate DESC) AS rn,
                                CASE
                                    WHEN row_number() OVER (PARTITION BY oso_1.lead_id ORDER BY oso_1.createdate DESC) = 1 AND sum(
                                    CASE
									WHEN oso_1.status = ANY (ARRAY[43, 357]) THEN 1
									ELSE NULL::integer
                                    END) OVER (PARTITION BY oso_1.lead_id) > 0 AND (oso_1.status <> ALL (ARRAY[43, 357])) THEN 2::bigint
                                    WHEN row_number() OVER (PARTITION BY oso_1.lead_id ORDER BY oso_1.createdate DESC) <> 1 AND (oso_1.status = ANY (ARRAY[43, 357])) THEN 1::bigint
                                    ELSE row_number() OVER (PARTITION BY oso_1.lead_id ORDER BY oso_1.createdate DESC)
                                END AS final_rn
                           FROM od_sale_order oso_1
                          WHERE oso_1.status <> 46) a_1
                  WHERE a_1.final_rn = 1) oso ON cc_fresh.lead_id = oso.lead_id AND oso.geo::text = cc_fresh.geo::text
             LEFT JOIN od_do_new odn ON odn.so_id = oso.so_id AND oso.geo::text = odn.geo::text
             LEFT JOIN ( SELECT cs.geo,
                    cs.synonym_id,
                    cs.type,
                    cs.name,
                    cs.value,
                    cs.dscr,
                    cs.type_id,
                    cs.localized_name,
                    cs.name AS lead_status
                   FROM cf_synonym cs
                  WHERE cs.type::text = 'lead status'::text) cf_lead ON cc_fresh.lead_status = cf_lead.value AND cc_fresh.geo::text = cf_lead.geo::text
             LEFT JOIN ( SELECT cs.geo,
                    cs.synonym_id,
                    cs.type,
                    cs.name,
                    cs.value,
                    cs.dscr,
                    cs.type_id,
                    cs.localized_name,
                    cs.name AS lead_status
                   FROM cf_synonym cs
                  WHERE cs.type::text = 'sale order status'::text) cf_so ON oso.status = cf_so.value AND oso.geo::text = cf_so.geo::text
             LEFT JOIN ( SELECT cs.geo,
                    cs.synonym_id,
                    cs.type,
                    cs.name,
                    cs.value,
                    cs.dscr,
                    cs.type_id,
                    cs.localized_name,
                    cs.name AS lead_status
                   FROM cf_synonym cs
                  WHERE cs.type::text = 'delivery order status'::text) cf_do ON odn.status = cf_do.value AND odn.geo::text = cf_do.geo::text
             LEFT JOIN bp_partner p ON cc_fresh.agc_id = p.pn_id AND p.geo::text = cc_fresh.geo::text
             LEFT JOIN bp_partner pn ON pn.pn_id = odn.carrier_id AND pn.geo::text = odn.geo::text
             LEFT JOIN cp_campaign cc ON cc_fresh.cp_id = cc.cp_id AND cc_fresh.geo::text = cc.geo::text
          WHERE cc_fresh.lead_type::text = 'A'::text AND (lower(cc.name::text) <> 'cptest'::text AND lower(cc.name::text) <> 'cp_test'::text OR cc.name IS NULL) AND cc_fresh.geo::text <> 'RKB'::text AND cc_fresh.createdate::date >= '2024-01-01'::date
        ), cte_group AS (
         SELECT cte_init.createdate,
            cte_init.geo,
            cte_init.offer,
            cte_init.network,
            cte_init.sale_campaign,
                CASE
                    WHEN (cte_init.network::text = ANY (ARRAY['EW'::character varying::text, 'AT'::character varying::text, 'ADT'::character varying::text, 'ABT'::character varying::text, 'ARB'::character varying::text, 'CSL'::character varying::text, 'MKR'::character varying::text, 'XXX'::character varying::text, 'PFC'::character varying::text, 'ORG'::character varying::text, 'ORG2'::character varying::text, 'PIB'::character varying::text, 'MH'::character varying::text, 'MP'::character varying::text, 'IGO'::character varying::text, 'VIC'::character varying::text, 'ODS'::character varying::text, 'DAT'::character varying::text, 'VAL'::character varying::text, 'MIR'::character varying::text, 'NGN'::character varying::text, 'WIL'::character varying::text, 'PD'::character varying::text, 'CTR'::character varying::text, 'U_DOMA'::character varying::text, 'ABG'::character varying::text])) OR cte_init.network::text = 'U_RUS'::text AND cte_init.geo::text = 'TH'::text OR cte_init.sub IS NULL THEN 'No PubID'::character varying
                    WHEN cte_init.sub::text = ''::text THEN 'blank'::character varying
                    ELSE cte_init.sub
                END AS pub,
            count(DISTINCT cte_init.lead_id) AS total_lead,
            cte_init.cf_so_lead_status,
            cte_init.cf_do_lead_status,
            count(DISTINCT
                CASE
                    WHEN cte_init.lead_status = 2 AND (lower(cte_init.cf_so_lead_status::text) = ANY (ARRAY['validated'::text, 'delay'::text])) THEN cte_init.lead_id
                    ELSE NULL::bigint
                END) AS validated,
            count(DISTINCT
                CASE
                    WHEN cte_init.lead_status = 2 AND (lower(cte_init.cf_so_lead_status::text) = ANY (ARRAY['validated'::text, 'delay'::text])) AND (lower(cte_init.cf_do_lead_status::text) = ANY (ARRAY['delivered'::text, 'refund'::text])) THEN cte_init.lead_id
                    ELSE NULL::bigint
                END) AS delivered
           FROM cte_init
          GROUP BY cte_init.createdate, cte_init.geo, cte_init.offer, cte_init.network, cte_init.sale_campaign, (
                CASE
                    WHEN (cte_init.network::text = ANY (ARRAY['EW'::character varying::text, 'AT'::character varying::text, 'ADT'::character varying::text, 'ABT'::character varying::text, 'ARB'::character varying::text, 'CSL'::character varying::text, 'MKR'::character varying::text, 'XXX'::character varying::text, 'PFC'::character varying::text, 'ORG'::character varying::text, 'ORG2'::character varying::text, 'PIB'::character varying::text, 'MH'::character varying::text, 'MP'::character varying::text, 'IGO'::character varying::text, 'VIC'::character varying::text, 'ODS'::character varying::text, 'DAT'::character varying::text, 'VAL'::character varying::text, 'MIR'::character varying::text, 'NGN'::character varying::text, 'WIL'::character varying::text, 'PD'::character varying::text, 'CTR'::character varying::text, 'U_DOMA'::character varying::text, 'ABG'::character varying::text])) OR cte_init.network::text = 'U_RUS'::text AND cte_init.geo::text = 'TH'::text OR cte_init.sub IS NULL THEN 'No PubID'::character varying
                    WHEN cte_init.sub::text = ''::text THEN 'blank'::character varying
                    ELSE cte_init.sub
                END), cte_init.cf_so_lead_status, cte_init.cf_do_lead_status
        ), cte_raw AS (
         SELECT bm.createdate,
            date_part('week'::text, bm.createdate + '1 day'::interval) AS lead_week,
            date_part('month'::text, bm.createdate) AS lead_month,
            date_part('week'::text, CURRENT_DATE + '1 day'::interval) AS current_week,
            (date_trunc('week'::text, bm.createdate + '1 day'::interval) - '1 day'::interval)::date AS week_start,
            (date_trunc('week'::text, CURRENT_DATE + '1 day'::interval) - '1 day'::interval)::date AS week_start_current,
            "left"(bm.geo::text, 2) AS geo,
            COALESCE(btrim(dstfc.fin_camp), bm.sale_campaign::text) AS category,
            bm.sale_campaign AS cam_lead,
            bm.network,
            bm.offer AS product_name,
            bm.pub,
            bm.total_lead,
            bm.validated,
            bm.delivered
           FROM cte_group bm
             LEFT JOIN dim_sale_to_fin_camp dstfc ON "left"(bm.geo::text, 2) = btrim(dstfc.country_code) AND bm.sale_campaign::text = btrim(dstfc.sale_camp)
          ORDER BY bm.createdate, ("left"(bm.geo::text, 2)), bm.sale_campaign, bm.offer, bm.pub
        ), data AS (
         SELECT cte_raw.createdate,
            cte_raw.lead_week,
            cte_raw.lead_month,
            cte_raw.current_week,
            cte_raw.week_start,
            cte_raw.week_start_current,
            cte_raw.geo,
            cte_raw.category,
            cte_raw.cam_lead,
            cte_raw.network,
            cte_raw.product_name,
            cte_raw.pub,
            cte_raw.total_lead,
            cte_raw.validated,
            cte_raw.delivered,
                CASE
                    WHEN cte_raw.geo = 'ID'::text THEN cte_raw.week_start >= (cte_raw.week_start_current - 21)
                    WHEN cte_raw.geo = ANY (ARRAY['VN'::text, 'MY'::text]) THEN cte_raw.week_start >= (cte_raw.week_start_current - 14)
                    WHEN cte_raw.geo = ANY (ARRAY['TH'::text, 'PH'::text,'IN'::text]) THEN cte_raw.week_start >= (cte_raw.week_start_current - 7)
                    ELSE false
                END AS inrangeforecast
           FROM cte_raw
        ), data_forecast1 AS (
         SELECT data.createdate,
            data.lead_week,
            data.lead_month,
            data.current_week,
            data.week_start,
            data.week_start_current,
            data.geo,
            data.category,
            data.cam_lead,
            data.network,
            data.product_name,
            data.pub,
            data.total_lead,
            data.validated,
            data.delivered,
            data.inrangeforecast
           FROM data
          WHERE NOT data.inrangeforecast 
         			AND (
							data.geo = 'VN'::text 
							AND data.createdate <= (data.week_start_current - 15) 
							AND data.createdate >= (data.week_start_current - 35) 
							OR data.geo = 'ID'::text 
							AND data.createdate <= (data.week_start_current - 22) 
							AND data.createdate >= (data.week_start_current - 42) 
							OR data.geo = 'TH'::text 
							AND data.category = 'Fresh Hair'::text 
							AND data.createdate <= '2022-08-31'::date 
							AND data.createdate >= '2022-08-01'::date 
							OR data.geo = 'TH'::text 
							AND data.category <> 'Fresh Hair'::text 
							AND data.createdate <= (data.week_start_current - 22) 
							AND data.createdate >= (data.week_start_current - 42) 
							OR data.geo = 'PH'::text 
							AND data.createdate <= (data.week_start_current - 22) 
							AND data.createdate >= (data.week_start_current - 42) 
                            OR data.geo = 'IN'::text 
							AND data.createdate <= (data.week_start_current - 22) 
							AND data.createdate >= (data.week_start_current - 42) 
							OR data.geo = 'MY'::text 
							AND data.createdate <= (data.week_start_current - 15) 
							AND data.createdate >= (data.week_start_current - 35)
          				)
        ), full_data_forecast1 AS (
         SELECT data_forecast.geo,
            data_forecast.category,
            data_forecast.product_name,
            data_forecast.network,
            data_forecast.pub,
            sum(data_forecast.validated) AS validated,
            sum(data_forecast.delivered) AS delivered,
                CASE
                    WHEN sum(data_forecast.validated) = 0::numeric THEN 0::double precision
                    ELSE sum(data_forecast.delivered)::double precision / sum(data_forecast.validated)::double precision
                END AS dr_forecast
           FROM data_forecast1 data_forecast
          GROUP BY data_forecast.geo, data_forecast.category, data_forecast.product_name, data_forecast.network, data_forecast.pub
        ), full_data_forecast AS (
         SELECT a_1.geo,
            a_1.category,
            a_1.product_name,
            a_1.network,
            a_1.pub,
            a_1.validated,
            a_1.delivered,
            a_1.dr_forecast,
            NULL::bigint AS validated2,
            NULL::bigint AS delivered2,
            NULL::bigint AS dr_forecast2,
            NULL::bigint AS validated3,
            NULL::bigint AS delivered3,
            NULL::bigint AS dr_forecast3
           FROM full_data_forecast1 a_1
        ), full_data_forecast_by_network AS (
         SELECT full_data_forecast.geo,
            full_data_forecast.category,
            full_data_forecast.product_name,
            full_data_forecast.network,
            sum(full_data_forecast.validated) AS validated_by_network,
            NULL::bigint AS validated_by_network2,
            NULL::bigint AS validated_by_network3,
            sum(full_data_forecast.delivered) AS delivered_by_network,
            NULL::bigint AS delivered_by_network2,
            NULL::bigint AS delivered_by_network3,
                CASE
                    WHEN sum(full_data_forecast.validated) = 0::numeric THEN 0::double precision
                    ELSE sum(full_data_forecast.delivered)::double precision / sum(full_data_forecast.validated)::double precision
                END AS dr_forecast_by_network,
            NULL::bigint AS dr_forecast_by_network2,
            NULL::bigint AS dr_forecast_by_network3
           FROM full_data_forecast
          GROUP BY full_data_forecast.geo, full_data_forecast.category, full_data_forecast.product_name, full_data_forecast.network
        ), full_data_forecast_by_offer AS (
         SELECT full_data_forecast.geo,
            full_data_forecast.category,
            full_data_forecast.product_name,
            sum(full_data_forecast.validated) AS validated_by_offer,
            sum(full_data_forecast.delivered) AS delivered_by_offer,
                CASE
                    WHEN sum(full_data_forecast.validated) = 0::numeric THEN 0::double precision
                    ELSE sum(full_data_forecast.delivered)::double precision / sum(full_data_forecast.validated)::double precision
                END AS dr_forecast_by_offer,
            NULL::bigint AS validated_by_offer2,
            NULL::bigint AS delivered_by_offer2,
            NULL::bigint AS dr_forecast_by_offer2,
            NULL::bigint AS validated_by_offer3,
            NULL::bigint AS delivered_by_offer3,
            NULL::bigint AS dr_forecast_by_offer3
           FROM full_data_forecast
          GROUP BY full_data_forecast.geo, full_data_forecast.category, full_data_forecast.product_name
        ), full_data_forecast_by_cat AS (
         SELECT full_data_forecast.geo,
            full_data_forecast.category,
            sum(full_data_forecast.validated) AS validated_by_cat,
            sum(full_data_forecast.delivered) AS delivered_by_cat,
                CASE
                    WHEN sum(full_data_forecast.validated) = 0::numeric THEN 0::double precision
                    ELSE sum(full_data_forecast.delivered)::double precision / sum(full_data_forecast.validated)::double precision
                END AS dr_forecast_by_cat,
            NULL::bigint AS validated_by_cat2,
            NULL::bigint AS delivered_by_cat2,
            NULL::bigint AS dr_forecast_by_cat2,
            NULL::bigint AS validated_by_cat3,
            NULL::bigint AS delivered_by_cat3,
            NULL::bigint AS dr_forecast_by_cat3
           FROM full_data_forecast
          GROUP BY full_data_forecast.geo, full_data_forecast.category
        )
 SELECT raw.geo,
    raw.cam_lead AS category,
    raw.product_name,
    raw.network,
        CASE
            WHEN raw.pub IS NULL THEN 'No PubID'::character varying
            WHEN raw.pub::text = ''::text THEN 'blank'::character varying
            ELSE raw.pub
        END AS pub,
    a.validated,
    a.delivered,
    a.dr_forecast,
    b.validated_by_network,
    b.delivered_by_network,
    b.dr_forecast_by_network,
    c.validated_by_offer,
    c.delivered_by_offer,
    c.dr_forecast_by_offer,
    d.validated_by_cat,
    d.delivered_by_cat,
    d.dr_forecast_by_cat,
        CASE
            WHEN raw.product_name::text = 'bonivita-my'::text THEN d.dr_forecast_by_cat
            WHEN raw.product_name::text = 'megaburn390cpl-id'::text THEN 0.8::double precision
            ELSE
            CASE
                WHEN a.validated > 30::numeric THEN a.dr_forecast
                ELSE
                CASE
                    WHEN b.validated_by_network > 30::numeric THEN b.dr_forecast_by_network
                    ELSE
                    CASE
                        WHEN c.validated_by_offer > 30::numeric THEN c.dr_forecast_by_offer
                        ELSE d.dr_forecast_by_cat
                    END
                END
            END
        END AS dr_forecast_final,
    a.validated2,
    a.delivered2,
    a.dr_forecast2,
    b.validated_by_network2,
    b.delivered_by_network2,
    b.dr_forecast_by_network2,
    c.validated_by_offer2,
    c.delivered_by_offer2,
    c.dr_forecast_by_offer2,
    d.validated_by_cat2,
    d.delivered_by_cat2,
    d.dr_forecast_by_cat2,
    NULL::bigint AS dr_forecast_final2,
    a.validated3,
    a.delivered3,
    a.dr_forecast3,
    b.validated_by_network3,
    b.delivered_by_network3,
    b.dr_forecast_by_network3,
    c.validated_by_offer3,
    c.delivered_by_offer3,
    c.dr_forecast_by_offer3,
    d.validated_by_cat3,
    d.delivered_by_cat3,
    d.dr_forecast_by_cat3,
    NULL::bigint AS dr_forecast_final3
   FROM ( SELECT DISTINCT cte_raw.geo,
            cte_raw.cam_lead,
            cte_raw.category,
            cte_raw.network,
            cte_raw.product_name,
            cte_raw.pub
           FROM cte_raw) raw
     LEFT JOIN full_data_forecast a ON raw.geo = a.geo AND raw.category = a.category AND raw.product_name::text = a.product_name::text AND raw.network::text = a.network::text AND raw.pub::text = a.pub::text
     LEFT JOIN full_data_forecast_by_network b ON raw.geo = b.geo AND raw.category = b.category AND raw.product_name::text = b.product_name::text AND raw.network::text = b.network::text
     LEFT JOIN full_data_forecast_by_offer c ON raw.geo = c.geo AND raw.category = c.category AND raw.product_name::text = c.product_name::text
     LEFT JOIN full_data_forecast_by_cat d ON raw.geo = d.geo AND raw.category = d.category
