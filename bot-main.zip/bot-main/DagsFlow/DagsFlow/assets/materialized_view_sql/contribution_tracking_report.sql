WITH raw_items AS (
         SELECT od_so_item.geo,
            od_so_item.so_id,
            sum(od_so_item.quantity) AS items
           FROM od_so_item
          WHERE od_so_item.price <> 0
          GROUP BY od_so_item.geo, od_so_item.so_id
        ), cl_fresh1 AS (
         SELECT cl.createdate::date AS createdate,
            date_part('week'::text, cl.createdate + '1 day'::interval) AS lead_week,
            date_part('month'::text, cl.createdate) AS lead_month,
            date_part('year'::text, cl.createdate) AS lead_year,
                CASE
                    WHEN cl.createdate::date = '2022-01-01'::date THEN 4::double precision
                    WHEN cl.createdate::date = '2021-10-01'::date OR cl.createdate::date = '2021-10-02'::date THEN 3::double precision
                    WHEN cl.createdate::date = '2022-04-01'::date OR cl.createdate::date = '2022-04-02'::date THEN 1::double precision
                    ELSE date_part('quarter'::text, cl.createdate)
                END AS lead_quarter,
            date_part('week'::text, CURRENT_DATE + '1 day'::interval) AS current_week,
            (date_trunc('week'::text, cl.createdate + '1 day'::interval) - '1 day'::interval)::date AS week_start,
            (date_trunc('week'::text, CURRENT_DATE + '1 day'::interval) - '1 day'::interval)::date AS week_start_current,
                CASE
                    WHEN cl.prod_name IS NULL THEN 'No offer'::character varying
                    ELSE cl.prod_name
                END AS offer,
            cl.lead_id,
            cl.geo,
            cl.country_code,
                CASE
                    WHEN (cl.geo::text = ANY (ARRAY['VN'::character varying::text, 'VN2'::character varying::text])) AND cl.lead_type::text = 'A'::text THEN 'VN'::character varying
                    WHEN (cl.geo::text = ANY (ARRAY['TH'::character varying::text, 'TH2'::character varying::text])) AND cl.lead_type::text = 'A'::text THEN 'TH'::character varying
                    ELSE cl.geo
                END AS geo_2,
            cl.prod_name,
            cl.agc_code,
            cl.lead_type,
            cl.lead_status,
            cl.agc_id,
            cl.cp_id,
            cl.affiliate_id,
            cl.subid1,
            cl.province,
            cl.spl_mrp,
            cl.click_id,
            cl.ar_target,
            cl.postback_status,
            cl.batch_id,
                CASE
                    WHEN cl.lead_status = 4 OR cl.lead_status = 5 AND cl.assigned = 0 THEN 1
                    ELSE 0
                END AS filters,
            cl.actual_call
           FROM ( SELECT 
                    cl_fresh.createdate,
                    cl_fresh.lead_id,
                    cl_fresh.geo,
                    case when cl_fresh.geo = 'VNID' then 'VNID' else left(cl_fresh.geo::text, 2) end AS country_code,
                    cl_fresh.prod_name,
                    cl_fresh.agc_code,
                    cl_fresh.lead_type,
                    cl_fresh.lead_status,
                    cl_fresh.agc_id,
                    cl_fresh.cp_id,
                    cl_fresh.affiliate_id,
                    cl_fresh.subid1,
                    cl_fresh.province,
                    cl_fresh.assigned,
                    cl_fresh.click_id,
                    cl_fresh.actual_call,
                    cl_fresh.postback_status,
                    cl_fresh.batch_id,
                    lower(cl_fresh.name::text) AS cust_name,
                    dct.spl_mrp,
                    dct.ar_target
                   FROM cl_fresh cl_fresh
                     LEFT JOIN dim_cpl_target dct ON dct.pub = cl_fresh.affiliate_id::text AND dct.offer = cl_fresh.prod_name::text AND cl_fresh.createdate >= dct.from_date AND cl_fresh.createdate <= dct.to_date
                  WHERE cl_fresh.lead_type::text = 'A'::text AND cl_fresh.createdate >= '2024-01-01 00:00:00'::timestamp without time zone) cl
          WHERE cl.cust_name !~~ '%test%'::text
        ), sale_order AS (
         SELECT a_1.so_id,
            a_1.geo,
            a_1.cp_id,
            a_1.lead_id,
            a_1.amount,
            a_1.payment_method,
            a_1.status,
            a_1.createdate,
            ri.items,
            a_1.creation_date,
            a_1.validated_rn,
            a_1.rn,
            a_1.final_rn
           FROM ( SELECT oso_1.so_id,
                    oso_1.geo,
                    oso_1.cp_id,
                    oso_1.lead_id,
                    oso_1.amount,
                    oso_1.payment_method,
                    oso_1.status,
                    oso_1.createdate,
                    oso_1.creation_date,
                    sum(
                        CASE
                            WHEN oso_1.status = ANY (ARRAY[43, 357]) THEN 1
                            ELSE NULL::integer
                        END) OVER (PARTITION BY oso_1.lead_id) AS validated_rn,
                    row_number() OVER (PARTITION BY oso_1.lead_id ORDER BY oso_1.createdate DESC) AS rn,
                        CASE
                            WHEN row_number() OVER (PARTITION BY oso_1.lead_id ORDER BY oso_1.createdate DESC) = 1 AND sum(
                            CASE
                                WHEN oso_1.status = ANY (ARRAY[43, 357]) THEN 1
                                ELSE NULL::integer
                            END) OVER (PARTITION BY oso_1.lead_id) > 0 AND (oso_1.status <> ALL (ARRAY[43, 357])) THEN 2::bigint
                            WHEN row_number() OVER (PARTITION BY oso_1.lead_id ORDER BY oso_1.createdate DESC) <> 1 AND (oso_1.status = ANY (ARRAY[43, 357])) THEN 1::bigint
                            ELSE row_number() OVER (PARTITION BY oso_1.lead_id ORDER BY oso_1.createdate DESC)
                        END AS final_rn
                   FROM ( SELECT od_sale_order.so_id,
                            od_sale_order.geo,
                            od_sale_order.cp_id,
                            od_sale_order.lead_id,
                            od_sale_order.amount,
                            od_sale_order.payment_method,
                            od_sale_order.status,
                            od_sale_order.createdate,
                            od_sale_order.creation_date
                           FROM od_sale_order
                          WHERE od_sale_order.createdate >= (CURRENT_DATE - 90) AND od_sale_order.status <> 46) oso_1) a_1
             LEFT JOIN raw_items ri ON a_1.geo::text = ri.geo::text AND a_1.so_id = ri.so_id
          WHERE a_1.final_rn = 1
        ), cte_raw AS (
         SELECT cl_fresh.createdate,
            cl_fresh.lead_week,
            cl_fresh.lead_month,
            cl_fresh.lead_year,
            cl_fresh.lead_quarter,
            cl_fresh.current_week,
            cl_fresh.week_start,
            cl_fresh.week_start_current,
            cl_fresh.lead_id,
            cl_fresh.lead_type,
            cl_fresh.geo,
            cl_fresh.country_code,
            cl_fresh.offer,
            cl_fresh.affiliate_id AS network,
            cl_fresh.subid1 AS sub,
            cl_fresh.lead_status,
            cl_fresh.spl_mrp,
            cl_fresh.ar_target,
            cl_fresh.postback_status,
            cl_fresh.batch_id,
            cl_fresh.actual_call,
            oso.so_id,
            oso.items,
            oso.status AS so_status,
            oso.amount AS oso_amount,
            odn.status AS do_status,
            cc.name AS sale_campaign,
            ll.new_urgent,
            cl_fresh.agc_id,
            afs.payout,
            afs.max_po
           FROM ( SELECT cl_fresh1.createdate,
                    cl_fresh1.lead_week,
                    cl_fresh1.lead_month,
                    cl_fresh1.lead_year,
                    cl_fresh1.lead_quarter,
                    cl_fresh1.current_week,
                    cl_fresh1.week_start,
                    cl_fresh1.week_start_current,
                    cl_fresh1.offer,
                    cl_fresh1.lead_id,
                    cl_fresh1.postback_status,
                    cl_fresh1.batch_id,
                    cl_fresh1.geo,
                    cl_fresh1.country_code,
                    cl_fresh1.geo_2,
                    cl_fresh1.prod_name,
                    cl_fresh1.agc_code,
                    cl_fresh1.lead_type,
                    cl_fresh1.lead_status,
                    cl_fresh1.agc_id,
                    cl_fresh1.cp_id,
                    cl_fresh1.affiliate_id,
                    cl_fresh1.subid1,
                    cl_fresh1.province,
                    cl_fresh1.filters,
                    cl_fresh1.spl_mrp,
                    cl_fresh1.ar_target,
                    cl_fresh1.click_id,
                    cl_fresh1.actual_call
                   FROM cl_fresh1
                  WHERE cl_fresh1.filters = 0) cl_fresh
             LEFT JOIN sale_order oso ON cl_fresh.lead_id = oso.lead_id AND oso.geo::text = cl_fresh.geo::text
             LEFT JOIN od_do_new odn ON odn.so_id = oso.so_id AND oso.geo::text = odn.geo::text
             LEFT JOIN new_urgent_temp ll ON cl_fresh.geo::text = ll.geo::text AND cl_fresh.lead_id::text = ll.lead_id::text
             LEFT JOIN ods_affscale_conversion afs ON afs.transaction_id = cl_fresh.click_id::text
             LEFT JOIN ( SELECT od_so_item.geo,
                    od_so_item.so_id,
                    sum(od_so_item.quantity) AS quantity
                   FROM od_so_item
                  GROUP BY od_so_item.geo, od_so_item.so_id) osi ON oso.so_id = osi.so_id AND oso.geo::text = osi.geo::text
             LEFT JOIN bp_partner p ON cl_fresh.agc_id = p.pn_id AND p.geo::text = cl_fresh.geo::text
             LEFT JOIN cp_campaign cc ON cl_fresh.cp_id = cc.cp_id AND cl_fresh.geo::text = cc.geo::text
          WHERE cl_fresh.lead_type::text = 'A'::text AND (lower(cc.name::text) <> 'cptest'::text AND lower(cc.name::text) <> 'cp_test'::text OR cc.name IS NULL)
        ), cte_lead_traffics AS (
         SELECT lead_traffics.affiliate_id AS network,
            lead_traffics.traffic,
            lead_traffics.applied_from_date::date AS started_date,
            lead_traffics.applied_to_date::date AS ending_date
           FROM lead_traffics
          WHERE lead_traffics.applied_from_date::date <= lead_traffics.applied_to_date::date
        ), cte_ar_mrps AS (
         SELECT ar_mrps.affiliate_id AS network,
            ar_mrps.offer_id AS product_name,
                CASE
                    WHEN lower(ar_mrps.sub_id) = '*'::text THEN ''::text
                    WHEN lower(ar_mrps.sub_id) = ''::text THEN 'blank'::text
                    ELSE ar_mrps.sub_id
                END AS sub_id,
            ar_mrps.ar_mrp,
            ar_mrps.applied_from_date::date AS started_date,
            ar_mrps.applied_to_date::date AS ending_date,
                CASE
                    WHEN lower(ar_mrps.sub_id) = '*'::text THEN concat(ar_mrps.affiliate_id, '_', ar_mrps.offer_id)
                    WHEN lower(ar_mrps.sub_id) = ''::text THEN concat(ar_mrps.affiliate_id, '_', 'blank', '_', ar_mrps.offer_id)
                    ELSE concat(ar_mrps.affiliate_id, '_', ar_mrps.sub_id, '_', ar_mrps.offer_id)
                END AS target_key
           FROM ar_mrps
        ), cte_lead_mrps AS (
         SELECT lead_mrps.affiliate_id AS network,
            lead_mrps.offer_id AS product_name,
                CASE
                    WHEN lower(lead_mrps.sub_id) = '*'::text THEN ''::text
                    WHEN lower(lead_mrps.sub_id) = ''::text THEN 'blank'::text
                    ELSE lead_mrps.sub_id
                END AS sub_id,
            lead_mrps.lead_mrp,
            lead_mrps.applied_from_date::date AS started_date,
            lead_mrps.applied_to_date::date AS ending_date,
                CASE
                    WHEN lower(lead_mrps.sub_id) = '*'::text THEN concat(lead_mrps.affiliate_id, '_', lead_mrps.offer_id)
                    WHEN lower(lead_mrps.sub_id) = ''::text THEN concat(lead_mrps.affiliate_id, '_', 'blank', '_', lead_mrps.offer_id)
                    ELSE concat(lead_mrps.affiliate_id, '_', lead_mrps.sub_id, '_', lead_mrps.offer_id)
                END AS target_key
           FROM lead_mrps
        ), cte_group_raw AS (
         SELECT cte_raw.createdate,
            cte_raw.lead_week,
            cte_raw.lead_month,
            cte_raw.lead_year,
            cte_raw.current_week,
            cte_raw.week_start,
            cte_raw.week_start_current,
            cte_raw.geo,
            cte_raw.country_code,
            cte_raw.offer,
            cte_raw.batch_id,
            cte_raw.network,
                CASE
                    WHEN cte_raw.geo::text ^@ 'VN'::text AND cte_raw.week_start >= (cte_raw.week_start_current - 14) THEN 1
                    WHEN cte_raw.geo::text ^@ 'ID'::text AND cte_raw.week_start >= (cte_raw.week_start_current - 21) THEN 1
                    WHEN cte_raw.geo::text ^@ 'TH'::text AND cte_raw.week_start >= (cte_raw.week_start_current - 7) THEN 1
                    WHEN cte_raw.geo::text ^@ 'PH'::text AND cte_raw.week_start >= (cte_raw.week_start_current - 7) THEN 1
                    WHEN cte_raw.geo::text ^@ 'MY'::text AND cte_raw.week_start >= (cte_raw.week_start_current - 14) THEN 1
                    ELSE 0
                END AS inrangeforecast,
            sum(
                CASE
                    WHEN cte_raw.do_status = 59 THEN 1
                    ELSE 0
                END) AS delivered,
            sum(cte_raw.new_urgent) AS new_,
            avg(cte_raw.payout) AS payout,
            avg(cte_raw.max_po) AS max_po,
            sum(cte_raw.actual_call) AS total_actual_call,
            sum(
                CASE
                    WHEN cte_raw.lead_status = ANY (ARRAY[6, 7, 10, 11]) THEN cte_raw.actual_call
                    ELSE 0
                END) AS total_actual_uncall,
            COALESCE(dim_pc."FIN camp", ''::text) AS category,
                CASE
                    WHEN (cte_raw.network::text = ANY (ARRAY['EW'::character varying::text, 'AT'::character varying::text, 'ADT'::character varying::text, 'ABT'::character varying::text, 'ARB'::character varying::text, 'CSL'::character varying::text, 'MKR'::character varying::text, 'XXX'::character varying::text, 'PFC'::character varying::text, 'ORG'::character varying::text, 'ORG2'::character varying::text, 'PIB'::character varying::text, 'MH'::character varying::text, 'MP'::character varying::text, 'IGO'::character varying::text, 'VIC'::character varying::text, 'ODS'::character varying::text, 'DAT'::character varying::text, 'VAL'::character varying::text, 'MIR'::character varying::text, 'NGN'::character varying::text, 'WIL'::character varying::text, 'PD'::character varying::text, 'CTR'::character varying::text, 'U_DOMA'::character varying::text, 'ABG'::character varying::text])) OR cte_raw.network::text = 'U_RUS'::text AND cte_raw.geo::text = 'TH'::text OR cte_raw.sub IS NULL THEN 'No PubID'::character varying
                    WHEN cte_raw.sub::text = ''::text THEN 'blank'::character varying
                    ELSE cte_raw.sub
                END AS pub,
            cte_raw.sale_campaign,
            cte_raw.agc_id,
            cte_raw.items,
                CASE
                    WHEN cdbmm.manager IS NULL THEN 'Others'::text
                    ELSE cdbmm.manager
                END AS manager,
                CASE
                    WHEN cdbmm.manager = ANY (ARRAY['Jane'::text, 'Marcus'::text, 'Nikita'::text]) THEN 'Jane'::text
                    WHEN cdbmm.manager = ANY (ARRAY['David'::text, 'Anna'::text, 'Vlad.N'::text]) THEN 'David'::text
                    WHEN cdbmm.manager = 'Others'::text OR cdbmm.manager IS NULL THEN 'Others'::text
                    ELSE NULL::text
                END AS "Team",
            count(DISTINCT cte_raw.lead_id) AS total_lead,
            count(DISTINCT cte_raw.so_id) AS total_so,
            count(DISTINCT
                CASE
                    WHEN cte_raw.lead_status = ANY (ARRAY[6, 7, 10, 11]) THEN cte_raw.lead_id
                    ELSE NULL::bigint
                END) AS uncall,
            count(DISTINCT
                CASE
                    WHEN cte_raw.lead_status = ANY (ARRAY[4, 5]) THEN cte_raw.lead_id
                    ELSE NULL::bigint
                END) AS trash,
            count(DISTINCT
                CASE
                    WHEN cte_raw.lead_status = 2 THEN cte_raw.lead_id
                    ELSE NULL::bigint
                END) AS approved,
            count(DISTINCT
                CASE
                    WHEN cte_raw.lead_status = 2 AND (cte_raw.postback_status IS NULL OR cte_raw.postback_status::text = 'approved'::text) THEN cte_raw.lead_id
                    ELSE NULL::bigint
                END) AS approved_pb,
            count(DISTINCT
                CASE
                    WHEN cte_raw.lead_status = 3 THEN cte_raw.lead_id
                    ELSE NULL::bigint
                END) AS rejected,
            count(
                CASE
                    WHEN cte_raw.lead_status = ANY (ARRAY[2, 3, 8, 9, 14]) THEN cte_raw.lead_id
                    ELSE NULL::bigint
                END) AS contactable,
            count(DISTINCT
                CASE
                    WHEN cte_raw.so_status = ANY (ARRAY[43, 357]) THEN cte_raw.lead_id
                    ELSE NULL::bigint
                END) AS validated,
            count(DISTINCT
                CASE
                    WHEN cte_raw.so_status = ANY (ARRAY[43, 357]) AND (cte_raw.postback_status IS NULL OR cte_raw.postback_status::text = 'approved'::text) THEN cte_raw.lead_id
                    ELSE NULL::bigint
                END) AS total_approved_postback,
            count(DISTINCT
                CASE
                    WHEN cte_raw.so_status = ANY (ARRAY[43, 357]) AND (cte_raw.postback_status::text = ANY (ARRAY['pending_postback'::character varying::text, 'pending_pb'::character varying::text])) THEN cte_raw.lead_id
                    ELSE NULL::bigint
                END) AS total_pending_postback,
            sum(
                CASE
                    WHEN cte_raw.so_status = ANY (ARRAY[43, 357]) THEN cte_raw.oso_amount
                    ELSE NULL::numeric
                END) AS amt_validated,
            sum(
                CASE
                    WHEN cte_raw.do_status = 59 THEN cte_raw.oso_amount
                    ELSE NULL::numeric
                END) AS amt_delivered,
            sum(
                CASE
                    WHEN cte_raw.do_status = ANY (ARRAY[53, 59, 61, 56]) THEN 1
                    ELSE 0
                END) AS finalized_do,
            sum(
                CASE
                    WHEN cte_raw.so_status = ANY (ARRAY[43, 357]) AND (cte_raw.postback_status IS NULL OR cte_raw.postback_status::text = 'approved'::text) THEN cte_raw.oso_amount
                    ELSE NULL::numeric
                END) AS amt_validated_pb,
                CASE
                    WHEN tf.traffic = ''::text OR tf.traffic IS NULL THEN 'No Traffic'::text
                    ELSE tf.traffic
                END AS traffic_source,
            COALESCE(am.ar_mrp, am_2.ar_mrp) AS ar_target_mrp,
            lm.lead_mrp,
            lm_2.lead_mrp AS pub_lead_mrp,
            avg(cte_raw.spl_mrp) AS spl_mrp,
            avg(cte_raw.ar_target) AS ar_target,
                CASE
                    WHEN cte_raw.geo::text ^@ 'TH'::text THEN 'TH'::text
                    WHEN cte_raw.geo::text ^@ 'VN'::text THEN 'VN'::text
                    WHEN cte_raw.geo::text ^@ 'ID'::text THEN 'ID'::text
                    WHEN cte_raw.geo::text ^@ 'MY'::text THEN 'MY'::text
                    WHEN cte_raw.geo::text ^@ 'PH'::text THEN 'PH'::text
                    ELSE cte_raw.geo::text
                END AS geo_rate
           FROM cte_raw
             LEFT JOIN cdm_dim_ar_mrp_target_by_date dim_at ON
                CASE
                    WHEN cte_raw.sub::text = ''::text THEN concat(cte_raw.network, '_', 'blank', '_', cte_raw.offer)
                    ELSE concat(cte_raw.network, '_', cte_raw.sub, '_', cte_raw.offer)
                END = dim_at.target_key AND cte_raw.createdate >= dim_at.started_date::date AND cte_raw.createdate <= dim_at.ending_date::date
             LEFT JOIN cdm_dim_ar_mrp_target_by_date dim_at_2 ON concat(cte_raw.network, '_', cte_raw.offer) = dim_at_2.target_key AND cte_raw.createdate >= dim_at_2.started_date::date AND cte_raw.createdate <= dim_at_2.ending_date::date
             LEFT JOIN cte_lead_traffics tf ON cte_raw.network::text = tf.network AND cte_raw.createdate >= tf.started_date AND cte_raw.createdate <= tf.ending_date
             LEFT JOIN cte_ar_mrps am ON
                CASE
                    WHEN cte_raw.sub::text = ''::text THEN concat(cte_raw.network, '_', 'blank', '_', cte_raw.offer)
                    ELSE concat(cte_raw.network, '_', cte_raw.sub, '_', cte_raw.offer)
                END = am.target_key AND cte_raw.createdate >= am.started_date AND cte_raw.createdate <= am.ending_date
             LEFT JOIN cte_ar_mrps am_2 ON concat(cte_raw.network, '_', cte_raw.offer) = am_2.target_key AND cte_raw.createdate >= am_2.started_date AND cte_raw.createdate <= am_2.ending_date
             LEFT JOIN cte_lead_mrps lm ON
                CASE
                    WHEN cte_raw.sub::text = ''::text THEN concat(cte_raw.network, '_', 'blank', '_', cte_raw.offer)
                    ELSE concat(cte_raw.network, '_', cte_raw.sub, '_', cte_raw.offer)
                END = lm.target_key AND cte_raw.createdate >= lm.started_date AND cte_raw.createdate <= lm.ending_date
             LEFT JOIN cte_lead_mrps lm_2 ON concat(cte_raw.network, '_', cte_raw.offer) = lm_2.target_key AND cte_raw.createdate >= lm_2.started_date AND cte_raw.createdate <= lm_2.ending_date
             LEFT JOIN ( SELECT bd_temp_am."Name" AS network,
                    bd_temp_am."Manager" AS manager
                   FROM bd_temp_am) cdbmm ON lower(cdbmm.network) = lower(cte_raw.network::text)
             LEFT JOIN cdm_dim_product_cat dim_pc ON lower(cte_raw.offer::text) = lower(dim_pc.product_name) AND lower(cte_raw.geo::text) = lower(dim_pc.geo)
          GROUP BY cte_raw.batch_id, cte_raw.items, cte_raw.createdate, cte_raw.country_code, cte_raw.lead_week, cte_raw.lead_month, cte_raw.lead_year, cte_raw.current_week, cte_raw.week_start, cte_raw.week_start_current, cte_raw.geo, cte_raw.offer, cte_raw.network, cte_raw.agc_id, dim_pc."FIN camp", (
                CASE
                    WHEN (cte_raw.network::text = ANY (ARRAY['EW'::character varying::text, 'AT'::character varying::text, 'ADT'::character varying::text, 'ABT'::character varying::text, 'ARB'::character varying::text, 'CSL'::character varying::text, 'MKR'::character varying::text, 'XXX'::character varying::text, 'PFC'::character varying::text, 'ORG'::character varying::text, 'ORG2'::character varying::text, 'PIB'::character varying::text, 'MH'::character varying::text, 'MP'::character varying::text, 'IGO'::character varying::text, 'VIC'::character varying::text, 'ODS'::character varying::text, 'DAT'::character varying::text, 'VAL'::character varying::text, 'MIR'::character varying::text, 'NGN'::character varying::text, 'WIL'::character varying::text, 'PD'::character varying::text, 'CTR'::character varying::text, 'U_DOMA'::character varying::text, 'ABG'::character varying::text])) OR cte_raw.network::text = 'U_RUS'::text AND cte_raw.geo::text = 'TH'::text OR cte_raw.sub IS NULL THEN 'No PubID'::character varying
                    WHEN cte_raw.sub::text = ''::text THEN 'blank'::character varying
                    ELSE cte_raw.sub
                END), cte_raw.sale_campaign, (COALESCE(am.ar_mrp, am_2.ar_mrp)), lm.lead_mrp, lm_2.lead_mrp, cdbmm.manager, tf.traffic, (
                CASE
                    WHEN cte_raw.geo::text ^@ 'VN'::text AND cte_raw.week_start >= (cte_raw.week_start_current - 14) THEN 1
                    WHEN cte_raw.geo::text ^@ 'ID'::text AND cte_raw.week_start >= (cte_raw.week_start_current - 21) THEN 1
                    WHEN cte_raw.geo::text ^@ 'TH'::text AND cte_raw.week_start >= (cte_raw.week_start_current - 7) THEN 1
                    WHEN cte_raw.geo::text ^@ 'PH'::text AND cte_raw.week_start >= (cte_raw.week_start_current - 7) THEN 1
                    WHEN cte_raw.geo::text ^@ 'MY'::text AND cte_raw.week_start >= (cte_raw.week_start_current - 14) THEN 1
                    ELSE 0
                END)
        ), cte_group_cal_aov AS (
         SELECT cte_group_raw.createdate,
            cte_group_raw.lead_week,
            cte_group_raw.lead_month,
            cte_group_raw.lead_year,
            cte_group_raw.current_week,
            cte_group_raw.sale_campaign,
            cte_group_raw.week_start,
            cte_group_raw.week_start_current,
            cte_group_raw.geo,
            cte_group_raw.country_code,
            cte_group_raw.offer,
            cte_group_raw.network,
            cte_group_raw.category,
            cte_group_raw.batch_id,
            cte_group_raw.pub,
            cte_group_raw.items,
            cte_group_raw.manager,
            cte_group_raw."Team",
            cte_group_raw.inrangeforecast,
            cte_group_raw.ar_target_mrp,
            cte_group_raw.lead_mrp,
            cte_group_raw.pub_lead_mrp,
            cte_group_raw.total_lead,
            cte_group_raw.total_so,
            cte_group_raw.uncall,
            cte_group_raw.trash,
            cte_group_raw.payout,
            cte_group_raw.max_po,
            cte_group_raw.total_actual_call,
            cte_group_raw.total_actual_uncall,
            cte_group_raw.approved,
            cte_group_raw.approved_pb,
            cte_group_raw.contactable,
            cte_group_raw.finalized_do,
            cte_group_raw.rejected,
            cte_group_raw.validated,
            cte_group_raw.delivered,
            cte_group_raw.new_,
            cte_group_raw.amt_validated,
            cte_group_raw.amt_validated_pb,
            cte_group_raw.amt_delivered,
            cte_group_raw.total_approved_postback,
            cte_group_raw.total_pending_postback,
            dbat.aov_target,
                CASE
                    WHEN cte_group_raw.validated = 0 THEN 0::double precision
                    ELSE cte_group_raw.amt_validated::double precision / rate.exchange
                END AS amt_validated_usd,
                CASE
                    WHEN cte_group_raw.total_approved_postback = 0 THEN 0::double precision
                    ELSE cte_group_raw.amt_validated_pb::double precision / rate.exchange
                END AS amt_validated_pb_usd,
                CASE
                    WHEN cte_group_raw.delivered = 0 THEN 0::double precision
                    ELSE cte_group_raw.amt_delivered::double precision / rate.exchange
                END AS amt_delivered_usd,
            cte_group_raw.spl_mrp,
            rate.exchange,
            cte_group_raw.ar_target,
                CASE
                    WHEN cte_group_raw.total_lead = 0 THEN 0::double precision
                    ELSE cte_group_raw.trash::double precision / cte_group_raw.total_lead::double precision
                END AS tr,
                CASE
                    WHEN cte_group_raw.total_lead = 0 THEN 0::double precision
                    ELSE cte_group_raw.validated::double precision / cte_group_raw.total_lead::double precision
                END AS ar_qa
           FROM cte_group_raw
             LEFT JOIN dim_exchange_rate rate ON cte_group_raw.geo_rate = rate.geo AND cte_group_raw.createdate >= rate.started_date::date AND cte_group_raw.createdate <= rate.ending_date::date
             LEFT JOIN dim_bd_aov_target dbat ON cte_group_raw.offer::text = dbat.offer::text AND cte_group_raw.network::text = dbat.pub::text AND cte_group_raw.createdate >= dbat.from_date AND cte_group_raw.createdate <= dbat.to_date
        )
, final as 
(
 SELECT cte_group_cal_aov.createdate,
    cte_group_cal_aov.lead_week,
    cte_group_cal_aov.lead_month,
    cte_group_cal_aov.lead_year,
    cte_group_cal_aov.lead_year || '-'::text || cte_group_cal_aov.lead_month AS lead_year_month,
    cte_group_cal_aov.items,
    cte_group_cal_aov.current_week,
    cte_group_cal_aov.week_start,
    cte_group_cal_aov.week_start_current,
    cte_group_cal_aov.geo,
    cte_group_cal_aov.country_code,
    cte_group_cal_aov.total_approved_postback,
    cte_group_cal_aov.total_pending_postback,
        CASE
            WHEN cte_group_cal_aov.offer::text ~~* '%cpl%'::text THEN lower(cte_group_cal_aov.offer::text)::character varying
            ELSE cte_group_cal_aov.offer
        END AS offer,
    cte_group_cal_aov.network,
    cte_group_cal_aov.category,
    cte_group_cal_aov.batch_id,
    cte_group_cal_aov.pub,
    cte_group_cal_aov.finalized_do,
    cte_group_cal_aov.sale_campaign,
    cte_group_cal_aov.manager,
    cte_group_cal_aov."Team",
    cte_group_cal_aov.ar_target_mrp,
    cte_group_cal_aov.lead_mrp,
    cte_group_cal_aov.pub_lead_mrp,
    cte_group_cal_aov.total_lead,
    cte_group_cal_aov.total_so,
    cte_group_cal_aov.uncall,
    cte_group_cal_aov.trash,
    cte_group_cal_aov.approved,
    cte_group_cal_aov.approved_pb,
    cte_group_cal_aov.rejected,
    cte_group_cal_aov.contactable,
    cte_group_cal_aov.validated,
    cte_group_cal_aov.delivered,
    cte_group_cal_aov.tr,
    cte_group_cal_aov.new_,
    cte_group_cal_aov.payout,
    cte_group_cal_aov.max_po,
    cte_group_cal_aov.total_actual_call,
    cte_group_cal_aov.total_actual_uncall,
    cte_group_cal_aov.ar_qa,
    cte_group_cal_aov.amt_validated,
    cte_group_cal_aov.amt_validated_pb,
    cte_group_cal_aov.amt_validated_usd,
    cte_group_cal_aov.amt_delivered_usd,
    cte_group_cal_aov.amt_validated_pb_usd,
    cte_group_cal_aov.spl_mrp,
    cte_group_cal_aov.exchange,
    cte_group_cal_aov.inrangeforecast,
    cte_group_cal_aov.ar_target,
    cte_group_cal_aov.aov_target,
    dt."Lead MRP" AS deal_lead_mrp,
    dt."AR_MRP" AS deal_armrp,
    dt."AOV_MRP" AS deal_aov_mrp,
    dt."SPL target" AS deal_spl_target,
    dt."DR_MRP" AS deal_dr_mrp,
    dt."%Lead cost MRP" AS deal_lead_cost_mrp,
    dt."%GM1 MRP" AS deal_gm1_mrp,
    dt."%GM2 MRP" AS deal_gm2_mrp,
        CASE
            WHEN btrim(dt."Type") ^@ 'CPL'::text THEN 'CPL'::text
            ELSE 'CPA'::text
        END AS deal_type,
    gm.tax_rate,
    COALESCE(ddfm.dr_forecast, COALESCE(
        CASE
            WHEN cte_group_cal_aov.inrangeforecast = 1 THEN cddfbd.dr_forecast_final
            ELSE
            CASE
                WHEN cte_group_cal_aov.validated = 0 THEN 0::double precision
                ELSE cte_group_cal_aov.delivered::double precision / cte_group_cal_aov.validated::double precision
            END
        END,
        CASE
            WHEN cte_group_cal_aov.validated = 0 THEN 0::double precision
            ELSE cte_group_cal_aov.delivered::double precision / cte_group_cal_aov.validated::double precision
        END)) AS dr_final,
    CURRENT_DATE - 1 AS last_refresh
   FROM cte_group_cal_aov
     LEFT JOIN cdm_dim_dr_forecast_by_date cddfbd ON cte_group_cal_aov.country_code = cddfbd.geo AND cte_group_cal_aov.sale_campaign::text = cddfbd.category AND cte_group_cal_aov.offer::text = cddfbd.product_name AND cte_group_cal_aov.network::text = cddfbd.network AND cte_group_cal_aov.pub::text = cddfbd.pub
     LEFT JOIN dim_bd_gm_input gm ON gm.geo = cte_group_cal_aov.country_code AND cte_group_cal_aov.createdate >= gm.started_date::date AND cte_group_cal_aov.createdate <= gm.ending_date::date
     LEFT JOIN dim_follow_up_deal_target dt ON dt."Pub" = cte_group_cal_aov.network::text AND lower(dt."Offer") = lower(cte_group_cal_aov.offer::text) AND cte_group_cal_aov.createdate >= dt."Start date" AND cte_group_cal_aov.createdate <= dt."end date"
     LEFT JOIN dim_dr_manual_forecast ddfm ON cte_group_cal_aov.network::text = ddfm.network AND cte_group_cal_aov.offer::text = ddfm.offer AND cte_group_cal_aov.createdate >= ddfm."from" AND cte_group_cal_aov.createdate <= ddfm."to"
     )
     select a.*, 
            case when a.offer ilike '%cpl%' then total_lead - trash else 0 end cpl_lead
     from final a