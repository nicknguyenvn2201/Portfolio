select 
  fct.geo,
  fct.lead_id,
  fct.so_id,
  fct.do_id,
  ou.user_name agent_name,
  fct.name customer_name,
  null address,
  fct.province customer_address_province,
  fct.district customer_address_district,
  fct.subdistrict customer_address_subdistrict,
  cfs.name payment_method,
  fct.so_amount sales_amount,
  fct.offer lead_product_name,
  fct.productcrosssell product_cross_sell,
  fct.tracking_code delivery_tracking_code,
  fct.do_code,
  fct.ffm_code,
  fct.warehouse_name delivery_warehouse,
  fct.carrier delivery_carrier,
  fct.lead_status,
  fct.so_status,
  fct.do_status,
  fct.lead_type,
  fct.payout,
  fct.max_po,
  fct.lead_date,
  fct.lead_modify_date lead_modifydate,
  fct.so_date,
  fct.so_modify_date so_modifydate,
  fct.do_date,
  fct.do_modify_date do_modifydate,
  case when fct.do_status = 'delivered' then fct.do_modify_date end delivery_delivered_time,
  fct.network,
  fct.sale_campaign campaign_name,
  null campaign_status,
  null campaign_category,
  fct.click_id,
  fct.postback_status,
  fct.postback_date postback_time,
  case
   when(fct.network in ('EW','AT','ADT','ABT','ARB','CSL','MKR','XXX','PFC','ORG','ORG2','PIB','MH',
                         'MP','IGO','VIC','ODS','DAT','VAL','MIR','NGN','WIL','PD','CTR','U_DOMA','ABG'
                         )
        )
    or fct.network = 'U_RUS' and fct.geo = 'TH'
    or fct.pub is null
   then 'No PubID'
   when fct.pub = ''
   then 'blank'
   else fct.pub
   end as pub,
   fresh_lead_id lead_fresh_id,
   fresh_org_id lead_fresh_geo,
   updated_at source_update_time
from data_master_raw fct
left join (select 
             distinct 
              geo,
              user_id,
              user_name 
           from or_user where user_type in ('agent', 'system')
           ) ou on 
 fct.assigned = ou.user_id
 and fct.geo = ou.geo
LEFT JOIN cf_synonym cfs ON 
 fct.geo::text = cfs.geo::text AND fct.payment_method = cfs.value 
 AND cfs.type::text = 'payment mothod'::text
where fct.name::text !~~ '%test%'::text
and not ( fct.lead_status = 'duplicated' 
            or 
        (fct.lead_status = 'trash' and fct.assigned = 0)
        )
and fct.geo is not null
and not (fct.geo = 'ID' and fct.org_id = 4)
