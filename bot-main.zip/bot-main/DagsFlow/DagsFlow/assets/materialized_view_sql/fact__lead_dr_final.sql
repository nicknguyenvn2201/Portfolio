with
    base_fact as (
        select
            left(geo, 2) as country_code,
            (date_trunc('week', lead_date + interval '1' day) - interval '1' day)::date
            as week_start,
            (
                date_trunc('week', current_date + interval '1' day) - interval '1' day
            )::date as week_start_current,
            geo,
            lead_date::date,
            lead_id,
            campaign_name,
            lead_product_name,
            network,
            pub,
            lead_type,
            case
                when do_status in ('delivered')
                then 1
                when do_status in ('returned', 'returning')
                then 0
                else null
            end as dr_actual
        from "tms_central"."dareport"."fact__lead_sales_delivery"
    ),
    find_in_range_forecast as (
        select
            base.*,
            case
                when country_code = 'ID'
                then week_start >= (week_start_current - 21)
                when country_code in ('VN', 'MY')
                then week_start >= (week_start_current - 14)
                when country_code in ('TH', 'PH')
                then week_start >= (week_start_current - 7)
                else false
            end as is_in_range_forecast
        from base_fact as base
    ),
    dim_dr_forecast_fresh as (
        select
            geo as country_code,
            category as campaign_name,
            product_name as lead_product_name,
            network,
            pub,
            dr_forecast_final as dr_forecast
        from "tms_central"."dareport"."cdm_dim_dr_forecast_by_date"
    ),
    dim_dr_forecast_resell as (
        select
            geo as country_code,
            category as campaign_name,
            dr_forecast_final as dr_forecast
        from "tms_central"."dareport"."cdm_dim_dr_forecast_resell"
    ),
    join_with_actual_and_forecast as (
        select
            base.*,
            forecast_fresh.dr_forecast as dr_forecast_fresh,
            forecast_resell.dr_forecast as dr_forecast_resell
        from find_in_range_forecast as base
        left join
            dim_dr_forecast_fresh as forecast_fresh
            on base.country_code = forecast_fresh.country_code
            and base.campaign_name = forecast_fresh.campaign_name
            and base.lead_product_name = forecast_fresh.lead_product_name
            and base.network = forecast_fresh.network
            and base.pub = forecast_fresh.pub
            and base.lead_type = 'A'
        left join
            dim_dr_forecast_resell as forecast_resell
            on base.country_code = forecast_resell.country_code
            and base.campaign_name = forecast_resell.campaign_name
            and base.lead_type <> 'A'
    ),
    find_dr_final as (
        select
            *,
            case
                when dr_actual is not null
                then dr_actual
                when is_in_range_forecast and dr_forecast_fresh is not null
                then dr_forecast_fresh
                when is_in_range_forecast and dr_forecast_resell is not null
                then dr_forecast_resell
                else 0
            end as dr_final
        from join_with_actual_and_forecast
    )
select geo, lead_id, dr_final, lead_date
from find_dr_final
