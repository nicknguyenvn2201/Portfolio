select geo, org_id
from "base_layer"."pd_product"
where geo is not null and org_id is not null and not (geo = 'TH' and org_id = 12)
group by 1, 2