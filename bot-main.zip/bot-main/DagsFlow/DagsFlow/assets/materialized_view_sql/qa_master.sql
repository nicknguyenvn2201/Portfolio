WITH a AS 
(
select  odn.geo geo,
		odn.org_id orgId,
		odn.so_id ma_don_hang,
		odn.customer_id leadid,
		cl.lead_type leadtype, 
		cl.total_call,
		cl.address dia_chi,
		cl.ghi_chu_khach_hang,
		odn.do_code ma_don_goc,
		odn.tracking_code,
		odn.do_id,
		case when COALESCE(j.shortname, cl.agc_code) = 'AFS' then affiliate_id else COALESCE(j.shortname, cl.agc_code) end as sourcename,
		h.user_name assgin,
		cl.address,
		odn.customer_name ten_nguoi_nhan,
		n.code zipcode_db,
		n.name phuong_xa,
		m.name quan_huyen,
		l.name tinh_thanh_pho,
		b.shortname warehouse,
		warehouse_name,
		e.shortname carrier,
		p.name status,
		o.name so_status,
		d.name statustransport,
		CASE
			WHEN d.name IN ('delivered', 'refund') THEN 'Delivered'
			WHEN d.name IN ('returned','returning') THEN 'Reject'
			WHEN d.name IN ('intransit', 'packed', 'ready to pick') THEN 'Intransit' -- 31.01.23
			when d.name in ('delivering', 'delivery fail', 'picked up') then 'Delivering' -- 31.01.23
			WHEN d.name IN ('cancel') THEN 'Cancelled'
			WHEN d.name IN ('new', 'pending', 'picking') THEN 'New'
			WHEN d.name = 'Unassigned' then 'Unassigned'  -- 31.01.23
			ELSE 'Undefined'  -- 31.01.23
		END AS adjusted_status_transport,
		odn.createdate as createdate_dt,
		date(odn.createdate) AS created_date,
	    odn.closetime,
	    odn.firstdelivertime,
		date_part('week', odn.createdate) AS week_of_year,
		to_char(odn.createdate, 'YYYY-MM') AS month_of_year,
		odn.updatedate AS do_updatedate,
		CASE
			oso.payment_method WHEN 1 THEN 'COD'
			WHEN 2 THEN 'Bank tranfer'
		END AS payment_method ,
		coalesce(oso.amount, 0) as so_tien_thu_cod,
		round(EXTRACT(epoch FROM (odn.createdate - oso.createdate))::numeric/86400,1) AS qa_time
		, q.product1 products_name_1
		, q.qty1 products_qty_1
		, q.price1 products_price_1
		, q.product2 products_name_2
		, q.qty2 products_qty_2
		, q.price2 products_price_2
		, q.product3 products_price_3
		, q.qty3 products_qty_3
		, q.price3 products_price_3
		, q.product4 products_price_4
		, q.qty4 products_qty_4
		, q.price4 products_price_4
		, (q.price1*q.qty1) + (q.price2*q.qty2) + (q.price3*q.qty3) + (q.price4*q.qty4) total_value
		, odn.FFM_id
		, q.so_id
	from (select * from od_do_new where geo ^@ 'VN') odn
	LEFT JOIN (select * from od_sale_order where geo ^@ 'VN') oso ON
		odn.so_id = oso.so_id and odn.geo = oso.geo
	LEFT JOIN (
		SELECT cl.geo, cl.org_id, lead_id, prod_name, pp.name lead_product, total_call,lead_status, lead_type, agc_id, agc_code,
		assigned,cl.address, province, district, subdistrict, postal_code, affiliate_id, subid1, cc.name cp_name, comment as ghi_chu_khach_hang
		FROM (select * from cl_fresh where geo ^@ 'VN')cl
		LEFT JOIN (select * from pd_product where geo ^@ 'VN') pp ON
		pp.prod_id = cl.prod_id and pp.geo = cl.geo
		LEFT JOIN (select * from cp_campaign where geo ^@ 'VN') cc ON
		cc.cp_id = cl.cp_id and cc.geo = cl.geo
		WHERE cl.modifydate >= date_trunc('month',current_date - interval '4 months') 
		and cl.cp_id not in (504,505) -- Remove Orders From System Repository/ResearchMarket
		) cl ON
		cl.lead_id = odn.customer_id and cl.geo = odn.geo
	LEFT JOIN (
		SELECT
			so_id, a.geo,
			max((CASE WHEN item_no = 1 THEN b.name END)) AS product1,
			coalesce(max((CASE WHEN item_no = 1 THEN quantity END)), 0) AS qty1,
			coalesce(max((CASE WHEN item_no = 1 THEN a.price END)), 0) AS price1,
			max((CASE WHEN item_no = 2 THEN b.name END)) AS product2,
			coalesce(max((CASE WHEN item_no = 2 THEN quantity END)), 0) AS qty2,
			coalesce(max((CASE WHEN item_no = 2 THEN a.price END)), 0) AS price2,
			max((CASE WHEN item_no = 3 THEN b.name END)) AS product3,
			coalesce(max((CASE WHEN item_no = 3 THEN quantity END)), 0) AS qty3,
			coalesce(max((CASE WHEN item_no = 3 THEN a.price END)), 0) AS price3,
			max((CASE WHEN item_no = 4 THEN b.name END)) AS product4,
			coalesce(max((CASE WHEN item_no = 4 THEN quantity END)), 0) AS qty4,
			coalesce(max((CASE WHEN item_no = 4 THEN a.price END)), 0) AS price4
		from (select * from od_so_item where geo ^@ 'VN') a 
		JOIN (select * from pd_product where geo ^@ 'VN') b ON
			a.prod_id = b.prod_id and a.geo = b.geo
		GROUP BY
			so_id, a.geo
		ORDER BY
			so_id desc
			) q ON
		q.so_id = oso.so_id and q.geo = oso.geo
	LEFT JOIN (select * from bp_partner where geo ^@ 'VN') b ON
		odn.FFM_id = b.pn_id and odn.geo = b.geo
	LEFT JOIN (select * from bp_warehouse where geo ^@ 'VN') c ON
		odn.warehouse_id = c.warehouse_id and odn.geo = c.geo
	LEFT JOIN bp_partner e ON
		e.pn_id = odn.carrier_id and e.geo = odn.geo 
	LEFT JOIN (select * from or_user where geo ^@ 'VN') h ON
		cl.assigned = h.user_id and cl.geo = h.geo
	LEFT JOIN (select * from bp_partner where geo ^@ 'VN') j ON
		j.pn_id = cl.agc_id and j.geo = cl.geo
	-- Join region
	LEFT JOIN (select * from lc_province where geo ^@ 'VN') l ON
		l.prv_id::TEXT = cl.province and l.geo = cl.geo
	LEFT JOIN (select * from lc_region where geo ^@ 'VN')AS reg ON
		l.region_id = reg.region_id and l.geo = reg.geo
	LEFT JOIN (select * from lc_district where geo ^@ 'VN') m ON
		m.dt_id::TEXT = cl.district and m.geo = cl.geo
	LEFT JOIN (select * from lc_subdistrict where geo ^@ 'VN') n ON
		n.sdt_id::TEXT = cl.subdistrict and n.geo = cl.geo
	left join (select * from lc_postal_code where geo ^@ 'VN') u on 
		u.id::text = cl.postal_code and u.geo = cl.geo
	LEFT JOIN (SELECT * FROM cf_synonym where TYPE = 'delivery order status' and geo ^@ 'VN')d ON
		odn.status = d.value and odn.geo = d.geo
	LEFT JOIN (SELECT * FROM cf_synonym where TYPE = 'sale order status' and geo ^@ 'VN') o ON
		oso.status = o.value and oso.geo = o.geo
	LEFT JOIN (SELECT * FROM cf_synonym where TYPE = 'lead status' and geo ^@ 'VN') p ON
		cl.lead_status = p.value and cl.geo = p.geo
)
, log AS (
         SELECT cl.lead_id AS leadid,
            cl.geo,
            cl.lead_type AS leadtype,
            cl.lead_date,
            cl.productname,
            cl.campaign,
            l_1.ma_don_goc,
                CASE
                    WHEN lower(oso.qa_note::text) ~~ '%ycgl%'::text THEN l_1.ma_don_hang
                    ELSE NULL::double precision
                END AS rescued_resend,
            l_1.ma_don_hang,
            l_1.tracking_code,
            l_1.ten_nguoi_nhan,
                CASE
                    WHEN cl.sourcename::text = 'AFS'::text THEN cl.affiliate_id
                    ELSE cl.sourcename
                END AS sourcename,
            l_1.assgin,
            l_1.tinh_thanh_pho,
            l_1.carrier,
            l_1.ghi_chu_khach_hang,
            l_1.status AS lead_status,
            l_1.so_status,
            d.name AS raw_status_transport,
            l_1.status_transport,
                CASE
                    WHEN lower(l_1.status_transport) = 'new'::text THEN 'New'::text
                    WHEN lower(l_1.status_transport) = ANY (ARRAY['packed'::text, 'picking'::text, 'in preparation'::text, 'ready to pick'::text]) THEN 'Preparing'::text
                    WHEN lower(l_1.status_transport) = 'pending'::text THEN 'Pending'::text
                    WHEN lower(l_1.status_transport) = ANY (ARRAY['intransit'::text, 'picked up'::text, 'Pending Delivery'::text]) THEN 'In-transit'::text
                    WHEN lower(l_1.status_transport) = ANY (ARRAY['Pre-Delivery'::text, 'delivering'::text]) THEN 'Delivering'::text
                    WHEN lower(l_1.status_transport) = 'delivery fail'::text THEN 'Failed'::text
                    WHEN lower(l_1.status_transport) = 'delivered'::text THEN 'Delivered'::text
                    WHEN lower(l_1.status_transport) = 'reject'::text THEN 'Reject'::text
                    WHEN lower(l_1.status_transport) = ANY (ARRAY['returning'::text, 'returned'::text]) THEN 'Return'::text
                    WHEN lower(l_1.status_transport) = 'cancel'::text THEN 'Cancel'::text
                    WHEN lower(l_1.status_transport) = 'unassigned'::text THEN 'Unassigned'::text
                    ELSE 'New'::text
                END AS adjusted_status_transport,
            l_1.created_date,
            l_1.created_week,
            l_1.created_month,
                CASE
                    WHEN lower(l_1.ten_nguoi_nhan) ~~ 'rs%'::text THEN 'Resell'::text
                    WHEN lower(l_1.ten_nguoi_nhan) ~~ 'qt%'::text THEN 'CIT'::text
                    ELSE 'Fresh'::text
                END AS team,
            cl.total_call,
                CASE
                    WHEN lower(l_1.payment_method) = 'bank tranfer'::text THEN 'bank transfer'::text
                    ELSE lower(l_1.payment_method)
                END AS payment_method,
            l_1.so_tien_thu_cod,
            l_1.total_value,
            quan.qty1 + quan.qty2 + quan.qty3 + quan.qty4 AS total_qty,
            cl.return_reason,
                CASE
                    WHEN lower(cl.sourcename::text) ~~ 'de%'::text THEN 'DELIVERED'::character varying
                    WHEN lower(cl.sourcename::text) ~~ 're%'::text AND "substring"(lower(cl.sourcename::text), 1, 3) <> 're_'::text THEN 'RETURNED'::character varying
                    WHEN lower(cl.sourcename::text) ~~ 'cl%'::text THEN 'CLOSED'::character varying
                    WHEN lower(cl.sourcename::text) ~~ 'rj%'::text THEN 'REJECT'::character varying
                    WHEN "substring"(lower(cl.sourcename::text), 1, 3) = 're_'::text THEN 'EXTERNAL'::character varying
                    ELSE cl.sourcename
                END AS rs_source
           FROM ( SELECT a.created_date,
                    to_char(a.created_date::timestamp with time zone, 'YYYY-WW'::text) AS created_week,
                    to_char(a.created_date::timestamp with time zone, 'YYYY-MM'::text) AS created_month,
                    a.ma_don_hang,
                    a.ma_don_goc,
                    a.ten_nguoi_nhan,
                    a.assgin,
                    a.carrier,
                    a.ghi_chu_khach_hang,
                    a.status,
                    a.so_status,
                    lower(a.statustransport) AS status_transport,
                    a.payment_method,
                    a.so_tien_thu_cod,
                    a.tracking_code,
                    a.geo,
                    a.total_value,
                    a.tinh_thanh_pho
                   FROM a
                  WHERE a.created_date::date >= '2023-01-01'::date AND a.ten_nguoi_nhan !~~ 'MD-%'::text
                  ORDER BY a.created_date DESC) l_1
             LEFT JOIN ( SELECT od_sale_order.so_id,
                    od_sale_order.lead_id,
                    od_sale_order.geo,
                    od_sale_order.qa_note
                   FROM od_sale_order
                  WHERE od_sale_order.geo::text ^@ 'VN'::text AND od_sale_order.createdate::date >= '2023-01-01'::date) oso ON l_1.ma_don_hang::numeric::integer::text = oso.so_id::text AND l_1.geo = oso.geo::text
             LEFT JOIN ( SELECT od_do_new.geo,
                    od_do_new.status,
                    od_do_new.so_id
                   FROM od_do_new
                  WHERE od_do_new.geo::text ^@ 'VN'::text) odn ON l_1.ma_don_hang = odn.so_id::double precision AND l_1.geo = odn.geo::text
             LEFT JOIN ( SELECT cf_synonym.geo,
                    cf_synonym.synonym_id,
                    cf_synonym.type,
                    cf_synonym.name,
                    cf_synonym.value,
                    cf_synonym.dscr,
                    cf_synonym.type_id,
                    cf_synonym.localized_name
                   FROM cf_synonym
                  WHERE cf_synonym.type::text = 'delivery order status'::text AND cf_synonym.geo::text ^@ 'VN'::text) d ON odn.status = d.value AND odn.geo::text = d.geo::text
             LEFT JOIN ( SELECT a.so_id,
                    a.geo,
                    COALESCE(max(
                        CASE
                            WHEN a.item_no = 1 THEN a.quantity
                            ELSE NULL::integer
                        END), 0) AS qty1,
                    COALESCE(max(
                        CASE
                            WHEN a.item_no = 2 THEN a.quantity
                            ELSE NULL::integer
                        END), 0) AS qty2,
                    COALESCE(max(
                        CASE
                            WHEN a.item_no = 3 THEN a.quantity
                            ELSE NULL::integer
                        END), 0) AS qty3,
                    COALESCE(max(
                        CASE
                            WHEN a.item_no = 4 THEN a.quantity
                            ELSE NULL::integer
                        END), 0) AS qty4
                   FROM od_so_item a
                  WHERE a.geo::text ^@ 'VN'::text
                  GROUP BY a.so_id, a.geo) quan ON quan.so_id = oso.so_id AND quan.geo::text = oso.geo::text
             LEFT JOIN ( SELECT d_1.org_id,
                    d_1.geo,
                    d_1.lead_id,
                    d_1.prod_id,
                    d_1.productname,
                    d_1.total_call,
                    d_1.lead_status,
                    d_1.lead_type,
                    d_1.agc_code,
                    d_1.address,
                    d_1.agc_id,
                    d_1.cp_id,
                    d_1.province,
                    d_1.district,
                    d_1.subdistrict,
                    d_1.assigned,
                    d_1.lead_date,
                    d_1.modifydate,
                    d_1.affiliate_id,
                    d_1.return_reason,
                    COALESCE(p.shortname, d_1.agc_code, 'LOYAL CUSTOMER'::character varying) AS sourcename,
                    cp.name AS campaign
                   FROM ( SELECT cl_fresh.org_id,
                            cl_fresh.geo,
                            cl_fresh.lead_id,
                            cl_fresh.prod_id,
                            cl_fresh.prod_name AS productname,
                            cl_fresh.total_call,
                            cl_fresh.lead_status,
                            cl_fresh.lead_type,
                            cl_fresh.agc_code,
                            cl_fresh.address,
                            cl_fresh.agc_id,
                            cl_fresh.cp_id,
                            cl_fresh.province,
                            cl_fresh.district,
                            cl_fresh.subdistrict,
                            cl_fresh.assigned,
                            cl_fresh.createdate::date AS lead_date,
                            cl_fresh.modifydate,
                            cl_fresh.affiliate_id,
                            cl_fresh.user_defin_05 AS return_reason
                           FROM cl_fresh
                          WHERE cl_fresh.geo::text ^@ 'VN'::text AND cl_fresh.createdate::date >= '2023-01-01'::date) d_1
                     LEFT JOIN ( SELECT bp.pn_id,
                            bp.geo,
                            bp.shortname
                           FROM bp_partner bp
                          WHERE bp.geo::text ^@ 'VN'::text) p ON d_1.agc_id = p.pn_id AND d_1.geo::text = p.geo::text
                     LEFT JOIN ( SELECT cc.cp_id,
                            cc.geo,
                            cc.name
                           FROM cp_campaign cc
                          WHERE cc.geo::text ^@ 'VN'::text) cp ON d_1.cp_id = cp.cp_id AND d_1.geo::text = cp.geo::text) cl ON oso.lead_id = cl.lead_id AND oso.geo::text = cl.geo::text
        ), cs AS (
         SELECT a.id AS cs_id,
            a.do_code,
            a.do_code_geo,
            a.do_id,
            a.do_id_geo,
            a.so_id AS soid,
            a.geo AS cs_geo,
            b.status_name AS cs_status,
            c.substatus_name AS sub_cs_status,
            a.lastmile_reason,
            a.lastmile_reason_detail,
            f.user_name,
            g.user_name AS update_by,
            a.createdate AS job_create_dt,
            a.job_create,
            a.job_create_week,
            a.job_create_month,
            a.job_update,
            b.status_name AS new_status,
            d.status_name AS reason,
            e.substatus_name AS sub_reason,
                CASE
                    WHEN e.substatus_name::text = dvrmp.system_status THEN dvrmp.pbi_status::character varying
                    ELSE e.substatus_name
                END AS sub_reason_change,
            a.is_pre_delivery,
            a.is_pre_delivered_before,
            a.package_products,
            a.priority,
            act_group.isresend,
            act_group.act_month,
            act_group.actime,
            act_group.actime_with_time,
            act_group.actime_week,
            act_group.actime_month,
            act_group.productivity,
                CASE
                    WHEN a.job_type = 1 THEN 'Rescued'::text
                    WHEN a.job_type = 2 THEN 'Pre-delivery'::text
                    WHEN a.job_type = 3 THEN 'Remind Call'::text
                    ELSE 'Others'::text
                END AS job_type
           FROM ( SELECT r.id,
                    r.do_code,
                    concat(r.do_code, '_', r.geo) AS do_code_geo,
                    r.do_id,
                    concat(r.do_id, '_', r.geo) AS do_id_geo,
                    r.so_id,
                    r.geo,
                    r.lastmile_reason,
                    r.lastmile_reason_detail,
                    r.createdate,
                    r.createdate::date AS job_create,
                    to_char(r.createdate::timestamp with time zone, 'YYYY-WW'::text) AS job_create_week,
                    to_char(r.createdate::date::timestamp with time zone, 'YYYY-MM'::text) AS job_create_month,
                    r.updatedate AS job_update,
                    r.job_status,
                    r.job_sub_status,
                    r.job_reason,
                    r.job_sub_reason,
                    r.assigned,
                    r.is_pre_delivery,
                    r.is_pre_delivered_before,
                    r.package_products,
                    r.job_type,
                    r.priority
                   FROM rc_rescue_job r
                  WHERE r.geo::text ^@ 'VN'::text AND r.createdate::date >= '2023-01-01'::date) a
             LEFT JOIN ( SELECT rc_status.geo,
                    rc_status.status,
                    rc_status.status_name,
                    rc_status.id
                   FROM rc_status
                  WHERE rc_status.type = 1 AND rc_status.geo::text ^@ 'VN'::text) b ON b.status = a.job_status AND b.geo::text = a.geo::text
             LEFT JOIN ( SELECT rc_substatus.geo,
                    rc_substatus.substatus,
                    rc_substatus.substatus_name,
                    rc_substatus.status_id
                   FROM rc_substatus
                  WHERE rc_substatus.geo::text ^@ 'VN'::text) c ON c.substatus = a.job_sub_status AND c.status_id = b.id AND c.geo::text = b.geo::text
             LEFT JOIN ( SELECT rc_status.geo,
                    rc_status.status,
                    rc_status.status_name,
                    rc_status.id
                   FROM rc_status
                  WHERE rc_status.type = 2 AND rc_status.geo::text ^@ 'VN'::text) d ON d.status = a.job_reason AND d.geo::text = a.geo::text
             LEFT JOIN ( SELECT rc_substatus.geo,
                    rc_substatus.substatus,
                    rc_substatus.substatus_name,
                    rc_substatus.status_id,
                        CASE
                            WHEN rc_substatus.geo::text ^@ 'VN'::text THEN 'VN'::text
                            ELSE NULL::text
                        END AS geo_original
                   FROM rc_substatus
                  WHERE rc_substatus.geo::text ^@ 'VN'::text) e ON e.substatus = a.job_sub_reason AND e.status_id = d.id AND e.geo::text = d.geo::text
             LEFT JOIN ( SELECT dim_vn_reason_mapping.country_code,
                    dim_vn_reason_mapping.type,
                    dim_vn_reason_mapping.system_status,
                    dim_vn_reason_mapping.pbi_status
                   FROM dim_vn_reason_mapping) dvrmp ON dvrmp.system_status = e.substatus_name::text AND dvrmp.country_code = e.geo_original
             LEFT JOIN ( SELECT ra.geo,
                    ra.rc_job_id,
                    ra.act_time AS actime_with_time,
                    date_trunc('month'::text, ra.act_time::date::timestamp with time zone) AS act_month,
                    ra.act_time::date AS actime,
                    to_char(ra.act_time::timestamp with time zone, 'YYYY-WW'::text) AS actime_week,
                    to_char(ra.act_time::date::timestamp with time zone, 'YYYY-MM'::text) AS actime_month,
                    count(ra.rc_job_id) AS productivity,
                    sum(
                        CASE
                            WHEN ra.new_status = 4 AND ra.new_substatus = 3 THEN 1
                            ELSE 0
                        END) AS isresend,
                    ra.updateby
                   FROM rc_activity ra
                  WHERE ra.geo::text ^@ 'VN'::text AND ra.act_time::date >= '2023-01-01'::date
                  GROUP BY (ra.act_time::date), ra.rc_job_id, ra.updateby, ra.geo, ra.act_time) act_group ON a.id = act_group.rc_job_id AND a.geo::text = act_group.geo::text
             LEFT JOIN ( SELECT or_user.geo,
                    or_user.user_id,
                    or_user.user_name
                   FROM or_user
                  WHERE or_user.geo::text ^@ 'VN'::text AND or_user.user_type::text = 'CS'::text) f ON a.assigned = f.user_id AND a.geo::text = f.geo::text
             LEFT JOIN ( SELECT or_user.geo,
                    or_user.user_id,
                    or_user.user_name
                   FROM or_user
                  WHERE or_user.geo::text ^@ 'VN'::text AND or_user.user_type::text = 'CS'::text) g ON g.user_id = act_group.updateby AND g.geo::text = act_group.geo::text
        )
 SELECT 
    l.leadid,
    l.geo,
    l.leadtype,
    l.lead_date,
    l.productname,
    l.campaign,
    l.ma_don_goc,
    l.rescued_resend,
    l.ma_don_hang,
    l.tracking_code,
    l.ten_nguoi_nhan,
    l.sourcename,
    l.assgin,
    l.tinh_thanh_pho,
    l.carrier,
    l.ghi_chu_khach_hang,
    l.lead_status,
    l.so_status,
    l.raw_status_transport,
    l.status_transport,
    l.adjusted_status_transport,
    l.created_date,
    l.created_week,
    l.created_month,
    l.team,
    l.total_call,
    l.payment_method,
    l.so_tien_thu_cod,
    l.total_value,
    l.total_qty,
    l.return_reason,
    l.rs_source,
    cs.cs_id,
    cs.do_code,
    cs.do_code_geo,
    cs.do_id,
    cs.do_id_geo,
    cs.soid,
    cs.cs_geo,
    cs.cs_status,
    cs.sub_cs_status,
    cs.lastmile_reason,
    cs.lastmile_reason_detail,
    cs.user_name AS original_user_name,
        CASE
            WHEN "position"(cs.user_name::text, '@'::text) > 0 THEN "left"(cs.user_name::text, "position"(cs.user_name::text, '@'::text) - 1)::character varying
            ELSE cs.user_name
        END AS user_name,
    cs.update_by AS original_update_by,
        CASE
            WHEN "position"(cs.update_by::text, '@'::text) > 0 THEN "left"(cs.update_by::text, "position"(cs.update_by::text, '@'::text) - 1)::character varying
            ELSE cs.update_by
        END AS update_by,
    cs.job_create_dt,
    cs.job_create,
    cs.job_create_week,
    cs.job_create_month,
    cs.job_update,
    cs.new_status,
    cs.reason,
    cs.sub_reason,
    cs.sub_reason_change,
    cs.is_pre_delivery,
    cs.is_pre_delivered_before,
    cs.package_products,
    cs.priority,
    cs.isresend,
    cs.act_month,
    cs.actime,
    cs.actime_with_time,
    cs.actime_week,
    cs.actime_month,
    cs.productivity,
    cs.job_type
   FROM log l
     LEFT JOIN cs cs ON l.ma_don_hang::numeric::integer::text = cs.soid::text AND l.geo::text = cs.cs_geo::text