select geo,
lead_id,
status,
createdate
from od_sale_order 
where createdate >= current_date
and status <> 46
