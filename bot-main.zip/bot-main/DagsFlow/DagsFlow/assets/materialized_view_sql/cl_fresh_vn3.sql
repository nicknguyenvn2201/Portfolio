select cf.geo,
cf.lead_id,
cf.assigned,
cf.cp_id
from cl_fresh cf 
left join od_sale_order oso on cf.lead_id = oso.lead_id and cf.geo = oso.geo
where cf.lead_type = 'M'
and cf.geo = 'VN3'
and oso.createdate >= current_date
and oso.status <> 46
