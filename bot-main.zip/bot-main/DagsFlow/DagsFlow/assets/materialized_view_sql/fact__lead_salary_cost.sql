with
    base_fact as (
        select
            geo,
            lead_id,
            lead_date::date as lead_date,
            left(geo, 2) as country_code,
            lead_product_name as offer,
            network,
            campaign_name as sale_campaign
        from "tms_central"."dareport"."fact__lead_sales_delivery" as base
    ),
    base_salary_cost as (
        select
            country_code,
            start_date,
            end_date,
            sum(salary_cost_per_lead_usd) as total_salary_cost_per_lead_usd
        from "tms_central"."dareport"."stg_dim__enrich_salary_cost"
        group by 1, 2, 3
    ),
    map_salary_cost as (
        select base.*, total_salary_cost_per_lead_usd
        from base_fact as base
        inner join
            base_salary_cost as base_salary_cost
            on base.country_code = base_salary_cost.country_code
            and base.lead_date
            between base_salary_cost.start_date and base_salary_cost.end_date
    )
select
    geo,
    lead_id,
    lead_date,
    null as "type",
    country_code,
    offer,
    network,
    sale_campaign,
    null::integer as lead_this_month_per_type,
    null::integer as lead_this_month,
    total_salary_cost_per_lead_usd as salary_ibs_cit_cost_usd_per_lead,
    null::double precision as salary_hybrid_cost_usd_per_lead
from map_salary_cost
