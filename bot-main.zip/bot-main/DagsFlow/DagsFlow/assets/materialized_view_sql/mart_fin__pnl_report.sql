with
    __dbt__cte__fact__cost_of_goods_sold as (
        with
            item as (select * from "tms_central"."dareport"."fact__item_with_cost"),
            big_fact as (
                select * from "tms_central"."dareport"."fact__lead_sales_delivery"
            ),
            enrich_and_filter_data as (
                select
                    item.*,
                    lead_product_name as offer,
                    network,
                    campaign_name as sale_campaign
                from item
                left join
                    big_fact on item.geo = big_fact.geo and item.so_id = big_fact.so_id
                where big_fact.do_status = 'delivered'
            )
        select *
        from enrich_and_filter_data
    ),
    calculate_cost as (
        select
            lead_date::date as lead_date,
            left(geo, 2) as country_code,
            offer,
            network,
            sale_campaign,
            sum(
                coalesce(item_quantity * unit_cost_local_cur_by_lead_created_time, 0)
            ) as total_prod_cost
        from __dbt__cte__fact__cost_of_goods_sold as ct
        where so_date >= '2023-01-01'
        group by 1, 2, 3, 4, 5
    ),
    logistics as (
        select * from "tms_central"."dareport"."dim_finance_bd_logistics_cost"
    ),
    commissions as (select * from "tms_central"."dareport"."dim_fin_commission"),
    plans as (select * from "tms_central"."dareport"."dim_finance_plan_figure"),
    salaries as (
        select
            lead_date,
            country_code,
            offer,
            network,
            sale_campaign,
            sum(salary_ibs_cit_cost_usd_per_lead) as salary_cost_usd
        from "tms_central"."dareport"."fact__lead_salary_cost"
        group by 1, 2, 3, 4, 5
    ),
    tel_cost as (
        select country_code, "start_date", "end_date", tel_cost_per_lead_local_cur
        from "tms_central"."dareport"."dim_finance_tel_cost"
        where lead_type = 'Fresh'
    )
select
    pf.*,
    ct.total_prod_cost / exchange_rate as total_prod_cost_usd,
    logistics_cost_per_validated_order_usd * validated as logistics_cost_usd,
    amt_delivered_usd * commissions.commission_rate_fresh as commission_cost_usd,
    salary_cost_usd,
    tel_cost_per_lead_local_cur / exchange_rate as tel_cost_per_lead_usd,
    plans.gp_target
from "tms_central"."dareport"."mart_fin__perf_report" as pf
left join
    calculate_cost as ct
    on pf.country_code = ct.country_code
    and pf.createdate = ct.lead_date
    and pf.offer = ct.offer
    and pf.network = ct.network
    and pf.sale_campaign = ct.sale_campaign
left join
    logistics
    on pf.country_code = logistics.country_code
    and pf.createdate between logistics.start_date and logistics.end_date
left join
    commissions
    on pf.country_code = commissions.country_code
    and pf.createdate between commissions.start_date and commissions.end_date
left join
    salaries
    on pf.country_code = salaries.country_code
    and pf.createdate = salaries.lead_date
    and pf.offer = salaries.offer
    and pf.network = salaries.network
    and pf.sale_campaign = salaries.sale_campaign
left join
    tel_cost
    on pf.country_code = tel_cost.country_code
    and pf.createdate between tel_cost.start_date and tel_cost.end_date
left join
    plans
    on pf.country_code = plans.country_code
    and extract(year from pf.createdate) = plans.year
    and extract(month from pf.createdate) = plans.month
    and pf.offer = plans.offer
    and pf.network = plans.partner
    and pf.sale_campaign = plans.sales_camp
