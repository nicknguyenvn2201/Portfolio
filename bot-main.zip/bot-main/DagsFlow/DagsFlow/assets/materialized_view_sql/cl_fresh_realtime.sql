select *
from cl_fresh
where createdate >= current_date - 6
and lead_type = 'A'
