with
    base_fact as (
        select
            fact.geo,
            lead_id,
            lead_date::date as lead_date,
            left(fact.geo, 2) as country_code,
            sales_amount as sales_amount_local,
            sales_amount / exchange as sales_amount_usd,
            lead_type = 'A' as is_fresh_lead
        from "tms_central"."dareport"."fact__lead_sales_delivery" fact
        left join
            "tms_central"."dareport"."dim_exchange_rate" as dim
            on fact.lead_date::date
            between dim.started_date::date and dim.ending_date::date
            and left(fact.geo, 2) = dim.geo
        where
            lead_date >= (
                select min("start_date")
                from "tms_central"."dareport"."dim_finance_salary_cost"
            )
            and so_status in ('validated', 'delay')
    ),
    join_base_fact_with as (
        select base.*, dr_final, sales_amount_usd * dr_final as sales_amount
        from base_fact as base
        left join
            "tms_central"."dareport"."fact__lead_dr_final" as dr_table
            on base.geo = dr_table.geo
            and base.lead_id = dr_table.lead_id
    ),
    calculate_amount as (
        select
            base_dim.*,
            sum(sales_amount) as total_revenue_delivered_usd,
            sum(
                case when is_fresh_lead then sales_amount else 0 end
            ) as total_fresh_revenue_delivered_usd,
            sum(
                case when not is_fresh_lead then sales_amount else 0 end
            ) as total_resell_revenue_delivered_usd,
            count(*) as total_lead_in_period
        from "tms_central"."dareport"."dim_finance_salary_cost" as base_dim
        left join
            join_base_fact_with as fact
            on base_dim.country_code = fact.country_code
            and fact.lead_date between base_dim.start_date and base_dim.end_date
        group by 1, 2, 3, 4, 5
    ),
    calculate_weight as (
        select
            country_code,
            "start_date",
            "end_date",
            team,
            greatest(
                least(
                    "end_date" - "start_date" + 1, current_date - "start_date" + 1
                )::float
                / ("end_date" - "start_date" + 1)::float,
                0
            ) as day_weight,
            total_monthly_cost_usd,
            total_lead_in_period,
            total_fresh_revenue_delivered_usd
            / nullif(total_revenue_delivered_usd, 0) as weight_lead_fresh,  -- is Fresh Portion
            total_resell_revenue_delivered_usd
            / nullif(total_revenue_delivered_usd, 0) as weight_lead_resell  -- is Resell Portion
        from calculate_amount
    )
select
    *,
    case
        when team = 'IBS'
        then total_monthly_cost_usd * day_weight / total_lead_in_period
        when team = 'HYBRID'
        then
            total_monthly_cost_usd
            * day_weight
            * weight_lead_fresh
            / total_lead_in_period
        else null
    end as salary_cost_per_lead_usd,
    null::double precision as weighted_total_monthly_cost_usd_by_fresh,
    null::double precision as weighted_total_monthly_cost_usd_by_resell
from calculate_weight
