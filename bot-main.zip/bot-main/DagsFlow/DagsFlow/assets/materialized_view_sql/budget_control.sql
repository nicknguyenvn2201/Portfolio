WITH cte_ar_mrps AS (
         SELECT ar_mrps.affiliate_id AS network,org_id,
            ar_mrps.offer_id AS product_name,
                CASE
                    WHEN lower(ar_mrps.sub_id) = '*'::text THEN ''::text
                    WHEN lower(ar_mrps.sub_id) = ''::text THEN 'blank'::text
                    ELSE ar_mrps.sub_id
                END AS sub_id,
            ar_mrps.ar_mrp,
            ar_mrps.applied_from_date::date AS started_date,
            ar_mrps.applied_to_date::date AS ending_date,
                CASE
                    WHEN lower(ar_mrps.sub_id) = '*'::text THEN concat(ar_mrps.affiliate_id, '_', ar_mrps.offer_id)
                    WHEN lower(ar_mrps.sub_id) = ''::text THEN concat(ar_mrps.affiliate_id, '_', 'blank', '_', ar_mrps.offer_id)
                    ELSE concat(ar_mrps.affiliate_id, '_', ar_mrps.sub_id, '_', ar_mrps.offer_id)
                END AS target_key
           FROM ar_mrps
        )
   , base AS (
         SELECT row_number() OVER (PARTITION BY lead_mrps.affiliate_id, lead_mrps.offer_id, lead_mrps.sub_id ORDER BY lead_mrps.applied_to_date DESC) AS rn,
            lead_mrps.affiliate_id AS network,
            lead_mrps.offer_id AS product_name,
                CASE
                    WHEN lower(lead_mrps.sub_id) = '*'::text THEN ''::text
                    WHEN lower(lead_mrps.sub_id) = ''::text THEN 'blank'::text
                    ELSE lead_mrps.sub_id
                END AS sub_id,
            lead_mrps.lead_mrp,
            org_id,
            lead_mrps.applied_from_date::date AS started_date,
            lead_mrps.applied_to_date::date AS ending_date,
                CASE
                    WHEN lead_mrps.applied_to_date::date < (date_trunc('month'::text, now()) + '1 mon -1 days'::interval) THEN 1
                    ELSE 0
                END AS flag,
            date_part('day'::text, date_trunc('month'::text, now()) + '1 mon -1 days'::interval - now()) AS interval_,
                CASE
                    WHEN lower(lead_mrps.sub_id) = '*'::text THEN concat(lead_mrps.affiliate_id, '_', lead_mrps.offer_id)
                    WHEN lower(lead_mrps.sub_id) = ''::text THEN concat(lead_mrps.affiliate_id, '_', 'blank', '_', lead_mrps.offer_id)
                    ELSE concat(lead_mrps.affiliate_id, '_', lead_mrps.sub_id, '_', lead_mrps.offer_id)
                END AS target_key
           FROM lead_mrps
        ), transform_cte AS (
         SELECT base.network,
            base.product_name,
            generate_series(base.started_date::timestamp with time zone, base.ending_date::timestamp with time zone, '1 day'::interval) AS lead_mrp_date,
            base.lead_mrp
           FROM base
          WHERE base.sub_id = ''::text AND base.flag = 1
          ORDER BY base.network, base.product_name, base.started_date
        ), l7d AS (
         SELECT transform_cte.network,
            transform_cte.product_name,
            avg(transform_cte.lead_mrp) AS lead_mrp_last_7d
           FROM transform_cte
          WHERE transform_cte.lead_mrp_date >= (CURRENT_DATE - 6) AND transform_cte.lead_mrp_date <= CURRENT_DATE
          GROUP BY transform_cte.network, transform_cte.product_name
        ), cte_lead_mrps AS (
         SELECT b.lead_mrp_last_7d,
            a.rn,
            a.network,
            a.product_name,
            a.sub_id,
            a.lead_mrp,
            a.org_id,
            a.started_date,
            a.ending_date,
            a.flag,
            a.interval_,
            a.target_key,
                CASE
                    WHEN a.rn = 1 AND a.ending_date >= (CURRENT_DATE - 6) THEN COALESCE(a.lead_mrp, b.lead_mrp_last_7d)::double precision * a.interval_
                    ELSE 0::double precision
                END AS remaining_lead_mrp_target
           FROM base a
             LEFT JOIN l7d b ON a.network = b.network AND a.product_name = b.product_name AND a.ending_date >= (CURRENT_DATE - 6) AND a.flag = 1 AND a.rn = 1
        )
,roi_cte AS (
select 
            roi_1.aging,
            roi_1.lead_year,
            roi_1.createdate lead_date,
            roi_1.lead_week,
            roi_1.lead_month,
            roi_1.network,
            roi_1.pub,
            roi_1.sale_campaign cam_lead,
            roi_1.offer product_name,
            roi_1.total_lead,
            roi_1.trash,
            roi_1.validated,
            roi_1.amt_validated,
            roi_1.delivered,
            roi_1.finalized_do,
            roi_1.amt_delivered,
            roi_1.payout,
            roi_1.max_po,
            roi_1.geo,
            roi_1.cpl_lead,
            roi_1.total_approved_postback,
            roi_1.country_code,
            roi_1.exchange_rate exchange,
            roi_1.product_fn,
            roi_1.inrangeforecast,
            roi_1.geo_bd,      
            gm.tax_rate,
            gm.tele_rate,
            gm.commission_rate,
            gm.bd_comm_rate,
            uc.unit_cost,
            lc.ffm_fee,
            lc.lm_fee,
            lc.return_rate,
            lc.cod_rate,
            lc.portion,         
            COALESCE(dim_mkt_1.mkt_expense_target, dim_mkt.mkt_expense_target, dim_mkt_2.mkt_expense_target) AS mkt_expense_target,
            COALESCE(am.ar_mrp, am_2.ar_mrp) AS ar_target,
            lm_2.lead_mrp,
            lm_2.remaining_lead_mrp_target,
            lm_2.started_date,
            lm_2.ending_date,      
            dim_at_2.target_key    
                
from (select 
            date_part('day'::text, now() - createdate::timestamp with time zone) - 1::double precision AS aging,
            lead_year,
            createdate,
            date_part('week'::text,createdate + '1 day'::interval) AS lead_week,
            date_part('month'::text,createdate + '1 day'::interval) AS lead_month,
            network,
            pub,
            sale_campaign,
            offer,
            total_lead,
            trash,
            validated,
            amt_validated,
            delivered,
            finalized_do,
            amt_delivered,
            payout,
            max_po,
            geo,
            cpl_lead,
            total_approved_postback,
            country_code,
            exchange_rate,
            case WHEN offer ~~ '%rosta%X%'::text THEN 'prostaniX -'::text ELSE offer END AS product_fn,
                CASE
                    WHEN geo ^@ 'VN'::text AND (date_trunc('week'::text, createdate + '1 day'::interval) - '1 day'::interval)::date >= ((date_trunc('week'::text, CURRENT_DATE + '1 day'::interval) - '1 day'::interval)::date - 14) THEN 1
                    WHEN geo ^@ 'ID'::text AND (date_trunc('week'::text, createdate + '1 day'::interval) - '1 day'::interval)::date >= ((date_trunc('week'::text, CURRENT_DATE + '1 day'::interval) - '1 day'::interval)::date - 21) AND (date_trunc('week'::text,createdate + '1 day'::interval) - '1 day'::interval)::date >= '2023-01-08'::date THEN 1
                    WHEN geo ^@ 'TH'::text AND (date_trunc('week'::text, createdate + '1 day'::interval) - '1 day'::interval)::date >= ((date_trunc('week'::text, CURRENT_DATE + '1 day'::interval) - '1 day'::interval)::date - 7) THEN 1
                    WHEN geo ^@ 'MY'::text AND (date_trunc('week'::text, createdate + '1 day'::interval) - '1 day'::interval)::date >= ((date_trunc('week'::text, CURRENT_DATE + '1 day'::interval) - '1 day'::interval)::date - 14) THEN 1
                    WHEN geo ^@ 'PH'::text AND (date_trunc('week'::text, createdate + '1 day'::interval) - '1 day'::interval)::date >= ((date_trunc('week'::text, CURRENT_DATE + '1 day'::interval) - '1 day'::interval)::date - 7) THEN 1
                    ELSE 0
                END AS inrangeforecast,
              geo_bd,
              CASE
                    WHEN createdate::date < '2024-06-01'::date AND geo::text = 'VNID'::text THEN 16
                    WHEN geo::text ^@ 'VN'::text THEN 4
                    WHEN geo::text ^@ 'ID'::text THEN 9
                    WHEN geo::text ^@ 'MY'::text THEN 11
                    WHEN geo::text ^@ 'PH'::text THEN 14
                    WHEN geo::text ^@ 'TH'::text THEN 10
                    WHEN geo::text ^@ 'IN'::text THEN 19
                    ELSE 0
                END AS geo_id
from bd_master_filter where createdate >= current_date - interval '5' month) roi_1
LEFT JOIN ( SELECT dim_mkt_exp_target.geo,
                    dim_mkt_exp_target.product_name,
                    dim_mkt_exp_target.category,
                    dim_mkt_exp_target.network,
                    dim_mkt_exp_target."Pub",
                    dim_mkt_exp_target.mkt_expense_target,
                    dim_mkt_exp_target.week_num_target,
                    dim_mkt_exp_target.started_date,
                    dim_mkt_exp_target.ending_date,
                    dim_mkt_exp_target."Rank",
                    dim_mkt_exp_target.last_update,
                        CASE
                            WHEN dim_mkt_exp_target.network IS NOT NULL AND dim_mkt_exp_target."Pub" IS NOT NULL THEN concat(dim_mkt_exp_target.product_name, '_', dim_mkt_exp_target.network, '_', dim_mkt_exp_target."Pub")
                            ELSE 'no_key'::text
                        END AS key_1,
                        CASE
                            WHEN dim_mkt_exp_target.network IS NULL AND dim_mkt_exp_target."Pub" IS NULL AND dim_mkt_exp_target.product_name IS NOT NULL THEN dim_mkt_exp_target.product_name
                            ELSE 'no_key'::text
                        END AS key_2,
                        CASE
                            WHEN dim_mkt_exp_target.network IS NULL AND dim_mkt_exp_target."Pub" IS NULL AND dim_mkt_exp_target.product_name IS NULL THEN dim_mkt_exp_target.geo
                            ELSE 'no_key'::text
                        END AS key_3
                   FROM dim_mkt_exp_target) dim_mkt ON lower(roi_1.offer) = lower(dim_mkt.key_2) AND roi_1.createdate::date >= dim_mkt.started_date::date AND roi_1.createdate::date <= dim_mkt.ending_date::date
             LEFT JOIN ( SELECT dim_mkt_exp_target.geo,
                    dim_mkt_exp_target.product_name,
                    dim_mkt_exp_target.category,
                    dim_mkt_exp_target.network,
                    dim_mkt_exp_target."Pub",
                    dim_mkt_exp_target.mkt_expense_target,
                    dim_mkt_exp_target.week_num_target,
                    dim_mkt_exp_target.started_date,
                    dim_mkt_exp_target.ending_date,
                    dim_mkt_exp_target."Rank",
                    dim_mkt_exp_target.last_update,
                        CASE
                            WHEN dim_mkt_exp_target.network IS NOT NULL AND dim_mkt_exp_target."Pub" IS NOT NULL THEN concat(dim_mkt_exp_target.product_name, '_', dim_mkt_exp_target.network, '_', dim_mkt_exp_target."Pub")
                            ELSE 'no_key'::text
                        END AS key_1,
                        CASE
                            WHEN dim_mkt_exp_target.network IS NULL AND dim_mkt_exp_target."Pub" IS NULL AND dim_mkt_exp_target.product_name IS NOT NULL THEN dim_mkt_exp_target.product_name
                            ELSE 'no_key'::text
                        END AS key_2,
                        CASE
                            WHEN dim_mkt_exp_target.network IS NULL AND dim_mkt_exp_target."Pub" IS NULL AND dim_mkt_exp_target.product_name IS NULL THEN dim_mkt_exp_target.geo
                            ELSE 'no_key'::text
                        END AS key_3
                   FROM dim_mkt_exp_target) dim_mkt_1 ON lower(concat(roi_1.offer, '_', roi_1.network, '_', roi_1.pub)) = lower(dim_mkt_1.key_1) AND roi_1.createdate::date >= dim_mkt_1.started_date::date AND roi_1.createdate::date <= dim_mkt_1.ending_date::date
             LEFT JOIN ( SELECT dim_mkt_exp_target.geo,
                    dim_mkt_exp_target.product_name,
                    dim_mkt_exp_target.category,
                    dim_mkt_exp_target.network,
                    dim_mkt_exp_target."Pub",
                    dim_mkt_exp_target.mkt_expense_target,
                    dim_mkt_exp_target.week_num_target,
                    dim_mkt_exp_target.started_date,
                    dim_mkt_exp_target.ending_date,
                    dim_mkt_exp_target."Rank",
                    dim_mkt_exp_target.last_update,
                        CASE
                            WHEN dim_mkt_exp_target.network IS NOT NULL AND dim_mkt_exp_target."Pub" IS NOT NULL THEN concat(dim_mkt_exp_target.product_name, '_', dim_mkt_exp_target.network, '_', dim_mkt_exp_target."Pub")
                            ELSE 'no_key'::text
                        END AS key_1,
                        CASE
                            WHEN dim_mkt_exp_target.network IS NULL AND dim_mkt_exp_target."Pub" IS NULL AND dim_mkt_exp_target.product_name IS NOT NULL THEN dim_mkt_exp_target.product_name
                            ELSE 'no_key'::text
                        END AS key_2,
                        CASE
                            WHEN dim_mkt_exp_target.network IS NULL AND dim_mkt_exp_target."Pub" IS NULL AND dim_mkt_exp_target.product_name IS NULL THEN dim_mkt_exp_target.geo
                            ELSE 'no_key'::text
                        END AS key_3
                   FROM dim_mkt_exp_target) dim_mkt_2 ON
                CASE
                    WHEN roi_1.geo ^@ 'TH' THEN 'TH'
                    WHEN roi_1.geo ^@ 'VN' THEN 'VN'
                    WHEN roi_1.geo ^@ 'ID' THEN 'ID'
                    ELSE roi_1.geo
                END = dim_mkt_2.key_3 AND roi_1.createdate::date >= dim_mkt_2.started_date::date AND roi_1.createdate::date <= dim_mkt_2.ending_date::date
             LEFT JOIN cdm_dim_ar_mrp_target_by_date dim_at_2 ON concat(roi_1.network, '_', roi_1.offer) = dim_at_2.target_key AND roi_1.createdate::date >= dim_at_2.started_date::date AND roi_1.createdate::date <= dim_at_2.ending_date::date
             LEFT JOIN cte_ar_mrps am on
             am.org_id = roi_1.geo_id and
                CASE
                    WHEN roi_1.pub = ''::text THEN concat(roi_1.network, '_', 'blank', '_', roi_1.offer)
                    ELSE concat(roi_1.network, '_', roi_1.pub, '_', roi_1.offer)
                END = am.target_key AND roi_1.createdate >= am.started_date AND roi_1.createdate <= am.ending_date
             LEFT JOIN cte_ar_mrps am_2 ON 
             am_2.org_id = roi_1.geo_id and
             concat(roi_1.network, '_', roi_1.offer) = am_2.target_key AND roi_1.createdate >= am_2.started_date AND roi_1.createdate <= am_2.ending_date
             LEFT JOIN cte_lead_mrps lm_2 ON 
             lm_2.org_id = roi_1.geo_id and
             concat(roi_1.network, '_', roi_1.offer) = lm_2.target_key AND roi_1.createdate >= lm_2.started_date AND roi_1.createdate <= lm_2.ending_date
             LEFT JOIN dim_bd_gm_input gm ON gm.geo = roi_1.country_code 
               AND roi_1.createdate::date >= gm.started_date::date AND roi_1.createdate::date <= gm.ending_date::date
             LEFT JOIN dim_bd_unit_cost uc ON btrim(lower(uc.offer)) = lower(roi_1.offer) AND uc.geo =
                roi_1.country_code AND roi_1.createdate::date >= uc.started_date::date AND roi_1.createdate::date <= uc.ending_date::date
             LEFT JOIN dim_bd_log_cost lc ON lc.geo =
                roi_1.country_code AND roi_1.createdate::date >= lc.started_date::date AND roi_1.createdate::date <= lc.ending_date::date
)
, final as 
(
SELECT dlcrp."Lead Target",
    dlcrp."Validated target",
    dlcrp."DR target",
    dlcrp."AOV target",
    dlcrp."Revenue target",
    dlcrp."Lead cost Plan",
    roi.aging,
    roi.lead_date,
    roi.lead_year,
    roi.remaining_lead_mrp_target,
    roi.network,
    roi.pub,
    roi.cam_lead,
    roi.product_name,
    roi.total_lead,
    roi.trash,
    roi.validated,
    roi.amt_validated,
    roi.delivered,
    roi.finalized_do,
    roi.amt_delivered,
    roi.payout,
    roi.max_po,
    case when roi.geo = 'ID2' then 'ID' else roi.geo end geo,
    roi.country_code,
    roi.cpl_lead,
    roi.tax_rate,
    roi.tele_rate,
    roi.commission_rate,
    roi.bd_comm_rate,
    roi.unit_cost,
    roi.ffm_fee,
    roi.lm_fee,
    roi.return_rate,
    roi.cod_rate,
    roi.portion,
    roi.lead_week,
    roi.lead_month,
    roi.mkt_expense_target,
    roi.ar_target,
    roi.lead_mrp,
    roi.started_date,
    roi.ending_date,
    roi.target_key,
    roi.exchange,
    roi.product_fn,
    roi.inrangeforecast,
    roi.geo_bd,
    roi.total_approved_postback,
    case when roi.ar_target is null then null else roi.total_lead end total_lead_mrp,
    case when roi.validated > 0 then roi.finalized_do/roi.validated else 0 end do_done,
    roi.lead_date || roi.geo || roi.network || roi.product_name || roi.cam_lead as join_key,
    case when roi.geo = 'VN2' then 'VN' else roi.geo end geo_2,
    NULL::text AS latest_ar_target,
    COALESCE(ddfm.dr_forecast,COALESCE(
        CASE
            WHEN roi.inrangeforecast = 3 THEN cddfbd.dr_forecast_final3
            ELSE
            CASE
                WHEN roi.inrangeforecast = 2 THEN cddfbd.dr_forecast_final2
                ELSE
                CASE
                    WHEN roi.inrangeforecast = 1 THEN cddfbd.dr_forecast_final
                    ELSE
                    CASE
                        WHEN roi.validated = 0 THEN 0::double precision
                        ELSE roi.delivered::double precision / roi.validated::double precision
                    END
                END
            END
        END,
        CASE
            WHEN roi.validated = 0 THEN 0::double precision
            ELSE roi.delivered::double precision / roi.validated::double precision
        END)) AS dr_final,
    mbp.spl_plan,
    mbp.lead_cost_budget,
    mbp.mkt_budget,
    mbd.spl_plan AS spl_plan_def,
    mbd.lead_cost_budget AS lead_cost_budget_def,
    mbd.mkt_budget AS mkt_budget_def,
        CASE
            WHEN va.affiliate_id IS NOT NULL THEN 1
            ELSE 0
        END AS vip_pub,
    df."AR Forecast",
    df."AOV Forecast",
    df."DR_Forecast",
    df."SPL Forecast",
    df."%Lead cost FC",
    df."%GM1 FC",
    df."%GM2 FC",
    dt."Lead MRP" AS deal_lead_mrp,
    dt."AR_MRP" AS deal_armrp,
    dt."AOV_MRP" AS deal_aov_mrp,
    dt."SPL target" AS deal_spl_target,
    dt."DR_MRP" AS deal_dr_mrp,
    dt."%Lead cost MRP" AS deal_lead_cost_mrp,
    dt."%GM1 MRP" AS deal_gm1_mrp,
    dt."%GM2 MRP" AS deal_gm2_mrp,
    dt."Type",
        CASE
            WHEN btrim(dt."Type") ^@ 'CPL'::text THEN 'CPL'::text
            ELSE 'CPA'::text
        END AS deal_type,
    sfpsc.cost_usd,
    dfblc.logistics_cost_per_validated_order_usd,
    dmbtc.lead_target AS camp_lead_target,
    dmbtc.spl_target AS camp_spl_target,
    dmbtc.percentage_lead_cost_target AS camp_percentage_lead_cost_target,
    dmbtg.lead_target AS geo_lead_target,
    dmbtg.spl_target AS geo_spl_target,
    dmbtg.percentage_lead_cost_target AS geo_percentage_lead_cost_target,
    dmbto.lead_target AS offer_lead_target,
    dmbto.spl_target AS offer_spl_target,
    dmbto.percentage_lead_cost_target AS offer_percentage_lead_cost_target,
    dfgt.lead_cost_target AS geo_lead_cost_target,
    dfgt.ar_qa_plan AS geo_ar_qa_plan,
    dfgt.dr_mrp AS geo_dr_mrp,
    dfgt.aov_mrp AS geo_aov_mrp,
    dfct.lead_cost_target AS camp_lead_cost_target,
    dfct.ar_qa_plan AS camp_ar_qa_plan,
    dfct.dr_mrp AS camp_dr_mrp,
    dfct.aov_mrp AS camp_aov_mrp,
    dfot.lead_cost_target AS offer_lead_cost_target,
    dfot.ar_qa_plan AS offer_ar_qa_plan,
    dfot.dr_mrp AS offer_dr_mrp,
    dfot.aov_mrp AS offer_aov_mrp,
    dct.spl_mrp
   FROM roi_cte roi
     LEFT JOIN ( SELECT DISTINCT cdm_dim_dr_forecast_by_date.geo,
            cdm_dim_dr_forecast_by_date.category,
            cdm_dim_dr_forecast_by_date.product_name,
            cdm_dim_dr_forecast_by_date.network,
            cdm_dim_dr_forecast_by_date.pub,
            cdm_dim_dr_forecast_by_date.validated,
            cdm_dim_dr_forecast_by_date.delivered,
            cdm_dim_dr_forecast_by_date.dr_forecast,
            cdm_dim_dr_forecast_by_date.validated_by_network,
            cdm_dim_dr_forecast_by_date.delivered_by_network,
            cdm_dim_dr_forecast_by_date.dr_forecast_by_network,
            cdm_dim_dr_forecast_by_date.validated_by_offer,
            cdm_dim_dr_forecast_by_date.delivered_by_offer,
            cdm_dim_dr_forecast_by_date.dr_forecast_by_offer,
            cdm_dim_dr_forecast_by_date.validated_by_cat,
            cdm_dim_dr_forecast_by_date.delivered_by_cat,
            cdm_dim_dr_forecast_by_date.dr_forecast_by_cat,
            cdm_dim_dr_forecast_by_date.dr_forecast_final,
            cdm_dim_dr_forecast_by_date.validated2,
            cdm_dim_dr_forecast_by_date.delivered2,
            cdm_dim_dr_forecast_by_date.dr_forecast2,
            cdm_dim_dr_forecast_by_date.validated_by_network2,
            cdm_dim_dr_forecast_by_date.delivered_by_network2,
            cdm_dim_dr_forecast_by_date.dr_forecast_by_network2,
            cdm_dim_dr_forecast_by_date.validated_by_offer2,
            cdm_dim_dr_forecast_by_date.delivered_by_offer2,
            cdm_dim_dr_forecast_by_date.dr_forecast_by_offer2,
            cdm_dim_dr_forecast_by_date.validated_by_cat2,
            cdm_dim_dr_forecast_by_date.delivered_by_cat2,
            cdm_dim_dr_forecast_by_date.dr_forecast_by_cat2,
            cdm_dim_dr_forecast_by_date.dr_forecast_final2,
            cdm_dim_dr_forecast_by_date.validated3,
            cdm_dim_dr_forecast_by_date.delivered3,
            cdm_dim_dr_forecast_by_date.dr_forecast3,
            cdm_dim_dr_forecast_by_date.validated_by_network3,
            cdm_dim_dr_forecast_by_date.delivered_by_network3,
            cdm_dim_dr_forecast_by_date.dr_forecast_by_network3,
            cdm_dim_dr_forecast_by_date.validated_by_offer3,
            cdm_dim_dr_forecast_by_date.delivered_by_offer3,
            cdm_dim_dr_forecast_by_date.dr_forecast_by_offer3,
            cdm_dim_dr_forecast_by_date.validated_by_cat3,
            cdm_dim_dr_forecast_by_date.delivered_by_cat3,
            cdm_dim_dr_forecast_by_date.dr_forecast_by_cat3,
            cdm_dim_dr_forecast_by_date.dr_forecast_final3
           FROM cdm_dim_dr_forecast_by_date) cddfbd ON
       roi.country_code = cddfbd.geo AND roi.cam_lead = cddfbd.category AND roi.product_name = cddfbd.product_name AND roi.network = cddfbd.network AND roi.pub = cddfbd.pub
     LEFT JOIN mkt_budget_plan mbp ON roi.cam_lead = mbp.sales_camp AND roi.network = mbp.network AND roi.product_name = mbp.product_name AND roi.lead_date::date >= mbp.from_date::date AND roi.lead_date::date <= mbp.to_date::date
     LEFT JOIN mkt_budget_default mbd ON
        roi.country_code = mbd.geo AND roi.cam_lead = mbd.sales_camp AND roi.lead_date::date >= mbd.from_date::date AND roi.lead_date::date <= mbd.to_date::date
     LEFT JOIN vip_affiliates va ON roi.network = va.affiliate_id AND roi.product_name = va.offer_id AND roi.lead_date::date >= va.applied_from_date::date AND roi.lead_date::date <= va.applied_to_date::date
     LEFT JOIN dim_follow_up_deal_target dt ON roi.country_code = dt."Geo" and dt."Pub" = roi.network AND lower(dt."Offer") = lower(roi.product_name) AND roi.lead_date::date >= dt."Start date" AND roi.lead_date::date <= dt."end date"
     LEFT JOIN dim_follow_up_deal_forecast df ON df."Pub" = roi.network AND lower(df."Offer") = lower(roi.product_name) AND roi.lead_date::date >= df."Start date" AND roi.lead_date::date <= df."end date"
     LEFT JOIN dim_lead_cost_rev_plan dlcrp ON dlcrp."Pub" = roi.network AND dlcrp."Offer" = roi.product_name AND dlcrp."Month"::double precision = roi.lead_month AND dlcrp."Year"::double precision = roi.lead_year
     LEFT JOIN stg_fin__pretty_salary_cost sfpsc ON sfpsc.salary_cost_type = 'ibs'::text AND roi.network = sfpsc.network::text AND roi.product_name = sfpsc.offer::text AND roi.lead_date = sfpsc.lead_date AND roi.cam_lead = sfpsc.sale_campaign::text
     LEFT JOIN dim_finance_bd_logistics_cost dfblc ON roi.country_code = dfblc.country_code AND roi.lead_date >= dfblc.start_date AND roi.lead_date <= dfblc.end_date
     LEFT JOIN dim_mkt_budget_target_camp dmbtc ON roi.cam_lead = dmbtc.camp AND roi.country_code = dmbtc.geo AND roi.lead_date::date >= dmbtc.from_date AND roi.lead_date::date <= dmbtc.to_date
     LEFT JOIN dim_mkt_budget_target_geo dmbtg ON roi.country_code = dmbtg.geo AND roi.lead_date::date >= dmbtg.from_date AND roi.lead_date::date <= dmbtg.to_date
     LEFT JOIN dim_mkt_budget_target_offer dmbto ON roi.product_name = dmbto.offer AND roi.lead_date::date >= dmbto.from_date AND roi.lead_date::date <= dmbto.to_date
     LEFT JOIN dim_finance_geo_target dfgt ON roi.lead_year = dfgt.year_::double precision AND roi.country_code = dfgt.country_code AND dfgt.month_::double precision = roi.lead_month
     LEFT JOIN dim_finance_camp_target dfct ON roi.lead_year = dfct.year_::double precision AND roi.country_code = dfct.country_code AND dfct.month_::double precision = roi.lead_month AND dfct.sales_camp = roi.cam_lead
     LEFT JOIN dim_finance_offer_target dfot ON roi.lead_year = dfot.year_::double precision AND dfot.month_::double precision = roi.lead_month AND dfot.offer = roi.product_name
     LEFT JOIN dim_cpl_target dct ON dct.pub = roi.network AND dct.offer = roi.product_name AND roi.lead_date::date >= dct.from_date AND roi.lead_date::date <= dct.to_date
     LEFT JOIN dim_dr_manual_forecast ddfm ON roi.country_code = ddfm.country_code and roi.network::text = ddfm.network AND roi.product_name::text = ddfm.offer AND roi.lead_date >= ddfm."from" AND roi.lead_date <= ddfm."to"
)
,ranked_cte_act as (
select row_number() over (partition by report_date::date, geo, offer, network, sale_campaign order by report_date desc) rn, *
from public.actual_max_po_tracking mpt
), final_act as (
select report_date::date - 6 start_date, report_date::date end_date,*
from ranked_cte_act
), ranked_cte as (
select row_number() over (partition by report_date::date, geo, offer, network, sale_campaign order by report_date desc) rn, *
from public.max_po_tracking mpt
), final_ as (
select report_date::date - 6 start_date, report_date::date end_date,*
from ranked_cte
where rn = 1
), max_po as (
select 
fc.start_date,fc.end_date,fc.rn,fc.id,fc.report_id,fc.created_time,
coalesce(fc.geo,act.geo) geo,
coalesce(fc.offer, act.offer) offer
,coalesce(fc.network, act.network) network
,coalesce(fc.sale_campaign,act.sale_campaign) sale_campaign
,fc.total_lead,fc.lead_validated,fc.lead_delivered,fc.lead_cost,fc.production_cost,fc.production_cost_forecast,fc.
tele_cost,fc.logistics_cost,fc.agent_cost,fc.lead_mrp,fc.amt_validated,fc.revenue,fc.lead_commission_cost,fc.gp1,fc.
gp2,fc.dr,fc.aov,fc.gm1,fc.gm2,fc.mkt_budget_type,fc.mkt_budget,fc.group1,fc.group2,fc.buffer_base,fc.buffer,fc.final_mkt_budget,fc.
max_po_acceptance,
coalesce(act.report_date,fc.report_date) report_date,
act.total_lead act_total_lead,act.lead_validated act_lead_validated,
act.gp1 act_gp1,act.gp2 act_gp2,act.dr act_dr,act.aov act_aov,act.gm1 act_gm1,act.gm2 act_gm2,act.max_po_acceptance act_max_po_acceptance
from final_ fc 
full join final_act act on fc.end_date = act.end_date and fc.network = act.network and fc.offer = act.offer and fc.sale_campaign = act.sale_campaign
)
select
        a."Lead Target",
	    a."Validated target",
	    a."DR target",
	    a."AOV target",
	    a."Revenue target",
	    a."Lead cost Plan",
	    a.aging,
	    a.lead_date,
	    a.lead_year,
	    a.remaining_lead_mrp_target,
	    a.network,
	    a.pub,
	    a.cam_lead,
	    a.total_lead,
	    a.trash,
	    a.validated,
	    a.amt_validated,
	    a.delivered,
	    a.finalized_do,
	    a.amt_delivered,
	    a.payout,
	    a.max_po,
	    a.geo,
	    a.country_code,
	    a.cpl_lead,
	    a.tax_rate,
	    a.tele_rate,
	    a.commission_rate,
	    a.bd_comm_rate,
	    a.unit_cost,
	    a.ffm_fee,
	    a.lm_fee,
	    a.return_rate,
	    a.cod_rate,
	    a.portion,
	    a.lead_week,
	    a.lead_month,
	    a.mkt_expense_target,
	    a.ar_target,
	    a.lead_mrp,
	    a.started_date,
	    a.ending_date,
	    a.target_key,
	    a.exchange,
	    a.product_fn product_name,
	    a.inrangeforecast,
	    a.geo_bd,
	    NULL::text AS latest_ar_target,
	    a.dr_final,
	    a.spl_plan,
	    a.lead_cost_budget,
	    a.mkt_budget,
	    a.spl_plan_def,
	    a.lead_cost_budget_def,
	    a.mkt_budget_def,
	    a.vip_pub,
	    a."AR Forecast",
	    a."AOV Forecast",
	    a."DR_Forecast",
	    a."SPL Forecast",
	    a."%Lead cost FC",
	    a."%GM1 FC",
	    a."%GM2 FC",
	    a.deal_lead_mrp,
	    a.deal_armrp,
	    a.deal_aov_mrp,
	    a.deal_spl_target,
	    a.deal_dr_mrp,
	    a.deal_lead_cost_mrp,
	    a.deal_gm1_mrp,
	    a.deal_gm2_mrp,
	    a."Type",
	    a.deal_type,
	    a.cost_usd,
	    a.logistics_cost_per_validated_order_usd,
	    a.camp_lead_target,
	    a.camp_spl_target,
	    a.camp_percentage_lead_cost_target,
	    a.geo_lead_target,
	    a.geo_spl_target,
	    a.geo_percentage_lead_cost_target,
	    a.offer_lead_target,
	    a.offer_spl_target,
	    a.offer_percentage_lead_cost_target,
	    a.geo_lead_cost_target,
	    a.geo_ar_qa_plan,
	    a.geo_dr_mrp,
	    a.geo_aov_mrp,
	    a.camp_lead_cost_target,
	    a.camp_ar_qa_plan,
	    a.camp_dr_mrp,
	    a.camp_aov_mrp,
	    a.offer_lead_cost_target,
	    a.offer_ar_qa_plan,
	    a.offer_dr_mrp,
	    a.offer_aov_mrp,
	    a.spl_mrp,
	    a.total_approved_postback,
      	a.total_lead_mrp,     	
      	a.geo_2,
      	case when a.do_done > 0.9 then a.delivered else a.validated * a.dr_final end delivered_final,     
        date_trunc('week', date_trunc('week',a.lead_date) - interval '3 day') - interval '1 day' week_start,
        date_trunc('week', date_trunc('week',a.lead_date) - interval '3 day') + interval '5 day' week_end,
        date_trunc('week', date_trunc('week',a.lead_date) - interval '3 day') - interval '8 day' week_start_2,
        date_trunc('week', date_trunc('week',a.lead_date) - interval '3 day') + interval '-2 day' week_end_2,
        date_trunc('week', date_trunc('week',a.lead_date) - interval '3 day') - interval '15 day' week_start_3,
        date_trunc('week', date_trunc('week',a.lead_date) - interval '3 day') + interval '-9 day' week_end_3,
        date_trunc('week', date_trunc('week',a.lead_date) - interval '3 day') - interval '22 day' week_start_4,
        date_trunc('week', date_trunc('week',a.lead_date) - interval '3 day') + interval '-16 day' week_end_4,
      	cm.fresh "COM cost",
      	lm.order_local_cur "LM cost",
      	ffm.order_local_cur "FFM cost",
      	cod.cod "COD cost",
      	bd.agent_cost_2 "standard agent cost",
       	bd.agent_cost_3 "% agent cost trash",
       	uni.unit_cost_lc,
       	uni.offer,
       	tel."TEL cost",
       	rtn."RTN cost",
        mp.max_po_acceptance ak_fc_max_po,
        mp.act_max_po_acceptance ak_act_max_po
from final a
left join max_po mp on a.lead_date = mp.report_date and a.country_code = mp.geo and a.product_name = mp.offer and a.network = mp.network and mp.sale_campaign = a.cam_lead      
left join dim_commision_cost cm on 
 a.country_code = cm.geo 
 and a.lead_date >= cm.started_date::date 
 and a.lead_date <= cm.ending_date::date
left join dim_lm_cost lm on 
 a.country_code = lm.geo 
 and a.lead_date >= lm.started_date::date 
 and a.lead_date <= lm.ending_date::date
left join dim_ffm_cost ffm on 
 a.country_code = ffm.geo 
 and a.lead_date >= ffm.started_date::date 
 and a.lead_date <= ffm.ending_date::date
left join dim_log_cod cod on a.country_code = cod.geo and a.lead_date >= cod.started_date::date and a.lead_date <= cod.ending_date::date
left join -- tel_cost
(
 SELECT 
    geo,
    started_date,
    ending_date,
    AVG(cast(lead_local_cur as FLOAT)) "TEL cost"
  FROM dim_tel_cost
  group by 1,2,3
) tel on a.country_code = tel.geo and a.lead_date >= tel.started_date::date and a.lead_date <= tel.ending_date::date
left join -- rtn
(
 SELECT 
    geo,
    started_date,
    ending_date,
    AVG(cast(rtn as FLOAT)) "RTN cost"
  FROM dim_log_rtn
  group by 1,2,3
) rtn on a.country_code = rtn.geo and a.lead_date >= rtn.started_date::date and a.lead_date <= rtn.ending_date::date
left join  dim_bd_agent_cost bd on a.country_code = bd.geo and a.lead_date >= bd.started_date::date and a.lead_date <= bd.ending_date::date and a.cam_lead = bd.sale_campaign
left join -- unit cost
     (
      select 
        osi.geo_2 geo,
        cl.createdate::date,
        cl.prod_name offer,
        cl.affiliate_id pub,
        cl.subid1 sub,
       sum(unit_cost) unit_cost_lc
     from 
       (select 
         geo, 
         case when geo ^@ 'ID' then 'ID' else geo end geo_2,
         lead_id,
         so_id,
         sum(unit_cost_local_cur_by_lead_created_time*item_quantity) unit_cost
	   from fact__item_with_cost
         where lead_date >= current_date - interval '5' month
       group by 1,2,3,4) osi
       join (select * from od_sale_order where createdate >= current_date - interval '5' month) oso on oso.so_id = osi.so_id and oso.geo = osi.geo and oso.status in (43,357)
		join (select * from od_do_new where createdate >= current_date - interval '5' month) odn on osi.so_id = odn.so_id and osi.geo = odn.geo and odn.status = 59
		join (
		SELECT 
		 cl_fresh.createdate,
		 cl_fresh.lead_id,
		 cl_fresh.geo,
		 CASE
		   WHEN cl_fresh.prod_name IS NULL THEN 'No offer'
		   ELSE cl_fresh.prod_name
		 END AS offer,
		 cl_fresh.prod_name,
		 cl_fresh.lead_type,
		 cl_fresh.lead_status,
		 case 
			 when lower(prod_name) like '%prosta%id' then 472  -- Fresh HC 
             when lower(prod_name) like '%duramax%th' then 567  -- Fresh ME
		     else cl_fresh.cp_id
		 end cp_id,
		 cl_fresh.affiliate_id,
		 CASE
		   WHEN (cl_fresh.affiliate_id in ('EW', 'AT', 'ADT', 'ABT', 'ARB', 'CSL', 'MKR', 'XXX', 'PFC', 'ORG', 'ORG2', 'PIB', 'MH', 'MP', 'IGO', 
		                			'VIC', 'ODS', 'DAT', 'VAL', 'MIR', 'NGN', 'WIL', 'PD', 'CTR', 'U_DOMA', 'ABG')) 
		                			OR cl_fresh.affiliate_id= 'U_RUS' AND cl_fresh.geo = 'TH' OR cl_fresh.subid1 IS NULL THEN 'No PubID'
		   WHEN cl_fresh.subid1 = '' THEN 'blank'
		   ELSE cl_fresh.subid1
		 end as subid1,
		 cl_fresh.assigned,
		 lower(cl_fresh.name) AS cust_name
		 FROM cl_fresh
		 WHERE cl_fresh.lead_type = 'A' 
                 and createdate >= current_date - interval '5' month
		) cl on cl.lead_id = osi.lead_id and cl.geo = osi.geo
		group by 1,2,3,4,5
	  ) uni on a.geo = uni.geo and a.lead_date = uni.createdate and a.network = uni.pub and a.pub = uni.sub and a.product_name = uni.offer
