with
    cte_raw as (
        select
            oso.createdate::date as createdate,
            extract('week' from oso.createdate + interval '1 day') as lead_week,
            extract('month' from oso.createdate) as lead_month,
            extract('week' from current_date + interval '1 day') as current_week,
            (date_trunc('week', oso.createdate + interval '1 day') - interval '1 day')::date
            as week_start,
            (
                date_trunc('week', current_date + interval '1 day') - interval '1 day'
            )::date as week_start_current,
            left(oso.geo, 2) as geo,
            cc.name category,
            case when creation_date is null then 'validated' else 'delay' end validation_type,
            coalesce(extract(day from creation_date - oso.createdate),0) delay_duration,
            sum(case when oso.status in (43,357) then 1 else 0 end) validated,
            sum(case when odn.status = 59 then 1 else 0 end) delivered
        from od_sale_order oso
        left join cl_fresh cf on cf.geo = oso.geo and oso.lead_id = cf.lead_id
        left join cp_campaign cc on cf.cp_id = cc.cp_id and cf.geo = cc.geo
        left join od_do_new odn on oso.geo = odn.geo and oso.so_id = odn.so_id
        where cf.lead_type = 'M'
        and oso.createdate >= current_date - 60
        group by 1,2,3,4,5,6,7,8,9,10
    ),
    data as (
        select
            *,
            case
                when geo = 'ID'
                then week_start >= (week_start_current - 21)
                when geo in ('VN', 'MY')
                then week_start >= (week_start_current - 14)
                when geo in ('TH', 'PH')
                then week_start >= (week_start_current - 7)
                else false
            end as inrangeforecast
        from cte_raw
    ),
    data_forecast1 as (
        select data.*
        from data
        where
            not inrangeforecast
            and (
                (
                    data.geo ^@ 'VN'
                    and createdate <= week_start_current - 15
                    and createdate >= week_start_current - 35
                )
                or (
                    data.geo ^@ 'ID'
                    and createdate <= week_start_current - 22
                    and createdate >= week_start_current - 42
                )
                or (
                    data.geo ^@ 'TH'
                    and createdate <= week_start_current - 22
                    and createdate >= week_start_current - 42
                )
                or (
                    data.geo ^@ 'PH'
                    and createdate <= week_start_current - 22
                    and createdate >= week_start_current - 42
                )  -- -- 22.06.2023
                or (
                    data.geo ^@ 'MY'
                    and createdate <= week_start_current - 15
                    and createdate >= week_start_current - 35
                )
            )
    ),
    full_data_forecast_by_geo as (
        select
            data_forecast.geo,
            sum(validated) as validated,
            sum(delivered) as delivered,
            case
                when sum(validated) = 0
                then 0
                else sum(delivered) / sum(validated)::float
            end as dr_forecast
        from data_forecast1 data_forecast
        group by 1
    )
select
    raw.geo,
    validated,
    delivered,
    dr_forecast dr_forecast
from full_data_forecast_by_geo raw
