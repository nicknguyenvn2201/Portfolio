with main_ as (
select geo, user_id, lower(user_name) user_name, substring(user_name,1,position('@' in user_name)) short_name 
from or_user
where user_type = 'agent'
), final_ as (
select geo,user_id,user_name,short_name,
case when short_name ilike '%af%' then 'Fresh'
     when short_name ilike '%ar%' then 'Fresh Resell'
     when short_name ilike '%ac%' then 'CIT'
     else 'Undefined'
     end as team
from main_
)
select geo,user_id,user_name,
case when geo in ('MY','MY2','TH1','TH2','PH','TH') and (short_name ilike 'a%' or short_name ilike 'f%') then 'Fresh'
     when geo in ('MY','MY2','TH1','TH2','PH','TH') and short_name ilike 'r%' then 'CIT'
     when geo ^@ 'ID' and short_name ilike '%bk%' then 'Fresh'
     when geo ^@ 'ID' and short_name not ilike '%bk%' then 'CIT'
     when geo ^@ 'VN' and short_name ilike '%resell%' then 'Fresh Resell'
     when geo ^@ 'VN' and short_name ilike '%cit%' then 'CIT'
     when geo ^@ 'VN' and short_name ilike 'a%' then 'Fresh'
     else 'Undefined'
     end team
from final_
where team = 'Undefined'
union all 
select geo,user_id,user_name,team
from final_
where team <> 'Undefined'
