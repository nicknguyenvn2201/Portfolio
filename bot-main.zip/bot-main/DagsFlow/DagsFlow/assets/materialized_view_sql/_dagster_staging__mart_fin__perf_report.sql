-- dareport."_dagster_staging__mart_fin__perf_report" source

CREATE OR REPLACE VIEW dareport."_dagster_staging__mart_fin__perf_report"
AS WITH cte_drfc_aging AS (
         SELECT fd.geo,
            fd.lead_date::date AS lead_date,
            fd.source,
            fd.offer_product,
            fd.sale_camp,
            count(DISTINCT
                CASE
                    WHEN fd.orderstatus::text = ANY (ARRAY['validated'::character varying, 'delay'::character varying]::text[]) THEN fd.leadid
                    ELSE NULL::text
                END) AS validated,
            sum(fd.dr) AS delivered_fc_aging,
                CASE
                    WHEN sum(fd.dr) = 0::double precision OR count(DISTINCT
                    CASE
                        WHEN fd.orderstatus::text = ANY (ARRAY['validated'::character varying, 'delay'::character varying]::text[]) THEN fd.leadid
                        ELSE NULL::text
                    END) = 0 THEN 0::double precision
                    ELSE sum(fd.dr) / count(DISTINCT
                    CASE
                        WHEN fd.orderstatus::text = ANY (ARRAY['validated'::character varying, 'delay'::character varying]::text[]) THEN fd.leadid
                        ELSE NULL::text
                    END)::double precision
                END AS dr_forecast_aging
           FROM finance_daily_view fd
          WHERE fd.leadtypename = 'Fresh'::text AND fd.aging <=
                CASE
                    WHEN fd.geo = 'VN'::text THEN 22
                    WHEN fd.geo = 'ID'::text THEN 28
                    WHEN fd.geo = 'TH'::text THEN 17
                    WHEN fd.geo = 'PH'::text THEN 17
                    WHEN fd.geo = 'MY'::text THEN 15
                    ELSE NULL::integer
                END AND fd.lead_date >= '2023-01-01 00:00:00'::timestamp without time zone
          GROUP BY (fd.lead_date::date), fd.source, fd.offer_product, fd.sale_camp, fd.geo
        ), cte_agg_bd_master AS (
         SELECT bm_1.createdate,
            bm_1.country_code,
            bm_1.offer,
            bm_1.network,
            bm_1.sale_campaign,
            sum(bm_1.total_lead) AS total_lead,
            avg(bm_1.ar_target_mrp) AS ar_target_mrp,
            avg(bm_1.pub_lead_mrp) AS pub_lead_mrp,
            sum(bm_1.validated) AS validated,
            sum(bm_1.cpl_lead) AS cpl_lead,
            sum(bm_1.amt_validated) AS amt_validated,
            sum(bm_1.delivered) AS delivered,
            avg(bm_1.tax_rate) AS tax_rate,
            max(bm_1.inrangeforecast) AS inrangeforecast,
            sum(bm_1.amt_delivered) AS amt_delivered,
            avg(bm_1.payout) AS payout,
            avg(bm_1.max_po) AS max_po,
            avg(bm_1.exchange_rate) AS exchange_rate,
            avg(bm_1.gap_po) AS gap_po,
                CASE
                    WHEN sum(bm_1.validated) = 0::numeric THEN 0::double precision
                    ELSE sum(bm_1.amt_validated_usd) / sum(bm_1.validated)::double precision
                END AS aov,
            sum(bm_1.amt_validated_usd) AS amt_validated_usd,
                CASE
                    WHEN sum(bm_1.delivered) = 0::numeric THEN 0::double precision
                    ELSE sum(bm_1.amt_delivered_usd) / sum(bm_1.delivered)::double precision
                END AS aov_delivered,
            sum(bm_1.amt_delivered_usd) AS amt_delivered_usd,
            sum(bm_1.dr_final * bm_1.validated::double precision) AS total_deli_drfc
           FROM bd_master bm_1
          WHERE bm_1.manager IS NULL OR (bm_1.manager <> ALL (ARRAY['Nastya'::text, 'Anton'::text, 'Aleks'::text])) AND bm_1.lead_year = 2023::double precision AND bm_1.createdate >= '2023-01-01'::date
          GROUP BY bm_1.createdate, bm_1.country_code, bm_1.offer, bm_1.network, bm_1.sale_campaign
        UNION
         SELECT DISTINCT '2023-01-01'::date AS createdate,
            dim_finance_plan_figure.country_code,
            dim_finance_plan_figure.offer,
            dim_finance_plan_figure.partner AS network,
            dim_finance_plan_figure.sales_camp AS sale_campaign,
            NULL::numeric AS total_lead,
            NULL::numeric AS ar_target_mrp,
            NULL::numeric AS pub_lead_mrp,
            NULL::numeric AS validated,
            NULL::numeric AS cpl_lead,
            NULL::numeric AS amt_validated,
            NULL::numeric AS delivered,
            NULL::numeric AS tax_rate,
            NULL::numeric AS inrangeforecast,
            NULL::numeric AS amt_delivered,
            NULL::numeric AS payout,
            NULL::numeric AS max_po,
            NULL::numeric AS exchange_rate,
            NULL::numeric AS gap_po,
            NULL::numeric AS aov,
            NULL::numeric AS amt_validated_usd,
            NULL::numeric AS aov_delivered,
            NULL::numeric AS amt_delivered_usd,
            NULL::numeric AS total_deli_drfc
           FROM dim_finance_plan_figure
        ), cte_full_data_agg_bd_master AS (
         SELECT cte_agg_bd_master.country_code,
            cte_agg_bd_master.offer,
            cte_agg_bd_master.network,
            generate_series('2023-01-01 00:00:00+07'::timestamp with time zone, CURRENT_DATE::timestamp with time zone, '1 day'::interval)::date AS createdate
           FROM cte_agg_bd_master
          GROUP BY cte_agg_bd_master.country_code, cte_agg_bd_master.offer, cte_agg_bd_master.network
        ), cte_final AS (
         SELECT fbm.country_code,
            fbm.offer,
            fbm.network,
            fbm.createdate,
            bm_1.sale_campaign,
            date_part('week'::text, fbm.createdate + '1 day'::interval) AS lead_week,
            date_part('month'::text, fbm.createdate) AS lead_month,
            date_part('year'::text, fbm.createdate) AS lead_year,
            bm_1.total_lead,
            bm_1.ar_target_mrp,
            bm_1.pub_lead_mrp,
            bm_1.validated,
            bm_1.cpl_lead,
            bm_1.amt_validated,
            bm_1.amt_validated_usd,
            bm_1.delivered,
            bm_1.tax_rate,
            bm_1.inrangeforecast,
            bm_1.amt_delivered,
            bm_1.amt_delivered_usd,
            bm_1.payout,
            bm_1.max_po,
            bm_1.exchange_rate,
            bm_1.gap_po,
            bm_1.total_deli_drfc,
            drfca.delivered_fc_aging,
            drfca.dr_forecast_aging
           FROM cte_full_data_agg_bd_master fbm
             LEFT JOIN cte_agg_bd_master bm_1 ON fbm.country_code = bm_1.country_code AND fbm.offer::text = bm_1.offer::text AND fbm.network::text = bm_1.network::text AND fbm.createdate = bm_1.createdate
             LEFT JOIN cte_drfc_aging drfca ON bm_1.country_code = drfca.geo AND bm_1.createdate = drfca.lead_date AND bm_1.sale_campaign::text = drfca.sale_camp::text AND bm_1.offer::text = drfca.offer_product::text AND bm_1.network::text = drfca.source::text
        )
 SELECT bm.country_code,
    bm.offer,
    bm.network,
    bm.createdate,
    bm.sale_campaign,
    bm.lead_week,
    bm.lead_month,
    bm.lead_year,
    bm.total_lead,
    bm.ar_target_mrp,
    bm.pub_lead_mrp,
    bm.validated,
    bm.cpl_lead,
    bm.amt_validated,
    bm.amt_validated_usd,
    bm.delivered,
    bm.tax_rate,
    bm.inrangeforecast,
    bm.amt_delivered,
    bm.amt_delivered_usd,
    bm.payout,
    bm.max_po,
    bm.exchange_rate,
    bm.gap_po,
    bm.total_deli_drfc,
    bm.delivered_fc_aging,
    bm.dr_forecast_aging,
    dfpf.daily_lead_plan,
    dfpf.ar_qa_plan,
    dfpf.aov_plan,
    dfpf.dr_plan,
    dlcrp."Lead cost Plan" AS lead_cost_plan_percentage,
    dfm.markup,
    dct.spl_mrp,
    dct.ar_target
   FROM cte_final bm
     LEFT JOIN dim_finance_plan_figure dfpf ON dfpf.country_code = bm.country_code AND dfpf.month::double precision = bm.lead_month AND dfpf.year::double precision = bm.lead_year AND dfpf.offer = bm.offer::text AND dfpf.partner = bm.network::text
     LEFT JOIN dim_lead_cost_rev_plan dlcrp ON dlcrp."Geo" = bm.country_code AND dlcrp."Month"::double precision = bm.lead_month AND dlcrp."Year"::double precision = bm.lead_year AND dlcrp."Offer" = bm.offer::text AND dlcrp."Pub" = bm.network::text
     LEFT JOIN dim_cpl_target dct ON dct.pub = bm.network::text AND dct.offer = bm.offer::text AND bm.createdate >= dct.from_date AND bm.createdate <= dct.to_date
     LEFT JOIN dim_finance_markup dfm ON dfm.country_code = bm.country_code AND dfm.month::double precision = bm.lead_month AND dfm.year::double precision = bm.lead_year;
