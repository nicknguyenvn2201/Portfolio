-- dareport.traffic_bd_master source

  CREATE MATERIALIZED VIEW dareport.traffic_bd_master_qtest_1
  WITH(autovacuum_enabled=true)
  TABLESPACE pg_default as

--WITH cte_lead_traffics AS (
--    SELECT lead_traffics.affiliate_id AS network,
--    lead_traffics.offer_id AS product_name,
--    CASE
--        WHEN lower(lead_traffics.sub_id) = '*'::text THEN ''::text
--        WHEN lower(lead_traffics.sub_id) = ''::text THEN 'blank'::text
--        ELSE lead_traffics.sub_id
--        END AS sub_id,
--    lead_traffics.traffic,
--    lead_traffics.applied_from_date::date AS started_date,
--    lead_traffics.applied_to_date::date AS ending_date,
--    CASE
--        WHEN lower(lead_traffics.sub_id) = '*'::text THEN concat(lead_traffics.affiliate_id, '_', lead_traffics.offer_id)
--        WHEN lower(lead_traffics.sub_id) = ''::text THEN concat(lead_traffics.affiliate_id, '_', 'blank', '_', lead_traffics.offer_id)
--        ELSE concat(lead_traffics.affiliate_id, '_', lead_traffics.sub_id, '_', lead_traffics.offer_id)
--        END AS target_key
--    FROM lead_traffics
--    WHERE lead_traffics.applied_from_date::date <= lead_traffics.applied_to_date::date
--)
--
--, 
WITH cte_ar_mrps AS (
    SELECT ar_mrps.affiliate_id AS network,
    ar_mrps.offer_id AS product_name,
    CASE
        WHEN lower(ar_mrps.sub_id) = '*'::text THEN ''::text
        WHEN lower(ar_mrps.sub_id) = ''::text THEN 'blank'::text
        ELSE ar_mrps.sub_id
        END AS sub_id,
    ar_mrps.ar_mrp,
    ar_mrps.applied_from_date::date AS started_date,
    ar_mrps.applied_to_date::date AS ending_date,
    CASE
        WHEN lower(ar_mrps.sub_id) = '*'::text THEN concat(ar_mrps.affiliate_id, '_', ar_mrps.offer_id)
        WHEN lower(ar_mrps.sub_id) = ''::text THEN concat(ar_mrps.affiliate_id, '_', 'blank', '_', ar_mrps.offer_id)
        ELSE concat(ar_mrps.affiliate_id, '_', ar_mrps.sub_id, '_', ar_mrps.offer_id)
        END AS target_key
    FROM ar_mrps
)


SELECT d.lead_date::date AS createdate, --createdate
    count(DISTINCT d.lead_id) AS leads,
    d.geo,
    CASE
        WHEN d.lead_date::date >= '2024-06-01'::date AND d.geo::text ^@ 'VN'::text THEN 'VN'::text
        ELSE d.geo::text END AS geo_bd,
    CASE
        WHEN d.geo::text ^@ 'TH'::text THEN 'TH'::character varying
        WHEN d.geo::text ^@ 'VN'::text THEN 'VN'::character varying
        WHEN d.geo::text ^@ 'ID'::text THEN 'ID'::character varying
        WHEN d.geo::text ^@ 'MY'::text THEN 'MY'::character varying
        WHEN d.geo::text ^@ 'PH'::text THEN 'PH'::character varying
        ELSE d.geo
        END::text AS country_code,
    d.offer as prod_name, --prod_name in cl_fresh
    d.province AS province_name, --change from product_id to production_name
    d.sale_campaign AS campaign, --cc.name (from cp_campaign)
    d.lead_type,
    d.postback_status,
    CASE
        WHEN d.postback_status::text ~~ '%pending%'::text THEN 'Pending'::character varying
        WHEN d.postback_status::text = 'approved'::text THEN 'Approved'::character varying
        WHEN d.postback_status::text = 'rejected'::text THEN 'Rejected'::character varying
        WHEN d.postback_status::text = 'trash'::text THEN 'Trash'::character varying
        ELSE d.postback_status
        END AS adjusted_postback_status,
    d.network as affiliate_id, --affiliate_id in cl_fresh
    d.pub as subid1, --subid1 in cl_fresh
--    CASE
--        WHEN COALESCE(mrp.traffic, mrp_2.traffic) = ''::text OR COALESCE(mrp.traffic, mrp_2.traffic) IS NULL THEN 'No Traffic'::text
--        ELSE COALESCE(mrp.traffic, mrp_2.traffic)
--        END AS traffic_source,
    COALESCE(am.ar_mrp, am_2.ar_mrp) AS ar_target_mrp,
    agerange.name AS customer_age,
    gender.name AS customer_gender,
    COALESCE(
    CASE
        WHEN d.network::text = ANY (ARRAY['AFS'::character varying::text, 'OFP'::character varying::text]) THEN d.network
        -- WHEN COALESCE(p.shortname, d.agc_code)::text = ANY (ARRAY['AFS'::character varying::text, 'OFP'::character varying::text]) THEN d.network
        ELSE COALESCE(d.network, 'LOYAL CUSTOMER'::character varying)
        -- ELSE COALESCE(p.shortname, d.agc_code, 'LOYAL CUSTOMER'::character varying)
        END, 'No network'::character varying) AS network,
    fkd.campaign_group AS mb_campaign,
    replace(split_part(fkd.campaign_group, '-'::text, 2), ' '::text, ''::text) AS offer,
    replace(split_part(fkd.campaign_group, '-'::text, 1), ' '::text, ''::text) AS mb_buyer,
    fkd.sub_id_1 AS mb_placement,
    fkd.sub_id_3 AS mb_ad_sets,
    fkd.sub_id_4 AS mb_ads,
    fkd.device_model
FROM dareport.data_master_raw d --cl_fresh
-- LEFT JOIN cp_campaign cp ON cp.cp_id = d.cp_id AND cp.geo::text = d.geo::text
LEFT JOIN mkt_data mdv ON mdv.lead_id = d.lead_id AND d.geo::text = mdv.geo::text
LEFT JOIN ( SELECT cs.geo,
    cs.synonym_id,
    cs.type,
    cs.name,
    cs.value,
    cs.dscr,
    cs.type_id,
    cs.localized_name
    FROM cf_synonym cs
    WHERE cs.type::text = 'age range'::text) agerange ON mdv.cust_age = agerange.value AND agerange.geo::text = mdv.geo::text
    LEFT JOIN ( SELECT cs.geo,
                cs.synonym_id,
                cs.type,
                cs.name,
                cs.value,
                cs.dscr,
                cs.type_id,
                cs.localized_name
                FROM cf_synonym cs
                WHERE cs.type::text = 'gender'::text) gender ON mdv.cust_gender = gender.value AND gender.geo::text = mdv.geo::text
        
--    LEFT JOIN cte_lead_traffics mrp ON
--                                    CASE
--                                        WHEN d.pub::text = ''::text THEN concat(d.network, '_', 'blank', '_', d.offer)
--                                        ELSE concat(d.network, '_', d.pub, '_', d.offer)
--                                    END = mrp.target_key AND d.lead_date::date >= mrp.started_date AND d.lead_date::date <= mrp.ending_date
--    LEFT JOIN cte_lead_traffics mrp_2 ON concat(d.network, '_', d.offer) = mrp_2.target_key AND d.lead_date::date >= mrp_2.started_date AND d.lead_date::date <= mrp_2.ending_date
    LEFT JOIN cte_ar_mrps am ON
						        CASE
						            WHEN d.pub::text = ''::text THEN concat(d.network, '_', 'blank', '_', d.offer)
						            ELSE concat(d.network, '_', d.pub, '_', d.offer) END = am.target_key 
							AND d.lead_date >= am.started_date 
							AND d.lead_date <= am.ending_date
    LEFT JOIN cte_ar_mrps am_2 ON concat(d.network, '_', d.offer) = am_2.target_key 
				    		AND d.lead_date >= am_2.started_date 
				    		AND d.lead_date <= am_2.ending_date
    -- LEFT JOIN bp_partner p ON d.agc_id = p.pn_id AND p.geo::text = d.geo::text
    LEFT JOIN base_fact__affscale_conversion bfac ON bfac.transaction_id = d.click_id::text
    LEFT JOIN ( SELECT fact_keitaro_data.campaign,
                fact_keitaro_data.campaign_group,
                fact_keitaro_data.device_model,
                fact_keitaro_data.sub_id_1,
                fact_keitaro_data.sub_id_2,
                fact_keitaro_data.sub_id_3,
                fact_keitaro_data.sub_id_4,
                fact_keitaro_data.ad_campaign_id,
                fact_keitaro_data.sub_id_8,
                fact_keitaro_data.datetime,
                fact_keitaro_data.campaign_id,
                fact_keitaro_data.conversions,
                fact_keitaro_data.sales,
                fact_keitaro_data.revenue,
                fact_keitaro_data.cost,
                fact_keitaro_data.sub_id,
                fact_keitaro_data.sub_id_7,
                fact_keitaro_data.sale_revenue
                FROM fact_keitaro_data) fkd ON fkd.sub_id = bfac.aff_click_id
WHERE d.lead_type::text = 'A'::text AND lower(d.name::text) !~~ '%test%'::text AND d.lead_date::date >= '2022-01-01'::date AND d.lead_status = 'approved'
GROUP BY d.geo, d.province, (d.lead_date::date), fkd.campaign_group, fkd.sub_id_1, fkd.sub_id_3, fkd.sub_id_4, fkd.device_model, d.offer, d.sale_campaign, d.lead_type, d.postback_status, d.network, d.pub, agerange.name, gender.name, 
--	(CASE
--        WHEN COALESCE(mrp.traffic, mrp_2.traffic) = ''::text OR COALESCE(mrp.traffic, mrp_2.traffic) IS NULL THEN 'No Traffic'::text
--        ELSE COALESCE(mrp.traffic, mrp_2.traffic) END),
    (CASE
        WHEN d.network = ANY (ARRAY['AFS'::character varying::text, 'OFP'::character varying::text]) THEN d.network
        -- WHEN COALESCE(d.network, d.agc_code)::text = ANY (ARRAY['AFS'::character varying::text, 'OFP'::character varying::text]) THEN d.network
        ELSE COALESCE(d.network, 'LOYAL CUSTOMER'::character varying)
        -- ELSE COALESCE(d.network, d.agc_code, 'LOYAL CUSTOMER'::character varying)
        END), 
(COALESCE(am.ar_mrp, am_2.ar_mrp))
ORDER BY (d.lead_date::date) DESC
-- WITH DATA;
