with
    cte_drfc_aging as (
        select
            fd.geo,
            fd.lead_date::date as lead_date,
            fd.source,
            fd.offer_product,
            fd.sale_camp,
            count(
                distinct case
                    when fd.orderstatus in ('validated', 'delay')
                    then fd.leadid
                    else null
                end
            ) as validated,
            sum(fd.dr)::float as delivered_fc_aging,  -- number of so_id that has dostatus = delivered or intransit*ins_to_del
            case
                when
                    sum(fd.dr) = 0
                    or count(
                        distinct case
                            when fd.orderstatus in ('validated', 'delay')
                            then fd.leadid
                            else null
                        end
                    )
                    = 0
                then 0
                else
                    sum(fd.dr) / count(
                        distinct case
                            when fd.orderstatus in ('validated', 'delay')
                            then fd.leadid
                            else null
                        end
                    )
            end as dr_forecast_aging
        from "tms_central"."dareport"."finance_daily_view" fd
        where
            fd.leadtypename = 'Fresh'
            and fd.aging <= (
                case
                    when fd.geo = 'VN'::text
                    then 22
                    when fd.geo = 'ID'::text
                    then 28
                    when fd.geo = 'TH'::text
                    then 17
                    when fd.geo = 'PH'::text
                    then 17
                    when fd.geo = 'MY'::text
                    then 15
                    else null::integer
                end
            )
            and lead_date >= '2023-01-01'

        group by fd.lead_date::date, fd.source, fd.offer_product, fd.sale_camp, fd.geo
    ),
    cte_agg_bd_master as (
        select
            bm.createdate,
            bm.country_code,
            bm.offer,
            bm.network,
            bm.sale_campaign,  -- lead_week,lead_month,lead_year, bm.geo,
            sum(bm.total_lead) total_lead,
            avg(bm.ar_target_mrp) ar_target_mrp,
            avg(bm.pub_lead_mrp) pub_lead_mrp,
            sum(bm.validated) validated,
            sum(bm.cpl_lead) cpl_lead,
            sum(bm.amt_validated) amt_validated,
            sum(bm.delivered) delivered,
            avg(bm.tax_rate) tax_rate,
            max(bm.inrangeforecast) inrangeforecast,
            sum(amt_delivered) amt_delivered,
            avg(payout) payout,
            avg(max_po) max_po,
            avg(exchange_rate) exchange_rate,
            avg(gap_po) gap_po,
            case
                when sum(bm.validated) = 0
                then 0::double precision
                else
                    sum(bm.amt_validated_usd)::double precision
                    / sum(bm.validated)::double precision
            end as aov,
            sum(bm.amt_validated_usd) amt_validated_usd,
            case
                when sum(bm.delivered) = 0
                then 0::double precision
                else
                    sum(bm.amt_delivered_usd)::double precision
                    / sum(bm.delivered)::double precision
            end as aov_delivered,
            sum(bm.amt_delivered_usd) amt_delivered_usd,
            -- , AVG(bm.dr_final) dr_final
            sum(bm.dr_final * bm.validated) total_deli_drfc
        from "tms_central"."dareport"."bd_master" bm
        where
            bm.manager is null
            or bm.manager not in ('Nastya', 'Anton', 'Aleks')
            and lead_year = 2023  -- and offer = 'vipprostanix-id' and lead_month = 8
            and createdate >= '2023-01-01'

        group by bm.createdate, bm.country_code, bm.offer, bm.network, bm.sale_campaign  -- lead_week, lead_month,lead_year, --  , bm.pub
        union
        select distinct
            '2023-01-01'::date as createdate,
            country_code,
            offer,
            partner as network,
            sales_camp as sale_campaign,  -- country_code as geo,
            null::numeric as total_lead,
            null::numeric as ar_target_mrp,
            null::numeric as pub_lead_mrp,
            null::numeric as validated,
            null::numeric as cpl_lead,
            null::numeric as amt_validated,
            null::numeric as delivered,
            null::numeric as tax_rate,
            null::numeric as inrangeforecast,
            null::numeric as amt_delivered,
            null::numeric as payout,
            null::numeric as max_po,
            null::numeric as exchange_rate,
            null::numeric as gap_po,
            null::numeric as aov,
            null::numeric as amt_validated_usd,
            null::numeric as aov_delivered,
            null::numeric as amt_delivered_usd,
            -- , null::numeric as dr_final
            null::numeric as total_deli_drfc
        from "tms_central"."dareport"."dim_finance_plan_figure"
    ),
    cte_full_data_agg_bd_master as (
        select
            country_code,
            offer,
            network,  -- , sale_campaign -- bm.createdate, lead_week,lead_month,lead_year, geo,
            generate_series(
                ('2023-01-01')::timestamp
                with time zone, (current_date)::timestamp
                with time zone, '1 day'::interval
            )::date as createdate
        from cte_agg_bd_master
        group by country_code, offer, network  -- , sale_campaign
    ),
    cte_final as (
        select
            fbm.*,
            bm.sale_campaign,
            date_part('week'::text, fbm.createdate + '1 day'::interval) as lead_week,
            date_part('month'::text, fbm.createdate) as lead_month,
            date_part('year'::text, fbm.createdate) as lead_year,
            bm.total_lead,
            bm.ar_target_mrp,
            bm.pub_lead_mrp,
            bm.validated,
            bm.cpl_lead,
            bm.amt_validated,
            bm.amt_validated_usd,
            bm.delivered,
            bm.tax_rate,
            bm.inrangeforecast,
            bm.amt_delivered,
            bm.amt_delivered_usd,
            bm.payout,
            bm.max_po,
            bm.exchange_rate,
            bm.gap_po,
            -- bm.dr_final,
            bm.total_deli_drfc,
            drfca.delivered_fc_aging,
            drfca.dr_forecast_aging
        from cte_full_data_agg_bd_master fbm
        left join
            cte_agg_bd_master bm
            on fbm.country_code = bm.country_code
            and fbm.offer = bm.offer
            and fbm.network = bm.network
            -- and fbm.sale_campaign = bm.sale_campaign
            and fbm.createdate::date = bm.createdate::date
        left join
            cte_drfc_aging drfca
            on bm.country_code::text = drfca.geo
            and bm.createdate::date = drfca.lead_date::date
            and bm.sale_campaign::text = drfca.sale_camp
            and bm.offer = drfca.offer_product
            and bm."network" = drfca."source"
    )
select
    bm.*,
    dfpf.daily_lead_plan,
    dfpf.ar_qa_plan,
    dfpf.aov_plan,
    dfpf.dr_plan,
    dlcrp."Lead cost Plan" as lead_cost_plan_percentage,
    dfm.markup,
    dct.spl_mrp,
    dct.ar_target  -- 26.06.2023
from cte_final bm
left join
    "tms_central"."dareport"."dim_finance_plan_figure" dfpf
    on dfpf.country_code = bm.country_code
    and dfpf."month" = bm.lead_month
    and dfpf."year" = bm.lead_year
    -- and dfpf.sales_camp = bm.sale_campaign
    and dfpf.offer = bm.offer
    and dfpf.partner = bm.network
left join
    "tms_central"."dareport"."dim_lead_cost_rev_plan" dlcrp
    on dlcrp."Geo" = bm.country_code
    and dlcrp."Month" = bm.lead_month
    and dlcrp."Year" = bm.lead_year
    and dlcrp."Offer" = bm.offer
    and dlcrp."Pub" = bm.network
left join
    "tms_central"."dareport"."dim_cpl_target" dct
    on dct.pub = bm.network
    and dct.offer = bm.offer
    and bm.createdate >= dct.from_date
    and bm.createdate <= dct.to_date
left join
    "tms_central"."dareport"."dim_finance_markup" dfm
    on dfm.country_code = bm.country_code
    and dfm."month" = bm.lead_month
    and dfm."year" = bm.lead_year
