WITH filtered_data_master AS (
    SELECT lead_modify_date, lead_date, so_date, total_call, lead_id, geo, lead_status, sale_campaign, so_status, do_status, so_amount, assigned
    FROM data_master_raw
    WHERE (lead_date >= current_date - INTERVAL '90 days' OR so_date >= current_date - INTERVAL '90 days') 
      AND geo = 'VN3'
),
agent_user AS (
    SELECT geo, user_name, user_id 
    FROM or_user 
    WHERE user_type = 'agent'
),
enabled_teams AS (
    SELECT user_id, team_id, geo
    FROM or_team_member
    WHERE enabled = true
),
active_teams AS (
    SELECT id, name, geo
    FROM or_team
    WHERE enable = true
),
call_summary AS (
    SELECT geo, lead_id, COUNT(*) AS call_session, SUM(duration) AS duration
    FROM fact_cdr
    WHERE geo = 'VN3' 
      AND createtime >= current_date - INTERVAL '90 days'
    GROUP BY geo, lead_id
),
agent_onboard AS (
    SELECT geo, assigned, on_board_date, (current_date - on_board_date)::float / 30 AS on_board_interval_months
    FROM dim_agent_on_board
),
fresh_leads AS (
    SELECT geo, lead_id, assigned_group_id 
    FROM cl_fresh 
    WHERE geo = 'VN3'
)

SELECT
    cm.lead_modify_date AS modifydate,
    cm.lead_date,
    cm.so_date,
    cm.total_call,
    cm.lead_id,
    cm.geo,
    cm.lead_status,
    cm.sale_campaign,
    cm.so_status,
    cm.do_status,
    cm.so_amount,
    ou.user_name,
    ot.name AS team,
    daob.on_board_date,
    daob.on_board_interval_months,
    mft.f1_lead_id, mft.f_type, mft.f1_lead_date, mft.f1_network, mft.f1_offer, mft.f1_geo,
    TRIM(REGEXP_REPLACE(og.name, '[0-9]', '', 'g')) AS team_final,
    CASE 
        WHEN lead_status ILIKE '%callback%' AND (cr.duration = 0 OR cr.duration IS NULL) THEN 0 
        ELSE 1 
    END AS lead_adj,
    CASE 
        WHEN cr.duration > 10 THEN 1 
        ELSE 0 
    END AS contactable_lead,
    cr.call_session
FROM filtered_data_master AS cm
LEFT JOIN agent_user AS ou ON cm.geo = ou.geo AND cm.assigned = ou.user_id
LEFT JOIN enabled_teams AS tm ON ou.user_id = tm.user_id AND ou.geo = tm.geo
LEFT JOIN active_teams AS ot ON ot.id = tm.team_id AND ot.geo = tm.geo
LEFT JOIN call_summary AS cr ON cm.lead_id = cr.lead_id AND cm.geo = cr.geo
LEFT JOIN agent_onboard AS daob ON daob.geo = cm.geo AND daob.assigned = cm.assigned
LEFT JOIN mv_f_type_vn3 AS mft ON mft.geo = cm.geo AND mft.lead_id = cm.lead_id
LEFT JOIN fresh_leads AS cf ON cf.geo = cm.geo AND cf.lead_id = cm.lead_id
LEFT JOIN or_group AS og ON cf.geo = og.geo AND cf.assigned_group_id = og.group_id
