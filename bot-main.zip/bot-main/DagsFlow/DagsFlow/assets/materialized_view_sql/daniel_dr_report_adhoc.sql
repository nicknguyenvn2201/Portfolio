with
    raw_data as (
        select
            geo,
            campaign_name,
            so_id,
            lead_type,
            customer_address_province province,
            delivery_carrier,
            case
                when do_status = 'delivered' then do_modifydate::date else null
            end do_modifydate,
            case
                when do_status = 'delivered' then sales_amount else null
            end delivered_amount,
            case
                when lead_type = 'A' then lead_date::date else so_date::date
            end as date_used
        from fact__lead_sales_delivery
        where so_status in ('delay', 'validated')
    )
select
    r.geo,
    r.campaign_name,
    r.so_id,
    r.lead_type,
    r.do_modifydate,
    r.date_used,
    r.province,
    r.delivery_carrier,
    date_part('week'::text, r.date_used + '1 day'::interval) date_used_week,
    w1.week_used_1_start,
    w1.week_used_1_end,
    w1.week_used_2_start,
    w1.week_used_2_end,
    w1.week_used_3_start,
    w1.week_used_3_end,
    w1.week_used_4_start,
    w1.week_used_4_end,
    w1.week_used_5_start,
    w1.week_used_5_end,
    w1.week_used_6_start,
    w1.week_used_6_end,
    w1.week_used_7_start,
    w1.week_used_7_end,
    w1.week_used_8_start,
    w1.week_used_8_end,
    w1.week_used_9_start,
    w1.week_used_9_end,
    w1.week_used_10_start,
    w1.week_used_10_end,
    delivered_amount,
    case
        when
            r.do_modifydate::date
            between w1.week_used_1_start::date and w1.week_used_1_end::date
        then 1
        else 0
    end do_w1,
    case
        when
            r.do_modifydate::date
            between w1.week_used_2_start::date and w1.week_used_2_end::date
        then 1
        else 0
    end do_w2,
    case
        when
            r.do_modifydate::date
            between w1.week_used_3_start::date and w1.week_used_3_end::date
        then 1
        else 0
    end do_w3,
    case
        when
            r.do_modifydate::date
            between w1.week_used_4_start::date and w1.week_used_4_end::date
        then 1
        else 0
    end do_w4,
    case
        when
            r.do_modifydate::date
            between w1.week_used_5_start::date and w1.week_used_5_end::date
        then 1
        else 0
    end do_w5,
    case
        when
            r.do_modifydate::date
            between w1.week_used_6_start::date and w1.week_used_6_end::date
        then 1
        else 0
    end do_w6,
    case
        when
            r.do_modifydate::date
            between w1.week_used_7_start::date and w1.week_used_7_end::date
        then 1
        else 0
    end do_w7,
    case
        when
            r.do_modifydate::date
            between w1.week_used_8_start::date and w1.week_used_8_end::date
        then 1
        else 0
    end do_w8,
    case
        when
            r.do_modifydate::date
            between w1.week_used_9_start::date and w1.week_used_9_end::date
        then 1
        else 0
    end do_w9,
    case
        when
            r.do_modifydate::date
            between w1.week_used_10_start::date and w1.week_used_10_end::date
        then 1
        else 0
    end do_w10,
    case when abs(r.date_used - r.do_modifydate) = 1 then 1 else 0 end d1,
    case when abs(r.date_used - r.do_modifydate) = 2 then 1 else 0 end d2,
    case when abs(r.date_used - r.do_modifydate) = 3 then 1 else 0 end d3,
    case when abs(r.date_used - r.do_modifydate) = 4 then 1 else 0 end d4,
    case when abs(r.date_used - r.do_modifydate) = 5 then 1 else 0 end d5,
    case when abs(r.date_used - r.do_modifydate) = 6 then 1 else 0 end d6,
    case when abs(r.date_used - r.do_modifydate) = 7 then 1 else 0 end d7,
    case when abs(r.date_used - r.do_modifydate) = 8 then 1 else 0 end d8,
    case when abs(r.date_used - r.do_modifydate) = 9 then 1 else 0 end d9,
    case when abs(r.date_used - r.do_modifydate) = 10 then 1 else 0 end d10,
    case when abs(r.date_used - r.do_modifydate) = 11 then 1 else 0 end d11,
    case when abs(r.date_used - r.do_modifydate) = 12 then 1 else 0 end d12,
    case when abs(r.date_used - r.do_modifydate) = 13 then 1 else 0 end d13,
    case when abs(r.date_used - r.do_modifydate) = 14 then 1 else 0 end d14,
    case when abs(r.date_used - r.do_modifydate) = 15 then 1 else 0 end d15,
    case when abs(r.date_used - r.do_modifydate) = 16 then 1 else 0 end d16,
    case when abs(r.date_used - r.do_modifydate) = 17 then 1 else 0 end d17,
    case when abs(r.date_used - r.do_modifydate) = 18 then 1 else 0 end d18,
    case when abs(r.date_used - r.do_modifydate) = 19 then 1 else 0 end d19,
    case when abs(r.date_used - r.do_modifydate) = 20 then 1 else 0 end d20,
    case when abs(r.date_used - r.do_modifydate) = 21 then 1 else 0 end d21,
    case when abs(r.date_used - r.do_modifydate) = 22 then 1 else 0 end d22,
    case when abs(r.date_used - r.do_modifydate) = 23 then 1 else 0 end d23,
    case when abs(r.date_used - r.do_modifydate) = 24 then 1 else 0 end d24,
    case when abs(r.date_used - r.do_modifydate) = 25 then 1 else 0 end d25,
    case when abs(r.date_used - r.do_modifydate) = 26 then 1 else 0 end d26,
    case when abs(r.date_used - r.do_modifydate) = 27 then 1 else 0 end d27,
    case when abs(r.date_used - r.do_modifydate) = 28 then 1 else 0 end d28,
    case when abs(r.date_used - r.do_modifydate) = 29 then 1 else 0 end d29,
    case when abs(r.date_used - r.do_modifydate) = 30 then 1 else 0 end d30,
    case when abs(r.date_used - r.do_modifydate) = 31 then 1 else 0 end d31,
    case when abs(r.date_used - r.do_modifydate) = 32 then 1 else 0 end d32,
    case when abs(r.date_used - r.do_modifydate) = 33 then 1 else 0 end d33,
    case when abs(r.date_used - r.do_modifydate) = 34 then 1 else 0 end d34,
    case when abs(r.date_used - r.do_modifydate) = 35 then 1 else 0 end d35,
    case when abs(r.date_used - r.do_modifydate) = 36 then 1 else 0 end d36,
    case when abs(r.date_used - r.do_modifydate) = 37 then 1 else 0 end d37,
    case when abs(r.date_used - r.do_modifydate) = 38 then 1 else 0 end d38,
    case when abs(r.date_used - r.do_modifydate) = 39 then 1 else 0 end d39,
    case when abs(r.date_used - r.do_modifydate) = 40 then 1 else 0 end d40,
    case when abs(r.date_used - r.do_modifydate) = 41 then 1 else 0 end d41,
    case when abs(r.date_used - r.do_modifydate) = 42 then 1 else 0 end d42,
    case when abs(r.date_used - r.do_modifydate) = 43 then 1 else 0 end d43,
    case when abs(r.date_used - r.do_modifydate) = 44 then 1 else 0 end d44,
    case when abs(r.date_used - r.do_modifydate) = 45 then 1 else 0 end d45,
    case when abs(r.date_used - r.do_modifydate) = 46 then 1 else 0 end d46,
    case when abs(r.date_used - r.do_modifydate) = 47 then 1 else 0 end d47,
    case when abs(r.date_used - r.do_modifydate) = 48 then 1 else 0 end d48,
    case when abs(r.date_used - r.do_modifydate) = 49 then 1 else 0 end d49,
    case when abs(r.date_used - r.do_modifydate) = 50 then 1 else 0 end d50,
    case when abs(r.date_used - r.do_modifydate) = 51 then 1 else 0 end d51,
     case when abs(r.date_used - r.do_modifydate) = 52 then 1 else 0 end d52,
    case when abs(r.date_used - r.do_modifydate) = 53 then 1 else 0 end d53,
     case when abs(r.date_used - r.do_modifydate) = 54 then 1 else 0 end d54,
    case when abs(r.date_used - r.do_modifydate) = 55 then 1 else 0 end d55,
     case when abs(r.date_used - r.do_modifydate) = 56 then 1 else 0 end d56,
    case when abs(r.date_used - r.do_modifydate) = 57 then 1 else 0 end d57,
     case when abs(r.date_used - r.do_modifydate) = 58 then 1 else 0 end d58,
     case when abs(r.date_used - r.do_modifydate) = 59 then 1 else 0 end d59,
    case when abs(r.date_used - r.do_modifydate) = 60 then 1 else 0 end d60,
     case when abs(r.date_used - r.do_modifydate) = 61 then 1 else 0 end d61,
    case when abs(r.date_used - r.do_modifydate) = 62 then 1 else 0 end d62,
    case when abs(r.date_used - r.do_modifydate) = 63 then 1 else 0 end d63,
    case when abs(r.date_used - r.do_modifydate) = 64 then 1 else 0 end d64,
    case when abs(r.date_used - r.do_modifydate) = 65 then 1 else 0 end d65,
     case when abs(r.date_used - r.do_modifydate) = 66 then 1 else 0 end d66,
    case when abs(r.date_used - r.do_modifydate) = 67 then 1 else 0 end d67,
     case when abs(r.date_used - r.do_modifydate) = 68 then 1 else 0 end d68,
     case when abs(r.date_used - r.do_modifydate) = 69 then 1 else 0 end d69,
    case when abs(r.date_used - r.do_modifydate) = 70 then 1 else 0 end d70
    
from raw_data r
left join
    (
        select
            geo,
            so_id,
            date_used + interval '1 days' week_used_1_start,
            date_used + interval '7 days' week_used_1_end,
            date_used + interval '8 days' week_used_2_start,
            date_used + interval '14 days'  week_used_2_end,
            date_used + interval '15 days' week_used_3_start,
            date_used + interval '21 days' week_used_3_end,
            date_used + interval '22 days' week_used_4_start,
            date_used + interval '28 days' week_used_4_end,
            date_used + interval '29 days' week_used_5_start,
            date_used + interval '35 days' week_used_5_end,
            date_used + interval '36 days' week_used_6_start,
            date_used + interval '42 days' week_used_6_end,
            date_used + interval '43 days' week_used_7_start,
            date_used + interval '49 days' week_used_7_end,
            date_used + interval '50 days' week_used_8_start,
            date_used + interval '56 days' week_used_8_end,
            date_used + interval '57 days' week_used_9_start,
            date_used + interval '63 days' week_used_9_end,
            date_used + interval '64 days' week_used_10_start,
            date_used + interval '70 days' week_used_10_end
        from raw_data
    ) w1
    on w1.so_id = r.so_id
    and w1.geo = r.geo
where date_used >= '2024-01-01'