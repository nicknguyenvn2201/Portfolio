-- dareport.mv_keitaro_cis source

CREATE MATERIALIZED VIEW dareport.mv_keitaro_cis
TABLESPACE pg_default
AS WITH cte_keitaro_raw AS (
         SELECT fkd.campaign,
                CASE
                    WHEN fkd.campaign ~~* '%test%'::text THEN 'Test'::text
                    WHEN fkd.campaign ~~* '%scale%'::text THEN 'Scale'::text
                    ELSE NULL::text
                END AS campaign_type,
            fkd.campaign_group,
            replace(split_part(fkd.campaign, '_'::text, 1), ' '::text, ''::text) AS mb_buyer,
            (replace(split_part(fkd.campaign, '_'::text, 2), ' '::text, ''::text) || '_'::text) || replace(split_part(fkd.campaign, '_'::text, 3), ' '::text, ''::text) AS offer,
            upper("left"(replace(split_part(fkd.campaign, '-'::text, 3), ' '::text, ''::text), 2)) AS geo,
            fkd.device_model,
            fkd.sub_id_2 AS campaign_group_id,
            fkd.sub_id_3 AS ad_sets,
            fkd.sub_id_4 AS ads,
            fkd.ad_campaign_id,
            fkd.sub_id_7 AS mb_content,
            fkd.datetime AS createdate,
                CASE
                    WHEN fkd.datetime = '2023-12-31'::date THEN 1::double precision
                    ELSE date_part('week'::text, fkd.datetime + '1 day'::interval)
                END AS lead_week,
                CASE
                    WHEN fkd.datetime = '2023-12-31'::date THEN 1::double precision
                    ELSE date_part('month'::text, fkd.datetime)
                END AS lead_month,
                CASE
                    WHEN fkd.datetime = '2023-12-31'::date THEN 2024::double precision
                    ELSE date_part('year'::text, fkd.datetime)
                END AS lead_year,
            fkd.campaign_id,
            fkd.conversions AS leads,
            fkd.sales AS approved,
            fkd.revenue,
            fkd.sale_revenue,
            fkd.cost,
            fkd.sub_id
           FROM ( SELECT fact_keitaro_data.campaign,
                    fact_keitaro_data.campaign_group,
                    fact_keitaro_data.device_model,
                    fact_keitaro_data.sub_id,
                    fact_keitaro_data.sub_id_2,
                    fact_keitaro_data.sub_id_3,
                    fact_keitaro_data.sub_id_4,
                    fact_keitaro_data.ad_campaign_id,
                    fact_keitaro_data.sub_id_7,
                    fact_keitaro_data.datetime,
                    fact_keitaro_data.campaign_id,
                    fact_keitaro_data.conversions,
                    fact_keitaro_data.sales,
                    fact_keitaro_data.revenue,
                    fact_keitaro_data.sale_revenue,
                    fact_keitaro_data.cost
                   FROM fact_keitaro_data_cis fact_keitaro_data) fkd
        ), cte_ar_mrps AS (
         SELECT ar_mrps.affiliate_id AS network,
            ar_mrps.offer_id AS product_name,
                CASE
                    WHEN lower(ar_mrps.sub_id) = '*'::text THEN ''::text
                    WHEN lower(ar_mrps.sub_id) = ''::text THEN 'blank'::text
                    ELSE ar_mrps.sub_id
                END AS sub_id,
            ar_mrps.ar_mrp,
            ar_mrps.applied_from_date::date AS started_date,
            ar_mrps.applied_to_date::date AS ending_date,
                CASE
                    WHEN lower(ar_mrps.sub_id) = '*'::text THEN concat(ar_mrps.affiliate_id, '_', ar_mrps.offer_id)
                    WHEN lower(ar_mrps.sub_id) = ''::text THEN concat(ar_mrps.affiliate_id, '_', 'blank', '_', ar_mrps.offer_id)
                    ELSE concat(ar_mrps.affiliate_id, '_', ar_mrps.sub_id, '_', ar_mrps.offer_id)
                END AS target_key
           FROM ar_mrps
        ), cte_raw_final AS (
         SELECT rank() OVER (PARTITION BY r.sub_id ORDER BY d.lead_id, d.geo, bfac.transaction_id) AS sub_id_rank,
            d.postback_status,
                CASE
                    WHEN d.postback_status::text ~~ '%pending%'::text THEN 'pending'::character varying
                    ELSE d.postback_status
                END AS adjusted_postback_status,
            bfac.conversion_status,
            d.leadid_geo,
            d.tms_phone,
            r.campaign,
            r.campaign_type,
            r.campaign_group,
            r.mb_buyer,
            r.offer,
            r.geo,
            r.device_model,
            r.campaign_group_id,
            r.ad_sets,
            r.ads,
            r.ad_campaign_id,
            r.mb_content,
            r.createdate,
            r.lead_week,
            r.lead_month,
            r.lead_year,
            r.campaign_id,
            r.leads,
            r.approved,
            r.revenue,
            r.sale_revenue,
            r.cost,
            r.sub_id,
            d.subid1 AS subid1_cf,
            d.affiliate_id,
            d.prod_name,
            d.lead_id,
            bfac.aff_click_id,
            d.click_id::text AS click_id,
            bfac.transaction_id,
            cc.name AS sale_campaign,
            COALESCE(am.ar_mrp, am_2.ar_mrp) AS ar_target_mrp
           FROM ( SELECT cte_keitaro_raw.campaign,
                    cte_keitaro_raw.campaign_type,
                    cte_keitaro_raw.campaign_group,
                    cte_keitaro_raw.mb_buyer,
                    cte_keitaro_raw.offer,
                    cte_keitaro_raw.geo,
                    cte_keitaro_raw.device_model,
                    cte_keitaro_raw.campaign_group_id,
                    cte_keitaro_raw.ad_sets,
                    cte_keitaro_raw.ads,
                    cte_keitaro_raw.ad_campaign_id,
                    cte_keitaro_raw.mb_content,
                    cte_keitaro_raw.createdate,
                    cte_keitaro_raw.lead_week,
                    cte_keitaro_raw.lead_month,
                    cte_keitaro_raw.lead_year,
                    cte_keitaro_raw.campaign_id,
                    cte_keitaro_raw.leads,
                    cte_keitaro_raw.approved,
                    cte_keitaro_raw.revenue,
                    cte_keitaro_raw.sale_revenue,
                    cte_keitaro_raw.cost,
                    cte_keitaro_raw.sub_id
                   FROM cte_keitaro_raw) r
             LEFT JOIN ( SELECT base_fact__affscale_conversion.revenue,
                    base_fact__affscale_conversion.payout,
                    base_fact__affscale_conversion.added_timestamp,
                    base_fact__affscale_conversion.aff_click_id,
                    base_fact__affscale_conversion.profit,
                    base_fact__affscale_conversion.changed_timestamp,
                    base_fact__affscale_conversion.currency,
                    base_fact__affscale_conversion.conversion_status,
                    base_fact__affscale_conversion.sub_id1,
                    base_fact__affscale_conversion.sub_id2,
                    base_fact__affscale_conversion.transaction_id,
                    base_fact__affscale_conversion.sub_id3,
                    base_fact__affscale_conversion.sub_id4,
                    base_fact__affscale_conversion.sub_id5,
                    base_fact__affscale_conversion.advertiser_user_id,
                    base_fact__affscale_conversion."affiliate.id",
                    base_fact__affscale_conversion."affiliate.value",
                    base_fact__affscale_conversion."paid_to_affiliate.id",
                    base_fact__affscale_conversion."paid_to_affiliate.value",
                    base_fact__affscale_conversion."offer.id",
                    base_fact__affscale_conversion."offer.value",
                    base_fact__affscale_conversion."affiliate_invoice.id",
                    base_fact__affscale_conversion."affiliate_invoice.value"
                   FROM base_fact__affscale_conversion) bfac ON r.sub_id = bfac.aff_click_id
             LEFT JOIN ( SELECT cl_fresh.click_id,
                    cl_fresh.subid1,
                    cl_fresh.affiliate_id,
                    cl_fresh.prod_name,
                    cl_fresh.createdate::date AS createdate_cf,
                    cl_fresh.cp_id,
                    cl_fresh.lead_id,
                    cl_fresh.geo,
                    cl_fresh.postback_status,
                    concat(cl_fresh.lead_id::text, '_', cl_fresh.geo) AS leadid_geo,
                    cl_fresh.phone AS tms_phone
                   FROM cl_fresh
                  WHERE cl_fresh.createdate::date >= '2023-11-22'::date AND cl_fresh.lead_type::text = 'A'::text AND cl_fresh.affiliate_id::text = 'LSK'::text AND lower(cl_fresh.name::text) !~~ '%test%'::text AND
                        CASE
                            WHEN cl_fresh.lead_status = 4 OR cl_fresh.lead_status = 5 AND cl_fresh.assigned = 0 THEN 1
                            ELSE 0
                        END <> 1) d ON bfac.transaction_id = d.click_id::text
             LEFT JOIN cp_campaign cc ON d.cp_id = cc.cp_id AND d.geo::text = cc.geo::text
             LEFT JOIN cte_ar_mrps am ON
                CASE
                    WHEN d.subid1::text = ''::text THEN concat(d.affiliate_id, '_', 'blank', '_', d.prod_name)
                    ELSE concat(d.affiliate_id, '_', d.subid1, '_', d.prod_name)
                END = am.target_key AND d.createdate_cf >= am.started_date AND d.createdate_cf <= am.ending_date
             LEFT JOIN cte_ar_mrps am_2 ON concat(d.affiliate_id, '_', d.prod_name) = am_2.target_key AND d.createdate_cf >= am_2.started_date AND d.createdate_cf <= am_2.ending_date
        ), cte_prod_mapping AS (
         SELECT cte_raw_final.offer,
            cte_raw_final.geo,
            cte_raw_final.prod_name AS prod_name_cf,
            cte_raw_final.affiliate_id AS affiliate_id_cf,
            rank() OVER (PARTITION BY cte_raw_final.offer ORDER BY (count(DISTINCT cte_raw_final.leadid_geo)) DESC) AS offer_rank
           FROM cte_raw_final
          WHERE cte_raw_final.offer IS NOT NULL AND cte_raw_final.prod_name IS NOT NULL
          GROUP BY cte_raw_final.offer, cte_raw_final.geo, cte_raw_final.prod_name, cte_raw_final.affiliate_id
        ), cte_prod_mapping_final AS (
         SELECT cte_prod_mapping.offer,
            cte_prod_mapping.geo,
            cte_prod_mapping.prod_name_cf,
            cte_prod_mapping.affiliate_id_cf
           FROM cte_prod_mapping
          WHERE cte_prod_mapping.offer_rank = 1
        ), cte_final AS (
         SELECT f.sub_id_rank,
            f.postback_status,
            f.adjusted_postback_status,
            f.conversion_status,
            f.campaign,
            f.campaign_type,
            f.campaign_group,
            f.mb_buyer,
            f.geo,
            f.device_model,
            f.campaign_group_id,
            f.ad_sets,
            f.ads,
            f.ad_campaign_id,
            f.mb_content,
            f.ar_target_mrp,
            f.createdate,
            f.lead_week,
            f.lead_month,
            f.lead_year,
                CASE
                    WHEN f.createdate = '2022-01-01'::date THEN 'W52-2021'::text
                    ELSE (('W'::text || f.lead_week) || '-'::text) || f.lead_year
                END AS "Week",
            (f.lead_month || '-'::text) || f.lead_year AS "Month",
                CASE
                    WHEN f.lead_week < 10::double precision THEN (f.lead_year::text || '0'::text) || f.lead_week::text
                    ELSE f.lead_year::text || f.lead_week::text
                END AS lead_week_year,
                CASE
                    WHEN f.lead_month < 10::double precision THEN (f.lead_year::text || '0'::text) || f.lead_month::text
                    ELSE f.lead_year::text || f.lead_month::text
                END AS lead_month_year,
            f.campaign_id,
            f.leadid_geo,
            f.tms_phone,
                CASE
                    WHEN f.lead_id IS NULL AND (f.geo <> ALL (ARRAY['IN'::text, 'NG'::text])) THEN 0::bigint
                    ELSE f.leads
                END AS leads,
                CASE
                    WHEN f.lead_id IS NULL AND (f.geo <> ALL (ARRAY['IN'::text, 'NG'::text])) THEN 0::bigint
                    ELSE f.approved
                END AS approved,
            f.revenue,
            f.sale_revenue,
            f.cost,
            f.sub_id,
            f.offer,
            f.prod_name
           FROM cte_raw_final f
             LEFT JOIN cte_prod_mapping_final m ON m.offer = f.offer
          WHERE f.sub_id_rank = 1
        ), cte_final_f AS (
         SELECT cte_final.adjusted_postback_status,
            cte_final.campaign,
            cte_final.campaign_type,
            cte_final.campaign_group,
            cte_final.mb_buyer,
            cte_final.geo,
            cte_final.device_model,
            cte_final.campaign_group_id,
            cte_final.ad_sets,
            cte_final.ads,
            cte_final.mb_content,
            avg(cte_final.ar_target_mrp) AS ar_target_mrp,
            cte_final.createdate,
            cte_final.lead_week,
            cte_final.lead_month,
            cte_final.lead_year,
            cte_final."Week",
            cte_final."Month",
            cte_final.lead_week_year,
            cte_final.lead_month_year,
            cte_final.campaign_id,
            sum(cte_final.leads) AS leads,
            sum(cte_final.leads::numeric * cte_final.ar_target_mrp) AS approved_mrp,
            sum(cte_final.approved) AS approved,
            sum(cte_final.revenue) AS revenue,
            sum(cte_final.sale_revenue) AS sale_revenue,
            sum(cte_final.cost) AS cost,
            cte_final.offer,
            cte_final.prod_name
           FROM cte_final
          GROUP BY cte_final.adjusted_postback_status, cte_final.campaign, cte_final.campaign_type, cte_final.campaign_group, cte_final.mb_buyer, cte_final.geo, cte_final.device_model, cte_final.campaign_group_id, cte_final.ad_sets, cte_final.ads, cte_final.mb_content, cte_final.createdate, cte_final.lead_week, cte_final.lead_month, cte_final.lead_year, cte_final."Week", cte_final."Month", cte_final.lead_week_year, cte_final.lead_month_year, cte_final.campaign_id, cte_final.offer, cte_final.prod_name
        )
 SELECT cte_final_f.adjusted_postback_status,
    cte_final_f.campaign,
    cte_final_f.campaign_type,
    cte_final_f.campaign_group,
    cte_final_f.mb_buyer,
    cte_final_f.geo,
    cte_final_f.device_model,
    cte_final_f.campaign_group_id,
    cte_final_f.ad_sets,
    cte_final_f.ads,
    cte_final_f.mb_content,
    cte_final_f.ar_target_mrp,
    cte_final_f.createdate,
    cte_final_f.lead_week,
    cte_final_f.lead_month,
    cte_final_f.lead_year,
    cte_final_f."Week",
    cte_final_f."Month",
    cte_final_f.lead_week_year,
    cte_final_f.lead_month_year,
    cte_final_f.campaign_id,
    cte_final_f.leads,
    cte_final_f.approved_mrp,
    cte_final_f.approved,
    cte_final_f.revenue,
    cte_final_f.sale_revenue,
    cte_final_f.cost,
    cte_final_f.offer,
    cte_final_f.prod_name,
    NULL::text AS leadid_geo
   FROM cte_final_f
  WHERE cte_final_f.leads <> 0::numeric OR cte_final_f.revenue <> 0::double precision OR cte_final_f.cost <> 0::double precision
WITH DATA;
