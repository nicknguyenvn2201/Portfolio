select country_code,geo, assigned, min(lead_modify_date)::date on_board_date
from data_master_raw
group by 1,2,3
