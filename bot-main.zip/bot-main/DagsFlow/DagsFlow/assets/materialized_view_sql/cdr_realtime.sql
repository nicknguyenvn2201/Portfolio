select geo,createtime,
duration, 
user_id,
lead_id
from cdr 
where createtime >= current_date
