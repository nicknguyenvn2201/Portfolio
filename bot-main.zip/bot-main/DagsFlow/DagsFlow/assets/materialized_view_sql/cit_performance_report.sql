WITH a AS (   --PH
  SELECT 
    distinct
    geo,
    case when geo ^@ 'PH' then 'PH' end as country_code,
    user_name,
    SUBSTRING(user_name FROM 1 FOR POSITION('@' IN user_name) - 1) abc,
    SUBSTRING(
      SUBSTRING(user_name FROM 1 FOR POSITION('@' IN user_name) - 1),
      2,
      LENGTH(SUBSTRING(user_name FROM 2 FOR POSITION('@' IN user_name) - 1)) - 1
    ) AS value
  FROM or_user
  WHERE user_type = 'agent'
    AND (user_name LIKE 'a%' OR user_name LIKE 'r%')
    AND (geo ^@ 'PH')
)
, b as 
(
select
 country_code,
 value,
 count(distinct abc) total_users
from a
group by country_code,value
) 
,c as 
(
select
 distinct
  a.country_code,
  a.user_name,
  a.value,
  a.abc,
  case WHEN b.total_users > 1 THEN 'Fresh' ELSE 'CIT' END AS team
FROM a
JOIN b
on a.value = b.value
and a.country_code = b.country_code
)
,d as 
(
 select 
   country_code,
   user_name,
   team
 from c
)
,e as -- TH
( 
 SELECT 
   tm.geo,
   case when tm.geo ^@ 'TH' then 'TH' end as country_code,
   ou.user_name,
   case when ot.manager_id in (2002,2016,2182,1000156) then 'CIT' else 'Fresh' end team
FROM or_team_member tm
 LEFT JOIN or_user ou ON ou.user_id = tm.user_id AND ou.geo::text = tm.geo::text
 LEFT JOIN or_team ot ON ot.id = tm.team_id AND ot.geo::text = tm.geo::text
WHERE tm.geo ^@ 'TH'
)
, f as
(
 select 
  country_code,
  user_name,
  team
 from e
)
, g as -- VN ID MY
(
select
 case 
   when geo ^@ 'VN' then 'VN'
   when geo ^@ 'ID' then 'ID'
   when geo ^@ 'MY' then 'MY'
  end country_code,
  user_name,
  case 
    when geo ^@ 'VN' then
	 case 
	   when user_name LIKE '%cit%' THEN 'CIT' 
	   else 'Fresh' 
	 end
	when geo ^@ 'ID' then
	 case 
	   when user_name LIKE '%bk%' THEN 'Fresh'
	   else 'CIT' 
	 end
	when geo ^@ 'MY' then
	 case 
	   when user_name LIKE 'r%' THEN 'CIT'
	   else 'Fresh' 
	 end
	ELSE 'Others'
 END AS team
 from or_user
 where (geo ^@ 'VN' or geo ^@ 'ID' or geo ^@ 'MY')
)
,h as
(
 select
  country_code,
  user_name,
  team
 from g
 )
, team as 
(select * from d 
   union 
 select * from f
   union
 select * from h
 )
,i as
(
select  
  so_date,
  to_char(so_date,'yyyy-mm-dd') date,
  to_char(so_date, 'Dy') day_name,
  to_char(so_date, 'YYYY-WW'::text) week_year,
  to_char(so_date,'yyyy-mm') month_year,
  to_char(so_date, 'yyyy-q') AS quarter_year,
  to_char(so_date, 'yyyy') AS year,
  case 
	  when geo ^@ 'TH' then 'TH'
	  when geo ^@ 'VN' then 'VN'
	  when geo ^@ 'ID' then 'ID'
	  when geo ^@ 'MY' then 'MY'
	  else 'PH'
   end country_code,
   agname, 
   validated,
   so_amount as validated_revenue,
   delivered,
   delivered_amount delivered_revenue,
   case 
	  when geo ^@ 'TH' then '0.07'
	  when geo ^@ 'VN' then '0.08'
	  when geo ^@ 'ID' then '0.11'
	  when geo ^@ 'MY' then '0'
	  else 0.12
   end tax_rate,
   case 
	  when (geo ^@ 'TH' or geo ^@ 'VN' or geo ^@ 'ID') then 30
	  when geo ^@ 'MY' then 20
	  else 5
   end min_order,
   lead_type
from v_sale_master 
where so_date >= '2023-01-01' and lead_type = 'M'
)
select 
  a.so_date,
  a.date,
  a.day_name,
  a.month_year,
  a.week_year,
  a.quarter_year,
  a.year,
  a.country_code,
  a.agname,
  a.validated,
  a.validated_revenue,
  a.delivered,
  a.delivered_revenue,
  a.tax_rate,
  a.min_order,
  a.lead_type,
  c.team,
  b.exchange,
  SUM(a.validated) over (partition by a.so_date,a.country_code) geo_validated,
  d.public_holiday
from (select * from i) a 
left join dim_exchange_rate b on a.country_code = b.geo and a.so_date >= b.started_date and a.so_date <= b.ending_date
join team c on a.agname = c.user_name and a.country_code = c.country_code
left join dim_cit_performance d on a.country_code = d.geo and a.so_date = d.public_holiday