select *
from od_sale_order
where createdate >= current_date - 6
