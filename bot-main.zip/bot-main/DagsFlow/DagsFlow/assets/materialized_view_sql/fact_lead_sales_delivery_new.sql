with
    __dbt__cte__stg_fact__lead as (
        with
            source as (select * from "base_layer"."cl_fresh"),
            filter_base_rule as (
                select *
                from source as base
                where
                    not (
                        lead_status = 4  -- duplicated
                        or (lead_status = 5 and assigned = 0)  -- trash AND not assigned to any agent yet (auto trash)
                    )
                    and lower("name") not like '%test%'  -- < need to re-check this rule
                    -- and lower(prod_name) not like 'test' <- this is a main
                    -- dimension and
                    -- will be fitler out later by users
                    and geo is not null  -- this is a bug, might be removed later
                    and not (geo = 'ID' and org_id = 4)
            )
        select *
        from filter_base_rule
    ),
    __dbt__cte__stg_dim__campaign as (
        with
            campaign as (select * from "base_layer"."cp_campaign"),
            campaign_status as (
                select *
                from "base_layer"."cf_synonym"
                where "type" = 'campaign status'
            ),
            campaign_category as (
                select *
                from "base_layer"."cf_synonym"
                where "type" = 'campaign categories'
            ),
            denorm_with_status as (
                select
                    campaign.geo as geo,
                    campaign.org_id as org_id,
                    campaign.cp_id,
                    campaign.name as campaign_name,
                    campaign_status.name as campaign_status,
                    campaign_category.name as campaign_category
                from campaign
                inner join
                    campaign_status
                    on campaign.geo = campaign_status.geo
                    and campaign."status" = campaign_status.value
                inner join
                    campaign_category
                    on campaign.geo = campaign_category.geo
                    and campaign.cp_cat = campaign_category.value
            )
        select *
        from denorm_with_status
    ),
    __dbt__cte__stg_dim__agent as (
        select *
        from "base_layer"."or_user"
        where "user_type" in ('agent', 'system')
    ),
    __dbt__cte__base_fact__lead as (
        with
            staging as (select * from __dbt__cte__stg_fact__lead),
            clean_data as (
                select
                    case
                        when lower(prod_name) like '%vip%'
                        then cp_id
                        when lower(prod_name) like '%prosta%id'
                        then 472  -- Fresh HC
                        when lower(prod_name) like '%duramax%th'
                        then 567  -- Fresh ME
                        else cp_id
                    end cp_id_fixed,
                    case
                        when
                            (
                                affiliate_id in (
                                    'EW',
                                    'AT',
                                    'ADT',
                                    'ABT',
                                    'ARB',
                                    'CSL',
                                    'MKR',
                                    'XXX',
                                    'PFC',
                                    'ORG',
                                    'ORG2',
                                    'PIB',
                                    'MH',
                                    'MP',
                                    'IGO',
                                    'VIC',
                                    'ODS',
                                    'DAT',
                                    'VAL',
                                    'MIR',
                                    'NGN',
                                    'WIL',
                                    'PD',
                                    'CTR',
                                    'U_DOMA',
                                    'ABG'
                                )
                            )
                            or affiliate_id = 'U_RUS'
                            and geo = 'TH'
                            or subid1 is null
                        then 'No PubID'
                        when subid1 = ''
                        then 'blank'
                        else subid1
                    end as subid1_fixed,
                    base.*
                from staging as base
            ),
            lead as (select * from clean_data),
            lead_status as (
                select *
                from "base_layer"."cf_synonym"
                where "type" = 'lead status'
            ),
            denorm_with_status as (
                select lead_status.name as lead_status_value, lead.*
                from lead
                inner join
                    lead_status
                    on lead.geo = lead_status.geo
                    and lead.lead_status = lead_status.value
            ),
            denorm_with_campaign as (
                select campaign_name, campaign_status, campaign_category, lead.*
                from denorm_with_status as lead
                left join
                    __dbt__cte__stg_dim__campaign cp
                    on lead.org_id = cp.org_id
                    and lead.cp_id_fixed = cp.cp_id
            ),
            denorm_with_address as (
                select
                    province.name as customer_address_province,
                    district.name as customer_address_district,
                    subdistrict.name as customer_address_subdistrict,
                    lead.*
                from denorm_with_campaign as lead
                left join
                    "base_layer"."lc_province" province
                    on lead.geo = province.geo
                    and lead.province::bigint = province.prv_id
                left join
                    "base_layer"."lc_district" district
                    on lead.geo = district.geo
                    and lead.district::bigint = district.dt_id
                left join
                    "base_layer"."lc_subdistrict" subdistrict
                    on lead.geo = subdistrict.geo
                    and lead.subdistrict::bigint = subdistrict.sdt_id
            ),
            enrich_fresh_lead as (
                select
                    case
                        when fresh_lead_id is not null or fresh_lead_id <> 0
                        then fresh_lead_id
                        else null
                    end as lead_fresh_id,
                    case
                        when fresh_org_id is not null or fresh_org_id <> 0
                        then geos.geo
                        else null
                    end as lead_fresh_geo,
                    lead.*
                from denorm_with_address as lead
                left join
                    "tms_central"."dareport"."dim_geo_org_id" geos
                    on lead.fresh_org_id = geos.org_id
            ),
            denorm_with_agent_name as (
                select dim_agent.user_name as agent_name, lead.*
                from enrich_fresh_lead as lead
                left join
                    __dbt__cte__stg_dim__agent as dim_agent
                    on lead.geo = dim_agent.geo
                    and lead.assigned = dim_agent.user_id
            )
        select
            geo as geo,
            lead_id,
            agent_name,
            "address" as customer_address,
            "name" as customer_name,
            customer_address_province,
            customer_address_district,
            customer_address_subdistrict,
            prod_name as lead_product_name,
            lead_status_value as lead_status,
            lead_type,
            createdate as lead_date,
            modifydate as lead_modifydate,
            affiliate_id as network,
            campaign_name,
            campaign_status,
            campaign_category,
            click_id,
            postback_status,
            postback_date as postback_time,
            subid1_fixed as pub,
            lead_fresh_id,
            lead_fresh_geo,
            updated_at as source_update_time
        from denorm_with_agent_name as lead
    ),
    __dbt__cte__base_fact__lead_with_payout as (
        with
            leads as (select * from __dbt__cte__base_fact__lead),
            payouts as (
                select *
                from "tms_central"."dareport"."fct_affscale_network_conversion"
                where conversion_status = 'Approved'
            ),
            join_with_payout as (
                select leads.*, payouts.revenue as max_po, payouts.payout as payout
                from leads
                left join payouts on leads.click_id = payouts.transaction_id
            )
        select *
        from join_with_payout
    ),
    __dbt__cte__stg_fact__sales as (
        with
            source as (select * from "base_layer"."od_sale_order"),
            filter_status as (
                select * from source where status <> 46  -- 46 is unassigned
            )
        select *
        from filter_status
    ),
    __dbt__cte__base_fact__sales as (
        with
            staging as (select * from __dbt__cte__stg_fact__sales),
            sales_status as (
                select *
                from "base_layer"."cf_synonym"
                where "type" = 'sale order status'
            ),
            payment_status as (
                select *
                from "base_layer"."cf_synonym"
                where "type" = 'payment mothod'
            ),
            denorm_with_status as (
                select
                    sales_status.name as sales_status_value,
                    payment_status.name as payment_method_value,
                    sales.*
                from staging as sales
                inner join
                    sales_status
                    on sales.geo = sales_status.geo
                    and sales."status" = sales_status.value
                inner join
                    payment_status
                    on sales.geo = payment_status.geo
                    and sales.payment_method = payment_status.value
            )
        select
            sales.geo as geo,
            sales.lead_id,
            sales.so_id,
            payment_method_value as payment_method,
            sales.amount as sales_amount,
            sales_status_value as so_status,
            sales.createdate as so_date,
            sales.modifydate as so_modifydate,
            updated_at as source_update_time
        from denorm_with_status as sales
    ),
    __dbt__cte__stg_fact__delivery as (
        with
            remove_null_geo as (
                select * from "base_layer"."od_do_new" where geo is not null
            ),
            remove_invalid_status as (
                select * from remove_null_geo where "status" <> 44  
            )
        select *
        from remove_invalid_status
    ),
    __dbt__cte__base_fact__delivery as (
        with delivery as (select * from __dbt__cte__stg_fact__delivery),
            warehouse as (select * from "base_layer"."bp_warehouse"),
            carrier as (select * from "base_layer"."bp_partner"),
            delivery_status as (
                select *
                from "base_layer"."cf_synonym"
                where "type" = 'delivery order status'
            ),
            delivery_timestamp as (
                select * from "base_layer"."od_do_status_timestamp"
            ),
            denorm_with_status as (
                select delivery_status.name as delivery_status, delivery.*
                from delivery
                inner join
                    delivery_status
                    on delivery.geo = delivery_status.geo
                    and delivery."status" = delivery_status.value
            ),
            denorm_with_warehouse as (
                select warehouse.warehouse_shortname as delivery_warehouse, delivery.*
                from denorm_with_status delivery
                left join
                    warehouse
                    on delivery.geo = warehouse.geo
                    and delivery.warehouse_id = warehouse.warehouse_id
            ),
            denorm_with_carrier as (
                select carrier.shortname as delivery_carrier, delivery.*
                from denorm_with_warehouse delivery
                left join
                    carrier
                    on carrier.geo = delivery.geo
                    and carrier.pn_id = delivery.carrier_id
            ),
            denorm_with_timestamp as (
                select
                    delivery_timestamp.delivered_time as delivery_delivered_time,
                    delivery.*
                from denorm_with_carrier delivery
                left join
                    delivery_timestamp
                    on delivery_timestamp.org_id = delivery.org_id
                    and delivery_timestamp.do_id = delivery.do_id
            )
        select
            geo as geo,
            so_id,
            do_id,
            do_code,
            package_name as product_cross_sell,
            ffm_code as delivery_ffm_code,
            tracking_code as delivery_tracking_code,
            delivery_warehouse,
            delivery_carrier,
            delivery_status as do_status,
            createdate as do_date,
            updatedate as do_modifydate,
            delivery_delivered_time as delivery_delivered_time,
            updated_at as source_update_time
        from denorm_with_timestamp
    ),
    lead as (select * from __dbt__cte__base_fact__lead_with_payout),
    sales as (select * from __dbt__cte__base_fact__sales),
    delivery as (select * from __dbt__cte__base_fact__delivery),
    combine_fact as (
        select
            lead.geo as geo,
            lead.lead_id,
            sales.so_id,
            delivery.do_id,
            lead.agent_name,
            customer_name,
            customer_address,
            customer_address_province,
            customer_address_district,
            customer_address_subdistrict,
            payment_method,
            sales_amount,
            lead_product_name,
            product_cross_sell,
            delivery.do_code,
            delivery_ffm_code,
            delivery_tracking_code,
            delivery_warehouse,
            delivery_carrier,
            lead_status,
            so_status,
            do_status,
            lead.lead_type,
            payout,
            max_po,
            lead_date,
            lead_modifydate,
            so_date,
            so_modifydate,
            do_date,
            do_modifydate,
            delivery_delivered_time,
            network,
            campaign_name,
            campaign_status,
            campaign_category,
            click_id,
            postback_status,
            postback_time,
            pub,
            lead_fresh_id,
            lead_fresh_geo,
            greatest(
                lead.source_update_time,
                sales.source_update_time,
                delivery.source_update_time
            ) as source_update_time
        from lead
        left join sales on lead.geo = sales.geo and lead.lead_id = sales.lead_id
        left join delivery on sales.geo = delivery.geo and sales.so_id = delivery.so_id
    )
select *
from combine_fact
