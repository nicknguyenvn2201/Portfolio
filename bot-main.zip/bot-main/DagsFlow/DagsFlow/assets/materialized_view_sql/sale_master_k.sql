WITH rejected_list AS (
         SELECT "right"(cl.phone::text, 9) AS short_phone,
            1 AS isrf,
            oso.amount AS rfamount,
            cl.geo
           FROM cl_fresh cl
             LEFT JOIN od_sale_order oso ON cl.lead_id = oso.lead_id AND cl.geo::text = oso.geo::text
          WHERE lower(cl.name::text) ~~ '%(rj)%'::text AND cl.org_id = 4 AND cl.lead_type::text = 'M'::text AND cl.lead_status = 2 AND (oso.status = ANY (ARRAY[43, 357])) AND (lower(cl.agc_code::text) IS NULL OR lower(cl.agc_code::text)::character varying::text = ''::text OR lower(cl.agc_code::text) ~~ '%rj%'::text) AND cl.createdate >= '2022-01-01 00:00:00'::timestamp without time zone
        ), cte_raw AS (
         SELECT d.geo,
            d.country_code,
            q.name AS cpname,
            p.user_name AS agname,
            d.assigned,
            d.prod_name,
            d.agc_code,
            d.islockdown,
            d.isrocket,
                CASE
                    WHEN d.prod_name IS NULL THEN 'No offer'::character varying
                    ELSE d.prod_name
                END AS offer,
            COALESCE(
                CASE
                    WHEN COALESCE(bp.shortname, d.agc_code)::text = ANY (ARRAY['AFS'::character varying::text, 'OFP'::character varying::text]) THEN d.affiliate_id
                    ELSE COALESCE(bp.shortname, d.agc_code, 'LOYAL CUSTOMER'::character varying)
                END, 'No network'::character varying) AS network,
                CASE
                    WHEN COALESCE(bp.shortname, d.agc_code)::text = ANY (ARRAY['AFS'::character varying::text, 'OFP'::character varying::text]) THEN d.subid1
                    ELSE d.affiliate_id
                END AS sub,
            d.createdate::date AS lead_date,
            a.createdate::date AS so_date,
                CASE
                    WHEN d.lead_type::text = 'A'::text THEN 'A'::text
                    ELSE 'M'::text
                END AS lead_type,
            a.status AS order_status_id,
            count(DISTINCT d.lead_id) AS total_lead,
            sum(
                CASE
                    WHEN d.lead_status = 2 THEN 1
                    ELSE 0
                END) AS approved,
            sum(
                CASE
                    WHEN d.lead_status = ANY (ARRAY[2, 3, 8, 9, 14]) THEN 1
                    ELSE 0
                END) AS contactable,
            sum(
                CASE
                    WHEN d.lead_status = ANY (ARRAY[7, 10, 11]) THEN 1
                    ELSE 0
                END) AS uncall,
            sum(
                CASE
                    WHEN d.lead_status = 3 THEN 1
                    ELSE 0
                END) AS rejected,
            sum(
                CASE
                    WHEN rf.isrf = 1 AND d.lead_status = 3 THEN 1
                    ELSE 0
                END) AS no_validated_rocket,
            sum(
                CASE
                    WHEN d.lead_status = 2 THEN a.amount
                    ELSE 0::numeric
                END) AS approved_revenue,
            sum(
                CASE
                    WHEN d.lead_status = 2 AND (a.status = ANY (ARRAY[43, 357])) THEN 1
                    ELSE 0
                END) AS validated,
            sum(
                CASE
                    WHEN d.lead_status = 2 AND (a.status = ANY (ARRAY[43, 357])) AND
                    CASE
                        WHEN d.postback_status IS NULL THEN 1
                        WHEN d.postback_status::text = 'approved'::text THEN 1
                        ELSE 0
                    END = 1 THEN 1
                    ELSE 0
                END) AS total_approved_postback,
            sum(
                CASE
                    WHEN d.lead_status = 2 AND (a.status = ANY (ARRAY[43, 357])) AND odn.status = 59 THEN 1
                    ELSE 0
                END) AS delivered,
            sum(
                CASE
                    WHEN d.lead_status = 2 AND (a.status = ANY (ARRAY[43, 357])) AND odn.status = 59 THEN a.amount
                    ELSE 0::numeric
                END) AS delivered_amount,
            sum(
                CASE
                    WHEN odn.status <> ALL (ARRAY[53, 59, 61, 56]) THEN 1
                    ELSE 0
                END) AS unfinish,
            sum(
                CASE
                    WHEN d.lead_status = 2 AND (a.status = ANY (ARRAY[43, 357])) AND (odn.status <> ALL (ARRAY[59, 53, 57, 61, 56])) THEN a.amount
                    ELSE 0::numeric
                END) AS unfinish_amount,
            sum(
                CASE
                    WHEN d.lead_status = 5 THEN 1
                    ELSE 0
                END) AS trash,
            sum(
                CASE
                    WHEN d.lead_status = 6 THEN 1
                    ELSE 0
                END) AS closed,
            sum(
                CASE
                    WHEN d.lead_status = 8 THEN 1
                    ELSE 0
                END) AS callback_consulting,
            sum(
                CASE
                    WHEN d.lead_status = 9 THEN 1
                    ELSE 0
                END) AS callback_not_prospect,
            sum(
                CASE
                    WHEN d.lead_status = 14 THEN 1
                    ELSE 0
                END) AS callback_potential,
            sum(
                CASE
                    WHEN d.lead_status = 2 AND a.status = 44 THEN a.amount
                    ELSE 0::numeric
                END) AS cancel_revenue,
            sum(
                CASE
                    WHEN d.lead_status = 2 AND a.status = 44 THEN 1
                    ELSE 0
                END) AS cancel,
            sum(
                CASE
                    WHEN d.lead_status = 2 AND (a.status = ANY (ARRAY[43, 357])) THEN a.amount
                    ELSE 0::numeric
                END) AS so_amount,
            sum(
                CASE
                    WHEN rf.isrf = 1 AND d.lead_status = 3 THEN rf.rfamount
                    ELSE 0::numeric
                END) AS so_amount_rocket,
            sum(
                CASE
                    WHEN d.lead_status = 2 AND (a.status = ANY (ARRAY[43, 357])) AND odn.status = 59 THEN a.amount
                    ELSE 0::numeric
                END) AS net_revenue,
            avg(d.payout) AS payout,
            avg(d.max_po) AS max_po
           FROM ( SELECT cl_fresh.geo,
                        CASE
                            WHEN cl_fresh.geo::text ^@ 'VN'::text THEN 'VN'::character varying
                            WHEN cl_fresh.geo::text ^@ 'ID'::text THEN 'ID'::character varying
                            WHEN cl_fresh.geo::text ^@ 'MY'::text THEN 'MY'::character varying
                            WHEN cl_fresh.geo::text ^@ 'PH'::text THEN 'PH'::character varying
                            WHEN cl_fresh.geo::text ^@ 'TH'::text THEN 'TH'::character varying
                            ELSE cl_fresh.geo
                        END AS country_code,
                    cl_fresh.createdate,
                    cl_fresh.modifydate,
                    cl_fresh.lead_id,
                    cl_fresh.assigned,
                    cl_fresh.cp_id,
                    cl_fresh.prod_name,
                    cl_fresh.comment,
                    cl_fresh.agc_code,
                    cl_fresh.agc_id,
                    cl_fresh.postback_status,
                    "right"(cl_fresh.phone::text, 9) AS short_phone,
                        CASE
                            WHEN lower(cl_fresh.user_defin_05) ~~ '%lockdown%'::text THEN 1
                            ELSE 0
                        END AS islockdown,
                        CASE
                            WHEN cl_fresh.name::text ~~ '%RJ%'::text THEN 1
                            ELSE 0
                        END AS isrocket,
                        CASE
                            WHEN length(btrim(cl_fresh.affiliate_id::text)) <= 0 AND cl_fresh.lead_type::text = 'A'::text THEN 'NO_NETWORK'::character varying
                            ELSE cl_fresh.affiliate_id
                        END AS affiliate_id,
                    cl_fresh.lead_type,
                    cl_fresh.lead_status,
                        CASE
                            WHEN (cl_fresh.affiliate_id::text = ANY (ARRAY['EW'::character varying::text, 'AT'::character varying::text, 'ADT'::character varying::text, 'ABT'::character varying::text, 'ARB'::character varying::text, 'CSL'::character varying::text, 'MKR'::character varying::text, 'XXX'::character varying::text, 'PFC'::character varying::text, 'ORG'::character varying::text, 'ORG2'::character varying::text, 'PIB'::character varying::text, 'MH'::character varying::text, 'MP'::character varying::text, 'IGO'::character varying::text, 'VIC'::character varying::text, 'ODS'::character varying::text, 'DAT'::character varying::text, 'VAL'::character varying::text, 'MIR'::character varying::text, 'NGN'::character varying::text, 'WIL'::character varying::text, 'PD'::character varying::text, 'CTR'::character varying::text, 'U_DOMA'::character varying::text, 'ABG'::character varying::text])) OR cl_fresh.affiliate_id::text = 'U_RUS'::text AND cl_fresh.geo::text = 'TH'::text OR cl_fresh.subid1 IS NULL THEN 'No PubID'::character varying
                            WHEN cl_fresh.subid1::text = ''::text THEN 'blank'::character varying
                            ELSE cl_fresh.subid1
                        END AS subid1,
                    afs.payout,
                    afs.max_po
                   FROM cl_fresh
                     LEFT JOIN ods_affscale_conversion afs ON afs.transaction_id = cl_fresh.click_id::text
                  WHERE cl_fresh.createdate >= '2022-01-01 00:00:00'::timestamp without time zone AND
                        CASE
                            WHEN cl_fresh.lead_status = 4 OR cl_fresh.lead_status = 5 AND cl_fresh.assigned = 0 THEN 1
                            ELSE 0
                        END <> 1 AND lower(cl_fresh.name::text) !~~ '%test%'::text) d
             LEFT JOIN rejected_list rf ON rf.short_phone = d.short_phone AND rf.geo::text = d.geo::text
             LEFT JOIN bp_partner bp ON d.agc_id = bp.pn_id AND bp.geo::text = d.geo::text
             LEFT JOIN ( SELECT a_1.so_id,
                    a_1.org_id,
                    a_1.geo,
                    a_1.cp_id,
                    a_1.lead_id,
                    a_1.amount,
                    a_1.payment_method,
                    a_1.status,
                    a_1.createdate,
                    a_1.creation_date,
                    a_1.qa_note,
                    a_1.validated_rn,
                    a_1.rn,
                    a_1.final_rn
                   FROM ( SELECT oso.so_id,
                            oso.org_id,
                            oso.geo,
                            oso.cp_id,
                            oso.lead_id,
                            oso.amount,
                            oso.payment_method,
                            oso.status,
                            oso.createdate,
                            oso.creation_date,
                            oso.qa_note,
                            sum(
                                CASE
                                    WHEN oso.status = ANY (ARRAY[43, 357]) THEN 1
                                    ELSE NULL::integer
                                END) OVER (PARTITION BY oso.lead_id, oso.geo) AS validated_rn,
                            row_number() OVER (PARTITION BY oso.lead_id, oso.geo ORDER BY oso.createdate DESC) AS rn,
                                CASE
                                    WHEN row_number() OVER (PARTITION BY oso.lead_id, oso.geo ORDER BY oso.createdate DESC) = 1 AND sum(
                                    CASE
WHEN oso.status = ANY (ARRAY[43, 357]) THEN 1
ELSE NULL::integer
                                    END) OVER (PARTITION BY oso.lead_id, oso.geo) > 0 AND (oso.status <> ALL (ARRAY[43, 357])) THEN 2::bigint
                                    WHEN row_number() OVER (PARTITION BY oso.lead_id, oso.geo ORDER BY oso.createdate DESC) <> 1 AND (oso.status = ANY (ARRAY[43, 357])) THEN 1::bigint
                                    ELSE row_number() OVER (PARTITION BY oso.lead_id, oso.geo ORDER BY oso.createdate DESC)
                                END AS final_rn
                           FROM od_sale_order oso
                          WHERE oso.status <> 46 AND oso.createdate >= '2022-01-01 00:00:00'::timestamp without time zone) a_1
                  WHERE a_1.final_rn = 1) a ON d.lead_id = a.lead_id AND d.geo::text = a.geo::text
             LEFT JOIN od_do_new odn ON odn.so_id = a.so_id AND odn.geo::text = a.geo::text
             LEFT JOIN ( SELECT cf_synonym.geo,
                    cf_synonym.synonym_id,
                    cf_synonym.type,
                    cf_synonym.name,
                    cf_synonym.value,
                    cf_synonym.dscr,
                    cf_synonym.type_id,
                    cf_synonym.localized_name
                   FROM cf_synonym
                  WHERE cf_synonym.type_id = 4) cs ON cs.value = a.status AND cs.geo::text = a.geo::text
             LEFT JOIN ( SELECT cf_synonym.geo,
                    cf_synonym.synonym_id,
                    cf_synonym.type,
                    cf_synonym.name,
                    cf_synonym.value,
                    cf_synonym.dscr,
                    cf_synonym.type_id,
                    cf_synonym.localized_name
                   FROM cf_synonym
                  WHERE cf_synonym.type_id = 5) ds ON ds.value = odn.status AND ds.geo::text = odn.geo::text
             LEFT JOIN or_user p ON p.user_id = d.assigned AND p.geo::text = d.geo::text
             LEFT JOIN cp_campaign q ON q.cp_id = d.cp_id AND q.geo::text = d.geo::text
          GROUP BY d.geo, d.country_code, q.name, p.user_name, d.assigned, d.prod_name, (d.createdate::date), (a.createdate::date), d.lead_type, bp.shortname, d.subid1, d.agc_code, d.affiliate_id, a.status, d.islockdown, d.isrocket
        ), cte_ar_mrps AS (
         SELECT ar_mrps.affiliate_id AS network,
            ar_mrps.offer_id AS product_name,
                CASE
                    WHEN lower(ar_mrps.sub_id) = '*'::text THEN ''::text
                    WHEN lower(ar_mrps.sub_id) = ''::text THEN 'blank'::text
                    ELSE ar_mrps.sub_id
                END AS sub_id,
            ar_mrps.ar_mrp,
            ar_mrps.applied_from_date::date AS started_date,
            ar_mrps.applied_to_date::date AS ending_date,
                CASE
                    WHEN lower(ar_mrps.sub_id) = '*'::text THEN concat(ar_mrps.affiliate_id, '_', ar_mrps.offer_id)
                    WHEN lower(ar_mrps.sub_id) = ''::text THEN concat(ar_mrps.affiliate_id, '_', 'blank', '_', ar_mrps.offer_id)
                    ELSE concat(ar_mrps.affiliate_id, '_', ar_mrps.sub_id, '_', ar_mrps.offer_id)
                END AS target_key
           FROM ar_mrps
        ), cte_lead_mrps AS (
         SELECT lead_mrps.affiliate_id AS network,
            lead_mrps.offer_id AS product_name,
                CASE
                    WHEN lower(lead_mrps.sub_id) = '*'::text THEN ''::text
                    WHEN lower(lead_mrps.sub_id) = ''::text THEN 'blank'::text
                    ELSE lead_mrps.sub_id
                END AS sub_id,
            lead_mrps.lead_mrp,
            lead_mrps.applied_from_date::date AS started_date,
            lead_mrps.applied_to_date::date AS ending_date,
                CASE
                    WHEN lower(lead_mrps.sub_id) = '*'::text THEN concat(lead_mrps.affiliate_id, '_', lead_mrps.offer_id)
                    WHEN lower(lead_mrps.sub_id) = ''::text THEN concat(lead_mrps.affiliate_id, '_', 'blank', '_', lead_mrps.offer_id)
                    ELSE concat(lead_mrps.affiliate_id, '_', lead_mrps.sub_id, '_', lead_mrps.offer_id)
                END AS target_key
           FROM lead_mrps
        ), main_ AS (
         SELECT cte_raw.geo,
            cte_raw.country_code,
                CASE
                    WHEN lower(cte_raw.prod_name::text) ~~ '%vip%'::text THEN cte_raw.cpname
                    WHEN lower(cte_raw.prod_name::text) ~~ '%prosta%id'::text THEN 'Fresh HC'::character varying
                    WHEN lower(cte_raw.prod_name::text) ~~ '%duramax%th'::text THEN 'Fresh ME'::character varying
                    ELSE cte_raw.cpname
                END AS cpname,
            (date_trunc('week'::text, cte_raw.lead_date + '1 day'::interval) - '1 day'::interval)::date AS week_start,
            (date_trunc('week'::text, CURRENT_DATE + '1 day'::interval) - '1 day'::interval)::date AS week_start_current,
            cte_raw.agname,
            cte_raw.assigned,
            cte_raw.prod_name,
            cte_raw.agc_code,
            cte_raw.islockdown,
            cte_raw.isrocket,
            cte_raw.offer,
            cte_raw.network,
            cte_raw.sub,
            cte_raw.lead_date,
            cte_raw.so_date,
            cte_raw.lead_type,
            cte_raw.order_status_id,
            cte_raw.total_lead,
            cte_raw.approved,
            cte_raw.contactable,
            cte_raw.uncall,
            cte_raw.rejected,
            cte_raw.no_validated_rocket,
            cte_raw.approved_revenue,
            cte_raw.validated,
            cte_raw.total_approved_postback,
            cte_raw.delivered,
            cte_raw.delivered_amount,
            cte_raw.unfinish,
            cte_raw.unfinish_amount,
            cte_raw.trash,
            cte_raw.closed,
            cte_raw.callback_consulting,
            cte_raw.callback_not_prospect,
            cte_raw.callback_potential,
            cte_raw.cancel_revenue,
            cte_raw.cancel,
            cte_raw.so_amount,
            cte_raw.so_amount_rocket,
            cte_raw.net_revenue,
            cte_raw.payout,
            cte_raw.max_po,
                CASE
                    WHEN cte_raw.prod_name::text ~~ '%cpl%'::text THEN cte_raw.total_lead - cte_raw.trash
                    ELSE 0::bigint
                END AS cpl_lead,
            COALESCE(am.ar_mrp, am_2.ar_mrp) AS armrp,
            lm.lead_mrp,
            lm.started_date AS lead_mrp_started_date,
            lm.ending_date AS lead_mrp_ending_date,
            lm_2.lead_mrp AS pub_lead_mrp,
            lm_2.started_date AS pub_lead_mrp_started_date,
            lm_2.ending_date AS pub_lead_mrp_ending_date,
            CURRENT_TIMESTAMP AS "current_timestamp"
           FROM cte_raw
             LEFT JOIN cte_ar_mrps am ON
                CASE
                    WHEN cte_raw.sub::text = ''::text THEN concat(cte_raw.network, '_', 'blank', '_', cte_raw.offer)
                    ELSE concat(cte_raw.network, '_', cte_raw.sub, '_', cte_raw.offer)
                END = am.target_key AND cte_raw.lead_date >= am.started_date AND cte_raw.lead_date <= am.ending_date
             LEFT JOIN cte_ar_mrps am_2 ON concat(cte_raw.network, '_', cte_raw.offer) = am_2.target_key AND cte_raw.lead_date >= am_2.started_date AND cte_raw.lead_date <= am_2.ending_date
             LEFT JOIN cte_lead_mrps lm ON
                CASE
                    WHEN cte_raw.sub::text = ''::text THEN concat(cte_raw.network, '_', 'blank', '_', cte_raw.offer)
                    ELSE concat(cte_raw.network, '_', cte_raw.sub, '_', cte_raw.offer)
                END = lm.target_key AND cte_raw.lead_date >= lm.started_date AND cte_raw.lead_date <= lm.ending_date
             LEFT JOIN cte_lead_mrps lm_2 ON concat(cte_raw.network, '_', cte_raw.offer) = lm_2.target_key AND cte_raw.lead_date >= lm_2.started_date AND cte_raw.lead_date <= lm_2.ending_date
        ), final_ AS (
         SELECT main__.geo,
            main__.country_code,
            main__.cpname,
            main__.week_start,
            main__.week_start_current,
            main__.agname,
            main__.assigned,
            main__.prod_name,
            main__.agc_code,
            main__.islockdown,
            main__.isrocket,
            main__.offer,
            main__.network,
            main__.sub,
            main__.lead_date,
            main__.so_date,
            main__.lead_type,
            main__.order_status_id,
            main__.total_lead,
            main__.approved,
            main__.contactable,
            main__.uncall,
            main__.rejected,
            main__.no_validated_rocket,
            main__.approved_revenue,
            main__.validated,
            main__.total_approved_postback,
            main__.delivered,
            main__.delivered_amount,
            main__.unfinish,
            main__.unfinish_amount,
            main__.trash,
            main__.closed,
            main__.callback_consulting,
            main__.callback_not_prospect,
            main__.callback_potential,
            main__.cancel_revenue,
            main__.cancel,
            main__.so_amount,
            main__.so_amount_rocket,
            main__.net_revenue,
            main__.payout,
            main__.max_po,
            main__.cpl_lead,
            main__.armrp,
            main__.lead_mrp,
            main__.lead_mrp_started_date,
            main__.lead_mrp_ending_date,
            main__.pub_lead_mrp,
            main__.pub_lead_mrp_started_date,
            main__.pub_lead_mrp_ending_date,
            main__."current_timestamp",
                CASE
                    WHEN main__.country_code::text = 'VN'::text AND main__.week_start >= (main__.week_start_current - 14) THEN 1
                    WHEN main__.country_code::text = 'ID'::text AND main__.week_start >= (main__.week_start_current - 21) THEN 1
                    WHEN main__.country_code::text = 'TH'::text AND main__.week_start >= (main__.week_start_current - 7) THEN 1
                    WHEN main__.country_code::text = 'PH'::text AND main__.week_start >= (main__.week_start_current - 7) THEN 1
                    WHEN main__.country_code::text = 'MY'::text AND main__.week_start >= (main__.week_start_current - 14) THEN 1
                    ELSE 0
                END AS inrangeforecast
           FROM main_ main__
        )
 SELECT 
    final__.geo,
    final__.country_code,
    final__.cpname,
    final__.week_start,
    final__.week_start_current,
    final__.agname,
    final__.assigned,
    final__.prod_name,
    final__.agc_code,
    final__.islockdown,
    final__.isrocket,
    final__.offer,
    final__.network,
    final__.sub,
    final__.lead_date,
    final__.so_date,
    final__.lead_type,
    final__.order_status_id,
    final__.total_lead,
    final__.approved,
    final__.contactable,
    final__.uncall,
    final__.rejected,
    final__.no_validated_rocket,
    final__.approved_revenue,
    final__.validated,
    final__.total_approved_postback,
    final__.delivered,
    final__.delivered_amount,
    final__.unfinish,
    final__.unfinish_amount,
    final__.trash,
    final__.closed,
    final__.callback_consulting,
    final__.callback_not_prospect,
    final__.callback_potential,
    final__.cancel_revenue,
    final__.cancel,
    final__.so_amount,
    final__.so_amount_rocket,
    final__.net_revenue,
    final__.payout,
    final__.max_po,
    final__.cpl_lead,
    final__.armrp,
    final__.lead_mrp,
    final__.lead_mrp_started_date,
    final__.lead_mrp_ending_date,
    final__.pub_lead_mrp,
    final__.pub_lead_mrp_started_date,
    final__.pub_lead_mrp_ending_date,
    final__.inrangeforecast,
    COALESCE(ddfm.dr_forecast, COALESCE(
        CASE
            WHEN final__.inrangeforecast = 1 THEN cddfbd.dr_forecast_final
            ELSE
            CASE
                WHEN final__.validated = 0 THEN 0::double precision
                ELSE final__.delivered::double precision / final__.validated::double precision
            END
        END,
        CASE
            WHEN final__.validated = 0 THEN 0::double precision
            ELSE final__.delivered::double precision / final__.validated::double precision
        END)) AS dr_final,
    ag.agent_name,
	ag.team,
	ag.team_lead,
	ag.sup,
    ex.exchange,
    c.system_team,
    case 
     when (final__.geo ^@ 'VN' or final__.geo ^@ 'MY') then
    	case 
     		when final__.lead_type = 'M' and lower(ag.team) like '%cit%' then 'CIT'
     		when final__.lead_type = 'M' and lower(ag.team) not like '%cit%' then 'Fresh Resell' else null 
    	end 
     when final__.geo ^@ 'PH' then
    	case
     	 when ag.team = 'CIT' then 'CIT'
     	 when ag.team = 'Rocket' then 'Rocket'
     	 else 'Others'
    	end
     when final__.geo ^@ 'TH' then ag.team
     when final__.geo ^@ 'ID' then 
        case 
         when lower(final__.agname) like '%bk%' then 'Others'
         when lower(final__.agname) like '%cs%' then 'Others'
  	 else 'CIT' 
        end
     else 'Others'
   end as cit_team

   FROM (select * from final_ where lead_date >= '2023-11-01') final__
     LEFT JOIN cdm_dim_dr_forecast_by_date cddfbd ON final__.country_code::text = cddfbd.geo AND final__.cpname::text = cddfbd.category AND final__.offer::text = cddfbd.product_name AND final__.network::text = cddfbd.network AND final__.sub::text = cddfbd.pub
     LEFT JOIN dim_dr_manual_forecast ddfm ON final__.network::text = ddfm.network AND final__.offer::text = ddfm.offer AND final__.lead_date >= ddfm."from" AND final__.lead_date <= ddfm."to"
     left join dim_agent ag on ag.geo = final__.country_code and ag.email = final__.agname
     left join dim_exchange_rate ex on final__.country_code = ex.geo and final__.so_date >= ex.started_date and final__.so_date <= ex.ending_date
     left join
			(
			 select 
			   tm.geo,
			   left(tm.geo,2) country_code,
			   ou.user_name,
			   ot.name system_team  
			 from public.or_team_member tm
			 left join or_user ou on ou.user_id = tm.user_id and ou.geo = tm.geo
			 left join or_team ot on ot.id = tm.team_id and ot.geo = tm.geo
			 ) c on final__.agname = c.user_name and final__.geo = c.geo