with
    cte_raw as (
        select
            oso.createdate::date as createdate,
            extract('week' from oso.createdate + interval '1 day') as lead_week,
            extract('month' from oso.createdate) as lead_month,
            extract('week' from current_date + interval '1 day') as current_week,
            (date_trunc('week', oso.createdate + interval '1 day') - interval '1 day')::date
            as week_start,
            (
                date_trunc('week', current_date + interval '1 day') - interval '1 day'
            )::date as week_start_current,
            left(oso.geo, 2) as geo,
            cc.name category,
            case when creation_date is null then 'validated' else 'delay' end validation_type,
            coalesce(extract(day from creation_date - oso.createdate),0) delay_duration,
            sum(case when oso.status in (43,357) then 1 else 0 end) validated,
            sum(case when odn.status = 59 then 1 else 0 end) delivered
        from od_sale_order oso
        left join cl_fresh cf on cf.geo = oso.geo and oso.lead_id = cf.lead_id
        left join cp_campaign cc on cf.cp_id = cc.cp_id and cf.geo = cc.geo
        left join od_do_new odn on oso.geo = odn.geo and oso.so_id = odn.so_id
        where cf.lead_type = 'M'
        and oso.createdate >= current_date - 60
        group by 1,2,3,4,5,6,7,8,9,10
    ),
    data as (
        select
            *,
            case
                when geo = 'ID'
                then week_start >= (week_start_current - 21)
                when geo in ('VN', 'MY')
                then week_start >= (week_start_current - 14)
                when geo in ('TH', 'PH')
                then week_start >= (week_start_current - 7)
                else false
            end as inrangeforecast
        from cte_raw
    ),
    data_forecast1 as (
        select data.*
        from data
        where
            not inrangeforecast
            and (
                (
                    data.geo = 'VN'
                    and createdate <= week_start_current - 15
                    and createdate >= week_start_current - 35
                )
                or (
                    data.geo in ('ID', 'ID2')
                    and createdate <= week_start_current - 22
                    and createdate >= week_start_current - 42
                )
                or (
                    data.geo = 'TH'
                    and data.category = 'Fresh Hair'
                    and createdate <= '2022-08-31'
                    and createdate >= '2022-08-01'
                )
                or (
                    data.geo = 'TH'
                    and data.category <> 'Fresh Hair'
                    and createdate <= week_start_current - 22
                    and createdate >= week_start_current - 42
                )
                or (
                    data.geo = 'PH'
                    and createdate <= week_start_current - 22
                    and createdate >= week_start_current - 42
                )  -- -- 22.06.2023
                or (
                    data.geo = 'MY'
                    and createdate <= week_start_current - 15
                    and createdate >= week_start_current - 35
                )
            )
    ),
    data_forecast2 as (
        select data.*
        from data
        where
            not inrangeforecast
            and data.geo = 'ID'
            and createdate <= '2022-12-10'
            and createdate >= '2022-11-20'  -- -- 09.01.2023		
    ),
    data_forecast3 as (
        select data.*
        from data
        where
            not inrangeforecast
            and data.geo = 'TH'
            and createdate <= '2022-12-24'
            and createdate >= '2022-12-04'  -- - W49.50.51				---- 09.01.2023
    ),
    full_data_forecast1 as (
        select
            data_forecast.geo,
            data_forecast.category,
            validation_type,
            delay_duration,
            sum(validated) as validated,
            sum(delivered) as delivered,
            case
                when sum(validated) = 0
                then 0
                else sum(delivered) / sum(validated)::float
            end as dr_forecast
        from data_forecast1 data_forecast
        group by 1,2,3,4
    ),
    full_data_forecast2 as (
        select
            data_forecast.geo,
            data_forecast.category,
            validation_type,
            sum(validated) as validated,
            sum(delivered) as delivered,
            case
                when sum(validated) = 0
                then 0
                else sum(delivered) / sum(validated)::float
            end as dr_forecast
        from data_forecast1 data_forecast
        group by 1,2,3
    ),
    full_data_forecast_by_cat as (
        select
            data_forecast.geo,
            data_forecast.category,
            sum(validated) as validated,
            sum(delivered) as delivered,
            case
                when sum(validated) = 0
                then 0
                else sum(delivered) / sum(validated)::float
            end as dr_forecast
        from data_forecast1 data_forecast
        group by 1,2
    ),
    full_data_forecast_by_geo as (
        select
            data_forecast.geo,
            sum(validated) as validated,
            sum(delivered) as delivered,
            case
                when sum(validated) = 0
                then 0
                else sum(delivered) / sum(validated)::float
            end as dr_forecast
        from data_forecast1 data_forecast
        group by 1
    )
select
    raw.geo,
    raw.category,
    raw.validation_type,
    raw.delay_duration,
    case 
	    when d1.validated >= 20 
         then d1.dr_forecast
	    when (d1.validated < 20 or d1.validated is null) and d2.validated >= 20 
         then d2.dr_forecast
         when (d2.validated < 20 or d2.validated is null) and d3.validated >= 20
         then d3.dr_forecast
         when (d3.validated < 20 or d3.validated is null) and d4.validated >= 20
         then d4.dr_forecast
         else null
         end dr_forecast_final,
    d1.validated,
    d1.delivered,
    d1.dr_forecast dr_forecast,
    d2.validated validated_by_validation_type,
    d2.delivered delivered_by_validation_type,
    d2.dr_forecast dr_forecast_by_validation_type,
    d3.validated validated_by_cat,
    d3.delivered delivered_by_cat,
    d3.dr_forecast dr_forecast_by_cat,
    d4.validated validated_by_geo,
    d4.delivered delivered_by_geo,
    d4.dr_forecast dr_forecast_by_geo
from
    (
        select distinct geo, category, validation_type, delay_duration from cte_raw
    ) raw
left join full_data_forecast1 d1 on raw.geo = d1.geo and raw.category = d1.category and raw.validation_type = d1.validation_type and raw.delay_duration = d1.delay_duration
left join full_data_forecast2 d2 on raw.geo = d2.geo and raw.category = d2.category and raw.validation_type = d2.validation_type
left join full_data_forecast_by_cat d3 on raw.geo = d3.geo and raw.category = d3.category
left join full_data_forecast_by_geo d4 on raw.geo = d4.geo
