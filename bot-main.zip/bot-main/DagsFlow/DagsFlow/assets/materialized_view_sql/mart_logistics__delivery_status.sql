select
    geo,
    extract(year from do_date)
    || '-'
    || lpad(extract(month from do_date)::text, 2, '0') as delivery_date,
    count(*) as total_order,
    sum(case when do_status in ('delivered', 'refund') then 1 else 0 end) as delivered,
    sum(case when do_status = 'new' then 1 else 0 end) new_order,
    sum(
        case
            when (do_status = 'new') and (now()::date - do_date::date) >= 1
            then 1
            else 0
        end
    ) new_order_delay,
    sum(case when do_status = 'pending' then 1 else 0 end) pending,
    sum(
        case
            when (do_status = 'pending') and (now()::date - do_date::date) >= 1
            then 1
            else 0
        end
    ) pending_delay,
    sum(case when do_status = 'intransit' then 1 else 0 end) intransit,
    sum(case when do_status = 'delivering' then 1 else 0 end) delivering,
    sum(
        case
            when do_status not in ('delivered', 'returning', 'returned', 'cancel')
            then 1
            else 0
        end
    ) ongoing
from "tms_central"."dareport"."data_master_agg_id"
where do_date > now() - interval '3' month
group by 1, 2
order by 1, 2 desc
