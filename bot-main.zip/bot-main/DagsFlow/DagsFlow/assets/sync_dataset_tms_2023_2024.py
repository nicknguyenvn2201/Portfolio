from dagster import asset, Config, define_asset_job, ScheduleDefinition, AssetSelection
from DagsFlow.assets.utls.func import extract_from_dwh
from DagsFlow.resources.postgres import PostgresConnection

def create_monthly_asset(month: int, year: int, prev_asset_name=None):
    class BudgetControl(Config):
        io_format: str = "csv"
        io_abs_path: str = (
            f"Data team\\Power BI (backup)\\fin__tms_10_2023_to_12_2024\\fin__tms_{month:02}_{year}.csv"
        )
        sql_query: str = f'''SELECT *
                             FROM mart_fin__full_tms_data_2024
                             WHERE DATE("lead_created_date") BETWEEN '{year}-{month:02}-01' AND '{year}-{month:02}-{30 if month != 2 else 28}' '''

    @asset(
        key_prefix=[f"sharepoint_dataset_{month:02}_{year}"],
        group_name="sharepoint_dataset_tms",
        io_manager_key="dataneyu_storage",
        deps=[prev_asset_name] if prev_asset_name else []
    )
    def monthly_budget_control(oltp01_conn: PostgresConnection, config: BudgetControl):
        df = extract_from_dwh(config.sql_query, oltp01_conn, return_type="pandas")
        return df

    return BudgetControl, monthly_budget_control

# Create assets for each month
prev_asset_name = None
# for month in range(10, 13):  # October to December 2023
#     config_class, asset_func = create_monthly_asset(month, 2023, prev_asset_name)
#     globals()[f"tmsBudgetControl_{month}_2023"] = config_class
#     globals()[f"tms_budget_control_{month:02}_2023"] = asset_func  # Ensure unique name with format
#     prev_asset_name = f"tms_budget_control_{month:02}_2023"

for month in range(6, 13):  # Jun to December 2024
    config_class, asset_func = create_monthly_asset(month, 2024, prev_asset_name)
    globals()[f"tmsBudgetControl_{month}_2024"] = config_class
    globals()[f"tms_budget_control_{month:02}_2024"] = asset_func  # Ensure unique name with format
    prev_asset_name = f"tms_budget_control_{month:02}_2024"

for month in range(1, 13):  # January to December 2025
    config_class, asset_func = create_monthly_asset(month, 2025, prev_asset_name)
    globals()[f"tmsBudgetControl_{month}_2025"] = config_class
    globals()[f"tms_budget_control_{month:02}_2025"] = asset_func  # Ensure unique name with format
    prev_asset_name = f"tms_budget_control_{month:02}_2025"

# Schedule
sync_tms_2023_2024_budget_control_job = define_asset_job(
    name="sync_tms_2023_2024_budget_control_job",
    selection=AssetSelection.groups("sharepoint_dataset_tms")
)

sync_tms_2023_2024_budget_control_schedule = ScheduleDefinition(
    job=sync_tms_2023_2024_budget_control_job,
    cron_schedule="30 3 * * *",
    execution_timezone="Asia/Bangkok",
)
