from dagster import (
    asset,
    Config,
    Output,
    define_asset_job,
    ScheduleDefinition,
    MetadataValue,
    AssetSelection,
    MaterializeResult,
    get_dagster_logger,
    AssetExecutionContext,
)
from DagsFlow.assets.utls.func import extract_from_dwh, create_load_to_postgres_asset_db_master
from DagsFlow.resources.postgres import PostgresConnection
import requests as rq
import json
from os import getenv
from datetime import date, timedelta
import pandas as pd
import pyarrow as pa
from typing import Any
import dotenv
from dateutil.rrule import rrule, DAILY

logger = get_dagster_logger()


def download_keitaro_data_base_layer(
    date_: str,
):
    url = f"http://188.166.215.236/admin_api/v1/report/build"
    headers = {
        "accept": "application/json",
        "Api-Key": getenv("KEITARO_API_KEY"),
    }
    payload = {
        "range": {
            "timezone": "Asia/Ho_Chi_Minh",
            "from": date_,
            "to": date_,  # date.today().strftime("%Y-%m-%d"),
            # "interval": "today"
        },
        "metrics": [
            "campaign",
            "campaign_group",
            "device_model",
            "sub_id_1",
            "sub_id_2",
            "sub_id_3",
            "sub_id_4",
            "ad_campaign_id",
            "sub_id_8",
            "day",
            "campaign_id",
            "conversions",
            "sales",
            "revenue",
            "cost",
            "sub_id",
            "sub_id_7",
            "sale_revenue",
        ],
    }
    logger.info(payload)
    result = rq.post(url=url, headers=headers, data=json.dumps(payload)).json()["rows"]
    return result


@asset(
    group_name="keitaro_buyer_base_layer",
)
def extract_keitaro_api_base_layer(context: AssetExecutionContext) -> Output[pa.Table]:
    result_pd = pd.DataFrame()
    start_date = date(2023, 7, 1)  # project start date
    end_date = date.today()  ##.strftime("%Y-%m-%d")
    for dt in rrule(DAILY, dtstart=start_date, until=end_date):
        date___ = dt.strftime("%Y-%m-%d")
        result = download_keitaro_data_base_layer(date___)
        result_a = pd.json_normalize(result)
        # result_pd = result_pd.append(result_a)
        result_pd = pd.concat([result_pd, result_a], ignore_index=True)
    df = result_pd
    df = df.rename(columns={"day": "datetime"})
    df["datetime"] = pd.to_datetime(df["datetime"], errors="ignore")
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("campaign", "string"),
                ("campaign_group", "string"),
                ("device_model", "string"),
                ("sub_id_1", "string"),
                ("sub_id_2", "string"),
                ("sub_id_3", "string"),
                ("sub_id_4", "string"),
                ("ad_campaign_id", "string"),
                ("sub_id_8", "string"),
                ("datetime", "date32"),
                ("campaign_id", "int32"),
                # ("sub_id", "string"),
                ("conversions", "int32"),
                ("sales", "int32"),
                ("revenue", "float32"),
                ("cost", "float32"),
                ("sub_id", "string"),
                ("sub_id_7", "string"),
                ("sale_revenue", "float32"),
            ]
        ),
    )
    context.log.info(data)
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


# def processs_extract_keitaro_api(
#     extract_keitaro_api: pd.DataFrame,
# ) -> MaterializeResult:
#     return MaterializeResult(metadata={})

load_keitaro_api_base_layer = create_load_to_postgres_asset_db_master(
    asset_name="load_keitaro_api_base_layer",
    source_assets=[extract_keitaro_api_base_layer],
    target_table='"base_layer"."fact_keitaro_data"',
    group_name="keitaro_buyer_base_layer",
)

sync_mb_keitaro_api_job_base_layer = define_asset_job(
    name="sync_mb_keitaro_api_job_base_layer",
    selection=AssetSelection.assets(extract_keitaro_api_base_layer, load_keitaro_api_base_layer),
)

sync_mb_keitaro_api_schedule_base_layer = ScheduleDefinition(
    job=sync_mb_keitaro_api_job_base_layer,
    cron_schedule="30 0 * * *", # cron_schedule="35 8,9,10,11,12,13,14,16 * * *"
    execution_timezone="Asia/Bangkok",
)
