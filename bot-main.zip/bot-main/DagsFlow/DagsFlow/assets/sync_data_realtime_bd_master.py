import pandas as pd
import os
from dagster import (
    Config,
    get_dagster_logger,
    asset,
    AssetExecutionContext,
    MetadataValue,
    define_asset_job,
    DailyPartitionsDefinition,
    ScheduleDefinition,
    AssetSelection
)
import io
import psycopg as pg
from DagsFlow.assets.utls import func
from typing import Iterator
import requests as rq
from datetime import date
from datetime import timedelta
from pandas import DataFrame
import pyarrow as pa
from DagsFlow.assets.utls.func import (
    add_blocking_checks_to_asset,
    create_load_to_postgres_asset_db_master,
    create_download_from_sharepoint_asset_base_layer,
)
import psycopg2
from DagsFlow.assets.materialized_views import create_refresh_mv_asset,create_refreshable_table_asset

logger = get_dagster_logger()

oltp01_conn = os.getenv("PG_LIBPQ_CONN_CONFIG")

class sync_data_bd_master_realtime(Config):
    sql_query_truncate_cl_fresh_realtime: str = "delete from dareport.cl_fresh_realtime;"
    sql_query_insert_cl_fresh_realtime: str = '''insert into dareport.cl_fresh_realtime 
    select *
     from public.cl_fresh where createdate >= (CURRENT_DATE - 6)  and lead_type = 'A'; '''
    sql_query_truncate_od_sale_order_realtime: str = "delete from dareport.od_sale_order_realtime;"
    sql_query_insert_od_sale_order_realtime: str = "insert into dareport.od_sale_order_realtime select * from public.od_sale_order where createdate >= (CURRENT_DATE - 6)"

    sql_query_truncate_od_do_new_realtime: str = "delete from dareport.od_do_new_realtime;"
    sql_query_insert_od_do_new_realtime: str = "insert into dareport.od_do_new_realtime select * from public.od_do_new where createdate >= (CURRENT_DATE - 6)"

class config_data_bd_master_realtime(Config):
    sql_query_delete: str = "TRUNCATE dareport.realtime_bd_master_vtest;"

class config_data_leadstatus_bd_master_realtime(Config):
    sql_query_delete: str = "TRUNCATE dareport.leadstatus_bd_master_vtest;"

@asset(group_name="data_bd_master_realtime")
def truncate_table_cl_fresh_realtime(config: sync_data_bd_master_realtime):
    conn_details = psycopg2.connect(oltp01_conn)
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_truncate_cl_fresh_realtime)
    conn_details.commit()
    cursor.close()
    conn_details.close()

@asset(group_name="data_bd_master_realtime", deps=[truncate_table_cl_fresh_realtime])
def insert_new_data_table_cl_fresh_realtime(config: sync_data_bd_master_realtime):
    conn_details = psycopg2.connect(oltp01_conn)
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_insert_cl_fresh_realtime)
    conn_details.commit()
    cursor.close()
    conn_details.close()

@asset(group_name="data_bd_master_realtime")
def truncate_table_od_sale_order_realtime(config: sync_data_bd_master_realtime):
    conn_details = psycopg2.connect(oltp01_conn)
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_truncate_od_sale_order_realtime)
    conn_details.commit()
    cursor.close()
    conn_details.close()

@asset(group_name="data_bd_master_realtime", deps=[truncate_table_od_sale_order_realtime])
def insert_new_data_table_od_sale_order_realtime(config: sync_data_bd_master_realtime):
    conn_details = psycopg2.connect(oltp01_conn)
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_insert_od_sale_order_realtime)
    conn_details.commit()
    cursor.close()
    conn_details.close()

@asset(group_name="data_bd_master_realtime")
def truncate_table_od_do_new_realtime(config: sync_data_bd_master_realtime):
    conn_details = psycopg2.connect(oltp01_conn)
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_truncate_od_do_new_realtime)
    conn_details.commit()
    cursor.close()
    conn_details.close()

@asset(group_name="data_bd_master_realtime", deps=[truncate_table_od_do_new_realtime])
def insert_new_data_table_od_do_new_realtime(config: sync_data_bd_master_realtime):
    conn_details = psycopg2.connect(oltp01_conn)
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_insert_od_do_new_realtime)
    conn_details.commit()
    cursor.close()
    conn_details.close()




@asset(group_name="data_bd_master_realtime", deps = [insert_new_data_table_cl_fresh_realtime, insert_new_data_table_od_sale_order_realtime, insert_new_data_table_od_do_new_realtime])
def data_mv_realtime_bd_master(context: AssetExecutionContext) -> None:
    mv_realtime_bd_master = create_refresh_mv_asset(
        "realtime_bd_master", with_data=True
    )

@asset(group_name="data_bd_master_realtime", deps=[data_mv_realtime_bd_master])
def data_realtime_bd_master_table(context: AssetExecutionContext) -> None:
    realtime_bd_master_table = create_refreshable_table_asset(
    "realtime_bd_master_table",deps=[data_mv_realtime_bd_master]
)


@asset(group_name="data_bd_master_realtime", deps = [insert_new_data_table_cl_fresh_realtime, insert_new_data_table_od_sale_order_realtime, insert_new_data_table_od_do_new_realtime])
def data_mv_leadstatus_bd_master(config: config_data_bd_master_realtime):
    mv_leadstatus_bd_master = create_refresh_mv_asset(
    "leadstatus_bd_master", with_data=True
)

sync_data_bd_master_realtime = define_asset_job(
    name="sync_data_bd_master_realtime",
    selection=AssetSelection.groups("data_bd_master_realtime"),
)

sync_data_bd_master_realtime_schedule = ScheduleDefinition(
    job=sync_data_bd_master_realtime,
    cron_schedule= "5,15,25,35,45,55 * * * *", 
    execution_timezone="Asia/Bangkok",
)


