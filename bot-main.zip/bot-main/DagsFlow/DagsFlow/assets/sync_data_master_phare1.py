import os
from dagster import (
    Config,
    get_dagster_logger,
    asset,
    define_asset_job,
    ScheduleDefinition,
    AssetSelection
)
import psycopg2

logger = get_dagster_logger()


oltp01_conn = os.getenv("PG_LIBPQ_CONN_CONFIG")

class sync_data_master_phare1(Config):
    # sql_query_truncate_cl_fresh: str = "TRUNCATE dareport.cl_fresh_temp_phare1;"
    sql_query_insert_cl_fresh: str = '''INSERT INTO dareport.cl_fresh_temp_phare1 (id,lead_id,geo,agc_id,agc_code,org_id,cc_code,"name",phone,prod_id,prod_name,assigned,calledby,address,province,district,subdistrict,last_call_status,
     day_call,total_call,amount,lead_status,"result",user_defin_01,user_defin_02,user_defin_03,user_defin_04,user_defin_05,createdate,modifydate,modifyby,
     cp_id,callinglist_id,lead_type,agc_lead_address,other_name1,other_phone1,other_name2,other_phone2,other_name3,other_phone3,other_name4,other_phone4,
     other_name5,other_phone5,last_call_time,next_call_time,number_of_day,attempt_busy,attempt_noans,attemp_unreachable,click_id,affiliate_id,subid1,subid2,
     offer_id,agc_offer_id,terms,price,unit,customer_age,customer_email,cl_group,agcoffer_id,"source",postal_code,tracker_id,first_call_time,first_call_by,
     first_call_status,fcr_time,fcr_by,fcr_status,created_at,updated_at,crm_action_type,agent_group_id,min_skill_level,agent_skill_level,first_call_click,
     "comment",reference_lead_id,reference_org_id,delivery_package_code,agent_note,batch_id,lead_sequence,batch_sequence,fresh_lead_id,fresh_org_id,postback_status,
     postback_date,actual_call)
select id,lead_id,geo,agc_id,agc_code,org_id,cc_code,"name",phone,prod_id,prod_name,assigned,calledby,address,province,district,subdistrict,last_call_status,
     day_call,total_call,amount,lead_status,"result",user_defin_01,user_defin_02,user_defin_03,user_defin_04,user_defin_05,createdate,modifydate,modifyby,
     cp_id,callinglist_id,lead_type,agc_lead_address,other_name1,other_phone1,other_name2,other_phone2,other_name3,other_phone3,other_name4,other_phone4,
     other_name5,other_phone5,last_call_time,next_call_time,number_of_day,attempt_busy,attempt_noans,attemp_unreachable,click_id,affiliate_id,subid1,subid2,
     offer_id,agc_offer_id,terms,price,unit,customer_age,customer_email,cl_group,agcoffer_id,"source",postal_code,tracker_id,first_call_time,first_call_by,
     first_call_status,fcr_time,fcr_by,fcr_status,created_at,updated_at,crm_action_type,agent_group_id,min_skill_level,agent_skill_level,first_call_click,
     "comment",reference_lead_id,reference_org_id,delivery_package_code,agent_note,batch_id,lead_sequence,batch_sequence,fresh_lead_id,fresh_org_id,postback_status,
     postback_date,actual_call
from public.cl_fresh 
where modifydate >= now() - interval '24 hour'
ON CONFLICT (lead_id,geo) DO UPDATE 
SET id = EXCLUDED.id,
    agc_id = EXCLUDED.agc_id,
    agc_code = EXCLUDED.agc_code,
    org_id = EXCLUDED.org_id,
    cc_code = EXCLUDED.cc_code,
    "name" = EXCLUDED."name",
    phone = EXCLUDED.phone,
    prod_id = EXCLUDED.prod_id,
    prod_name = EXCLUDED.prod_name,
    assigned = EXCLUDED.assigned,
    calledby = EXCLUDED.calledby,
    address = EXCLUDED.address,
    province = EXCLUDED.province,
    district = EXCLUDED.district,
    subdistrict = EXCLUDED.subdistrict,
    last_call_status = EXCLUDED.last_call_status,
    day_call = EXCLUDED.day_call,
    total_call = EXCLUDED.total_call,
    amount = EXCLUDED.amount,
    lead_status = EXCLUDED.lead_status,
    "result" = EXCLUDED."result",
    user_defin_01 = EXCLUDED.user_defin_01,
    user_defin_02 = EXCLUDED.user_defin_02,
    user_defin_03 = EXCLUDED.user_defin_03,
    user_defin_04 = EXCLUDED.user_defin_04,
    user_defin_05 = EXCLUDED.user_defin_05,
    createdate = EXCLUDED.createdate,
    modifydate = EXCLUDED.modifydate,
    modifyby = EXCLUDED.modifyby,
    cp_id = EXCLUDED.cp_id,
    callinglist_id = EXCLUDED.callinglist_id,
    lead_type = EXCLUDED.lead_type,
    agc_lead_address = EXCLUDED.agc_lead_address,
    other_name1 = EXCLUDED.other_name1,
    other_phone1 = EXCLUDED.other_phone1,
    other_name2 = EXCLUDED.other_name2,
    other_phone2 = EXCLUDED.other_phone2,
    other_name3 = EXCLUDED.other_name3,
    other_phone3 = EXCLUDED.other_phone3,
    other_name4 = EXCLUDED.other_name4,
    other_phone4 = EXCLUDED.other_phone4,
    other_name5 = EXCLUDED.other_name5,
    other_phone5 = EXCLUDED.other_phone5,
    last_call_time = EXCLUDED.last_call_time,
    next_call_time = EXCLUDED.next_call_time,
    number_of_day = EXCLUDED.number_of_day,
    attempt_busy = EXCLUDED.attempt_busy,
    attempt_noans = EXCLUDED.attempt_noans,
    attemp_unreachable = EXCLUDED.attemp_unreachable,
    click_id = EXCLUDED.click_id,
    affiliate_id = EXCLUDED.affiliate_id,
    subid1 = EXCLUDED.subid1,
    subid2 = EXCLUDED.subid2,
    offer_id = EXCLUDED.offer_id,
    agc_offer_id = EXCLUDED.agc_offer_id,
    terms = EXCLUDED.terms,
    price = EXCLUDED.price,
    unit = EXCLUDED.unit,
    customer_age = EXCLUDED.customer_age,
    customer_email = EXCLUDED.customer_email,
    cl_group = EXCLUDED.cl_group,
    agcoffer_id = EXCLUDED.agcoffer_id,
    "source" = EXCLUDED."source",
    postal_code = EXCLUDED.postal_code,
    tracker_id = EXCLUDED.tracker_id,
    first_call_time = EXCLUDED.first_call_time,
    first_call_by = EXCLUDED.first_call_by,
    first_call_status = EXCLUDED.first_call_status,
    fcr_time = EXCLUDED.fcr_time,
   	fcr_by = EXCLUDED.fcr_by,
  	fcr_status = EXCLUDED.fcr_status,
 	created_at = EXCLUDED.created_at,
	updated_at = EXCLUDED.updated_at,
	crm_action_type = EXCLUDED.crm_action_type,
	agent_group_id = EXCLUDED.agent_group_id,
	min_skill_level	= EXCLUDED.min_skill_level,
	agent_skill_level = EXCLUDED.agent_skill_level,
	first_call_click = EXCLUDED.first_call_click,
	"comment" = EXCLUDED."comment",
	reference_lead_id = EXCLUDED.reference_lead_id,
	reference_org_id = EXCLUDED.reference_org_id,
	delivery_package_code = EXCLUDED.delivery_package_code,
	agent_note = EXCLUDED.agent_note,
	batch_id = EXCLUDED.batch_id,
	lead_sequence = EXCLUDED.lead_sequence,
	batch_sequence = EXCLUDED.batch_sequence,
	fresh_lead_id = EXCLUDED.fresh_lead_id,
	fresh_org_id = EXCLUDED.fresh_org_id,
	postback_status = EXCLUDED.postback_status,
	postback_date = EXCLUDED.postback_date,
	actual_call = EXCLUDED.actual_call; '''
    # sql_query_truncate_od_sale_order: str = "TRUNCATE dareport.od_sale_order_temp_phare1;"
    sql_query_insert_od_sale_order: str = '''INSERT INTO dareport.od_sale_order_temp_phare1 (id,so_id,org_id,geo,cp_id,ag_id,lead_id,amount,payment_method,status,
    createby,createdate,modifyby,modifydate,created_at,updated_at,creation_date,reason,qa_note,validate_by,lead_phone,customer_phone,discount_cash_2,lead_name,
    amount_deposit,list_price,discount_level,discount_type_1,unit_1,discount_cash_1,discount_percent_1,discount_type_2,unit_2,discount_percent_2,discount_type_3,
    unit_3,discount_cash_3,discount_percent_3,discount_type_4,unit_4,discount_cash_4,discount_percent_4,is_validated,appointment_date,qty_total,qty_saleable,
    amount_postpaid,delivery_package_code)
select id,so_id,org_id,geo,cp_id,ag_id,lead_id,amount,payment_method,status,
    createby,createdate,modifyby,modifydate,created_at,updated_at,creation_date,reason,qa_note,validate_by,lead_phone,customer_phone,discount_cash_2,lead_name,
    amount_deposit,list_price,discount_level,discount_type_1,unit_1,discount_cash_1,discount_percent_1,discount_type_2,unit_2,discount_percent_2,discount_type_3,
    unit_3,discount_cash_3,discount_percent_3,discount_type_4,unit_4,discount_cash_4,discount_percent_4,is_validated,appointment_date,qty_total,qty_saleable,
    amount_postpaid,delivery_package_code 
from public.od_sale_order 
where modifydate >= now() - interval '24 hour'
ON CONFLICT (so_id,geo) DO UPDATE 
SET id = EXCLUDED.id,
    lead_id = EXCLUDED.lead_id,
    org_id = EXCLUDED.org_id,
    cp_id = EXCLUDED.cp_id,
    ag_id = EXCLUDED.ag_id,
    amount = EXCLUDED.amount,
    payment_method = EXCLUDED.payment_method,
    status = EXCLUDED.status,
    createby = EXCLUDED.createby,
    createdate = EXCLUDED.createdate,
    modifyby = EXCLUDED.modifyby,
    modifydate = EXCLUDED.modifydate,
    created_at = EXCLUDED.created_at,
    updated_at = EXCLUDED.updated_at,
    creation_date = EXCLUDED.creation_date,
    reason = EXCLUDED.reason,
    qa_note = EXCLUDED.qa_note,
    validate_by = EXCLUDED.validate_by,
    lead_phone = EXCLUDED.lead_phone,
    customer_phone = EXCLUDED.customer_phone,
    discount_cash_2 = EXCLUDED.discount_cash_2,
    lead_name = EXCLUDED.lead_name,
    amount_deposit = EXCLUDED.amount_deposit,
    list_price = EXCLUDED.list_price,
    discount_level = EXCLUDED.discount_level,
    discount_type_1 = EXCLUDED.discount_type_1,
    unit_1 = EXCLUDED.unit_1,
    discount_cash_1 = EXCLUDED.discount_cash_1,
    discount_percent_1 = EXCLUDED.discount_percent_1,
    discount_type_2 = EXCLUDED.discount_type_2,
    unit_2 = EXCLUDED.unit_2,
    discount_percent_2 = EXCLUDED.discount_percent_2,
    discount_type_3 = EXCLUDED.discount_type_3,
    unit_3 = EXCLUDED.unit_3,
    discount_cash_3 = EXCLUDED.discount_cash_3,
    discount_percent_3 = EXCLUDED.discount_percent_3,
    discount_type_4 = EXCLUDED.discount_type_4,
    unit_4 = EXCLUDED.unit_4,
    discount_cash_4 = EXCLUDED.discount_cash_4,
    discount_percent_4 = EXCLUDED.discount_percent_4,
    is_validated = EXCLUDED.is_validated,
    appointment_date = EXCLUDED.appointment_date,
    qty_total = EXCLUDED.qty_total,
    qty_saleable = EXCLUDED.qty_saleable,
    amount_postpaid = EXCLUDED.amount_postpaid,
    delivery_package_code = EXCLUDED.delivery_package_code;'''
    sql_query_truncate_od_do_new: str = '''DELETE FROM dareport.od_do_new_temp_phare1
WHERE (so_id, geo) IN (
    SELECT so_id, geo
    FROM dareport.od_do_new_temp_phare1
    WHERE createdate >= CURRENT_DATE - INTERVAL '180 days'
)
AND createdate >= CURRENT_DATE - INTERVAL '180 days';'''
    sql_query_insert_od_do_new: str = '''insert into dareport.od_do_new_temp_phare1 select id,org_id,do_id,geo,so_id,ffm_id,warehouse_id,
    carrier_id,customer_id,firstdelivertime,tracking_code,ffm_code,package_name,package_description,package_id,amountcod,status,
    createby,createdate,updateby,updatedate,created_at,updated_at,do_code,closetime,error_message,customer_name,customer_phone,
    lastmile_return_code,customer_address,delivery_package_code,packed_time,picked_time 
    from public.od_do_new 
    where createdate >= CURRENT_DATE - INTERVAL '180 days';'''



@asset(group_name="data_master_phare1")
def insert_new_data_table_cl_fresh_temp_phare1(config: sync_data_master_phare1):
    conn_details = psycopg2.connect(oltp01_conn)
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_insert_cl_fresh)
    conn_details.commit()
    cursor.close()
    conn_details.close()


@asset(group_name="data_master_phare1")
def insert_new_data_table_od_sale_order_temp_phare1(config: sync_data_master_phare1):
    conn_details = psycopg2.connect(oltp01_conn)
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_insert_od_sale_order)
    conn_details.commit()
    cursor.close()
    conn_details.close()

@asset(group_name="data_master_phare1")
def truncate_table_od_do_new_temp_phare1(config: sync_data_master_phare1):
    conn_details = psycopg2.connect(oltp01_conn)
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_truncate_od_do_new)
    conn_details.commit()
    cursor.close()
    conn_details.close()

@asset(group_name="data_master_phare1", deps=[truncate_table_od_do_new_temp_phare1])
def insert_new_data_table_od_do_new_temp_phare1(config: sync_data_master_phare1):
    conn_details = psycopg2.connect(oltp01_conn)
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_insert_od_do_new)
    conn_details.commit()
    cursor.close()
    conn_details.close()


sync_data_master_phare1 = define_asset_job(
name="sync_data_master_phare1",
selection=AssetSelection.groups("data_master_phare1"),
)

sync_data_master_phare1_schedule = ScheduleDefinition(
    job=sync_data_master_phare1,
    cron_schedule= "0 * * * *", 
    execution_timezone="Asia/Bangkok",
)
