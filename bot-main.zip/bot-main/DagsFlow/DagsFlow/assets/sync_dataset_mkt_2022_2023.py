from dagster import asset, Config, define_asset_job, ScheduleDefinition, AssetSelection, execute_job
# from DagsFlow.assets.materialized_views import mkt_budget_control
from DagsFlow.assets.utls.func import extract_from_dwh
from DagsFlow.resources.postgres import PostgresConnection
import threading


#============================================================================================================
# month 10/2022
class MktBudgetControl_10_2022(Config):
    io_format: str = "csv"
    io_abs_path: str = (
        r"Data team\Power BI (backup)\fin_mkt_10_2022_to_12_2023\fin__mkt_10_2022.csv"
    )
    sql_query: str = '''select *
                        from mart_fin__mkt_monitoring
                        where DATE("Lead Createdate") between '2022-10-01' and '2022-10-31' '''
    

@asset(
    key_prefix=["sharepoint_dataset"],
    group_name="sharepoint_dataset",
    io_manager_key="dataneyu_storage"
)
def mkt_budget_control_10_2022(oltp01_conn: PostgresConnection, config: MktBudgetControl_10_2022):
    df = extract_from_dwh(config.sql_query, oltp01_conn, return_type="pandas")
    return df

#============================================================================================================
# month 11/2022
class MktBudgetControl_11_2022(Config):
    io_format: str = "csv"
    io_abs_path: str = (
        r"Data team\Power BI (backup)\fin_mkt_10_2022_to_12_2023\fin__mkt_11_2022.csv"
    )
    sql_query: str = '''select *
                        from mart_fin__mkt_monitoring
                        where DATE("Lead Createdate") between '2022-11-01' and '2022-11-30' '''
    

@asset(
    key_prefix=["sharepoint_dataset"],
    group_name="sharepoint_dataset",
    io_manager_key="dataneyu_storage"
)
def mkt_budget_control_11_2022(oltp01_conn: PostgresConnection, config: MktBudgetControl_11_2022):
    df = extract_from_dwh(config.sql_query, oltp01_conn, return_type="pandas")
    return df

#============================================================================================================
# month 12/2022
class MktBudgetControl_12_2022(Config):
    io_format: str = "csv"
    io_abs_path: str = (
        r"Data team\Power BI (backup)\fin_mkt_10_2022_to_12_2023\fin__mkt_12_2022.csv"
    )
    sql_query: str = '''select *
                        from mart_fin__mkt_monitoring
                        where DATE("Lead Createdate") between '2022-12-01' and '2022-12-31' '''
    

@asset(
    key_prefix=["sharepoint_dataset"],
    group_name="sharepoint_dataset",
    io_manager_key="dataneyu_storage"
)
def mkt_budget_control_12_2022(oltp01_conn: PostgresConnection, config: MktBudgetControl_12_2022):
    df = extract_from_dwh(config.sql_query, oltp01_conn, return_type="pandas")
    return df

#============================================================================================================
# month 1/2023
class MktBudgetControl_01_2023(Config):
    io_format: str = "csv"
    io_abs_path: str = (
        r"Data team\Power BI (backup)\fin_mkt_10_2022_to_12_2023\fin__mkt_01_2023.csv"
    )
    sql_query: str = '''select *
                        from mart_fin__mkt_monitoring
                        where DATE("Lead Createdate") between '2023-01-01' and '2023-01-31' '''
    

@asset(
    key_prefix=["sharepoint_dataset"],
    group_name="sharepoint_dataset",
    io_manager_key="dataneyu_storage"
)
def mkt_budget_control_01_2023(oltp01_conn: PostgresConnection, config: MktBudgetControl_01_2023):
    df = extract_from_dwh(config.sql_query, oltp01_conn, return_type="pandas")
    return df

#============================================================================================================
# month 2/2023
class MktBudgetControl_02_2023(Config):
    io_format: str = "csv"
    io_abs_path: str = (
        r"Data team\Power BI (backup)\fin_mkt_10_2022_to_12_2023\fin__mkt_02_2023.csv"
    )
    sql_query: str = '''select *
                        from mart_fin__mkt_monitoring
                        where DATE("Lead Createdate") between '2023-02-01' and '2023-02-28' '''
    

@asset(
    key_prefix=["sharepoint_dataset"],
    group_name="sharepoint_dataset",
    io_manager_key="dataneyu_storage"
)
def mkt_budget_control_02_2023(oltp01_conn: PostgresConnection, config: MktBudgetControl_02_2023):
    df = extract_from_dwh(config.sql_query, oltp01_conn, return_type="pandas")
    return df

#============================================================================================================
# month 3/2023
class MktBudgetControl_03_2023(Config):
    io_format: str = "csv"
    io_abs_path: str = (
        r"Data team\Power BI (backup)\fin_mkt_10_2022_to_12_2023\fin__mkt_03_2023.csv"
    )
    sql_query: str = '''select *
                        from mart_fin__mkt_monitoring
                        where DATE("Lead Createdate") between '2023-03-01' and '2023-03-31' '''
    

@asset(
    key_prefix=["sharepoint_dataset"],
    group_name="sharepoint_dataset",
    io_manager_key="dataneyu_storage"
)
def mkt_budget_control_03_2023(oltp01_conn: PostgresConnection, config: MktBudgetControl_03_2023):
    df = extract_from_dwh(config.sql_query, oltp01_conn, return_type="pandas")
    return df

#============================================================================================================
# month 4/2023
class MktBudgetControl_04_2023(Config):
    io_format: str = "csv"
    io_abs_path: str = (
        r"Data team\Power BI (backup)\fin_mkt_10_2022_to_12_2023\fin__mkt_04_2023.csv"
    )
    sql_query: str = '''select *
                        from mart_fin__mkt_monitoring
                        where DATE("Lead Createdate") between '2023-04-01' and '2023-04-30' '''
    

@asset(
    key_prefix=["sharepoint_dataset"],
    group_name="sharepoint_dataset",
    io_manager_key="dataneyu_storage"
)
def mkt_budget_control_04_2023(oltp01_conn: PostgresConnection, config: MktBudgetControl_04_2023):
    df = extract_from_dwh(config.sql_query, oltp01_conn, return_type="pandas")
    return df

#============================================================================================================
# month 5/2023
class MktBudgetControl_05_2023(Config):
    io_format: str = "csv"
    io_abs_path: str = (
        r"Data team\Power BI (backup)\fin_mkt_10_2022_to_12_2023\fin__mkt_05_2023.csv"
    )
    sql_query: str = '''select *
                        from mart_fin__mkt_monitoring
                        where DATE("Lead Createdate") between '2023-05-01' and '2023-05-31' '''
    

@asset(
    key_prefix=["sharepoint_dataset"],
    group_name="sharepoint_dataset",
    io_manager_key="dataneyu_storage"
)
def mkt_budget_control_05_2023(oltp01_conn: PostgresConnection, config: MktBudgetControl_05_2023):
    df = extract_from_dwh(config.sql_query, oltp01_conn, return_type="pandas")
    return df

#============================================================================================================
# month 6/2023
class MktBudgetControl_06_2023(Config):
    io_format: str = "csv"
    io_abs_path: str = (
        r"Data team\Power BI (backup)\fin_mkt_10_2022_to_12_2023\fin__mkt_06_2023.csv"
    )
    sql_query: str = '''select *
                        from mart_fin__mkt_monitoring
                        where DATE("Lead Createdate") between '2023-06-01' and '2023-06-30' '''
    

@asset(
    key_prefix=["sharepoint_dataset"],
    group_name="sharepoint_dataset",
    io_manager_key="dataneyu_storage"
)
def mkt_budget_control_06_2023(oltp01_conn: PostgresConnection, config: MktBudgetControl_06_2023):
    df = extract_from_dwh(config.sql_query, oltp01_conn, return_type="pandas")
    return df

#============================================================================================================
# month 7/2023
class MktBudgetControl_07_2023(Config):
    io_format: str = "csv"
    io_abs_path: str = (
        r"Data team\Power BI (backup)\fin_mkt_10_2022_to_12_2023\fin__mkt_07_2023.csv"
    )
    sql_query: str = '''select *
                        from mart_fin__mkt_monitoring
                        where DATE("Lead Createdate") between '2023-07-01' and '2023-07-31' '''
    

@asset(
    key_prefix=["sharepoint_dataset"],
    group_name="sharepoint_dataset",
    io_manager_key="dataneyu_storage"
)
def mkt_budget_control_07_2023(oltp01_conn: PostgresConnection, config: MktBudgetControl_07_2023):
    df = extract_from_dwh(config.sql_query, oltp01_conn, return_type="pandas")
    return df

#============================================================================================================
# month 8/2023
class MktBudgetControl_08_2023(Config):
    io_format: str = "csv"
    io_abs_path: str = (
        r"Data team\Power BI (backup)\fin_mkt_10_2022_to_12_2023\fin__mkt_08_2023.csv"
    )
    sql_query: str = '''select *
                        from mart_fin__mkt_monitoring
                        where DATE("Lead Createdate") between '2023-08-01' and '2023-08-31' '''
    

@asset(
    key_prefix=["sharepoint_dataset"],
    group_name="sharepoint_dataset",
    io_manager_key="dataneyu_storage"
)
def mkt_budget_control_08_2023(oltp01_conn: PostgresConnection, config: MktBudgetControl_08_2023):
    df = extract_from_dwh(config.sql_query, oltp01_conn, return_type="pandas")
    return df

#============================================================================================================
# month 9/2023
class MktBudgetControl_09_2023(Config):
    io_format: str = "csv"
    io_abs_path: str = (
        r"Data team\Power BI (backup)\fin_mkt_10_2022_to_12_2023\fin__mkt_09_2023.csv"
    )
    sql_query: str = '''select *
                        from mart_fin__mkt_monitoring
                        where DATE("Lead Createdate") between '2023-09-01' and '2023-09-30' '''
    

@asset(
    key_prefix=["sharepoint_dataset"],
    group_name="sharepoint_dataset",
    io_manager_key="dataneyu_storage"
)
def mkt_budget_control_09_2023(oltp01_conn: PostgresConnection, config: MktBudgetControl_09_2023):
    df = extract_from_dwh(config.sql_query, oltp01_conn, return_type="pandas")
    return df

#============================================================================================================
# month 10/2023
class MktBudgetControl_10_2023(Config):
    io_format: str = "csv"
    io_abs_path: str = (
        r"Data team\Power BI (backup)\fin_mkt_10_2022_to_12_2023\fin__mkt_10_2023.csv"
    )
    sql_query: str = '''select *
                        from mart_fin__mkt_monitoring
                        where DATE("Lead Createdate") between '2023-10-01' and '2023-10-31' '''
    

@asset(
    key_prefix=["sharepoint_dataset"],
    group_name="sharepoint_dataset",
    io_manager_key="dataneyu_storage"
)
def mkt_budget_control_10_23(oltp01_conn: PostgresConnection, config: MktBudgetControl_10_2023):
    df = extract_from_dwh(config.sql_query, oltp01_conn, return_type="pandas")
    return df

#============================================================================================================
# month 11/2023
class MktBudgetControl_11_2023(Config):
    io_format: str = "csv"
    io_abs_path: str = (
        r"Data team\Power BI (backup)\fin_mkt_10_2022_to_12_2023\fin__mkt_11_2023.csv"
    )
    sql_query: str = '''select *
                        from mart_fin__mkt_monitoring
                        where DATE("Lead Createdate") between '2023-11-01' and '2023-11-30' '''
    

@asset(
    key_prefix=["sharepoint_dataset"],
    group_name="sharepoint_dataset",
    io_manager_key="dataneyu_storage"
)
def mkt_budget_control_11_23(oltp01_conn: PostgresConnection, config: MktBudgetControl_11_2023):
    df = extract_from_dwh(config.sql_query, oltp01_conn, return_type="pandas")
    return df

#============================================================================================================
# month 12/2023
class MktBudgetControl_12_2023(Config):
    io_format: str = "csv"
    io_abs_path: str = (
        r"Data team\Power BI (backup)\fin_mkt_10_2022_to_12_2023\fin__mkt_12_2023.csv"
    )
    sql_query: str = '''select *
                        from mart_fin__mkt_monitoring
                        where DATE("Lead Createdate") between '2023-12-01' and '2023-12-31' '''
    

@asset(
    key_prefix=["sharepoint_dataset"],
    group_name="sharepoint_dataset",
    io_manager_key="dataneyu_storage"
)
def mkt_budget_control_12_23(oltp01_conn: PostgresConnection, config: MktBudgetControl_12_2023):
    df = extract_from_dwh(config.sql_query, oltp01_conn, return_type="pandas")
    return df

#=============================================================================================================
# scheduler
sync_mkt_2022_2023_budget_control_job = define_asset_job(
    name="sync_mkt_2022_2023_budget_control_job",
    selection=AssetSelection.assets(mkt_budget_control_10_2022,
                                    mkt_budget_control_11_2022,
                                    mkt_budget_control_12_2022,
                                    mkt_budget_control_01_2023,
                                    mkt_budget_control_02_2023,
                                    mkt_budget_control_03_2023,
                                    mkt_budget_control_04_2023,
                                    mkt_budget_control_05_2023,
                                    mkt_budget_control_06_2023,
                                    mkt_budget_control_07_2023,
                                    mkt_budget_control_08_2023,
                                    mkt_budget_control_09_2023,
                                    mkt_budget_control_10_23,
                                    mkt_budget_control_11_23,
                                    mkt_budget_control_12_23),
)

sync_mkt_2022_2023_budget_control_schedule = ScheduleDefinition(
    job=sync_mkt_2022_2023_budget_control_job,
    cron_schedule="0 3 * * *",
    execution_timezone="Asia/Bangkok",
)
