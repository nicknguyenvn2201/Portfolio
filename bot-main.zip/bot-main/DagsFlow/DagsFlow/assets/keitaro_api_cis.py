from dagster import (
    asset,
    Output,
    AssetExecutionContext,
    MetadataValue,
    WeeklyPartitionsDefinition,
    get_dagster_logger,
    schedule,
    define_asset_job,
    ScheduleEvaluationContext,
    RunRequest,
    DailyPartitionsDefinition,
    ScheduleDefinition,
)
import os
from pyarrow import Table
import psycopg as pg
import io
import requests as rq
import pandas as pd
import os
from datetime import timedelta, date, datetime
from dateutil.relativedelta import relativedelta, WE
from DagsFlow.assets.utls.func import extract_from_dwh
from DagsFlow.assets.utls.sql import SqlStore
import connectorx as cx
import numpy as np
from DagsFlow.resources.postgres import PostgresConnection
from os import getenv
from datetime import date
import pandas as pd
import pyarrow as pa
import psycopg2 as pg
import io
from dateutil.relativedelta import relativedelta
import os
from datetime import timedelta, date, datetime
import json

logger = get_dagster_logger()
TIMEZONE = os.getenv("DAGSTER_TIMEZONE")
MB_WEEKDAY_START = relativedelta

weekly_partitions_def = WeeklyPartitionsDefinition(
    start_date="2023-06-15",
    day_offset=3,
    end_offset=1,
)

# min date of CIS data
fixed_date = datetime(2025, 1, 13) #first date have CIS data

# last 3 months data
calculated_date = datetime.today() - relativedelta(months=2)

# start_date when compare fixed_date and last_3_month
start_date = max(calculated_date, fixed_date).strftime('%Y-%m-%d')

daily_partitions_def = DailyPartitionsDefinition(
    start_date=start_date,
    end_offset=1,
)

# daily_partitions_def = DailyPartitionsDefinition(
#     start_date="2025-01-13",
#     end_offset=1,
# )

def download_keitaro_data(date_s: str, date_e: str) -> dict:
    # url = "http://206.189.150.248/admin_api/v1/report/build" --blocked 2025 01 13
    url = "http://159.223.40.164/admin_api/v1/report/build"
    headers = {
        "accept": "application/json",
        "Api-Key": getenv("KEITARO_CIS_API_KEY"),
    }
    payload = {
        "range": {
            "timezone": "Asia/Ho_Chi_Minh",
            "from": date_s,
            "to": date_e,
        },
        "metrics": [
            "campaign",
            "campaign_group",
            "device_model",
            "sub_id_1",
            "sub_id_2",
            "sub_id_3",
            "sub_id_4",
            "ad_campaign_id",
            "sub_id_8",
            "day",
            "campaign_id",
            "conversions",
            "sales",
            "revenue",
            "cost",
            "sub_id",
            "sub_id_7",
            "sale_revenue",
        ],
    }
    logger.info(payload)
    response = rq.post(url=url, headers=headers, data=json.dumps(payload))
    response.raise_for_status()  # Đảm bảo kiểm tra lỗi HTTP
    result = response.json().get("rows", [])
    return result

@asset(
    partitions_def=daily_partitions_def,
    group_name="keitaro_buyer",
)
def extract_keitaro_cis_api(context: AssetExecutionContext) -> Output[pd.DataFrame]:
    start_date, _ = context.partition_time_window
    logger.info(f"Querying data on {start_date.strftime('%Y-%m-%d')}")
    json_response = download_keitaro_data(
        date_s=start_date.strftime("%Y-%m-%d"),
        date_e=start_date.strftime("%Y-%m-%d"),
    )
    result_a = pd.json_normalize(json_response)
    df = result_a.rename(columns={"day": "datetime", "offer": "offer_k"})
    df["datetime"] = pd.to_datetime(df["datetime"], errors="ignore")
    data = pa.Table.from_pandas(
        df,
        pa.schema([
            ("campaign", "string"),
            ("campaign_group", "string"),
            ("device_model", "string"),
            ("sub_id_1", "string"),
            ("sub_id_2", "string"),
            ("sub_id_3", "string"),
            ("sub_id_4", "string"),
            ("ad_campaign_id", "string"),
            ("sub_id_8", "string"),
            ("datetime", "date32"),
            ("campaign_id", "int32"),
            ("conversions", "int32"),
            ("sales", "int32"),
            ("revenue", "float32"),
            ("cost", "float32"),
            ("sub_id", "string"),
            ("sub_id_7", "string"),
            ("sale_revenue", "float32"),
        ]),
    )
    df_converted = data.to_pandas()
    context.log.info(data)
    return Output(value=df_converted, metadata={"Count": MetadataValue.int(data.num_rows)})

@asset(
    partitions_def=daily_partitions_def,
    compute_kind="postgres",
    group_name="keitaro_buyer",
)
def load_data_keitaro_cis_api(
    context: AssetExecutionContext,
    extract_keitaro_cis_api: pd.DataFrame,
) -> None:
    df = extract_keitaro_cis_api
    date_start, _ = context.partition_time_window
    date_start = date_start.strftime("%Y-%m-%d")
    
    # Kiểm tra chuỗi kết nối
    conn_str = os.getenv("PG_LIBPQ_CONN_CONFIG")
    if not conn_str:
        raise ValueError("PG_LIBPQ_CONN_CONFIG environment variable is not set or empty")

    with pg.connect(conn_str) as connection:
        with connection.cursor() as cursor:
            cursor.execute(
                f"DELETE FROM fact_keitaro_data_cis WHERE datetime = '{date_start}'"
            )
            buffer = io.BytesIO()
            df.to_csv(buffer, index=False, encoding="utf-8")
            buffer.seek(0)
            # Đảm bảo `cursor.copy_expert` được sử dụng đúng cách
            cursor.copy_expert(
                f"COPY fact_keitaro_data_cis FROM STDIN WITH CSV HEADER",
                buffer,
            )
            buffer.seek(0)  # Reset buffer position
            total_new_lead = cursor.execute(
                f"SELECT SUM(campaign_id) FROM fact_keitaro_data_cis WHERE datetime = '{date_start}'"
            )
            context.add_output_metadata(
                metadata={"New Lead Count": MetadataValue.int(total_new_lead)}
            )

sync_mb_keitaro_cis_api_job= define_asset_job(
    name="sync_mb_keitaro__cis_api_job",
    selection=[extract_keitaro_cis_api, load_data_keitaro_cis_api],
    partitions_def=daily_partitions_def,
)

@schedule(
    job=sync_mb_keitaro_cis_api_job,
    cron_schedule="15 8,19 * * *",
    execution_timezone=TIMEZONE,
)
def sync_mb_keitaro_cis_api_schedule(context: ScheduleEvaluationContext):
    partitions = daily_partitions_def.get_partition_keys()
    for partition in partitions:
        yield RunRequest(run_key=partition, partition_key=partition)



