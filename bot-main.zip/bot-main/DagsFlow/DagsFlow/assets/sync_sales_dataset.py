from dagster import asset, Config, define_asset_job, ScheduleDefinition, AssetSelection ##
from DagsFlow.assets.materialized_views import sale_master_k
from DagsFlow.assets.utls.func import extract_from_dwh
from DagsFlow.resources.postgres import PostgresConnection



class SaleReport(Config):
    io_format: str = "csv"
    io_abs_path: str = r"Data team\Data Source - SALES\dataset_sale_report.csv"
    sql_query: str = "select * from sale_master_k"  ####


@asset(
    key_prefix=["sharepoint_dataset"],
    group_name="sharepoint_dataset",
    io_manager_key="dataneyu_storage",
    deps=[sale_master_k],
)
def Sale_report(oltp01_conn: PostgresConnection, config: SaleReport):
    df = extract_from_dwh(config.sql_query, oltp01_conn, return_type="pandas")
    df = df.drop_duplicates()
    return df


sync_sale_report_job = define_asset_job(
    name="sync_sale_report_job",
    selection=AssetSelection.assets(Sale_report),
)

sync_sale_report_schedule = ScheduleDefinition(
    job=sync_sale_report_job,
    cron_schedule="0 0 * * *",
    execution_timezone="Asia/Bangkok",
)


