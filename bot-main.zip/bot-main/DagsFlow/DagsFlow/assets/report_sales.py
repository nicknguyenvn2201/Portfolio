from dagster import (
    AssetExecutionContext,
    get_dagster_logger,
    Output,
    asset,
    MetadataValue,
    define_asset_job,
    AssetSelection,
    ScheduleDefinition,
)
import os
import pandas as pd
import numpy as np
import pandas as pd
import numpy as np
import plotly.figure_factory as ff
import plotly.express as px
from DagsFlow.resources import telegram
from DagsFlow.assets.utls.func import extract_from_dwh
from DagsFlow.resources.postgres import PostgresConnection
from DagsFlow.assets.materialized_views import mart_sales__lead_backlog

logger = get_dagster_logger()


@asset(group_name="report_sales", deps=["mart_sales__lead_backlog"])
def dataset_lead_backlog(
    context: AssetExecutionContext, oltp01_conn: PostgresConnection
) -> Output[pd.DataFrame]:
    copy_query = """select * from mart_sales__lead_backlog where "Campaign" is not null and effective_date is not null"""
    lead_backlog = extract_from_dwh(copy_query, oltp01_conn)
    # remove earliest date since it only contains partial data
    lead_backlog: pd.DataFrame = lead_backlog[
        lead_backlog["effective_date"] > lead_backlog["effective_date"].min()
    ]
    lead_backlog = lead_backlog.convert_dtypes()
    try:
        metadata_table = {
            "Table": MetadataValue.md(
                lead_backlog.pivot_table(
                    index="geo",
                    columns="effective_date",
                    values="lead_count",
                    aggfunc=np.sum,
                ).to_markdown()
            )
        }
    except Exception as e:
        logger.error(e)
        metadata_table = {"Count": len(lead_backlog)}
    return Output(value=lead_backlog, metadata=metadata_table)


def _generate_table_image(df: pd.DataFrame, column_name: str) -> bytes:
    df = (
        df.pivot_table(
            index=column_name,
            columns="effective_date",
            values="lead_count",
            aggfunc=np.sum,
        )
        .iloc[:, -1:]
        .dropna()
    )
    df = df.sort_values(by=df.columns[0], ascending=False)
    df.insert(0, column_name, "")
    df[column_name] = df.index
    df["Total %"] = (df.iloc[:, -1] / np.sum(df.iloc[:, -1])).map("{:,.2%}".format)
    df.iloc[:, -2] = df.iloc[:, -2].map(int).map("{:d}".format)
    table = ff.create_table(df)
    table.update_layout(
        title_text=f"Fresh leads report by {column_name}",
        autosize=False,
        margin=dict(l=5, r=5, t=50, b=10),
    )
    return table.to_image("jpeg", scale=1)


def _generate_line_chart_image(df: pd.DataFrame) -> bytes:
    df = df[["effective_date", "lead_count"]]
    df = df.groupby(by="effective_date").sum()
    fig = px.line(
        df,
        y="lead_count",
        text="lead_count",
        labels={"effective_date": "Date", "lead_count": "Total leads"},
    )
    fig.update_traces(textposition="bottom right")
    fig.update_layout(
        title_text=f"New lead backlog trend",
        autosize=False,
        margin=dict(l=5, r=5, t=50, b=10),
    )
    return fig.to_image("jpeg", scale=1)


@asset(
    group_name="report_sales",
)
def report_backlog_sales_my(
    dataset_lead_backlog: pd.DataFrame,
    telebot_data: telegram.TelegramBot,
    telegram_chat: telegram.TelegramChat,
) -> None:
    df = dataset_lead_backlog
    chat_id = telegram_chat.get_id("SALES_MY")
    df["effective_date"] = df["effective_date"].dt.strftime("%Y-%m-%d")
    df = df[df["geo"].isin(["MY"])]
    table_product = _generate_table_image(df, "Product")
    table_campaign = _generate_table_image(df, "Campaign")
    chart_backlog = _generate_line_chart_image(df)
    telebot_data.send_photo(chat_id, table_product)
    telebot_data.send_photo(chat_id, table_campaign)
    telebot_data.send_photo(chat_id, chart_backlog)


@asset(
    group_name="report_sales",
)
def report_backlog_sales_id(
    dataset_lead_backlog: pd.DataFrame,
    telebot_data: telegram.TelegramBot,
    telegram_chat: telegram.TelegramChat,
) -> None:
    df = dataset_lead_backlog
    chat_id = telegram_chat.get_id("SALES_ID")
    df["effective_date"] = df["effective_date"].dt.strftime("%Y-%m-%d")
    df = df[df["geo"].isin(["ID2"])]
    table_product = _generate_table_image(df, "Product")
    table_campaign = _generate_table_image(df, "Campaign")
    chart_backlog = _generate_line_chart_image(df)
    telebot_data.send_photo(chat_id, table_product)
    telebot_data.send_photo(chat_id, table_campaign)
    telebot_data.send_photo(chat_id, chart_backlog)


@asset(
    group_name="report_sales",
)
def report_backlog_sales_vn(
    dataset_lead_backlog: pd.DataFrame,
    telebot_data: telegram.TelegramBot,
    telegram_chat: telegram.TelegramChat,
) -> None:
    df = dataset_lead_backlog
    chat_id = telegram_chat.get_id("SALES_VN")
    df["effective_date"] = df["effective_date"].dt.strftime("%Y-%m-%d")
    df = df[df["geo"].isin(["VN2", "VN4"])]
    table_product = _generate_table_image(df, "Product")
    table_campaign = _generate_table_image(df, "Campaign")
    chart_backlog = _generate_line_chart_image(df)
    telebot_data.send_photo(chat_id, table_product)
    telebot_data.send_photo(chat_id, table_campaign)
    telebot_data.send_photo(chat_id, chart_backlog)


@asset(
    group_name="report_sales",
)
def report_backlog_sales_th(
    dataset_lead_backlog: pd.DataFrame,
    telebot_data: telegram.TelegramBot,
    telegram_chat: telegram.TelegramChat,
) -> None:
    df = dataset_lead_backlog
    chat_id = telegram_chat.get_id("SALES_TH")
    df["effective_date"] = df["effective_date"].dt.strftime("%Y-%m-%d")
    df = df[df["geo"].isin(["TH2"])]
    table_product = _generate_table_image(df, "Product")
    table_campaign = _generate_table_image(df, "Campaign")
    chart_backlog = _generate_line_chart_image(df)
    telebot_data.send_photo(chat_id, table_product)
    telebot_data.send_photo(chat_id, table_campaign)
    telebot_data.send_photo(chat_id, chart_backlog)


@asset(
    group_name="report_sales",
)
def report_backlog_sales_ph(
    dataset_lead_backlog: pd.DataFrame,
    telebot_data: telegram.TelegramBot,
    telegram_chat: telegram.TelegramChat,
) -> None:
    df = dataset_lead_backlog
    chat_id = telegram_chat.get_id("SALES_PH")
    df["effective_date"] = df["effective_date"].dt.strftime("%Y-%m-%d")
    df = df[df["geo"].isin(["PH"])]
    table_product = _generate_table_image(df, "Product")
    table_campaign = _generate_table_image(df, "Campaign")
    chart_backlog = _generate_line_chart_image(df)
    telebot_data.send_photo(chat_id, table_product)
    telebot_data.send_photo(chat_id, table_campaign)
    telebot_data.send_photo(chat_id, chart_backlog)

@asset(
    group_name="report_sales",
)
def report_backlog_sales_in(
    dataset_lead_backlog: pd.DataFrame,
    telebot_data: telegram.TelegramBot,
    telegram_chat: telegram.TelegramChat,
) -> None:
    df = dataset_lead_backlog
    chat_id = telegram_chat.get_id("SALES_IN")
    df["effective_date"] = df["effective_date"].dt.strftime("%Y-%m-%d")
    df = df[df["geo"].isin(["IN1"])]
    table_product = _generate_table_image(df, "Product")
    table_campaign = _generate_table_image(df, "Campaign")
    chart_backlog = _generate_line_chart_image(df)
    telebot_data.send_photo(chat_id, table_product)
    telebot_data.send_photo(chat_id, table_campaign)
    telebot_data.send_photo(chat_id, chart_backlog)

generate_lead_backlog_report_job = define_asset_job(
    name="generate_lead_backlog_report_job",
    selection=AssetSelection.assets(
        mart_sales__lead_backlog,
        dataset_lead_backlog,
        report_backlog_sales_my,
        report_backlog_sales_id,
        report_backlog_sales_vn,
        report_backlog_sales_th,
        report_backlog_sales_ph, # disable for inactivity
        report_backlog_sales_in,
    ),
)
generate_lead_backlog_report_schedule = ScheduleDefinition(
    job=generate_lead_backlog_report_job,
    cron_schedule="30 7 * * *",
    execution_timezone="Asia/Bangkok",
)
