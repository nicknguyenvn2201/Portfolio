import pandas as pd
import os
from dagster import (
    get_dagster_logger,
    asset,
    AssetExecutionContext,
    MetadataValue,
    Output,
    define_asset_job,
    ScheduleEvaluationContext,
    RunRequest,
    schedule,
    DailyPartitionsDefinition,
    RetryPolicy,
    ScheduleDefinition,
)
import io
import psycopg as pg
from DagsFlow.assets.utls import func
from typing import Iterator
import requests as rq
from datetime import date
from datetime import timedelta

logger = get_dagster_logger()
#-------------------
START_OF_HISTORY = str(date.today()- timedelta(days = 5))[0:10] #"2022-01-01"
time_partitions = DailyPartitionsDefinition(start_date=START_OF_HISTORY, end_offset=1)
TIMEZONE = os.getenv("DAGSTER_TIMEZONE")


def download_payout_in_range(
    date_start: str,
    date_end: str,
    filters: dict = {},
    max_record: int = 500,
) -> Iterator[list]:
    current_page = 1
    url = "https://tracking.affscalecpa.com/api/v2/network/reports/conversions"
    columns = [
        "added_timestamp",
        "transaction_id",
        "conversion_status",
        "offer",
        "changed_timestamp",
        "payout",
        "profit",
        "revenue",
        "sub_id1",
        "sub_id2",
        "sub_id3",
        "sub_id4",
        "sub_id5",
        "affiliate",
        "affiliate_invoice",
        "aff_click_id",
        "paid_to_affiliate",
        "advertiser_user_id",
        "advertiser",
    ]
    headers = {"Content-type": "application/json"}
    payload = {
        "rangeFrom": date_start,
        "rangeTo": date_end,
        "columns": ",".join(columns),
        "filters": filters,
    }
    while True:
        params = {
            "api-key": os.getenv("AFFSCALE_API_KEY"),
            "lang": "en",
            "perPage": max_record,
            "page": current_page,
            "sortField": "added_timestamp",
            "sortDirection": "asc",
        }
        logger.info(f"Start downloading page {current_page}...")
        response = rq.get(url=url, params=params, headers=headers, json=payload)
        result = response.json()["info"]["transactions"]
        if not len(result) and current_page == 1:
            raise ValueError(
                f"Result for from {date_start} to {date_end} is empty on the first page"
            )
        elif not len(result):
            return
        yield result
        logger.info(f"Completed downloading page {current_page}")
        if len(result) < max_record:
            return
        current_page += 1


def download_payout(
    from_date: str,
    to_date: str,
    filters: dict,
) -> list:
    logger.info(f"Downloading max payout from {from_date} to {to_date}")
    result_list = []
    for result in download_payout_in_range(from_date, to_date, filters):
        result_list.append(result)
    result = [item for items in result_list for item in items]
    return result


@asset(
    partitions_def=time_partitions,
    group_name="dim_partner_base_layer",
    retry_policy=RetryPolicy(max_retries=3, delay=60),
)
def affscale_data_from_api_base_layer(context: AssetExecutionContext) -> Output[list]:
    """Pull full data from Affscale API

    API: https://tracking.affscalecpa.com/api/v2/network/reports/conversions

    Documentation: https://developers.scaleo.io/#9eaeb165-409c-433f-80e2-a0e0ee5077f0
    """

    date_start, date_end = context.partition_time_window
    date_start = date_start.strftime("%Y-%m-%d")
    date_end = date_start
    result = download_payout(date_start, date_end, {})
    return Output(
        value=result,
        metadata={"Row Count": MetadataValue.int(len(result))},
    )


@asset(partitions_def=time_partitions, group_name="dim_partner_base_layer")
def fct_affscale_network_conversion_base_layer(
    context: AssetExecutionContext,
    affscale_data_from_api_base_layer: list,
) -> None:
    primary_col = "transaction_id"
    target_table = '"base_layer"."fct_affscale_network_conversion"'
    templater = func.SqlStore()
    df = pd.json_normalize(affscale_data_from_api_base_layer)
    date_start, date_end = context.partition_time_window
    date_start = date_start.strftime("%Y-%m-%d")
    date_end = date_end.strftime("%Y-%m-%d")

    with pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG_DB_MASTER")) as connection:
        with connection.cursor() as cursor:
            target_table_columns = func.get_table_columns(cursor, target_table)
            df = df[target_table_columns]
            buffer = io.BytesIO()
            df.to_csv(buffer, index=False, header=True)
            buffer.seek(0)
            temp_table_name = f"temp_{context.run_id}".replace("-", "_")
            cursor.execute(
                f'create temp table "{temp_table_name}" (like {target_table} including defaults) on commit drop'
            )
            logger.info(f"Created temp table {temp_table_name}")
            with cursor.copy(
                f"""copy "{temp_table_name}" from stdin with (format csv, header)"""
            ) as copy:
                logger.info("Start copying data into temp table")
                copy.write(buffer.read())
            logger.info("Completed copying data into temp table")
            non_primary_cols = list(
                filter(lambda x: x != primary_col, target_table_columns)
            )
            upsert_statement = templater.get(
                "upsert_affscale_network_conversion"
            ).render(
                target_table=target_table,
                temp_table_name=temp_table_name,
                primary_col=primary_col,
                non_primary_cols=non_primary_cols,
            )
            logger.info("Start upserting master table")
            cursor.execute(upsert_statement)
            logger.info("Completed upserting master table")
            new_row_count = cursor.execute(
                f"select count(*) from {target_table} where added_timestamp >= '{date_start}' and added_timestamp < '{date_end}'"
            ).fetchone()
            context.add_output_metadata(
                metadata={"Row Count": MetadataValue.int(new_row_count[0])}
            )


@asset(group_name="dim_partner_base_layer", deps=["fct_affscale_network_conversion_base_layer"])
def ods_affscale_conversion_base_layer(context: AssetExecutionContext) -> None:
    target_table = '"base_layer"."ods_affscale_conversion"'
    templater = func.SqlStore()
    with pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG_DB_MASTER")) as connection:
        with connection.cursor() as cursor:
            insert_statement = templater.get("insert_approved_ods_conversion_base_layer").render()
            logger.info("Start inserting into target table")
            cursor.execute(insert_statement)
            logger.info("Completed inserting into target table")
            new_row_count = cursor.execute(
                f"select count(*) from {target_table}"
            ).fetchone()
            context.add_output_metadata(
                metadata={"New Row Count": MetadataValue.int(new_row_count[0])}
            )


update_fct_affscale_network_conversion_job_base_layer = define_asset_job(
    "update_fct_affscale_network_conversion_job_base_layer",
    selection=[
        fct_affscale_network_conversion_base_layer,
        affscale_data_from_api_base_layer,
    ],
    partitions_def=time_partitions,
)


@schedule(
    job=update_fct_affscale_network_conversion_job_base_layer,
    cron_schedule="0,15,30,45 8,9,10,11,12,13,14,15,16,17,18,19,20,21,22 * * *", # cron_schedule="5 0 * * *",
    execution_timezone=TIMEZONE,
    tags={"dagster/priority": "-1"},
)
def update_fct_affscale_network_conversion_base_layer_schedule(context: ScheduleEvaluationContext):
    partitions = time_partitions.get_partition_keys()[-45:]
    for partition in partitions:
        yield RunRequest(
            run_key=partition, partition_key=partition, tags={"dagster/priority": "-1"}
        )


update_ods_affscale_conversion_job_base_layer = define_asset_job(
    "update_ods_affscale_conversion_job_base_layer",
    selection=[
        ods_affscale_conversion_base_layer,
    ],
)

update_ods_affscale_conversion_base_layer_schedule = ScheduleDefinition(
    job=update_ods_affscale_conversion_job_base_layer,
    cron_schedule="10,25,40,55 8,9,10,11,12,13,14,15,16,17,18,19,20,21,22 * * *", # cron_schedule="30 0 * * *",
    execution_timezone=TIMEZONE,
)
