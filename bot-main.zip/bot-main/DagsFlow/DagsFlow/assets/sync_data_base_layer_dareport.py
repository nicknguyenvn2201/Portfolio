# inherit from user_input.py

import pandas as pd
from datetime import datetime, date
from dagster import (
    asset,
    get_dagster_logger,
    Output,
    MetadataValue,
    define_asset_job,
    AssetSelection,
    ScheduleDefinition,
    Config,
)

from DagsFlow.assets.utls.func import (
    add_blocking_checks_to_asset,
    create_load_to_postgres_asset_db_master,
    create_download_from_sharepoint_asset_base_layer,
)
from DagsFlow.assets.utls.checks import CheckDupDateRange, CheckDupDim, CheckNullColumn
from DagsFlow.assets.utls.func import extract_from_dwh
import pyarrow as pa
import numpy as np
from DagsFlow.resources.msgraph import MSSiteClient
from DagsFlow.resources.postgres import PostgresConnection
import io

logger = get_dagster_logger()


def _df_col_convert_to_float(
    df: pd.DataFrame, col_name: str, is_percentage: bool = False
):
    df = df.copy()
    if is_percentage:
        df[col_name] = df[col_name].str.replace("%", "")
    df[col_name] = df[col_name].str.replace("-", "")
    df[col_name] = df[col_name].str.replace(",", "")
    df[col_name] = pd.to_numeric(df[col_name])
    if is_percentage:
        df[col_name] = df[col_name] / 100
    return df


def _trim_all_columns_base_layer(df: pd.DataFrame) -> pd.DataFrame:
    """
    Trim whitespace from ends of each value across all series in dataframe
    """
    trim_strings = lambda x: x.strip() if isinstance(x, str) else x
    return df.applymap(trim_strings)

# 1. dim_bd_aov_target
@asset(group_name="dim_user_db_master")
def extract_bd_aov_target_base_layer() -> Output[pa.Table]:
    """
    Ingest Bd Aov Target from Web
    """
    df = pd.read_csv(
        r"https://docs.google.com/spreadsheets/d/e/2PACX-1vTsKC77L1DlOcUuta7bflrrRAusPQbOWSM0OggYBFEQ-sYrVBOqL_JRDJTWWX7w7caMEKWyOYE0xzqm/pub?gid=544925897&single=true&output=csv",
        dtype=str,
    )
    df = df.dropna(how="all")
    df = df.rename(
        columns={
            "OFFER": "offer",
            "PUB": "pub",
            "DEAL": "deal",
            "GEO": "geo",
            "AOV TARGET": "aov_target",
            "FROM": "from_date",
            "TO": "to_date",
        },
        errors="raise",
    )
    df["aov_target"] = df["aov_target"].apply(lambda x: float(x.replace(",", ".")))
    df["from_date"] = pd.to_datetime(
        df["from_date"],
        format="%d/%m/%Y",
        errors="ignore",
    )
    df["to_date"] = pd.to_datetime(
        df["to_date"],
        format="%d/%m/%Y",
        errors="ignore",
    )
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("offer", "string"),
                ("pub", "string"),
                ("deal", "string"),
                ("geo", "string"),
                ("aov_target", "float32"),
                ("from_date", "date32"),
                ("to_date", "date32"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


extract_bd_aov_target_base_layer = add_blocking_checks_to_asset(
    extract_bd_aov_target_base_layer,
    checks=[
        CheckDupDateRange(
            from_date_col="from_date",
            to_date_col="to_date",
            partitions="geo,pub,offer",
        ),
    ],
)

load_bd_aov_target_base_layer = create_load_to_postgres_asset_db_master(
    asset_name="load_bd_aov_target_base_layer",
    source_assets=[extract_bd_aov_target_base_layer],
    target_table='"base_layer"."dim_bd_aov_target"',
)




# 2. dim_cpl_target
@asset(group_name="dim_user_db_master")
def extract_cpl_target_base_layer() -> Output[pa.Table]:
    """
    Ingest Cpl Target from Web
    """
    df = pd.read_csv(
        r"https://docs.google.com/spreadsheets/d/e/2PACX-1vTsKC77L1DlOcUuta7bflrrRAusPQbOWSM0OggYBFEQ-sYrVBOqL_JRDJTWWX7w7caMEKWyOYE0xzqm/pub?gid=1385585103&single=true&output=csv",
        dtype=str,
    )
    df = df.dropna(how="all")
    df = df.rename(
        columns={
            "Offer": "offer",
            "Pub": "pub",
            "AR_Target": "ar_target",
            "DR_target": "dr_target",
            "AOV_Target": "aov_target",
            "SPL_MRP": "spl_mrp",
            "FROM": "from_date",
            "TO": "to_date",
        },
        errors="raise",
    )
    df["ar_target"] = df["ar_target"].apply(lambda x: int(x[:-1]) / 100)
    df["dr_target"] = df["dr_target"].apply(lambda x: int(x[:-1]) / 100)
    df["aov_target"] = df["aov_target"].apply(lambda x: float(x.replace(",", ".")))
    df["spl_mrp"] = df["spl_mrp"].apply(lambda x: float(x.replace(",", ".")))
    df["from_date"] = pd.to_datetime(df["from_date"], format="%d/%m/%Y")
    df["to_date"] = pd.to_datetime(df["to_date"], format="%d/%m/%Y")
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("offer", "string"),
                ("pub", "string"),
                ("ar_target", "float32"),
                ("dr_target", "float32"),
                ("aov_target", "float32"),
                ("spl_mrp", "float32"),
                ("from_date", "date32"),
                ("to_date", "date32"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


extract_cpl_target_base_layer = add_blocking_checks_to_asset(
    extract_cpl_target_base_layer,
    checks=[
        CheckDupDateRange(
            from_date_col="from_date",
            to_date_col="to_date",
            partitions="pub,offer",
        ),
        CheckNullColumn(),
    ],
)

load_cpl_target_base_layer = create_load_to_postgres_asset_db_master(
    asset_name="load_cpl_target_base_layer",
    source_assets=[extract_cpl_target_base_layer],
    target_table='"base_layer"."dim_cpl_target"',
)

# 3. cdm_dim_product_cat
@asset(group_name="dim_user_db_master")
def extract_product_cat_base_layer() -> Output[pa.Table]:
    """
    Ingest Product Category from Web
    """
    df = pd.read_csv(
        r"https://docs.google.com/spreadsheets/d/e/2PACX-1vTcG-kxHSLF6EFbP8Z9GfaRxhZuABuWFZRNfag4dq_IXM5AF050A_THx9Egu7xaog/pub?gid=162579363&single=true&output=csv",
        dtype=str,
    )
    df = df.dropna(how="all")
    df = df.rename(
        columns={
            "productname": "product_name",
            "Category": "category",
        },
        errors="raise",
    )
    df["last_update"] = datetime.now().strftime("%Y-%m-%d, %H:%M")

    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("product_name", "string"),
                ("category", "string"),
                ("geo", "string"),
                ("FIN camp", "string"),
                ("last_update", "string"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


load_product_cat_base_layer = create_load_to_postgres_asset_db_master(
    asset_name="load_product_cat_base_layer",
    source_assets=[extract_product_cat_base_layer],
    target_table='"base_layer"."cdm_dim_product_cat"',
)

download_fin_input_roi_base_layer = create_download_from_sharepoint_asset_base_layer(
    asset_name="download_fin_input_roi_base_layer",
    path_to_file="BD - Finance/[Global] Finance Input - ROI.xlsx",
    link=r"https://neyucom.sharepoint.com/sites/DATANEYU/_layouts/15/Doc.aspx?sourcedoc=%7B0F358821-88C2-485A-ADA7-0DF147E3327F%7D&file=[Global]%20Finance%20Input%20-%20ROI.xlsx&action=default&mobileredirect=true",
)

# 4. dim_bd_aov_dr_target
@asset(compute_kind="postgres", group_name="dim_user_db_master")
def extract_dim_bd_aov_dr_target_base_layer(download_fin_input_roi_base_layer: bytes) -> Output[pa.Table]:
    df = pd.read_excel(download_fin_input_roi_base_layer, sheet_name="AOV&DR&Lead")
    df = _trim_all_columns_base_layer(df)
    df["Daily_approved_Target"] = (
        df["Daily_approved_Target"].astype(str).str.replace(",", "").astype(int)
    )
    df["week_num_target"] = df["week_num_target"].astype(int)
    df["target_year"] = df["target_year"].astype(int)
    df = df.dropna(how="all")
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("CATEGORY", "string"),
                ("GEO", "string"),
                ("AOV_TARGET", "float32"),
                ("DR_TARGET", "float32"),
                ("Daily_approved_Target", "int32"),
                ("week_num_target", "int32"),
                ("target_year", "int32"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


load_dim_bd_aov_dr_target_base_layer = create_load_to_postgres_asset_db_master(
    asset_name="dim_bd_aov_dr_target_base_layer",
    source_assets=[extract_dim_bd_aov_dr_target_base_layer],
    target_table='"base_layer"."dim_bd_aov_dr_target"',
)

# 5. dim_bd_daily_lead_target
@asset(group_name="dim_user_db_master")
def extract_dim_bd_daily_lead_target_base_layer(download_fin_input_roi_base_layer: bytes) -> Output[pa.Table]:
    df = pd.read_excel(download_fin_input_roi_base_layer, sheet_name="Daily lead target")
    df = _trim_all_columns_base_layer(df)
    df = df[
        [
            "target_year",
            "week_num_target",
            "bd_manager",
            "network",
            "bd_level",
            "lead_level",
        ]
    ]
    df["week_num_target"] = df["week_num_target"].astype(int)
    df["target_year"] = df["target_year"].astype(int)
    df["network"] = df["network"].astype(str)
    df = df.dropna(how="all")
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("target_year", "int32"),
                ("week_num_target", "int32"),
                ("bd_manager", "string"),
                ("network", "string"),
                ("bd_level", "string"),
                ("lead_level", "string"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


load_dim_bd_daily_lead_target_base_layer = create_load_to_postgres_asset_db_master(
    asset_name="load_dim_bd_daily_lead_target_base_layer",
    source_assets=[extract_dim_bd_daily_lead_target_base_layer],
    target_table='"base_layer"."dim_bd_daily_lead_target"',
)

# 6. dim_bd_lead_level_by_date
@asset(group_name="dim_user_db_master")
def extract_dim_bd_lead_level_by_date_base_layer(
    download_fin_input_roi_base_layer: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(download_fin_input_roi_base_layer, sheet_name="Lead level by date")
    df = _trim_all_columns_base_layer(df)
    df["Started_date"] = pd.to_datetime(df["Started_date"])
    df["Ending_date"] = pd.to_datetime(df["Ending_date"])
    df["Official Approval"] = pd.to_datetime(df["Official Approval"])
    df["network"] = df["network"].astype(str)
    df["Manager"] = df["Manager"].astype(str)
    df["lead_level"] = df["lead_level"].astype(str)
    df = df.dropna(how="all")
    df = df[
        [
            "network",
            "Manager",
            "lead_level",
            "Official Approval",
            "Started_date",
            "Ending_date",
        ]
    ]
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("network", "string"),
                ("Manager", "string"),
                ("lead_level", "string"),
                ("Official Approval", "date32"),
                ("Started_date", "date32"),
                ("Ending_date", "date32"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


load_dim_bd_lead_level_by_date_base_layer = create_load_to_postgres_asset_db_master(
    asset_name="load_dim_bd_lead_level_by_date_base_layer",
    source_assets=[extract_dim_bd_lead_level_by_date_base_layer],
    target_table='"base_layer"."dim_bd_lead_level_by_date"',
)

# 7. dim_bd_aff_revenue_target
@asset(group_name="dim_user_db_master")
def extract_dim_bd_aff_revenue_target_base_layer(
    download_fin_input_roi_base_layer: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(download_fin_input_roi_base_layer, sheet_name="Aff revenue target")
    df = _trim_all_columns_base_layer(df)
    df["week_num_target"] = df["week_num_target"].astype(int)
    df["target_year"] = df["target_year"].astype(int)
    df["aff_revenue_target"] = (
        df["aff_revenue_target"].astype(str).str.replace(",", "").astype(int)
    )
    df["estimate_daily_lead"] = (
        df["estimate_daily_lead"].astype(str).str.replace(",", "").astype(int)
    )
    df["daily_approved_lead"] = (
        df["daily_approved_lead"].astype(str).str.replace(",", "").astype(int)
    )
    df["daily_delivered_lead"] = (
        df["daily_delivered_lead"].astype(str).str.replace(",", "").astype(int)
    )
    df = df.dropna(how="all")
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("target_year", "int32"),
                ("week_num_target", "int32"),
                ("bd_manager", "string"),
                ("aff_revenue_target", "int32"),
                ("estimate_daily_lead", "int32"),
                ("daily_approved_lead", "int32"),
                ("daily_delivered_lead", "int32"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


load_dim_bd_aff_revenue_target_base_layer = create_load_to_postgres_asset_db_master(
    asset_name="load_dim_bd_aff_revenue_target_base_layer",
    source_assets=[extract_dim_bd_aff_revenue_target_base_layer],
    target_table='"base_layer"."dim_bd_aff_revenue_target"',
)

# 8. dim_bd_gm_input
@asset(group_name="dim_user_db_master")
def extract_dim_bd_gm_input_base_layer(download_fin_input_roi_base_layer: bytes) -> Output[pa.Table]:
    df = pd.read_excel(download_fin_input_roi_base_layer, sheet_name="GM Input")
    df = _trim_all_columns_base_layer(df)
    df = df.dropna(how="all")
    df["index"] = df.index
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("index", "int32"),
                ("started_date", "date32"),
                ("ending_date", "date32"),
                ("geo", "string"),
                ("tax_rate", "float32"),
                ("tele_rate", "float32"),
                ("commission_rate", "float32"),
                ("bd_comm_rate", "float32"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


load_dim_bd_gm_input_base_layer = create_load_to_postgres_asset_db_master(
    asset_name="load_dim_bd_gm_input_base_layer",
    source_assets=[extract_dim_bd_gm_input_base_layer],
    target_table='"base_layer"."dim_bd_gm_input"',
)

# 9. dim_bd_unit_cost
@asset(group_name="dim_user_db_master")
def extract_dim_bd_unit_cost_base_layer(download_fin_input_roi_base_layer: bytes) -> Output[pa.Table]:
    df = pd.read_excel(download_fin_input_roi_base_layer, sheet_name="Unit Cost")
    df = _trim_all_columns_base_layer(df)
    df = df.dropna(how="all")
    df["index"] = df.index
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("index", "int32"),
                ("started_date", "date32"),
                ("geo", "string"),
                ("offer", "string"),
                ("unit_cost", "float32"),
                ("ending_date", "date32"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


load_dim_bd_unit_cost_base_layer = create_load_to_postgres_asset_db_master(
    asset_name="load_dim_bd_unit_cost_base_layer",
    source_assets=[extract_dim_bd_unit_cost_base_layer],
    target_table='"base_layer"."dim_bd_unit_cost"',
)

# 10. dim_bd_log_cost
@asset(group_name="dim_user_db_master")
def extract_dim_bd_log_cost_base_layer(download_fin_input_roi_base_layer: bytes) -> Output[pa.Table]:
    df = pd.read_excel(download_fin_input_roi_base_layer, sheet_name="Log cost")
    df = _trim_all_columns_base_layer(df)
    df = df[
        [
            "started_date",
            "ending_date",
            "geo",
            "courier",
            "ffm_fee",
            "lm_fee",
            "return_rate",
            "cod_rate",
            "portion",
        ]
    ]
    df = df.dropna(how="all")
    df["index"] = df.index
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("index", "int32"),
                ("started_date", "date32"),
                ("ending_date", "date32"),
                ("geo", "string"),
                ("courier", "string"),
                ("ffm_fee", "float32"),
                ("lm_fee", "float32"),
                ("return_rate", "float32"),
                ("cod_rate", "float32"),
                ("portion", "int32"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


load_dim_bd_log_cost_base_layer = create_load_to_postgres_asset_db_master(
    asset_name="load_dim_bd_log_cost_base_layer",
    source_assets=[extract_dim_bd_log_cost_base_layer],
    target_table='"base_layer"."dim_bd_log_cost"',
)


download_bd_fin_forecast_target_base_layer = create_download_from_sharepoint_asset_base_layer(
    asset_name="download_bd_fin_forecast_target_base_layer",
    path_to_file="BD - Finance/Forecast- target special deal.xlsx",
    link=r"https://neyucom.sharepoint.com/sites/DATANEYU/_layouts/15/Doc.aspx?sourcedoc=%7B74A04C95-5C1A-46E3-8C6C-9898039B93A8%7D&file=Forecast-%20target%20special%20deal.xlsx&action=default&mobileredirect=true",
)

# 11. dim_follow_up_deal_target
@asset(group_name="dim_user_db_master", metadata={"Owner": "anh.ngo.2@neyu.co"})
def extract_dim_follow_up_deal_target_base_layer(
    download_bd_fin_forecast_target_base_layer: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(
        download_bd_fin_forecast_target_base_layer,
        sheet_name="Target- follow up deal",
        dtype={
            "Geo": str,
            "Pub": str,
            "Offer": str,
            "Type": str,
            "Start date": str,
            "end date": str,
            "Lead MRP": int,
            "AR_MRP": float,
            "AOV_MRP": float,
            "SPL target": float,
            "DR_MRP": float,
            r"%Lead cost MRP": float,
            r"%GM1 MRP": float,
            r"%GM2 MRP": float,
        },
    )
    df = df.dropna(how="all")
    df["Start date"] = pd.to_datetime(df["Start date"], infer_datetime_format=True)
    df["end date"] = pd.to_datetime(df["end date"], infer_datetime_format=True)
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("Geo", "string"),
                ("Pub", "string"),
                ("Offer", "string"),
                ("Type", "string"),
                ("Start date", "date32"),
                ("end date", "date32"),
                ("Lead MRP", "int32"),
                ("AR_MRP", "float32"),
                ("AOV_MRP", "float64"),
                ("SPL target", "float64"),
                ("DR_MRP", "float32"),
                (r"%Lead cost MRP", "float32"),
                (r"%GM1 MRP", "float32"),
                (r"%GM2 MRP", "float32"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


extract_dim_follow_up_deal_target_base_layer = add_blocking_checks_to_asset(
    extract_dim_follow_up_deal_target_base_layer,
    checks=[
        CheckDupDateRange(
            from_date_col='"Start date"',
            to_date_col='"end date"',
            partitions="Geo,Pub,Offer",
        ),
    ],
)

load_dim_follow_up_deal_target_base_layer = create_load_to_postgres_asset_db_master(
    asset_name="load_dim_follow_up_deal_target_base_layer",
    source_assets=[extract_dim_follow_up_deal_target_base_layer],
    target_table='"base_layer"."dim_follow_up_deal_target"',
)


download_fin_perf_monitor_input_base_layer = create_download_from_sharepoint_asset_base_layer(
    asset_name="download_fin_perf_monitor_input_base_layer",
    path_to_file="BD - Finance/Performance Monitoring Input.xlsx",
    link=r"https://neyucom.sharepoint.com/sites/DATANEYU/_layouts/15/Doc.aspx?sourcedoc=%7B37640033-D271-47EF-8DC7-93CBA11557B8%7D&file=Performance%20Monitoring%20Input.xlsx&action=default&mobileredirect=true",
)

# 12. dim_finance_agent_type
@asset(
    group_name="dim_user_db_master",
    metadata={
        "Owner": "daniel.ha@neyu.co",
    },
)
def extract_dim_finance_agent_type_base_layer(
    download_fin_perf_monitor_input_base_layer: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(
        download_fin_perf_monitor_input_base_layer,
        sheet_name="dim_agent_type",
        dtype={
            "country_code": str,
            "agent_name": str,
            "type": str,
            "resell_account": str,
        },
    )
    df = df.dropna(how="all")
    df["type"] = df["type"].str.upper()
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("country_code", "string"),
                ("agent_name", "string"),
                ("type", "string"),
                ("resell_account", "string"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


load_dim_finance_agent_type_base_layer = create_load_to_postgres_asset_db_master(
    asset_name="load_dim_finance_agent_type_base_layer",
    source_assets=[extract_dim_finance_agent_type_base_layer],
    target_table='"base_layer"."dim_finance_agent_type"',
)


download_dim_bd_team_level_input_base_layer = create_download_from_sharepoint_asset_base_layer(
    asset_name="download_dim_bd_team_level_input_base_layer",
    path_to_file="BD - Finance/BD_INPUT/bd_team_level_input.xlsx",
    link=r"https://neyucom.sharepoint.com/:x:/r/sites/DATANEYU/_layouts/15/Doc.aspx?sourcedoc=%7B6e16d33a-d8a0-4cea-9b63-2b6640f2b2bc%7D&action=editnew",
)

# 13. dim_bd_team_level_input
@asset(
    group_name="dim_user_db_master",
    metadata={
        "Owner": "jane@neyu.co",
    },
)
def extract_dim_bd_team_level_input_base_layer(
    download_dim_bd_team_level_input_base_layer: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(
        download_dim_bd_team_level_input_base_layer,
        sheet_name="bd_level",
    )
    df = df.dropna(how="all")
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("bd_level_1", "string"),
                ("bd_level_2", "string"),
                ("bd_level_3", "string"),
                ("head_level", "string"),
                ("manager", "string"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


extract_dim_bd_team_level_input_base_layer = add_blocking_checks_to_asset(
    extract_dim_bd_team_level_input_base_layer,
    checks=[
        CheckDupDim("bd_level_1,bd_level_2,bd_level_3,head_level,manager"),
        CheckNullColumn(),
    ],
)

load_dim_bd_team_level_input_base_layer = create_load_to_postgres_asset_db_master(
    asset_name="load_dim_bd_team_level_input_base_layer",
    source_assets=[extract_dim_bd_team_level_input_base_layer],
    target_table='"base_layer"."dim_bd_team_level_input"',
)


## ##
download_dim_agent_mrp_base_layer = create_download_from_sharepoint_asset_base_layer(
    asset_name="download_dim_agent_mrp_base_layer",
    path_to_file="Sale/agent_mrp.xlsx",
    link=r"https://neyucom.sharepoint.com/:x:/r/sites/DATANEYU/_layouts/15/Doc.aspx?sourcedoc=%7BED4DF01F-FD1F-4374-894D-C154F3F83816%7D&file=agent_mrp.xlsx&action=default&mobileredirect=true",
)

# 14. dim_agent_mrp_rpl
@asset(
    group_name="dim_user_db_master",
    metadata={
        "Owner": "hai.nguyen@neyu.co",
    },
)
def extract_dim_agent_mrp_rpl_base_layer(
    download_dim_agent_mrp_base_layer: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(
        download_dim_agent_mrp_base_layer,
        sheet_name="dim_agent_armrp_rpl",
        dtype={
            "geo": str,
            "camp": str,
            "armrp": float,
            "rpl": float,
            "max_cap": int,
            "optimum_cap": int,
            "from": str,
            "to": str,
        },
    )
    df = df.dropna(how="all")
    df["from"] = pd.to_datetime(df["from"], infer_datetime_format=True)
    df["to"] = pd.to_datetime(df["to"], infer_datetime_format=True)
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("geo", "string"),
                ("camp", "string"),
                ("armrp", "float32"),
                ("rpl", "float32"),
                ("max_cap", "int32"),
                ("optimum_cap", "int32"),
                ("from", "date32"),
                ("to", "date32"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


extract_dim_agent_mrp_rpl_base_layer = add_blocking_checks_to_asset(
    extract_dim_agent_mrp_rpl_base_layer,
    checks=[
        CheckDupDateRange(
            from_date_col='"from"',
            to_date_col='"to"',
            partitions="geo,camp",
        ),
    ],
)


load_dim_agent_mrp_rpl_base_layer = create_load_to_postgres_asset_db_master(
    asset_name="load_dim_agent_mrp_rpl_base_layer",
    source_assets=[extract_dim_agent_mrp_rpl_base_layer],
    target_table='"base_layer"."dim_agent_mrp_rpl"',
)

# 15. dim_agent_dr_aov_mrp
@asset(
    group_name="dim_user_db_master",
    metadata={
        "Owner": "hai.nguyen@neyu.co",
    },
)
def extract_dim_agent_dr_aov_mrp_base_layer(
    download_dim_agent_mrp_base_layer: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(
        download_dim_agent_mrp_base_layer,
        sheet_name="dim_agent_dr_aov_mrp",
        dtype={
            "geo": str,
            "camp": str,
            "dr_mrp": float,
            "aov_mrp": float,
            "from": str,
            "to": str,
        },
    )
    df = df.dropna(how="all")
    df["from"] = pd.to_datetime(df["from"], infer_datetime_format=True)
    df["to"] = pd.to_datetime(df["to"], infer_datetime_format=True)
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("geo", "string"),
                ("camp", "string"),
                ("dr_mrp", "float32"),
                ("aov_mrp", "float32"),
                ("from", "date32"),
                ("to", "date32"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


extract_dim_agent_dr_aov_mrp_base_layer = add_blocking_checks_to_asset(
    extract_dim_agent_dr_aov_mrp_base_layer,
    checks=[
        CheckDupDateRange(
            from_date_col='"from"',
            to_date_col='"to"',
            partitions="geo,camp",
        ),
    ],
)


load_dim_agent_dr_aov_mrp_base_layer = create_load_to_postgres_asset_db_master(
    asset_name="load_dim_agent_dr_aov_mrp_base_layer",
    source_assets=[extract_dim_agent_dr_aov_mrp_base_layer],
    target_table='"base_layer"."dim_agent_dr_aov_mrp"',
)



download_bd_fin_dr_forecast_mapping_base_layer = create_download_from_sharepoint_asset_base_layer(
    asset_name="download_bd_fin_dr_forecast_mapping_base_layer",
    path_to_file="BD - Finance/DR_Forecast_mapping.xlsx",
    link=r"https://neyucom.sharepoint.com/:x:/r/sites/DATANEYU/_layouts/15/Doc.aspx?sourcedoc=%7B33366926-6A38-49D4-8B5E-D82DB1C69E52%7D&file=DR_Forecast_mapping.xlsx&action=default&mobileredirect=true",
)

# 16. dim_dr_manual_forecast
@asset(group_name="dim_user_db_master", metadata={"Owner": "linh.nguyen@neyu.co"})
def extract_dim_dr_manual_forecast_base_layer(
    download_bd_fin_dr_forecast_mapping_base_layer: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(
        download_bd_fin_dr_forecast_mapping_base_layer,
        sheet_name="dr_forecast_manual",
        dtype={
            "country_code": str,
            "network": str,
            "offer": str,
            "dr_forecast": float,
            "from": str,
            "to": str,
        },
    )
    df = df.dropna(how="all")
    df["from"] = pd.to_datetime(df["from"], infer_datetime_format=True)
    df["to"] = pd.to_datetime(df["to"], infer_datetime_format=True)
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("country_code", "string"),
                ("network", "string"),
                ("offer", "string"),
                ("dr_forecast", "float32"),
                ("from", "date32"),
                ("to", "date32"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


extract_dim_dr_manual_forecast_base_layer = add_blocking_checks_to_asset(
    extract_dim_dr_manual_forecast_base_layer,
    checks=[
        CheckDupDateRange(
            from_date_col='"from"',
            to_date_col='"to"',
            partitions="country_code,network,offer",
        ),
    ],
)

load_dim_dr_manual_forecast_base_layer = create_load_to_postgres_asset_db_master(
    asset_name="load_dim_dr_manual_forecast_base_layer",
    source_assets=[extract_dim_dr_manual_forecast_base_layer],
    target_table='"base_layer"."dim_dr_manual_forecast"',
)

#17.dim_agent
@asset(group_name="dim_user_db_master")
def extract_dim_agent_with_vn() -> Output[pa.Table]:
    """
    Ingest dim_agent VN from Web
    """
    source_url = {
        "VN": r"https://docs.google.com/spreadsheets/d/e/2PACX-1vRfB7GrkGEtwHTM_Ii_BrSdIOo2eW7SUAtLlvWCP8h5WR7U6tX8mtTsl2lSdZxuww/pub?gid=1767163213&single=true&output=csv",
    }
    df = pd.read_csv(source_url["VN"])
    df = _trim_all_columns_base_layer(df)
    df.drop_duplicates(inplace=True)
    df["geo"] = "VN"
    df = df[["agent_name", "email", "team", "team_lead", "sup", "geo"]]
    #df = df.dropna(subset=["agent_name", "email"])
    df = df.drop_duplicates(subset=["geo", "email"])
    df["index"] = df.index
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("index", "int32"),
                ("agent_name", "string"),
                ("email", "string"),
                ("team", "string"),
                ("team_lead", "string"),
                ("sup", "string"),
                ("geo", "string"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


@asset(group_name="dim_user_db_master")
def extract_dim_agent_with_id() -> Output[pa.Table]:
    """
    Ingest dim_agent ID from Web
    """
    source_url = {
        "ID": r"https://docs.google.com/spreadsheets/d/e/2PACX-1vT4xuxpk4HhC9O6WFAdCsoJPCqieqvZt1WExuFUxMFtOpxgf_R2H1pBU0_MnxlL_A/pub?gid=1177032992&single=true&output=csv",
    }
    df = pd.read_csv(source_url["ID"])
    df = df[~df["Agent ID"].isnull()]
    df = _trim_all_columns_base_layer(df)
    df.drop_duplicates(inplace=True)
    df["geo"] = "ID"
    df = df[["agent_name", "email", "team", "team_lead", "sup", "geo"]]
    df = df.dropna(subset=["agent_name", "email"])
    df = df.drop_duplicates(subset=["geo", "email"])
    df["index"] = df.index
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("index", "int32"),
                ("agent_name", "string"),
                ("email", "string"),
                ("team", "string"),
                ("team_lead", "string"),
                ("sup", "string"),
                ("geo", "string"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


@asset(group_name="dim_user_db_master")
def extract_dim_agent_with_th() -> Output[pa.Table]:
    """
    Ingest dim_agent TH from Web
    """
    source_url = {
        "TH": r"https://docs.google.com/spreadsheets/d/e/2PACX-1vSTTzQp74ytvJyV7d51jkAwrIH4YaYWrpCxIoAQWohDn5knFGc_m7WcMgDyiskxXQ/pub?gid=1474627709&single=true&output=csv",
    }
    df = pd.read_csv(source_url["TH"])
    df = _trim_all_columns_base_layer(df)
    df.drop_duplicates(inplace=True)
    df["geo"] = "TH"
    df = df[["agent_name", "email", "team", "team_lead", "sup", "geo"]]
    df = df.dropna(subset=["agent_name", "email"])
    df = df.drop_duplicates(subset=["geo", "email"])
    df["index"] = df.index
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("index", "int32"),
                ("agent_name", "string"),
                ("email", "string"),
                ("team", "string"),
                ("team_lead", "string"),
                ("sup", "string"),
                ("geo", "string"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


@asset(group_name="dim_user_db_master")
def extract_dim_agent_with_my() -> Output[pa.Table]:
    """
    Ingest dim_agent MY from Web
    """
    source_url = {
        "MY": r"https://docs.google.com/spreadsheets/d/e/2PACX-1vTlnUYFDMTgntDtYij5bdgjBwM7wEtzkRfWy9NOocwEiR9ZYvhVYTxsZe-lkFn8Rg/pub?gid=1799419456&single=true&output=csv",
    }
    df = pd.read_csv(source_url["MY"])
    df = _trim_all_columns_base_layer(df)
    df.drop_duplicates(inplace=True)
    df["geo"] = "MY"
    df = df[["agent_name", "email", "team", "team_lead", "sup", "geo"]]
    df = df.dropna(subset=["agent_name", "email"])
    df = df.drop_duplicates(subset=["geo", "email"])
    df["index"] = df.index
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("index", "int32"),
                ("agent_name", "string"),
                ("email", "string"),
                ("team", "string"),
                ("team_lead", "string"),
                ("sup", "string"),
                ("geo", "string"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


load_dim_agent = create_load_to_postgres_asset_db_master(
    asset_name="load_dim_agent_base_layer",
    source_assets=[
        extract_dim_agent_with_vn,
        extract_dim_agent_with_my,
        extract_dim_agent_with_th,
        extract_dim_agent_with_id
    ],
    target_table='"base_layer"."dim_agent"',
)

@asset(group_name="dim_user_db_master")
def extract_dim_bd_agent_cost_db_master(download_fin_input_roi_base_layer: bytes) -> Output[pa.Table]:
    df = pd.read_excel(download_fin_input_roi_base_layer, sheet_name="Agent cost")
    df = _trim_all_columns_base_layer(df)
    df = df.dropna(how="all")
    df["index"] = df.index
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("index", "int32"),
                ("started_date", "date32"),
                ("ending_date", "date32"),
                ("geo", "string"),
                ("sale_campaign", "string"),
                ("capacity", "int32"),
                ("agent_cost_2", "float32"),
                ("agent_cost_3", "float32"),
                ("per_agent_cost_trash", "float32"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


load_dim_bd_agent_cost = create_load_to_postgres_asset_db_master(
    asset_name="load_dim_bd_agent_cost_base_layer",
    source_assets=[extract_dim_bd_agent_cost_db_master],
    target_table='"base_layer"."dim_bd_agent_cost"',
)

download_fin_assumption_input_base_layer = create_download_from_sharepoint_asset_base_layer(
    asset_name="download_fin_assumption_input_base_layer",
    path_to_file="Finance Cost Input/Assumption_Input.xlsx",
    link=r"https://neyucom.sharepoint.com/sites/DATANEYU/_layouts/15/Doc.aspx?sourcedoc=%7BEBD45E21-4A6B-4BD9-8142-4AE8BE6E4514%7D&file=Assumption_Input.xlsx&action=default&mobileredirect=true",
)


@asset(group_name="dim_user_db_master")
def extract_dim_production_cost_db_master(
    download_fin_assumption_input_base_layer: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(download_fin_assumption_input_base_layer, sheet_name="PD")
    df = df[["started_date", "GEO", "product", "Unit Cost (Local Cur.)", "ending_date"]]
    df = df.dropna(how="all")
    df = df.rename(
        columns={
            "started_date": "start_date",
            "GEO": "geo",
            "product": "product",
            "Unit Cost (Local Cur.)": "unit_cost_local_currenncy",
            "ending_date": "ending_date",
        },
        errors="raise",
    )
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("start_date", "date32"),
                ("geo", "string"),
                ("product", "string"),
                ("unit_cost_local_currenncy", "float32"),
                ("ending_date", "date32"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


extract_dim_production_cost_db_master = add_blocking_checks_to_asset(
    extract_dim_production_cost_db_master,
    checks=[
        CheckDupDateRange(
            from_date_col="start_date",
            to_date_col="ending_date",
            partitions="upper(geo),upper(product)",
        ),
        CheckNullColumn(),
    ],
)


load_dim_production_cost_db_master = create_load_to_postgres_asset_db_master(
    asset_name="load_dim_production_cost_base_layer",
    source_assets=[extract_dim_production_cost_db_master],
    target_table='"base_layer"."dim_production_cost"',
)


download_fin_product_name_mapping_base_layer = create_download_from_sharepoint_asset_base_layer(
    asset_name="download_fin_product_name_mapping_base_layer",
    path_to_file="Finance Cost Input/Mapping Product Name.xlsx",
    link=r"https://neyucom.sharepoint.com/sites/DATANEYU/_layouts/15/Doc.aspx?sourcedoc=%7BA2523D22-3B5F-41C4-B7AD-2278D8320AA9%7D&file=Mapping%20Product%20Name.xlsx&action=default&mobileredirect=true",
)


@asset(compute_kind="postgres", group_name="dim_user_db_master")
def extract_dim_finance_product_salescamp_db_master(
    download_fin_product_name_mapping_base_layer: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(
        download_fin_product_name_mapping_base_layer, sheet_name="Sheet1", index_col=False
    )
    df = df.reset_index(drop=True)
    df = df[~df["offer"].isnull()]
    df.rename(columns={"Sales Camp": "sales_camp"}, inplace=True)
    df["sales_camp"] = df["sales_camp"].str.replace("\n", "")
    df["index"] = df.index
    df = df.dropna(how="all")
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("index", "int32"),
                ("geo", "string"),
                ("offer", "string"),
                ("product_name", "string"),
                ("sales_camp", "string"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


load_dim_finance_product_salescamp_db_master = create_load_to_postgres_asset_db_master(
    asset_name="load_dim_finance_product_salescamp_base_layer",
    source_assets=[extract_dim_finance_product_salescamp_db_master],
    target_table='"base_layer"."dim_finance_product_salescamp"',
)

# dim_vn_reason_mapping
download_vn_reason_mapping_base_layer = create_download_from_sharepoint_asset_base_layer(
    asset_name="download_vn_reason_mapping_base_layer",
    path_to_file="[VN] - Logistics/VN_Log_Mapping.xlsx",
    link=r"https://neyucom.sharepoint.com/:x:/r/sites/DATANEYU/_layouts/15/Doc.aspx?sourcedoc=%7BA9F606B4-1096-4591-8136-02B5608125DA%7D&file=VN_Log_Mapping.xlsx&action=default&mobileredirect=true&refreshcount=3",
)


@asset(
    group_name="dim_user_db_master",
    metadata={
        "Owner": "tien.nguyen.3@kiwi-eco.com",
    },
)
def extract_dim_vn_reason_mapping_db_master(
    download_vn_reason_mapping_base_layer: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(
        download_vn_reason_mapping_base_layer,
        sheet_name="Mapping reason",
    )
    df["country_code"] = "VN"
    df = df.dropna(how="all")
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("country_code", "string"),
                ("type", "string"),
                ("system_status", "string"),
                ("pbi_status", "string"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


load_dim_vn_reason_mapping_db_master = create_load_to_postgres_asset_db_master(
    asset_name="load_dim_vn_reason_mapping_base_layer",
    source_assets=[extract_dim_vn_reason_mapping_db_master],
    target_table='"base_layer"."dim_vn_reason_mapping"',
)


# dim_finance_bd_logistics_cost
@asset(
    group_name="dim_user_db_master",
    metadata={
        "Owner": "daniel.ha@neyu.co",
    },
)
def extract_dim_finance_bd_logistics_cost_db_master(
    download_fin_perf_monitor_input_base_layer: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(
        download_fin_perf_monitor_input_base_layer,
        sheet_name="logistics_cost",
        dtype={
            "country_code": str,
            "start_date": str,
            "end_date": str,
            "logistics_cost_per_validated_order_usd": float,
        },
    )
    df = df.dropna(how="any")
    df["country_code"] = df["country_code"].str.upper()
    df["start_date"] = pd.to_datetime(df["start_date"], infer_datetime_format=True)
    df["end_date"] = pd.to_datetime(df["end_date"], infer_datetime_format=True)
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("country_code", "string"),
                ("start_date", "date32"),
                ("end_date", "date32"),
                ("logistics_cost_per_validated_order_usd", "float32"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


load_dim_finance_bd_logistics_cost_db_master = create_load_to_postgres_asset_db_master(
    asset_name="load_dim_finance_bd_logistics_cost_base_layer",
    source_assets=[extract_dim_finance_bd_logistics_cost_db_master],
    target_table='"base_layer"."dim_finance_bd_logistics_cost"',
)

# dim_mkt_budget_target_camp
@asset(group_name="dim_user_db_master")
def extract_dim_mkt_budget_target_camp_db_master() -> Output[pa.Table]:
    """
    Ingest dim_mkt_budget_target_camp from Web
    """
    df = pd.read_csv(
        r"https://docs.google.com/spreadsheets/d/e/2PACX-1vTsKC77L1DlOcUuta7bflrrRAusPQbOWSM0OggYBFEQ-sYrVBOqL_JRDJTWWX7w7caMEKWyOYE0xzqm/pub?gid=1575141522&single=true&output=csv",
        dtype=str,
    )
    df = _trim_all_columns_base_layer(df)
    df.rename(
        columns={
            "GEO": "geo",
            "CAMP": "camp",
            "LEAD TARGET": "lead_target",
            "SPL TARGET": "spl_target",
            r"% LEAD COST TARGET": "percentage_lead_cost_target",
            "FROM": "from_date",
            "TO": "to_date",
        },
        inplace=True,
    )
    df = _df_col_convert_to_float(df, "lead_target")
    df = _df_col_convert_to_float(df, "spl_target")
    df = _df_col_convert_to_float(df, "percentage_lead_cost_target", True)
    df["from_date"] = pd.to_datetime(df["from_date"], infer_datetime_format=True)
    df["to_date"] = pd.to_datetime(df["to_date"], infer_datetime_format=True)
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("geo", "string"),
                ("camp", "string"),
                ("lead_target", "float32"),
                ("spl_target", "float32"),
                ("percentage_lead_cost_target", "float32"),
                ("from_date", "date32"),
                ("to_date", "date32"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


load_dim_mkt_budget_target_camp_db_master = create_load_to_postgres_asset_db_master(
    asset_name="load_dim_mkt_budget_target_camp_base_layer",
    source_assets=[extract_dim_mkt_budget_target_camp_db_master],
    target_table='"base_layer"."dim_mkt_budget_target_camp"',
)


# dim_mkt_budget_target_offer
@asset(group_name="dim_user_db_master")
def extract_dim_mkt_budget_target_offer_base_layer() -> Output[pa.Table]:
    """
    Ingest dim_mkt_budget_target_offer from Web
    """
    df = pd.read_csv(
        r"https://docs.google.com/spreadsheets/d/e/2PACX-1vTsKC77L1DlOcUuta7bflrrRAusPQbOWSM0OggYBFEQ-sYrVBOqL_JRDJTWWX7w7caMEKWyOYE0xzqm/pub?gid=1332960078&single=true&output=csv",
        dtype=str,
    )
    df = _trim_all_columns_base_layer(df)
    df.rename(
        columns={
            "OFFER": "offer",
            "LEAD TARGET": "lead_target",
            "SPL TARGET": "spl_target",
            r"% LEAD COST TARGET": "percentage_lead_cost_target",
            "FROM": "from_date",
            "TO": "to_date",
        },
        inplace=True,
    )
    df = _df_col_convert_to_float(df, "lead_target")
    df = _df_col_convert_to_float(df, "spl_target")
    df = _df_col_convert_to_float(df, "percentage_lead_cost_target", True)
    df["from_date"] = pd.to_datetime(df["from_date"], infer_datetime_format=True)
    df["to_date"] = pd.to_datetime(df["to_date"], infer_datetime_format=True)
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("offer", "string"),
                ("lead_target", "float32"),
                ("spl_target", "float32"),
                ("percentage_lead_cost_target", "float32"),
                ("from_date", "date32"),
                ("to_date", "date32"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


load_dim_mkt_budget_target_offer_db_master = create_load_to_postgres_asset_db_master(
    asset_name="load_dim_mkt_budget_target_offer_base_layer",
    source_assets=[extract_dim_mkt_budget_target_offer_base_layer],
    target_table='"base_layer"."dim_mkt_budget_target_offer"',
)



download_fin_target_source_base_layer = create_download_from_sharepoint_asset_base_layer(
    asset_name="download_fin_target_source_base_layer",
    path_to_file="BD - Finance/TARGET SOURCE FILE.xlsx",
    link=r"https://neyucom.sharepoint.com/sites/DATANEYU/_layouts/15/Doc.aspx?sourcedoc=%7BB072D6C2-6965-46EA-9B88-F12845F7D9ED%7D&file=TARGET%20SOURCE%20FILE.xlsx&action=default&mobileredirect=true",
)


# dim_lead_cost_rev_plan
@asset(
    group_name="dim_user_db_master",
    metadata={
        "Owner": "linh.nguyen@neyu.co",
    },
)
def extract_dim_lead_cost_rev_plan_db_master(
    download_fin_target_source_base_layer: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(
        download_fin_target_source_base_layer,
        sheet_name="Sheet1",
        dtype={
            "Geo": str,
            "Pub": str,
            "Offer": str,
            "Lead Target": int,
            "AR target": float,
            "Validated target": int,
            "DR target": float,
            "AOV target": int,
            "Revenue target": int,
            "Month": int,
            "Year": int,
            "Lead cost Plan": float,
        },
    )
    df = df.dropna(how="any")
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("Geo", "string"),
                ("Pub", "string"),
                ("Offer", "string"),
                ("Lead Target", "int32"),
                ("AR target", "float32"),
                ("Validated target", "int32"),
                ("DR target", "float32"),
                ("AOV target", "int32"),
                ("Revenue target", "int32"),
                ("Month", "int32"),
                ("Year", "int32"),
                ("Lead cost Plan", "float32"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


extract_dim_lead_cost_rev_plan_db_master = add_blocking_checks_to_asset(
    extract_dim_lead_cost_rev_plan_db_master, checks=[CheckDupDim("Month,Year,Pub,Offer")]
)


load_dim_lead_cost_rev_plan_db_master = create_load_to_postgres_asset_db_master(
    asset_name="load_dim_lead_cost_rev_plan_base_layer",
    source_assets=[extract_dim_lead_cost_rev_plan_db_master],
    target_table='"base_layer"."dim_lead_cost_rev_plan"',
)


# dim_finance_plan_figure
@asset(
    group_name="dim_user_db_master",
    metadata={
        "Owner": "daniel.ha@neyu.co",
    },
)
def extract_dim_finance_plan_figure_base_layer(
    download_fin_perf_monitor_input_base_layer: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(
        download_fin_perf_monitor_input_base_layer,
        sheet_name="plan_figure",
        dtype={
            "country_code": str,
            "sales_camp": str,
            "offer": str,
            "partner": str,
            "daily_lead_plan": float,
            "ar_qa_plan": float,
            "aov_plan": float,
            "dr_plan": float,
            "month": int,
            "year": int,
            "gp_target": float,
        },
    )
    df = df.dropna(how="all")
    df["country_code"] = df["country_code"].str.upper()
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("country_code", "string"),
                ("sales_camp", "string"),
                ("offer", "string"),
                ("partner", "string"),
                ("daily_lead_plan", "float64"),
                ("ar_qa_plan", "float64"),
                ("aov_plan", "float64"),
                ("dr_plan", "float32"),
                ("month", "int32"),
                ("year", "int32"),
                ("gp_target", "float32"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


extract_dim_finance_plan_figure_base_layer = add_blocking_checks_to_asset(
    extract_dim_finance_plan_figure_base_layer,
    checks=[
        CheckDupDim("country_code,sales_camp,offer,partner,month,year"),
        CheckNullColumn(["country_code", "sales_camp", "offer", "partner"]),
    ],
)


load_dim_finance_plan_figure_db_master = create_load_to_postgres_asset_db_master(
    asset_name="load_dim_finance_plan_figure_base_layer",
    source_assets=[extract_dim_finance_plan_figure_base_layer],
    target_table='"base_layer"."dim_finance_plan_figure"',
)

#schedule
populate_dim_table_job_base_layer = define_asset_job(
    name="populate_dim_table_job_base_layer",
    selection=AssetSelection.groups("dim_user_db_master"),
    config={
        "execution": {
            "config": {
                "multiprocess": {
                    "max_concurrent": 10,
                },
            }
        }
    },
)
populate_dim_table_schedule_base_layer = ScheduleDefinition(
    job=populate_dim_table_job_base_layer,
    cron_schedule="30 0 * * *", # cron_schedule="0 22 * * *"
    execution_timezone="Asia/Bangkok",
)

# done task
