import pandas as pd
import os
import numpy as np
import datetime
from datetime import timedelta
from datetime import date
import psycopg2 as pg
import psycopg2.extras
import os  
from dagster import (
    asset,
    define_asset_job,
    ScheduleDefinition,
)

TIMEZONE = os.getenv("DAGSTER_TIMEZONE")


# group_bd = [-817127457] #[-726235988] old group

# API_TOKEN = "5257985241:AAGahjIFbK3HLyzmIcCrzf2xalBKp4-KR3w"
# bot = telebot.TeleBot(API_TOKEN)
now = datetime.datetime.now()
# output_path = os.path.dirname(os.path.realpath("__file__"))


# CS data Indo
def extract_data(start_date, end_date):
    #x = list(map(int, lead_list.split()))
    q = """
        with cs AS (
    select
	a.createdate::date createdate,
	a.id rescue_id,
	b.status_name cs_status,
	c.substatus_name sub_cs_status,
	a.priority,
	a.lastmile_reason,
	g.do_id,
	a.do_code,
	k.name as delivery_status, -- new & right status transport, new LINE ADDING, we get this status transport for Rosa is OK
	a.amountcod cod,
	h.warehouse_name,
	g.package_name,
	a.lastmile_reason_detail,
	f.user_name,
	regexp_replace(a.job_comment, E'[\\n\\r]+', ' ', 'g' ) job_comment,
	a.createdate createdate,
	a.updatedate,
	date_trunc('month', a.createdate)::date as month,
	extract(month from a.createdate) as month_number,
	d.status_name AS reason,
	e.substatus_name AS sub_reason,
	cc.name campaign
    FROM
	rc_rescue_job a
    LEFT JOIN (
	SELECT
		*
	FROM
		rc_status
	WHERE
		TYPE = 1) b ON
	b.status = a.job_status --get status
    LEFT JOIN (
	SELECT
		*
	FROM
		rc_substatus) c ON
	c.substatus = a.job_sub_status
	AND c.status_id = b.id  -- get substatus
    LEFT JOIN (
	SELECT
		*
	FROM
		rc_status
	WHERE
		TYPE = 2) d ON
	d.status = a.job_reason -- get reason
    LEFT JOIN (
	SELECT
		*
	FROM
		rc_substatus) e ON
	e.substatus = a.job_sub_reason
	AND e.status_id = d.id -- get subreason
    LEFT JOIN or_user f ON
	a.assigned = f.user_id -- get agent cs name
    LEFT JOIN od_do_new g ON
	a.tracking_code = g.tracking_code -- get package name, do_id
    LEFT JOIN bp_warehouse h ON
	g.warehouse_id = h.warehouse_id -- get warehouse name
    left join cl_fresh cf on 
	g.customer_id = cf.lead_id -- build a bridge to 
    LEFT JOIN cp_campaign cc ON 
	cf.cp_id = cc.cp_id  -- get campaign name
    left join (select * from cf_synonym where type = 'delivery order status') i on a.do_status = i.value -- to hide if needed, get the latter right status transport
    left join (select * from cf_synonym where type = 'delivery order status') k on g.status = k.value -- new LINE ADDING
    WHERE
	a.createdate::date >= '{}' and a.createdate::date <= '{}' -- change the date here
    order by a.createdate::date asc)
	
    select * from cs
    """.format(start_date, end_date)
    try:
        #data = run_query( q, geo = 'indo')
        conn = pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG")) 
        cur = conn.cursor()
        data = pd.read_sql_query(q,conn)
        conn.commit()
        cur.close()
        conn.close()
        #no_lead = len(x)
    except:
        data = pd.DataFrame()
    return data

# Logistics data TH
def extract_data_TH(start_date, end_date):
    #x = list(map(int, lead_list.split()))
    q = """
    select
--2 note from RC
rrj.user_note
--3 campagine
, cc."name" as campaign
--4. Status TMS
, dosts."name" as tms_status
--ขอหลีดด้วยค่ะ (affaliate๗
, cf.affiliate_id
, odn.tracking_code
, lm.shortname as courier
, pp."name" as product_name
, lp.shortname as province
--, rrj.createdate
, odn.createdate
, cf.lead_id
, cf.subid1 as pub
from od_do_new odn
left join rc_rescue_job rrj on rrj.do_id = odn.do_id
left join od_sale_order oso on odn.so_id = oso.so_id 
left join cl_fresh cf on oso.lead_id = cf.lead_id 
left join cf_synonym dosts on dosts.value = odn.status and dosts.type_id = 5
left join bp_partner lm on odn.carrier_id = lm.pn_id and lm.pn_type = 121
left join lc_province lp on lp.prv_id = cf.province::int
left join od_so_item osi on osi.so_id = oso.so_id and osi.item_no = 1
left join pd_product pp on pp.prod_id = osi.prod_id 
left join cp_campaign cc on cc.cp_id = cf.cp_id 
--1 create date apr1-27
where odn.createdate::date between '{}' and '{}'
order by odn.createdate;
    """.format(start_date, end_date)
    try:
        # data = run_query( q, geo = 'th') 
        conn = pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG")) 
        cur = conn.cursor()
        data = pd.read_sql_query(q,conn)
        conn.commit()
        cur.close()
        conn.close()
        # format datetime: createdate
        data['createdate'] = pd.to_datetime(data["createdate"].dt.strftime('%d-%m-%Y'))
    except:
        data = pd.DataFrame()
    return data 

# CS data VN
def extract_data_VN(start_date, end_date):
    q = """
    select a.geo,rc_job_id, d.name activity, c.status_name new_status 
		, case when lower("comment") like '%system%' then "comment" else null end as comment
		, e.user_name updateby, f.user_name owner_name, g.user_name now_assigned
		, act_time, act_time::date act_time_date, b.createdate::date job_date, is_pre_delivery, h.substatus_name sub_cs_status
--date_trunc('month', act_time) act_month, act_time::date actime, e.user_name updateby, count(*) productivity
from rc_activity a
left join rc_rescue_job b on a.rc_job_id = b.id and a.geo = b.geo
left join (select * from rc_status where type = 1) c on b.job_status = c.status and b.geo = c.geo
left join rc_substatus h on h.status_id = b.id and h.geo = b.geo -- and h.substatus = b.job_sub_status 
left join (select * from cf_synonym where geo in ('VN','VN2') and type_id = 25) d on a.activity_type =d.value and d.geo = a.geo
left join od_do_new odn on b.do_id = odn.do_id and b.geo = odn.geo
left join or_user e on e.user_id = a.updateby and e.geo = a.geo
left join or_user f on f.user_id = a.owner_id and f.geo = a.geo
left join or_user g on g.user_id = b.assigned and g.geo = b.geo
where date_trunc('month', act_time) >= '2022-01-01'
and a.geo in ('VN','VN2')
--and act_time::date >= '2022-12-01' and act_time::date <='2022-12-31'
and act_time::date >= '{}' and act_time::date <='{}'
--and date_trunc('month', b.createdate) = date_trunc('month', act_time)
--and is_pre_delivery = FALSE
--and lower("comment") not like '%system%'
group by 1,2,3,4,5,6,7,8,9,10,11,12,13
    """.format(start_date, end_date)
    try:
        # data = run_query(q, geo = 'team')
        conn = pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG")) 
        cur = conn.cursor()
        data = pd.read_sql_query(q,conn)
        conn.commit()
        cur.close()
        conn.close()
        #
    except:
        data = pd.DataFrame()
    return data


def extract_raw_data_VN_operation(start_date, end_date):
    q = """
    with raw as
        (
        select  d.org_id orgid,a.so_id soid,e.do_id doid,e.do_code docode,d.lead_id leadid,
        d.prod_name productname, a.amount,
        --, pd.name as final_product, 
        case when d.prod_name is null or d.prod_name = '' then lower(ld.products_name_1) else lower(d.prod_name) end as final_product,
        coalesce(o.shortname,d.agc_code) as sourcename, d.affiliate_id, p.user_name agname ,
        case when lower(p.user_name) like '%cit%' then 'CIT' else 'Fresh' end as agent_type,
        ld.phuong_xa, ld.quan_huyen, ld.tinh_thanh_pho,
        f.shortname ffmname , j.warehouse_shortname warehousename ,
        k.shortname lastmilename ,
        case a.payment_method when 1 then 'COD' when 2 then 'Banking Tranfer' end as paymentmethod,
        g.name leadstatus, d.user_defin_05 as reason, h.name orderstatus, ld.status_transport deliverystatus ,d.lead_type leadtype,
        case when d.lead_type = 'A' then 'Fresh' else 'Resell' end as leadtypename , q.name cpname,
        d.createdate as lead_date, a.createdate as so_date,
        e.createdate as do_createdate, e.createdate::date as do_date, to_char(e.createdate, 'DY') as do_week_day, e.createdate::time as do_time,  e.lastmile_return_code,
        ld.picked_at, ld.attempts, e.firstdelivertime, sla.sla,
        rcp.user_name as agent_rescue, rs.name as rescue_status, rss.name as rescue_reason, osi.quantity, ld.ma_don_goc, oac.payout, rrj.createdate as rescue_createdate,
        case when e.lastmile_return_code is null then 'No' else 'Yes' end as is_rescued 
        --case when rcp.user_name is null and e.lastmile_return_code is null then 'No' else 'Yes' end as is_rescued 
        from (
                select geo, org_id, lead_id, prod_id, prod_name, total_call,lead_status, lead_type, agc_id, agc_code, 
                comment, address, province, district, subdistrict, assigned, createdate, modifydate, cp_id, callinglist_id, affiliate_id, user_defin_05,click_id       	
                from cl_fresh
                --where createdate >= '2021-01-01'
                where geo = 'VN'
            ) d 
        left join od_sale_order a on a.lead_id=d.lead_id and a.geo = d.geo
        left join od_do_new e on a.so_id=e.so_id and a.geo = e.geo
        left join bp_partner f on e.ffm_id = f.pn_id and e.geo = f.geo
        left join bp_warehouse j on e.warehouse_id = j.warehouse_id and e.geo = j.geo
        left join bp_partner k on e.carrier_id = k.pn_id and e.geo = k.geo
        left join bp_partner o on d.agc_id = o.pn_id and d.geo = o.geo
        left join (select * from rc_rescue_job rrj where job_type = 1 and geo = 'VN') rrj on rrj.so_id = a.so_id and rrj.geo = a.geo
        left join or_user rcp on rrj.assigned = rcp.user_id and rrj.geo = rcp.geo
        left join (select * from cf_synonym where type ='lead status') g on d.lead_status=g.value and d.geo = g.geo
        left join (select * from cf_synonym where type ='sale order status') h on a.status=h.value and a.geo = h.geo
        left join (select * from cf_synonym where type ='rescue status') rs on rrj.job_sub_status = rs.value and rrj.geo = rs.geo
        left join (select * from cf_synonym where type ='rescue reason') rss on rrj.job_sub_reason = rss.value and rrj.geo = rss.geo
        left join or_user p on p.user_id=d.assigned and p.geo = d.geo
        left join lc_province l on cast(l.prv_id as varchar)= cast(d.province as varchar) and l.geo = d.geo
        left join lc_district m on cast(m.dt_id as varchar)=cast(d.district as varchar) and m.geo = d.geo
        left join lc_subdistrict n on cast(n.sdt_id as varchar)=cast(d.subdistrict as varchar) and n.geo = d.geo
        left join cp_campaign q on q.cp_id = d.cp_id and q.geo = d.geo
        left join cl_calling_list r on r.callinglist_id = d.callinglist_id and r.geo = d.geo
        left join pd_product pd on d.prod_id = pd.prod_id and d.geo = pd.geo
        left join log_data_main ld on a.so_id = ld.ma_don_hang::numeric
        left join (select geo, so_id, sum(quantity) as quantity from od_so_item group by geo, so_id) osi on osi.so_id = a.so_id and osi.geo = a.geo
        left join ods_affscale_conversion oac on oac.lead_id = d.lead_id and oac.geo = d.geo
        left join (
                    select *,
                    case
                        when "3pl_name" like 'GHN%' then 'GHN'
                        when "3pl_name" like 'SNAPPY%' then 'SNAPPY'
                        end as carrier,
                    case
                        when "3pl_name" like '%HCM' then 'GHN HCM'
                        when "3pl_name" like '%HN' then 'GHN HN'
                        when "3pl_name" like '%DN' then 'GHN DN'
                        end as warehouse
                    from dim_sla ds
                    where geo = 'VN'
                ) sla
        on ld.tinh_thanh_pho = sla.province and j.warehouse_shortname = sla.warehouse and k.shortname = sla.carrier and d.geo = sla.geo
        where d.geo = 'VN'
        )
    select lead_date, so_date, firstdelivertime, leadtype, leadid, leadtypename, final_product, cpname, sourcename, affiliate_id, agname,
            agent_type, leadstatus, reason, orderstatus, amount, quantity, payout, soid as ma_don_hang, ma_don_goc, ffmname, warehousename, 
            do_createdate, lastmilename, picked_at, phuong_xa, quan_huyen, tinh_thanh_pho, paymentmethod, sla
            -- first_deliver_act_pickup: sum(picked_at, sla)
            , to_timestamp(picked_at, 'YYYY-MM-DD HH24:MI:SS') 
                + cast((sla || ' days') as interval) 
                as first_deliver_act_pickup
            -- first_deliver_promise_pickup: sum(promise_pickup_date, sla)
            ,case 
                -- COT applied for all carrier and ffm
                when do_week_day in ('MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT') and do_time < '15:00:00' then do_date
                when do_week_day in ('MON', 'TUE', 'WED', 'THU', 'FRI') and do_time > '15:00:00' then do_date + 1
                when do_week_day = 'SAT' and do_time > '15:00:00' then do_date + 2
                when do_week_day = 'SUN' then do_date + 1
                end -- as promise_pickup_date
                + cast((sla || ' days') as interval) 
                as first_deliver_promise_pickup
            , deliverystatus, attempts, rescue_createdate, agent_rescue, rescue_status, rescue_reason, lastmile_return_code, is_rescued
    from raw
    where lead_date::date between '{}' and '{}'
    """.format(start_date, end_date)
    try:
        # data = run_query(q, geo = 'team')
        conn = pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG")) 
        cur = conn.cursor()
        data = pd.read_sql_query(q,conn)
        conn.commit()
        cur.close()
        conn.close()
        #
    except:
        data = pd.DataFrame()
    return data


def extract_indo_resell_data():
# get shipping data from tms
    q = '''
    with 
    main_lead 
    as (
    select cl.createdate::date lead_date,cl.modifydate::date modifydate,cl.phone,cl.name,right(trim(phone),9) short_phone, g.name leadstatus, oso.order_status,
    lag(g.name,1) over (partition by right(trim(phone),9) order by cl.createdate) pre_status,
    lead_type, 
    total_call,
    extract(day from current_date - modifydate) modify_interval,
    prod_name,
    lag(cl.lead_type,1) over (partition by right(trim(phone),9) order by cl.createdate) pre_lead_type,
    lower(trim(agc_code)) source,
    lag(lower(cl.agc_code),1) over (partition by right(trim(phone),9) order by cl.createdate) pre_source,
    cl.user_defin_05 reason,
    row_number() over (partition by right(trim(phone),9) order by cl.createdate::date desc) rank_num
    from (select * from cl_fresh where createdate::text not like '00%'
    and modifydate::text not like '00%'
    ) cl
    left join (select * from cf_synonym where type ='lead status') g on cl.lead_status=g.value
    left join (
    select oso1.lead_id, o.name order_status
    from od_sale_order oso1
    join (select lead_id, max(createdate::date) createdate
    from (select lead_id, createdate from od_sale_order where createdate::text not like '00%') temp
    group by lead_id
    ) oso2 on oso1.lead_id = oso2.lead_id and oso1.createdate::date = oso2.createdate
    left join (select * from cf_synonym where type ='sale order status') o on oso1.status = o.value
    ) oso on cl.lead_id = oso.lead_id
    where trim(phone) !~ '[^0-9]'
    and trim(phone) is not null 
    and trim(phone)  not like '000%'
    and trim(phone) <> ''
    and g.name <> 'duplicated'
    ),
    main_log as 
    (
    select 
    right(trim(a.customer_phone),9) as short_phone_log,
    extract(day from current_date - updatedate) as update_interval,
    row_number() over (partition by right(trim(a.customer_phone),9) order by a.createdate::date desc) rank_num,
    case when product2 is null and product3 is null and product4 is null
    then product1
    when product2 is not null and product3 is null and product4 is null
    then product1 || ',' || product2
    when product2 is not null and product3 is not null and product4 is null
    then product1 || ',' || product2 || ',' || product3
    when product2 is not null and product3 is not null and product4 is not null
    then product1 || ',' || product2 || ',' || product3 || ',' || product4
    else 'No products' end as all_products,
    case when lower(d.name) like 're%' then 1 else 0 end as return,
    case when lower(d.name) like 'delivered' then 1 else 0 end as deliver,
    case when lower(product1) like '%amaislim%' then 'amaislim'
    when lower(product1) like '%jointlife%' then 'jointlife'
    when lower(product1) like '%gluco%' then 'glucoactive'
    when lower(product1) like '%paralab%' then 'paralab'
    when lower(product1) like '%maxi%' then 'maxiburn'
    when lower(product1) like '%cellar%' then 'cellarin'
    when lower(product1) like '%havita%' then 'havita' 
    when lower(product1) like '%rostani%' then 'prostanix'
    when lower(product1) like '%megamove%' then 'megamove'
    when lower(product1) like '%hemoni%' then 'hemonix'
    when lower(product1) like '%varik%' then 'varikose'
    when lower(product1) like '%eyela%' then 'eyelab'
    when lower(product1) like '%insu%' then 'insulab'
    when lower(product1) like '%tensi%' then 'tensilab'
    when lower(product1) like '%upbust%' then 'upbust'
    when lower(product1) like '%lamora%' then 'lamora'
    when lower(product1) like '%duracore%' then 'duracore'
    when lower(product1) like '%testoh%' then 'testoherb'
    when lower(product1) like '%testox%' then 'testoxmen'
    when lower(product1) like '%hairlab%' then 'hairlab'
    when lower(product1) like '%halip%' then 'halipix'
    when lower(product1) like '%puroni%' then 'puronix'
    when lower(product1) like '%strom%' then 'stromax'
    when lower(product1) like '%calme%' then 'calmerol'
    when lower(product1) like '%delux%' then 'deluxskin'
    when lower(product1) like '%liver%' then 'liverherb'
    when lower(product1) like '%megabu%' then 'megaburn'
    when lower(product1) like '%rostin%' then 'prostinol'
    when lower(product1) like '%yema%' then 'eyemax'
    else lower(product1)
    end as product_final,
    regexp_replace(i.address, E'[\\n\\r]+', ' ', 'g' ) as address, n.name wards, m.name district, l.name province, 
    d.name statustransport,
    a.createdate::date createdate, 
    updatedate updatedate,
    lower(product1) product1, qty1, price1,lower(product2) product2, qty2, price2, lower(product3) product3, qty3, price3, lower(product4) product4, qty4, price4
    from (select * from od_do_new where createdate::text not like '00%' and updatedate::text not like '00%') a
    left join (select * from cf_synonym where type ='delivery order status')d on a.status = d.value
    left join od_sale_order f on f.so_id=a.so_id
    left join or_user h on f.ag_id=h.user_id
    left join cl_fresh i on i.lead_id=a.customer_id
    left join lc_province l on l.prv_id::text=i.province
    left join lc_district m on m.dt_id::text=i.district
    left join lc_subdistrict n on n.sdt_id::text=i.subdistrict
    left join (select so_id,
        max((case when item_no = 1 then b.name  end)) as product1,
        max((case when item_no = 1 then quantity  end)) as Qty1,
        max((case when item_no = 1 then a.price  end)) as Price1,
        max((case when item_no = 2 then b.name  end)) as product2,
        max((case when item_no = 2 then quantity  end)) as Qty2,
        max((case when item_no = 2 then a.price  end)) as Price2,
        max((case when item_no = 3 then b.name  end)) as product3,
        max((case when item_no = 3 then quantity  end)) as Qty3,
        max((case when item_no = 3 then a.price  end)) as Price3,
        max((case when item_no = 4 then b.name  end)) as product4,
        max((case when item_no = 4 then quantity  end)) as Qty4,
        max((case when item_no = 4 then a.price  end)) as Price4
        from od_so_item a join pd_product b on a.prod_id=b.prod_id
        group by so_id
        order by so_id desc) q on q.so_id=f.so_id  
    where lower(h.user_name) not like '%it%'
    ),
    history as (
    select short_phone_log, 
    string_agg(all_products, ',') as product_history, 
    count(*) as purchase_count,
    sum(return) as returned_, 
    sum(deliver) as delivered_
    from main_log
    group by short_phone_log),
    log_final as (
    select s.*, 
    h.product_history,
    h.purchase_count,
    h.returned_, 
    h.delivered_
    from 
    (select ml.*
    from main_log ml
    where rank_num = 1
    ) s
    left join history h on s.short_phone_log = h.short_phone_log
    where s.all_products is not null 
    and s.all_products <> '')
    select 
    case when ml.leadstatus = 'closed' and lead_type = 'A' and ml.pre_status in ('approved','rejected', 'callback potential','callback consulting','callback not prospect
    ') then 'CLOSED_FRESH_contactable'
    when ml.leadstatus = 'closed' and lead_type = 'A' and ml.pre_status not in ('approved','rejected', 'callback potential','callback consulting','callback not prospect
    ') then 'CLOSED_FRESH_uncontactable'
    when ml.leadstatus = 'rejected' and lead_type = 'A' and lower(ml.reason) like '%expensive%'
    then 'RJ_FRESH_EXPENSIVE'
    when ml.leadstatus = 'rejected' and lead_type = 'A' and lower(ml.reason) like '%person%'
    then 'RJ_FRESH_PERSONAL_MATTER'
    when ml.leadstatus = 'rejected' and lead_type = 'A' and lower(ml.reason) like '%lockdown%'
    then 'RJ_FRESH_LOCKDOWN'
    when ml.leadstatus = 'rejected' and lead_type = 'A' and lower(ml.reason) like '%joking%'
    then 'RJ_FRESH_JOKING'
    when ml.leadstatus = 'rejected' and lead_type = 'A' and lower(ml.reason) like '%trust%'
    then 'RJ_FRESH_TRUST'
    when ml.leadstatus = 'rejected' and lead_type = 'A' and lower(ml.reason) like '%exceeded%'
    then 'RJ_FRESH_DELIVERY_TIME'
    when ml.leadstatus = 'rejected' and lead_type = 'A' and lower(ml.reason) like '%license%'
    then 'RJ_FRESH_LICENSE'
    when ml.leadstatus = 'rejected' and lead_type = 'A' and lower(ml.reason) like '%cod%'
    then 'RJ_FRESH_NON_COD'
    when ml.leadstatus = 'rejected' and lead_type = 'A' and lower(ml.reason) like '%doctor%'
    then 'RJ_FRESH_DOCTOR_ADVICE'
    when ml.leadstatus = 'rejected' and lead_type = 'A' and lower(ml.reason) like '%wrong%info%'
    then 'RJ_FRESH_WRONG_INFO'
    when ml.leadstatus = 'rejected' and lead_type = 'A' and (lower(ml.reason) like '%other%reason%'
    or lower(ml.reason) like '%busy%'
    or lower(ml.reason) like '%callback%'
    or lower(ml.reason) like '%previous%agent%'
    or lower(ml.reason) like '%many%time%')
    then 'RJ_FRESH_OTHER'
    when ml.leadstatus = 'closed' and lead_type = 'M' and source = 'delivered' and ml.pre_status = 'approved' then 'CLOSED_DELIVERED_potential'
    when ml.leadstatus = 'closed' and lead_type = 'M' and source = 'delivered' and ml.pre_status <> 'approved' then 'CLOSED_DELIVERED'
    when ml.leadstatus = 'closed' and lead_type = 'M' and source = 'rj_fresh' then 'RJ_FRESH_CLOSED'
    when ml.leadstatus = 'closed' and lead_type = 'M' and source = 'closed_fresh' then 'CLOSED_FRESH_CLOSED'
    when ml.leadstatus = 'rejected' and lead_type = 'M' and source = 'delivered' then 'RJ_DELIVERED'
    when ml.order_status = 'validated' and lead_type = 'A' and statustransport = 'delivered' and ml.lead_date <= lf.createdate then 'DELIVERED_CROSS_SELL'
    when (ml.source like '%delivered%cross%sell%' and lead_type = 'M' and leadstatus in ('rejected','closed','trash')
    and product_final in ('glucoactive','eyelab','testoxmen','lamora','hairlab','amaislim','maxiburn','halipix','stromax','liverherb','paralab','megaburn','calmerol','havita'))
    or (ml.source like '%delivered%cross%sell%' and lead_type = 'M' and ml.order_status = 'validated' and statustransport = 'delivered' and ml.lead_date <= lf.createdate
    and product_final in ('glucoactive','eyelab','testoxmen','lamora','hairlab','amaislim','maxiburn','halipix','stromax','liverherb','paralab','megaburn','calmerol','havita')
    )
    then 'DELIVERED_PROMOTION'
    when (ml.order_status = 'validated' and lead_type = 'M' and statustransport = 'delivered' and ml.lead_date <= lf.createdate and (ml.source::text not like '%delivered%cross%sell%' or ml.source is null))
    or (ml.source like '%delivered%cross%sell%' and lead_type = 'M' and leadstatus in ('rejected','closed','trash') and product_final not in ('glucoactive','eyelab','testoxmen','lamora','hairlab','amaislim','maxiburn','halipix','stromax','liverherb','paralab','megaburn','calmerol','havita'))
    or (ml.order_status = 'validated' and lead_type = 'M' and statustransport = 'delivered' and ml.lead_date <= lf.createdate and "source" like '%delivered%cross%sell%'
    and product_final not in ('glucoactive','eyelab','testoxmen','lamora','hairlab','amaislim','maxiburn','halipix','stromax','liverherb','paralab','megaburn','calmerol','havita')
    )
    or (ml.source like '%delivered%promo%' and lead_type = 'M' and leadstatus in ('rejected','closed','trash'))
    then 'DELIVERED'
    when ml.order_status = 'validated' and statustransport = 'returned' and returned_ < 3 and ml.lead_date <= lf.createdate then 'RETURNED'
    when ml.order_status = 'cancel' and modify_interval > 3 and 
    (statustransport in ('delivered','returned') or statustransport is null or statustransport = '')
    and returned_ < 3
    then 'QACANCEL'
    else 'Undefined'
    end as rs_source,
    case when ml.lead_date > lf.createdate then 1 else 0 end as filter,
    case when ml.prod_name is null or ml.prod_name = '' then product1 else ml.prod_name end product,
    ml.lead_date, ml.short_phone, ml.modify_interval, ml.modifydate, ml.phone, ml.name, ml.reason, ml.leadstatus,ml.pre_status, ml.order_status,ml.lead_type,ml.pre_lead_type,ml."source",ml.pre_source,
    lf.*
    from (select lead_date, order_status,prod_name,modifydate, modify_interval, phone, name, reason, leadstatus,pre_status,lead_type,pre_lead_type,"source",pre_source,short_phone from main_lead where rank_num = 1) ml 
    left join log_final lf on ml.short_phone = lf.short_phone_log
    '''
    # df_shipping = query_data(q, 'in')
    conn = pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG")) 
    cur = conn.cursor()
    df_shipping = pd.read_sql_query(q,conn)
    conn.commit()
    cur.close()
    conn.close()
    #get address from DB archive
    q = '''
    select short_phone, address as archive_address
    from 
    (select right(trim(phone),9) short_phone, address,
    row_number() over (partition by right(trim(phone),9) order by createdate desc) rank_num
    from cl_fresh
    where address is not null and address <> ''
    ) a
    where rank_num = 1
    '''

    df_shipping['all_products'] = df_shipping['all_products'].apply(lambda x: ', '.join(list(set(x.split(',')))) if str(x) != 'None' else '')
    df_shipping['product_history'] = df_shipping['product_history'].apply(lambda x: ', '.join(list(set(x.split(',')))) if str(x) != 'None' else '')
    df_shipping['comment'] = df_shipping.apply(lambda row: 'Total Purchase: {} ----- Latest Products: {} ----- All Products Purchased: {}'.format(row['purchase_count'],row['all_products'],row['product_history']),axis=1)

    df_duration = pd.read_excel('https://docs.google.com/spreadsheets/d/e/2PACX-1vTMd7qLYxjE0oFcMdCUlnSx-lPuR5qBJWevfusIE2GYIk9aSjvtn5Benfs1so6oUbRIjEVxluyNGGPe/pub?output=xlsx')
    df_duration = df_duration[['product_final','Duration (days)']]
    df_shipping['updatedate'] = df_shipping['updatedate'].apply(lambda x: pd.to_datetime(x))
    df_shipping = pd.merge(df_shipping, df_duration, on='product_final',how='left')
    df_shipping['total_duration'] = df_shipping['qty1']*df_shipping['Duration (days)']
    df_shipping['total_duration'] = df_shipping['total_duration'].apply(lambda x: 30 if x > 30 else x)
    df_shipping['today'] = pd.to_datetime(date.today())
    df_shipping['days_passed'] =  df_shipping['today']-  df_shipping['updatedate']
    df_shipping['days_passed'] = df_shipping['days_passed'].apply(lambda x: x.days)
    df_shipping['days_left'] = df_shipping['total_duration'] - df_shipping['days_passed']

    df = df_shipping[['rs_source','name','phone','address','reason','product','comment','days_left','modify_interval', 'filter']]
    df['Updated date'] = (datetime.now() + timedelta(days = 1)).strftime('%m/%d/%Y')
    df['Original ID'] = None
    df['Agent note'] = None


    df_delivered = df[(df['rs_source'] == 'DELIVERED') & (df['days_left'] <= 10)]
    df_delivered.rename(columns = {'name':'Customer Name', 'phone':'Customer Phone', 'address':'Address', 'rs_source':'Status transport',
                        'rs_source':'Status transport', 'comment':'Comment', 'product': 'Products Name'
                        }, inplace = True)
    df_delivered = df_delivered[['Original ID','Customer Name','Customer Phone','Address','Status transport','Updated date','Products Name','Comment','Agent note']]


    df_delivered_rs23 = df[(df['rs_source'] == 'CLOSED_DELIVERED')].sort_values(by=['days_left'],ascending=False)[:1000]
    df_delivered_rs23.rename(columns = {'name':'Customer Name', 'phone':'Customer Phone', 'address':'Address', 'rs_source':'Status transport',
                        'rs_source':'Status transport', 'comment':'Comment', 'product': 'Products Name'
                        }, inplace = True)
    df_delivered_rs23 = df_delivered_rs23[['Original ID','Customer Name','Customer Phone','Address','Status transport','Updated date','Products Name','Comment','Agent note']]
    df_delivered_rs23['Status transport'] = 'DELIVERED'
    df_rs2 = df_delivered_rs23[0:500]
    df_rs3 = df_delivered_rs23[500:1000]

    df_rj_delivered = df[(df['rs_source'] == 'RJ_DELIVERED') & (df['modify_interval'] >= 5)].sort_values(by=['days_left'],ascending=False)[:300]
    df_rj_delivered.rename(columns = {'name':'Customer Name', 'phone':'Customer Phone', 'address':'Address', 'rs_source':'Status transport',
                        'rs_source':'Status transport', 'comment':'Comment', 'product': 'Products Name'
                        }, inplace = True)
    df_rj_delivered = df_rj_delivered[['Original ID','Customer Name','Customer Phone','Address','Status transport','Updated date','Products Name','Comment','Agent note']]
    df_rs2 = pd.concat([df_rs2,df_rj_delivered[0:150]])
    df_rs3 = pd.concat([df_rs3,df_rj_delivered[150:300]])

    df_delivered_promotion = df[(df['rs_source'] == 'DELIVERED_PROMOTION')]
    df_delivered_promotion.rename(columns = {'name':'Customer Name', 'phone':'Customer Phone', 'address':'Address', 'rs_source':'Status transport',
                        'rs_source':'Status transport', 'comment':'Comment', 'product': 'Products Name'
                        }, inplace = True)
    df_delivered_promotion = df_delivered_promotion[['Original ID','Customer Name','Customer Phone','Address','Status transport','Updated date','Products Name','Comment','Agent note']]
    first_mark = int(np.floor(len(df_delivered_promotion)*0.3))
    second_mark = int(np.floor(len(df_delivered_promotion)*0.5))
    third_mark = int(np.floor(len(df_delivered_promotion)))
    df_delivered = pd.concat([df_delivered,df_delivered_promotion[0:first_mark]])
    df_rs2 = pd.concat([df_rs2,df_delivered_promotion[first_mark:second_mark+first_mark]])
    df_rs3 = pd.concat([df_rs3,df_delivered_promotion[second_mark+first_mark:third_mark]])

    df_delivered_cross_sell = df[(df['rs_source'] == 'DELIVERED_CROSS_SELL')]
    df_delivered_cross_sell.rename(columns = {'name':'Customer Name', 'phone':'Customer Phone', 'address':'Address', 'rs_source':'Status transport',
                        'rs_source':'Status transport', 'comment':'Comment', 'product': 'Products Name'
                        }, inplace = True)
    df_delivered_cross_sell = df_delivered_cross_sell[['Original ID','Customer Name','Customer Phone','Address','Status transport','Updated date','Products Name','Comment','Agent note']]
    first_mark = int(np.floor(len(df_delivered_cross_sell)*0.3))
    second_mark = int(np.floor(len(df_delivered_cross_sell)*0.5))
    third_mark = int(np.floor(len(df_delivered_cross_sell)))
    df_delivered = pd.concat([df_delivered,df_delivered_cross_sell[0:first_mark]])
    df_rs2 = pd.concat([df_rs2,df_delivered_cross_sell[first_mark:second_mark+first_mark]])
    df_rs3 = pd.concat([df_rs3,df_delivered_cross_sell[second_mark+first_mark:third_mark]])

    df_returned = df[(df['rs_source'] == 'RETURNED')][0:100]
    df_returned.rename(columns = {'name':'Customer Name', 'phone':'Customer Phone', 'address':'Address', 'rs_source':'Status transport',
                        'rs_source':'Status transport', 'comment':'Comment', 'product': 'Products Name'
                        }, inplace = True)
    df_returned = df_returned[['Original ID','Customer Name','Customer Phone','Address','Status transport','Updated date','Products Name','Comment','Agent note']]
    first_mark = int(np.floor(len(df_returned)*0.3))
    second_mark = int(np.floor(len(df_returned)*0.5))
    third_mark = int(np.floor(len(df_returned)))
    df_delivered = pd.concat([df_delivered,df_returned[0:first_mark]])
    df_rs2 = pd.concat([df_rs2,df_returned[first_mark:second_mark+first_mark]])
    df_rs3 = pd.concat([df_rs3,df_returned[second_mark+first_mark:third_mark]])

    df_rj_fresh_other = df[(df['rs_source'] == 'RJ_FRESH_OTHER') & (df['modify_interval'] >= 3)][0:500]
    df_rj_fresh_other.rename(columns = {'name':'Customer Name', 'phone':'Customer Phone', 'address':'Address', 'rs_source':'Status transport',
                        'rs_source':'Status transport', 'comment':'Comment', 'product': 'Products Name'
                        }, inplace = True)
    df_rj_fresh_other = df_rj_fresh_other[['Original ID','Customer Name','Customer Phone','Address','Status transport','Updated date','Products Name','Comment','Agent note']]
    df_rs2 = pd.concat([df_rs2,df_rj_fresh_other[0:250]])
    df_rs3 = pd.concat([df_rs3,df_rj_fresh_other[250:500]])

    df_delivered.to_excel('Resell 1.xlsx',index=False)
    df_rs2.to_excel('Resell 2.xlsx',index=False)
    df_rs3.to_excel('Resell 3.xlsx',index=False)

    data = ['Resell 1.xlsx', 'Resell 2.xlsx', 'Resell 3.xlsx']
    return data
    
## Accounting export AP data
def extract_ap_data():
    q = """
    select
    oac.createdate, oac.lead_id, oac.affiliate, oac.sub_id1, oac.offer, oac.max_po, oac.payout, oac.profit, oac.geo, oac.transaction_id, 
    ap."Payout" as paid_amount,
    "Advertiser User ID" as paid_lead,
    --, ap."Affiliate", ap."Offer", ap."Payout"
    ap."Currency", ap.payment_date,
    case when ap.payment_date is not null then 'paid' else 'unpaid' end as payment_status,
    ap."Payout" - oac.payout as payout_difference
    from ods_affscale_conversion oac
    left join ap_reconciliation ap
    on oac.lead_id = ap."Advertiser User ID" and oac.geo = ap.geo
    where ap.payment_date is not null and oac.payout <> ap."Payout"
    """
    try:
        # data = run_query(q, 'team')
        conn = pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG")) 
        cur = conn.cursor()
        data = pd.read_sql_query(q,conn)
        conn.commit()
        cur.close()
        conn.close()
    except:
        data = pd.DataFrame()
    return data


def bd_manager_update():
    temp_am = "https://docs.google.com/spreadsheets/d/e/2PACX-1vRLYsOejncitW9A9Ammi5xiZn5VFP5E92MSyHOZ0yksJkSqv6RTbISOcKgriGtX3A/pub?gid=805815929&single=true&output=csv"
    temp_am_df = pd.read_csv(temp_am)
    temp_am_df.drop_duplicates(subset = ['Name'],inplace=True)
    temp_am_df = temp_am_df[['Code', 'Name', 'Manager', 'MB']]
    temp_am_df['Traffic'] = temp_am_df.apply(lambda _: ' ', axis=1)
    temp_am_df_re = temp_am_df.fillna(' ')
    print("-Establishing connection to DWH...")
    conn = pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG")) 

    cur = conn.cursor()
    cur.execute("SET statement_timeout = 0")
    conn.commit()

    cur.execute("delete from bd_temp_am")
    conn.commit()
    print('-Finish deleting from bd_temp_am')

    df_columns = list(temp_am_df_re)
    columns = str(df_columns).replace("'",'"').replace('[','').replace(']','')
    values = "VALUES({})".format(",".join(["%s" for _ in df_columns])) 
    insert_stmt = """INSERT INTO {} ({}) {}""".format('bd_temp_am',columns,values)

    #create INSERT INTO table (columns) VALUES('%s',...)
    cur = conn.cursor()
    psycopg2.extras.execute_batch(cur, insert_stmt, list(temp_am_df.values))
    conn.commit()
    cur.close()
    conn.close()
    print('-Finish updating bd_temp_am')

    return temp_am_df


# Update bd manager BD
@asset(group_name="data_extractor")
# @bot.message_handler(commands=['update'])
def bot_update():
    try:
        data = bd_manager_update()
        if data is None:
            print("Fail updating data. Please try again")            
        else:
            print("Successfully updating AMs and Pubs.") 
    except Exception as error:
        print(f"The bot has problem {error}")


#schedule
# schedule.every().day.at("19:30").do(refresh_fulldata_leadstatus)
cs_data_extractor_job = define_asset_job(
    "cs_data_extractor_job",
    selection=[
        bot_update,
    ],
)

cs_data_extractor_schedule = ScheduleDefinition(
    job=cs_data_extractor_job,
    cron_schedule="*/10 * * * *",
    execution_timezone=TIMEZONE,
)



