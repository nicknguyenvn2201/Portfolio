from dagster import asset, Config, define_asset_job, ScheduleDefinition, AssetSelection
from DagsFlow.assets.materialized_views import forecast_snapshots
from DagsFlow.assets.utls.func import extract_from_dwh
from DagsFlow.resources.postgres import PostgresConnection
from datetime import date
from datetime import timedelta

class forecast_snapshot(Config):
    io_format: str = "csv"
    io_abs_path: str = (
        r"Data team\Forecast_snapshots\historical_tracking_{}.csv".format(str((date.today()- timedelta(days = 1)).day)+str((date.today()- timedelta(days = 1)).month)+str((date.today()- timedelta(days = 1)).year))
    )
    sql_query: str = "select * from forecast_snapshot"


@asset(
    key_prefix=["sharepoint_dataset"],
    group_name="sharepoint_dataset",
    io_manager_key="dataneyu_storage",
    deps=[forecast_snapshots]
)
def forecast_snapshot(oltp01_conn: PostgresConnection, config: forecast_snapshot):
    df = extract_from_dwh(config.sql_query, oltp01_conn, return_type="pandas")
    return df


sync_forecast_snapshot_job = define_asset_job(
    name="sync_forecast_snapshot_job",
    selection=AssetSelection.assets(forecast_snapshot),
)

sync_forecast_snapshot_schedule = ScheduleDefinition(
    job=sync_forecast_snapshot_job,
    cron_schedule="15 8 * * *",
    execution_timezone="Asia/Bangkok",
)
