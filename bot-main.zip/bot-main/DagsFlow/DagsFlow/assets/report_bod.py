from dagster import (
    get_dagster_logger,
    Output,
    asset,
    MetadataValue,
    define_asset_job,
    AssetSelection,
    ScheduleDefinition,
)

import os
import pandas as pd
import pandas as pd
from DagsFlow.resources import telegram
from DagsFlow.assets.utls.func import extract_from_dwh
from DagsFlow.assets.utls.sql import SqlStore
import connectorx as cx
from datetime import datetime
from typing import Union
from . import user_input
from DagsFlow.resources.postgres import PostgresConnection

logger = get_dagster_logger()


def _human_format(num: Union[int, float]) -> str:
    magnitude = 0
    while abs(num) >= 1000:
        magnitude += 1
        num /= 1000.0
    return "{}{}".format(
        "{:.02f}".format(num),
        ["", "K", "M", "B", "T"][magnitude],
    )


def _generate_report_for_geo(row: pd.Series) -> str:
    geo_to_flag = {
        "VN":"🇻🇳",
        #"VNVN":"🇻🇳",
        #"VNID":"🇻🇳",
        "PH":"🇵🇭",
        "MY":"🇲🇾",
        "ID":"🇮🇩",
        "TH":"🇹🇭"
    }
    use_today = True if datetime.now().hour >= 10 else False
    timestamp = datetime.now().strftime("%d/%m/%Y, %H:%M")
    geo = row["geo"]
    lead_count = (
        f'{int(row["today_leads"]):,}'
        if use_today
        else f'{int(row["yesterday_leads"]):,}'
    )
    lead_count_target = f'{row["daily_lead_target"]:,}'
    lead_count_kpi_perc = (
        row["today_lead_runrate"] if use_today else row["yesterday_lead_runrate"]
    )
    total_revenue = _human_format(
        row["today_total_revenue"] if use_today else row["yesterday_total_revenue"]
    )
    total_revenue_target = _human_format(row["total_daily_revenue_target"])
    total_revenue_kpi_perc = (
        row["today_revenue_runrate"] if use_today else row["yesterday_revenue_runrate"]
    )
    total_fresh_revenue = _human_format(
        row["today_fresh_revenue"] if use_today else row["yesterday_fresh_revenue"]
    )
    total_fresh_revenue_target = _human_format(row["fresh_daily_revenue_target"])
    total_fresh_revenue_kpi_perc = (
        row["today_fresh_revenue_runrate"]
        if use_today
        else row["yesterday_fresh_revenue_runrate"]
    )
    total_resell_revenue = _human_format(
        row["today_resell_revenue"] if use_today else row["yesterday_resell_revenue"]
    )
    total_resell_revenue_target = _human_format(row["resell_daily_revenue_target"])
    total_resell_revenue_kpi_perc = (
        row["today_resell_revenue_runrate"]
        if use_today
        else row["yesterday_resell_revenue_runrate"]
    )
    mtd_total_revenue = _human_format(row["mtd_total_revenue"])
    mtd_total_revenue_target = _human_format(row["total_monthly_target"])
    mtd_total_revenue_kpi_perc = row["total_mtd_revenue_runrate"]
    mtd_total_leads = _human_format(row["mtd_fresh_leads"])
    mtd_total_leads_target = _human_format(row["fresh_monthly_lead_target"])
    mtd_total_leads_kpi_perc = row["mtd_lead_runrate"]
    mtd_fresh_revenue = _human_format(row["mtd_fresh_revenue"])
    mtd_fresh_revenue_target = _human_format(row["fresh_monthly_target"])
    mtd_fresh_revenue_kpi_perc = row["fresh_mtd_revenue_runrate"]
    mtd_resell_revenue = _human_format(row["mtd_resell_revenue"])
    mtd_resell_revenue_target = _human_format(row["resell_monthly_target"])
    mtd_resell_revenue_kpi_perc = row["resell_mtd_revenue_runrate"]
    fresh_delay_orders = row["fresh_delay_orders"]
    resell_delay_orders = row["resell_delay_orders"]
    fresh_pending = row["fresh_pending"]
    resell_pending = row["resell_pending"]
    d1_in_preparation = row["d1_in_preparation"]
    d2_in_preparation = row["d2_in_preparation"]
    d3_in_preparation = row["d3_in_preparation"]
    d4_in_preparation = row["d4_in_preparation"]
    w0_dr = row["w0_dr"]
    w1_dr = row["w1_dr"]
    w2_dr = row["w2_dr"]
    w3_dr = row["w3_dr"]
    w0_fresh_dr = row["w0_fresh_dr"]
    w1_fresh_dr = row["w1_fresh_dr"]
    w2_fresh_dr = row["w2_fresh_dr"]
    w3_fresh_dr = row["w3_fresh_dr"]
    w0_resell_dr = row["w0_resell_dr"]
    w1_resell_dr = row["w1_resell_dr"]
    w2_resell_dr = row["w2_resell_dr"]
    w3_resell_dr = row["w3_resell_dr"]
    report = (
        f"""
{geo_to_flag[geo]}***{geo}*** - ({timestamp})
***Lead:*** {lead_count} / {lead_count_target} ***({lead_count_kpi_perc:.1%})***
***Rev:*** {total_revenue} / {total_revenue_target} ***({total_revenue_kpi_perc:.1%})***
***FS:*** {total_fresh_revenue} / {total_fresh_revenue_target} ***({total_fresh_revenue_kpi_perc:.1%})***
***RS:*** {total_resell_revenue} / {total_resell_revenue_target} ***({total_resell_revenue_kpi_perc:.1%})***

***MTD Leads:*** {mtd_total_leads} / {mtd_total_leads_target} ***({mtd_total_leads_kpi_perc:.1%})***
***MTD Rev:*** {mtd_total_revenue} / {mtd_total_revenue_target} ***({mtd_total_revenue_kpi_perc:.1%})***
***MTD-F:*** {mtd_fresh_revenue} / {mtd_fresh_revenue_target} ***({mtd_fresh_revenue_kpi_perc:.1%})***
***MTD-R:*** {mtd_resell_revenue} / {mtd_resell_revenue_target} ***({mtd_resell_revenue_kpi_perc:.1%})***

***Delayed:*** FS - {fresh_delay_orders} / RS - {resell_delay_orders}
***Pending:***  FS - {fresh_pending} / RS - {resell_pending}
***Preparation:*** {d1_in_preparation} / {d2_in_preparation} / {d3_in_preparation} / {d4_in_preparation}
***DR:*** {w0_dr * 100:0.1f} / {w1_dr * 100:0.1f} / {w2_dr * 100:0.1f} / {w3_dr * 100:0.1f}
***DR-F:*** {w0_fresh_dr * 100:0.1f} / {w1_fresh_dr * 100:0.1f} / {w2_fresh_dr * 100:0.1f} / {w3_fresh_dr * 100:0.1f}
***DR-R:*** {w0_resell_dr * 100:0.1f} / {w1_resell_dr * 100:0.1f} / {w2_resell_dr * 100:0.1f} / {w3_resell_dr * 100:0.1f}
""".replace(
            ".", "\."
        )
        .replace("(", "\(")
        .replace(")", "\)")
        .replace("-", "\-")
    )
    return report


@asset(
    group_name="report_bod",
    compute_kind="postgres",
    deps=[user_input.load_dim_geo_tracking_target],
)
def dataset_bod_daily_summary(oltp01_conn: PostgresConnection) -> Output[pd.DataFrame]:
    templates = SqlStore()
    summary_query = templates.get("get_daily_summary_for_bod").render()
    df: pd.DataFrame = extract_from_dwh(
        summary_query, oltp01_conn, return_type="arrow2"
    ).to_pandas()
    return Output(
        value=df, metadata={"Result": MetadataValue.md(df.to_markdown(index=False))}
    )


@asset(
    group_name="report_bod",
)
def report_bod_daily_summary(
    dataset_bod_daily_summary: pd.DataFrame,
    telebot_data: telegram.TelegramBot,
    telegram_chat: telegram.TelegramChat,
) -> None:
    df = dataset_bod_daily_summary
    for i, row in df.iterrows():
        report = _generate_report_for_geo(row)
        chat_id = telegram_chat.get_id("ALL_GEO_TARGET_TRACKING")
        telebot_data.send_message(chat_id, text=report, parse_mode="MarkdownV2")
        logger.info(f"Report sent for {row['geo']}")


generate_report_bod_daily_summary_job = define_asset_job(
    name="generate_report_bod_daily_summary_job",
    selection=AssetSelection.assets(
        user_input.download_geo_tracking_target,
        user_input.extract_dim_geo_tracking_target,
        user_input.load_dim_geo_tracking_target,
        dataset_bod_daily_summary,
        report_bod_daily_summary,
    ),
)
generate_report_bod_daily_summary_schedule = ScheduleDefinition(
    job=generate_report_bod_daily_summary_job,
    cron_schedule="0 1,10,15,21 * * *",
    execution_timezone="Asia/Bangkok",
)
