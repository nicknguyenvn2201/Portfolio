import pandas as pd
import numpy as np
import psycopg2 as pg
from io import BytesIO
import requests
from psycopg2 import extras
import datetime
from dagster import (
    asset,
    AssetExecutionContext,
    MaterializeResult,
    Config,
    define_asset_job,
    AssetSelection,
    ScheduleDefinition,
    RetryPolicy,
)
from DagsFlow.resources.postgres import PostgresConnection
from DagsFlow.assets.utls.func import extract_from_dwh
import io


@asset(group_name="push_dim_finance", retry_policy=RetryPolicy(max_retries=3))
def push_dim_finance_agg_vn(oltp01_conn: PostgresConnection) -> pd.DataFrame:
    query = f"""
	--- Finance Rebuild
	--- Vietnam DWH 2023
	with a as
	(select  d.orgid, d.soid, d.tracking_code, d.do_code,
	d.leadid,d.leadname ,d.leadphone,
	--case when d.prod_name is null or d.prod_name = '' then lower(product1)
	--	else lower(d.prod_name)
	--end as product_name,
	--b.product productcrosssell , 
	d.amount ,	
	d.sourcename,
	case when d.sourcename = 'AFS' and d.affiliateid = '122' then 'RTK' -- d.lead_date >= '2021-04-01' and 
	when d.sourcename = 'AFS' and d.affiliateid = '165' then 'TSM' -- d.lead_date >= '2021-04-01' and 
	when d.sourcename = 'AFS' and d.affiliateid = '169' then 'AKM' -- d.lead_date >= '2021-04-01' and 
	when d.sourcename = 'AFS' and d.affiliateid = '243' then 'LOL' -- d.lead_date >= '2021-04-01' and 
	when d.sourcename = 'AFS' and d.affiliateid = '250' then 'TEX' -- d.lead_date >= '2021-04-01' and 
	when d.sourcename = 'AFS' and d.affiliateid = '1' then '' -- d.lead_date >= '2021-04-01' and 
	--	when d.lead_date >= '2021-04-01' and sourcename = 'AFS' and affiliateid = '' then 'ART'
	when d.sourcename = 'AFS' and d.product_name like '%penirumaplus-vn%' and d.subid = '591' and d.affiliateid <> 'EMC' then 'ARB' -- d.lead_date::date = '2021-05-18' and 
	when d.sourcename = 'AFS' then d.affiliateid else d.sourcename -- d.lead_date >= '2021-04-01' and
	end as sourcename_fnl,--coalesce(o.shortname,d.agc_code) as sourcename ,
	d.sourcecode ,d.agid , d.agname,
	case
			when lower(d.agname) like '%cit%' then 'CIT'
			when lower(d.agname) not like '%cit%' then 'Fresh'
			else 'Others'
		end as team,
	case when lower(d.lstatus) = 'approved' then 1 else 0 end as approved,
	case when lower(d.lstatus) = 'trash' then 1 else 0 end as trash,
	case when lower(d.lstatus) in ('callback consulting','callback not prospect','callback potential') then 1 else 0 end as callback,
	case when lower(d.lstatus) in ('noanswer','unreachable') then 1 else 0 end as uncall,
	case when lower(d.sostatus) in ('validated','delay') then 1 else 0 end as validated,
	d.province,
	d.district,
	--d.comment ,coalesce(d.address||'###'||n.name||'-'||m.name||'-'||l.name ,d.address) as address,
	carrier, warehouse, status_transport, delivered, null delivering, cancelled, reject, --unassigned,
	CASE
            WHEN trim(lower(status_transport)) IN ('new') THEN 'New'
            WHEN trim(lower(status_transport)) IN ('packed','picking','in preparation','ready to pick') THEN 'Preparing'
            WHEN trim(lower(status_transport)) IN ('pending') THEN 'Pending'
            WHEN trim(lower(status_transport)) IN ('intransit','picked up','pending delivery') THEN 'In-transit'
            WHEN trim(lower(status_transport)) IN ('pre-delivery','delivering') THEN 'Delivering'
            WHEN trim(lower(status_transport))  IN ('delivery fail') THEN 'Failed'
			WHEN trim(lower(status_transport)) IN ('delivered') THEN 'Delivered'
			WHEN trim(lower(status_transport)) IN ('reject') THEN 'Reject'
			WHEN trim(lower(status_transport)) IN ('returning','returned') THEN 'Return'
			WHEN trim(lower(status_transport)) IN ('cancel') THEN 'Cancel'
			WHEN trim(lower(status_transport)) IN ('unassigned') THEN 'Unassigned'
    	   ELSE 'New'
	END AS adjusted_status_transport,
	--e.ffm_id ffmid,f.shortname ffmname ,e.warehouse_id warehouseid,j.warehouse_shortname warehousename , 
	--k.shortname lastmilename ,
	case d.payment_method when 1 then 'COD' when 2 then 'Bank Transfer' end as paymentmethod,
	case when trim(lower(status_transport)) not in ('delivered', 'reject', 'cancelled', 'unassigned', 'intransit') 
				or (status_transport is null and lower(d.sostatus) in ('validated','delay'))  
				or (status_transport = '' and lower(d.sostatus) in ('validated','delay')) 
				then 1 else 0 end as other_deli,
	--d.lead_status leadstatusid,
	d.lstatus as leadstatus ,
	d.postback_status,																									-- xx -- xx  -- 1
	--a.status sostatusid ,
	d.sostatus as orderstatus ,
	--e.status dostatusid ,i.name deliverystatus ,
	case when d.leadtype = 'S' then 'M' else d.leadtype end as leadtype,
	--d.createdate d.lead_date,
	d.modifydate, --coalesce(e.updatedate, a.modifydate,d.modifydate) modify_date 
	d.so_date,
	d. product_name,
	d.totalcall,
	--d.cp_id cpid,
	d.subid,
	--d.callinglist_id callinglistid,r.cl_name callinglistname ,1  groupid, 'null' groupname--t.group_id, t.short_name group_name
	case when d.sourcename = 'AFS' then d.affiliateid else d.sourcename end as affiliateid,
	--d.affiliateid, 
	--d.user_defin_05 reason, 
	d.click_id clickid, d.no_quantity,
	case when sourcename = 'AFS' then subid -- lead_date >= '2021-04-01' and 
		else affiliateid
	end as subid_fnl,
	case when leadphone like '%907688686%' then 'RS Lâm Xã Hào'
	when leadphone like '%936619478%' or leadphone like '%779132207%' then 'Nguyễn Nhạc Phi'
	when leadphone like '%367735682%' then 'chị Nhung'
	when leadphone like '%393241858%' then 'chị Phương'
	when leadphone like '%396591650%' then 'cô Hà Thị Nguyên'
	when leadphone like '%902472587%' then 'anh Duẩn'
	when leadphone like '%987311215%' then 'Trần Thiên Bình'
	when leadphone like '%912162091%' then 'anh Vinh Lương'
	when leadphone like '%913855881%' then 'Lý Thị Phong Mỹ'
	when leadphone like '%777880077%' then 'chị Trang'
	when leadphone like '%902477285%' then 'Dương Thế Sang'
	when leadphone like '%919714970%' then 'Trần Hiếu Hoàng'
	when leadphone like '%932673877%' then 'Nguyễn Vĩ'
	when leadphone like '%909937576%' then 'Nguyễn Thị Thu Dung'
	when leadphone like '%354077088%' then 'anh Lâm'
	when leadphone like '%347997537%' then 'anh Nam'
	when leadphone like '%903817576%' then 'anh Tiến Phong'
	when leadphone like '%522336938%' or leadphone like '%927502822%' then 'Nguyễn Lộc'
	when leadphone like '%923814400%' then 'Chiến Nguyễn'
	when leadphone like '%989264795%' then 'anh Tuấn'
	when leadphone like '%977153375%' or leadphone like '%982137818%' then 'anh Thanh'
	when leadphone like '%915998888%' then 'CIT Lã Tuấn Hưng'
	when leadphone like '%986761033%' then 'CIT cô Hoa'
	when leadphone like '%913848759%' then 'CIT anh Tuấn'
	when leadphone like '%936115314%' then 'CIT Đào Xuân Hoan'
	when leadphone like '%336850121%' then 'Nguyễn Văn Toàn'
	when leadphone like '%963093895%' then 'CIT chị Mai'
	when leadphone like '%975477516%' then 'Trịnh Minh Trung'
	when leadphone like '%827779911%' then 'Nguyễn Thị Đẹp'
	when leadphone like '%989796234%' then 'anh Hải'
	else 'Not wholesale' end as wholesale_name,
	case when leadtype = 'A' then lead_date else so_date end as date_used,
	max_po,
	payout,
    cpname,
    case when leadtype = 'M' and sourcename is not null and cpname = 'HC OS' then 1 else 0 end filters
	from (
			select d.org_id as orgid, d.lead_id as leadid, d.name as leadname, d.phone as leadphone,
			prod_id, prod_name, d.total_call as totalcall,lead_status, lead_type as leadtype, agc_id, agc_code as sourcecode, --comment,
			od.so_id as soid, od.payment_method, od.createdate as so_date,
			del.tracking_code, 
		--	e.ma_don_goc as do_code, 
			del.tracking_code as do_code,
			od.amount,
			p.user_name as agname, q.name as cpname, osi.no_quantity,
		--	e.quan_huyen as district,
			m.name as district, l.name as province,
		--	carrier, warehouse, 
			k.shortname as carrier,
			warehouse_name as warehouse,
			i.name as status_transport, 
		--	delivered, null delivering, cancelled, reject,
			case when g.name in ('approved') and lower(h.name) in ('validated', 'delay') and lower(i.name) in ('refund', 'delivered') then 1 else null end as delivered,
			null delivering,
			case when g.name in ('approved') and lower(h.name) in ('validated', 'delay') and lower(i.name) in ('cancelled') then 1 else null end as cancelled,
			case when g.name in ('approved') and lower(h.name) in ('validated', 'delay') and lower(i.name) in ('reject') then 1 else null end as reject,
			d.address, assigned as agid, d.createdate as lead_date, d.modifydate, d.cp_id, d.callinglist_id, affiliate_id as affiliateid, user_defin_05,click_id,subid1 as subid,
			coalesce(o.shortname,d.agc_code) as sourcename,
			case when d.prod_name is null or d.prod_name = '' then lower(product1) else lower(d.prod_name) end as product_name,
			g.name as lstatus, 
			d.postback_status, 																									-- xx -- xx -- 2
			h.name as sostatus,
			oac.max_po,
			oac.payout
			from (select * 
					from cl_fresh 
					where org_id = 4
					and modifydate::date >= '2023-01-01'
                    and CASE
			            WHEN cl_fresh.lead_status = 4 OR cl_fresh.lead_status = 5 AND cl_fresh.assigned = 0 THEN 1
			            ELSE 0
		        	END <> 1
				) d
			left join ( SELECT
		                    a_1.so_id,
		                    a_1.org_id,
		                    a_1.geo,
		                    a_1.cp_id,
		                    a_1.lead_id,
		                    a_1.amount,
		                    a_1.payment_method,
		                    a_1.status,
		                    a_1.createdate,
		                    a_1.creation_date,
		                    a_1.validated_rn,
		                    a_1.rn,
		                    a_1.final_rn
		                   FROM ( SELECT
		                            oso.so_id,
		                            oso.org_id,
		                            oso.geo,
		                            oso.cp_id,
		                            oso.lead_id,
		                            oso.amount,
		                            oso.payment_method,
		                            oso.status,
		                            oso.createdate,
		                            oso.creation_date,
		                            sum(
		                                CASE
		                                    WHEN oso.status = ANY (ARRAY[43, 357]) THEN 1
		                                    ELSE NULL::integer
		                                END) OVER (PARTITION BY oso.lead_id) AS validated_rn,
		                            row_number() OVER (PARTITION BY oso.lead_id ORDER BY oso.createdate DESC) AS rn,
		                                CASE
		                                    WHEN row_number() OVER (PARTITION BY oso.lead_id ORDER BY oso.createdate DESC) = 1 AND sum(
		                                    CASE
		WHEN oso.status = ANY (ARRAY[43, 357]) THEN 1
		ELSE NULL::integer
		                                    END) OVER (PARTITION BY oso.lead_id) > 0 AND (oso.status <> ALL (ARRAY[43, 357])) THEN 2::bigint
		                                    WHEN row_number() OVER (PARTITION BY oso.lead_id ORDER BY oso.createdate DESC) <> 1 AND (oso.status = ANY (ARRAY[43, 357])) THEN 1::bigint
		                                    ELSE row_number() OVER (PARTITION BY oso.lead_id ORDER BY oso.createdate DESC)
		                                END AS final_rn
		                           FROM od_sale_order oso
		                          WHERE 
		                          oso.org_id = 4 and oso.createdate::date >= '2023-01-01' and oso.status <> 46
		                          ) a_1
		                  WHERE a_1.final_rn = 1) od on od.lead_id = d.lead_id -- and od.geo = d.geo
			left join (select * from od_do_new where org_id = 4 and createdate::date >= '2023-01-01') del on del.so_id = od.so_id -- and del.geo = od.geo
		--	left join (select * from log_data_main where trim(lower(status_transport)) <> 'unassigned' and ma_don_goc not like 'ULT%') e on e.ma_don_hang::varchar = od.so_id::varchar and od.geo = 'VN'
		--	left join bp_partner o on d.agc_id = o.pn_id and d.geo = o.geo
		--	left join bp_partner f on e.ffm_id = f.pn_id and e.geo = f.geo
			left join (select * from bp_warehouse where geo = 'VN' )  j on del.warehouse_id = j.warehouse_id --and del.geo = j.geo
			left join (select * from bp_partner where geo = 'VN' )  k on del.carrier_id = k.pn_id --and del.geo = k.geo
			left join (select * from bp_partner where geo = 'VN' )  o on d.agc_id = o.pn_id --and d.geo = o.geo
			left join (select * from cf_synonym where type ='lead status' and geo = 'VN' ) g on d.lead_status=g.value -- and d.geo = g.geo
			left join (select * from cf_synonym where type ='sale order status' and geo = 'VN' ) h on od.status=h.value --and od.geo = h.geo
			left join (select * from cf_synonym where type ='delivery order status' and geo = 'VN' ) i on del.status=i.value --and del.geo = i.geo
			left join (select * from or_user where geo = 'VN' )  p on p.user_id=d.assigned --and p.geo = d.geo
			-- care for integer error input here
			left join (select * from lc_province where geo = 'VN' )  l on cast(l.prv_id as varchar) = cast(d.province as varchar) --and l.geo = d.geo
			left join (select * from lc_district where geo = 'VN' ) m on cast(m.dt_id as varchar) = cast(d.district as varchar) --and m.geo = d.geo
			left join (select * from lc_subdistrict where geo = 'VN' ) n on cast(n.sdt_id as varchar) = cast(d.subdistrict as varchar) --and n.geo = d.geo
			left join (select * from cp_campaign where geo = 'VN' ) q on q.cp_id = d.cp_id --and q.geo = d.geo
			left join (select * from cl_calling_list where geo = 'VN' ) r on r.callinglist_id = d.callinglist_id --and r.geo = d.geo
			left join (  select createdate,lead_id,affiliate,sub_id1,offer,max_po,payout,profit,transaction_id
			  from ods_affscale_conversion
			  where geo = 'VN' and createdate::date >= '2023-01-01'
			  ) oac 
			  on d.click_id = oac.transaction_id
			left join
			(with temp_so as (
				SELECT oi_id, osi.geo,
				so_id,
				quantity,
				item_no,
				osi.prod_id,
				pp.name as product_name,
				row_number() over(partition by so_id order by item_no) as item_no_new
				FROM (select * from od_so_item 
				where 
				    geo = 'VN'
				and createdate::date >= '2023-01-01'
				and prod_id not in (5031, 5032, 5037, 5038, 5039)
				) osi 
				left join (select * from pd_product where geo = 'VN') pp 
				on osi.prod_id = pp.prod_id -- and osi.geo = pp.geo
			--	order by osi.so_id 
				)
				SELECT so_id, -- geo,
				max((case when item_no_new = 1 then product_name end)) as product1,
				SUM(quantity) no_quantity,
				COUNT(DISTINCT prod_id) as no_product 
				FROM temp_so
				group by so_id --, geo
		--		order by so_id desc
				) osi
			on od.so_id = osi.so_id -- and od.geo = osi.geo
		) d 
	)
	-- final select
    , cte_final as ( 
	select
	date_used::date, sourcename, sourcename_fnl, agname, wholesale_name, leadtype, product_name, affiliateid, cpname, subid_fnl, subid, province, district, carrier, paymentmethod, warehouse,
	count(distinct leadid) as leads, sum(approved) as approve, sum(validated) as validate, 
	sum(trash) as trash, sum(callback) as callback, sum(uncall) as uncall,
	sum(case when a.leadstatus = 'approved' and a.orderstatus = 'validated' and a.status_transport in ('Delivered', 'delivered') then a.amount else null end) as delivered_amount,
	sum(case when a.leadstatus = 'approved' and a.orderstatus = 'validated' and a.status_transport in ('Delivered', 'delivered') then no_quantity else null end) as delivered_qty,
	sum(case when a.leadstatus = 'approved' and a.orderstatus = 'validated' and a.status_transport in ('Delivered', 'delivered') then delivered else null end) as delivered,
	sum(case when a.leadstatus = 'approved' and lower(a.orderstatus) in ('validated', 'delay') and (status_transport != 'Unassigned' or status_transport is null) then a.amount else null end) as validated_amount,
	sum(case when a.leadstatus = 'approved' and lower(a.orderstatus) in ('validated', 'delay') and (status_transport != 'Unassigned' or status_transport is null) then no_quantity else null end) as validated_qty,
	sum(case when a.leadstatus = 'approved' and lower(a.orderstatus) in ('validated', 'delay') and (status_transport != 'Unassigned' or status_transport is null) then validated else null end) as validated,
	sum(reject) as rejected,
	sum(cancelled) as cancelled,
	sum(other_deli) as other_deli,
--	count(distinct case when lower(orderstatus) in ('validated','delay') and (status_transport != 'Unassigned' or status_transport is null) then tracking_code else null end) as total_do, 
	-- rule changed (Hai and Daniel requested on 1 Jun 2022)
	count(distinct case when lower(leadstatus) = 'approved' and lower(orderstatus) in ('validated', 'delay') then leadid else null end) as total_do,
	count(distinct case when postback_status = 'approved'  then leadid else null end) as total_approved_postback,
	count(distinct case when lower(leadstatus) = 'approved' and lower(orderstatus) in ('validated', 'delay') and postback_status in ('pending_postback', 'pending_pb') then leadid else null end) as total_pending_postback,
	count(distinct case when lower(orderstatus) in ('validated','delay') and lower(status_transport) = 'intransit' then tracking_code else null end) as total_intransit,
	sum(amount) as total_amount, sum(no_quantity) as quantity, a.leadstatus, status_transport, adjusted_status_transport, team, 'VN' as "Geo", avg(max_po) max_po, avg(payout) payout
	from a
    where a.filters = 0
--	where date_used::date >= '2023-01-01'
	group by date_used, sourcename, sourcename_fnl, agname, wholesale_name, leadtype, product_name, affiliateid, cpname, subid_fnl, subid, province, district, carrier
	, paymentmethod, warehouse, a.leadstatus, status_transport, adjusted_status_transport, team
    )
	select  * , 
			case when product_name::text ~~ '%cpl%'::text THEN leads - trash 
			else null::bigint 
			end as cpl_lead
	from cte_final     
    """
    df: pd.DataFrame = extract_from_dwh(query, oltp01_conn)
    return df


@asset(group_name="push_dim_finance", retry_policy=RetryPolicy(max_retries=3))
def push_dim_finance_agg_id2(oltp01_conn: PostgresConnection) -> pd.DataFrame:
    query = f"""
	--- Finance Rebuild 
	--- Indo2 DWH 2023
	with a as
	(select  d.orgid, d.soid, d.tracking_code, d.do_code,
	d.leadid,d.leadname ,d.leadphone, --d.geo,
	--case when d.prod_name is null or d.prod_name = '' then lower(product1)
	--	else lower(d.prod_name)
	--end as product_name,
	--b.product productcrosssell , 
	d.amount ,
	d.sourcename,
	case when sourcename = 'AFS' then affiliateid else sourcename end as sourcename_fnl, -- lead_date::date >= '2021-04-01' and 
	d.sourcecode ,d.agid , d.agname,
	case
			when lower(d.agname) not like '%bk%' then 'CIT'
			when lower(d.agname) like '%bk%' then 'Fresh'
			else 'Others'
		end as team,
	case when lower(d.lstatus) = 'approved' then 1 else 0 end as approved,
	case when lower(d.lstatus) = 'trash' then 1 else 0 end as trash,
	case when lower(d.lstatus) in ('callback consulting','callback not prospect','callback potential') then 1 else 0 end as callback,
	case when lower(d.lstatus) in ('noanswer','unreachable') then 1 else 0 end as uncall,
	case when lower(d.sostatus) in ('validated','delay') then 1 else 0 end as validated,
	d.province,
	d.district,
	--d.comment ,coalesce(d.address||'###'||n.name||'-'||m.name||'-'||l.name ,d.address) as address,
	carrier, warehouse, status_transport, delivered, null delivering, cancelled, reject, --unassigned,
	CASE
            WHEN trim(lower(status_transport)) IN ('new') THEN 'New'
            WHEN trim(lower(status_transport)) IN ('packed','picking','in preparation','ready to pick') THEN 'Preparing'
            WHEN trim(lower(status_transport)) IN ('pending') THEN 'Pending'
            WHEN trim(lower(status_transport)) IN ('intransit','picked up','pending delivery') THEN 'In-transit'
            WHEN trim(lower(status_transport)) IN ('pre-delivery','delivering') THEN 'Delivering'
            WHEN trim(lower(status_transport))  IN ('delivery fail') THEN 'Failed'
			WHEN trim(lower(status_transport)) IN ('delivered') THEN 'Delivered'
			WHEN trim(lower(status_transport)) IN ('reject') THEN 'Reject'
			WHEN trim(lower(status_transport)) IN ('returning','returned') THEN 'Return'
			WHEN trim(lower(status_transport)) IN ('cancel') THEN 'Cancel'
			WHEN trim(lower(status_transport)) IN ('unassigned') THEN 'Unassigned'
    	   ELSE 'New'
	END AS adjusted_status_transport,
	--e.ffm_id ffmid,f.shortname ffmname ,e.warehouse_id warehouseid,j.warehouse_shortname warehousename , 
	--k.shortname lastmilename ,
	case d.payment_method when 1 then 'COD' when 2 then 'Bank Transfer' end as paymentmethod,
	d.other_deli,
	--d.lead_status leadstatusid,
	d.lstatus as leadstatus ,
	--a.status sostatusid ,
	d.sostatus as orderstatus ,
	--e.status dostatusid ,i.name deliverystatus ,
	case when d.leadtype = 'S' then 'M' else d.leadtype end as leadtype,
	--d.createdate d.lead_date,
	d.modifydate, --coalesce(e.updatedate, a.modifydate,d.modifydate) modify_date 
	d.so_date,
	--d. product_name,
	case when d.product_name like 'prostaniX-id' then 'prostaniX-id ' else d.product_name end as product_name,
	d.totalcall,
	--d.cp_id cpid,
	d.subid,
	--d.callinglist_id callinglistid,r.cl_name callinglistname ,1  groupid, 'null' groupname--t.group_id, t.short_name group_name
	case when d.sourcename = 'AFS' then d.affiliateid else d.sourcename end as affiliateid,
	--d.affiliateid, 
	--d.user_defin_05 reason, 
	d.click_id clickid, d.no_quantity, d.postback_status,
	case when sourcename = 'AFS' then subid
		else affiliateid
	end as subid_fnl,
	case 
		when leadphone like '%082352400657%' then 'Agus'
		when leadphone like '%82363879011%' then 'Andri Gonata'
		when leadphone like '%85774917558%' then 'Jojo'
		when leadphone like '%81291636234%' then 'Putra'
		when leadphone like '%3842431209%' or leadphone like '%82333549882%' or leadphone like '%83842431175%' then 'Sahid'
		when leadphone like '%81391423343%' or leadphone like '%88227797189%' then 'Rosyad'
		else 'Not wholesale' 
	end as wholesale_name,
	case when leadtype = 'A' then lead_date else so_date end as date_used,
	max_po,
	payout,
    d.cpname,
    case when leadtype = 'M' and sourcename is not null and cpname = 'HC OS' then 1 else 0 end filters
	from (
	select d.org_id as orgid, d.lead_id as leadid, d.name as leadname, d.phone as leadphone, d.postback_status,
	prod_id, prod_name, d.total_call as totalcall,lead_status, lead_type as leadtype, agc_id, agc_code as sourcecode, --comment,
	od.so_id as soid, od.payment_method, od.createdate as so_date,
	del.tracking_code, e.code as do_code, od.amount,
	p.user_name as agname, q.name as cpname, osi.no_quantity,
	e.name as district, l.name as province,
	k.shortname as carrier, --del.carrier_id as carrier, 
	j.warehouse_shortname as warehouse, --del.warehouse_id as warehouse, 
	i.name as status_transport,
	case when lower(i.name) in ('delivered', 'refund') and lower(h.name) not in ('unassigned') then 1 else 0 end as delivered,
	case when lower(i.name) in ('intransit', 'delivering') and lower(h.name) not in ('unassigned') then 1 else 0 end as delivering,
	case when lower(i.name) in ('cancel') and lower(h.name) not in ('unassigned') then 1 else 0 end as cancelled,
	case when lower(i.name) in ('returned', 'returning') and lower(h.name) not in ('unassigned') then 1 else 0 end as reject,
	case when (lower(i.name) not in ('delivered', 'refund', 'intransit', 'delivering', 'cancel', 'returned', 'returning')
			and lower(g.name) in ('approved') 
			and lower(h.name) in ('validated', 'delay'))
		or
			(lower(g.name) in ('approved') 
			and lower(h.name) in ('validated', 'delay') 
			and lower(i.name) is null)
		then 1 else 0 end as other_deli,
	d.address, assigned as agid, d.createdate as lead_date, d.modifydate, d.cp_id, d.callinglist_id, affiliate_id as affiliateid, user_defin_05,click_id,subid1 as subid,
	coalesce(o.shortname,d.agc_code) as sourcename,
	case when d.prod_name is null or d.prod_name = '' then lower(product1) else d.prod_name end as product_name,
	g.name as lstatus, h.name as sostatus,--, d.geo
	oac.max_po,
	oac.payout
	from (select * from cl_fresh where org_id = 8 and cp_id not in (504, 505)
    and CASE
            WHEN cl_fresh.lead_status = 4 OR cl_fresh.lead_status = 5 AND cl_fresh.assigned = 0 THEN 1
            ELSE 0
        END <> 1
    -- and createdate::date >= '2023-01-01'
		) d
	left join (select * from bp_partner where geo = 'ID2') o on d.agc_id = o.pn_id -- and d.geo = o.geo
	--left join bp_partner f on e.ffm_id = f.pn_id
	--left join bp_partner o on d.agc_id = o.pn_id
	left join ( SELECT
                    a_1.so_id,
                    a_1.org_id,
                    a_1.geo,
                    a_1.cp_id,
                    a_1.lead_id,
                    a_1.amount,
                    a_1.payment_method,
                    a_1.status,
                    a_1.createdate,
                    a_1.creation_date,
                    a_1.validated_rn,
                    a_1.rn,
                    a_1.final_rn
                   FROM ( SELECT
                            oso.so_id,
                            oso.org_id,
                            oso.geo,
                            oso.cp_id,
                            oso.lead_id,
                            oso.amount,
                            oso.payment_method,
                            oso.status,
                            oso.createdate,
                            oso.creation_date,
                            sum(
                                CASE
                                    WHEN oso.status = ANY (ARRAY[43, 357]) THEN 1
                                    ELSE NULL::integer
                                END) OVER (PARTITION BY oso.lead_id) AS validated_rn,
                            row_number() OVER (PARTITION BY oso.lead_id ORDER BY oso.createdate DESC) AS rn,
                                CASE
                                    WHEN row_number() OVER (PARTITION BY oso.lead_id ORDER BY oso.createdate DESC) = 1 AND sum(
                                    CASE
WHEN oso.status = ANY (ARRAY[43, 357]) THEN 1
ELSE NULL::integer
                                    END) OVER (PARTITION BY oso.lead_id) > 0 AND (oso.status <> ALL (ARRAY[43, 357])) THEN 2::bigint
                                    WHEN row_number() OVER (PARTITION BY oso.lead_id ORDER BY oso.createdate DESC) <> 1 AND (oso.status = ANY (ARRAY[43, 357])) THEN 1::bigint
                                    ELSE row_number() OVER (PARTITION BY oso.lead_id ORDER BY oso.createdate DESC)
                                END AS final_rn
                           FROM od_sale_order oso
                          WHERE oso.org_id = 8 and oso.status <> 46
                           --and oso.createdate::date >= '2023-01-01'
                          ) a_1
                  WHERE a_1.final_rn = 1) od on od.lead_id = d.lead_id -- and od.geo = d.geo
	left join (select * from od_do_new where org_id = 8 and createdate::date >= '2023-01-01') del on del.so_id = od.so_id -- and del.geo = od.geo
	left join (select * from bp_warehouse where geo = 'ID2')  j on del.warehouse_id = j.warehouse_id -- and del.geo = j.geo
	left join (select * from bp_partner where geo = 'ID2')  k on del.carrier_id = k.pn_id -- and del.geo = k.geo
	left join (select * from lc_district where geo = 'ID2')  e on cast(e.dt_id as varchar)=cast(d.district as varchar) --and e.geo = d.geo
	left join (select * from cf_synonym where type ='lead status' and geo = 'ID2') g on d.lead_status=g.value --and d.geo = g.geo
	left join (select * from cf_synonym where type ='sale order status' and geo = 'ID2') h on od.status=h.value --and od.geo = h.geo
	left join (select * from cf_synonym where type ='delivery order status' and geo = 'ID2') i on del.status=i.value --and del.geo = i.geo
	left join (select * from or_user where geo = 'ID2')  p on p.user_id=d.assigned --and p.geo = d.geo
	-- care for integer error input here
	left join (select * from lc_province where geo = 'ID2')  l on cast(l.prv_id as varchar) = cast(d.province as varchar) --and l.geo = d.geo
	--left join lc_district m on cast(m.dt_id as varchar) = cast(d.district as varchar)
	--left join lc_subdistrict n on cast(n.sdt_id as varchar) = cast(d.subdistrict as varchar)
	left join (select * from cp_campaign where geo = 'ID2')  q on q.cp_id = d.cp_id --and q.geo = d.geo
	left join (select * from cl_calling_list where geo = 'ID2')  r on r.callinglist_id = d.callinglist_id and r.geo = d.geo
	left join (select * from ods_affscale_conversion 
						where geo = 'ID' --and createdate::date = '2023-08-15'
						and createdate::date >= '2023-01-01' 
						) oac 
				on d.click_id = oac.transaction_id
				--on d.lead_id = oac.lead_id and d.geo = oac.geo
	left join
	(with temp_so as (
		SELECT oi_id, osi.geo,
		so_id,
		quantity,
		item_no,
		osi.prod_id,
		pp.name as product_name,
		row_number() over(partition by so_id order by item_no) as item_no_new
		FROM (select * from od_so_item where geo = 'ID2'
		     and createdate::date >= '2023-01-01'  ) osi 
		left join (select * from pd_product where org_id = 8)  pp
		on osi.prod_id = pp.prod_id -- and osi.geo = pp.geo
		-- where osi.geo = 'ID2'
		-- and osi.createdate::date >= '2023-01-01'
		)
		SELECT so_id,-- geo,
		max((case when item_no_new = 1 then product_name end)) as product1,
		SUM(quantity) no_quantity,
		COUNT(DISTINCT prod_id) as no_product 
		FROM temp_so
		group by so_id -- , geo
--		order by so_id desc
		) osi
	on od.so_id = osi.so_id 
) d 
--	where d.orgid = 8 --Indo2
	)-- final select
    , cte_final as ( 
	select
	date_used::date, sourcename, sourcename_fnl, agname, wholesale_name, leadtype, product_name, affiliateid, cpname, subid_fnl, subid, province, district, carrier, paymentmethod, warehouse,
	count(distinct leadid) as leads, sum(approved) as approve, sum(validated) as validate, sum(trash) as trash, sum(callback) as callback, sum(uncall) as uncall,
	sum(case when lower(leadstatus) = 'approved' and lower(orderstatus) = 'validated' and lower(status_transport) in ('delivered') then amount else null end) as delivered_amount,
	sum(case when lower(leadstatus) = 'approved' and lower(orderstatus) = 'validated' and lower(status_transport) in ('delivered') then no_quantity else null end) as delivered_qty,
	sum(case when lower(leadstatus) = 'approved' and lower(orderstatus) = 'validated' and lower(status_transport) in ('delivered') then delivered else null end) as delivered,
	sum(case when lower(leadstatus) = 'approved' and lower(orderstatus) in ('validated', 'delay') then amount else null end) as validated_amount,
	sum(case when lower(leadstatus) = 'approved' and lower(orderstatus) in ('validated', 'delay') then no_quantity else null end) as validated_qty,
	sum(case when lower(leadstatus) = 'approved' and lower(orderstatus) in ('validated', 'delay') then validated else null end) as validated,
	sum(reject) as rejected,
	sum(cancelled) as cancelled, 
	sum(other_deli) as other_deli,
	count(distinct case when lower(leadstatus) = 'approved' and lower(orderstatus) in ('validated', 'delay') then leadid else null end) as total_do,
	count(distinct case when postback_status = 'approved' then leadid else null end) as total_approved_postback,
	count(distinct case when lower(leadstatus) = 'approved' and lower(orderstatus) in ('validated', 'delay') and postback_status in ('pending_postback', 'pending_pb') then leadid else null end) as total_pending_postback,
	count(distinct case when lower(orderstatus) in ('validated', 'delay') and lower(status_transport) in ('intransit', 'delivering') then tracking_code else null end) as total_intransit,
	sum(amount) as total_amount, sum(no_quantity) as quantity, leadstatus, status_transport, adjusted_status_transport, team,
	'ID2' as "Geo",
	avg(max_po) max_po, avg(payout) payout
	from a
    where a.filters = 0
--	where date_used::date >= '2023-01-01'
	group by date_used, sourcename, sourcename_fnl, agname, wholesale_name, leadtype, product_name, affiliateid, cpname, subid_fnl, subid, province, district, 
	carrier, paymentmethod, warehouse, leadstatus, status_transport, adjusted_status_transport, team
        )
	select  * , 
			case when product_name::text ~~ '%cpl%'::text THEN leads - trash 
			else null::bigint 
			end as cpl_lead
	from cte_final     
    """
    df: pd.DataFrame = extract_from_dwh(query, oltp01_conn)
    return df


@asset(group_name="push_dim_finance", retry_policy=RetryPolicy(max_retries=3))
def push_dim_finance_agg_id(oltp01_conn: PostgresConnection) -> pd.DataFrame:
    query = f"""
with a as
	(select  d.orgid, d.soid, d.tracking_code, d.do_code,
	d.leadid,d.leadname ,d.leadphone, --d.geo,
	--case when d.prod_name is null or d.prod_name = '' then lower(product1)
	--	else lower(d.prod_name)
	--end as product_name,
	--b.product productcrosssell , 
	d.amount ,
	d.sourcename,
	case when sourcename = 'AFS' then affiliateid else sourcename end as sourcename_fnl, -- lead_date::date >= '2021-04-01' and
	d.sourcecode ,d.agid , d.agname,
	case
			when lower(d.agname) not like '%bk%' then 'CIT'
			when lower(d.agname) like '%bk%' then 'Fresh'
			else 'Others'
		end as team,
	case when lower(d.lstatus) = 'approved' then 1 else 0 end as approved,
	case when lower(d.lstatus) = 'trash' then 1 else 0 end as trash,
	case when lower(d.lstatus) in ('callback consulting','callback not prospect','callback potential') then 1 else 0 end as callback,
	case when lower(d.lstatus) in ('noanswer','unreachable') then 1 else 0 end as uncall,
	case when lower(d.sostatus) in ('validated','delay') then 1 else 0 end as validated,
	d.province,
	d.district,
	--d.comment ,coalesce(d.address||'###'||n.name||'-'||m.name||'-'||l.name ,d.address) as address,
	carrier, warehouse, status_transport, delivered, null delivering, cancelled, reject, --unassigned,
	CASE
            WHEN trim(lower(status_transport)) IN ('new') THEN 'New'
            WHEN trim(lower(status_transport)) IN ('packed','picking','in preparation','ready to pick') THEN 'Preparing'
            WHEN trim(lower(status_transport)) IN ('pending') THEN 'Pending'
            WHEN trim(lower(status_transport)) IN ('intransit','picked up','pending delivery') THEN 'In-transit'
            WHEN trim(lower(status_transport)) IN ('pre-delivery','delivering') THEN 'Delivering'
            WHEN trim(lower(status_transport))  IN ('delivery fail') THEN 'Failed'
			WHEN trim(lower(status_transport)) IN ('delivered') THEN 'Delivered'
			WHEN trim(lower(status_transport)) IN ('reject') THEN 'Reject'
			WHEN trim(lower(status_transport)) IN ('returning','returned') THEN 'Return'
			WHEN trim(lower(status_transport)) IN ('cancel') THEN 'Cancel'
			WHEN trim(lower(status_transport)) IN ('unassigned') THEN 'Unassigned'
    	   ELSE 'New'
	END AS adjusted_status_transport,
	--e.ffm_id ffmid,f.shortname ffmname ,e.warehouse_id warehouseid,j.warehouse_shortname warehousename , 
	--k.shortname lastmilename ,
	case d.payment_method when 1 then 'COD' when 2 then 'Bank Transfer' end as paymentmethod,
	d.other_deli,
	--d.lead_status leadstatusid,
	d.lstatus as leadstatus ,
	--a.status sostatusid ,
	d.sostatus as orderstatus ,
	--e.status dostatusid ,i.name deliverystatus ,
	case when d.leadtype = 'S' then 'M' else d.leadtype end as leadtype,
	--d.createdate d.lead_date,
	d.modifydate, --coalesce(e.updatedate, a.modifydate,d.modifydate) modify_date 
	d.so_date,
	--d. product_name,
	case when d.product_name like 'prostaniX-id' then 'prostaniX-id ' else d.product_name end as product_name,
	d.totalcall,
	--d.cp_id cpid,
	d.cpname ,
	d.subid,
	--d.callinglist_id callinglistid,r.cl_name callinglistname ,1  groupid, 'null' groupname--t.group_id, t.short_name group_name
	case when d.sourcename = 'AFS' then d.affiliateid else d.sourcename end as affiliateid,
	--d.affiliateid, 
	--d.user_defin_05 reason, 
	d.click_id clickid, d.no_quantity,
	case when  sourcename = 'AFS' then subid -- lead_date >= '2021-04-01' and
		else affiliateid
	end as subid_fnl,
	case 
		when leadphone like '%082352400657%' then 'Agus'
		when leadphone like '%82363879011%' then 'Andri Gonata'
		when leadphone like '%85774917558%' then 'Jojo'
		when leadphone like '%81291636234%' then 'Putra'
		when leadphone like '%3842431209%' or leadphone like '%82333549882%' or leadphone like '%83842431175%' then 'Sahid'
		when leadphone like '%81391423343%' or leadphone like '%88227797189%' then 'Rosyad'
		else 'Not wholesale' 
	end as wholesale_name,
	case when leadtype = 'A' then lead_date else so_date end as date_used,
	max_po,
	payout,
    d.postback_status,
    case when leadtype = 'M' and sourcename is not null and cpname = 'HC OS' then 1 else 0 end filters
	from (
	select d.org_id as orgid, d.lead_id as leadid, d.name as leadname, d.phone as leadphone,
	prod_id, prod_name, d.total_call as totalcall,lead_status, lead_type as leadtype, agc_id, agc_code as sourcecode, --comment,
	od.so_id as soid, od.payment_method, od.createdate as so_date,
	del.tracking_code, e.code as do_code, od.amount,
	p.user_name as agname, q.name as cpname, osi.no_quantity,
	e.name as district, l.name as province,
	k.shortname as carrier, --del.carrier_id as carrier, 
	j.warehouse_shortname as warehouse, --del.warehouse_id as warehouse, 
	i.name as status_transport,
	case when lower(i.name) in ('delivered', 'refund') and lower(h.name) not in ('unassigned') then 1 else 0 end as delivered,
	case when lower(i.name) in ('intransit', 'delivering') and lower(h.name) not in ('unassigned') then 1 else 0 end as delivering,
	case when lower(i.name) in ('cancel') and lower(h.name) not in ('unassigned') then 1 else 0 end as cancelled,
	case when lower(i.name) in ('returned', 'returning') and lower(h.name) not in ('unassigned') then 1 else 0 end as reject,
	case when (lower(i.name) not in ('delivered', 'refund', 'intransit', 'delivering', 'cancel', 'returned', 'returning')
			and lower(g.name) in ('approved') 
			and lower(h.name) in ('validated', 'delay'))
		or
			(lower(g.name) in ('approved') 
			and lower(h.name) in ('validated', 'delay') 
			and lower(i.name) is null)
		then 1 else 0 end as other_deli,
	d.address, assigned as agid, d.createdate as lead_date, d.modifydate, d.cp_id, d.callinglist_id, affiliate_id as affiliateid, user_defin_05,click_id,subid1 as subid,
	coalesce(o.shortname,d.agc_code) as sourcename,
	case when d.prod_name is null or d.prod_name = '' then lower(product1) else d.prod_name end as product_name,
	g.name as lstatus, h.name as sostatus,--, d.geo
	oac.max_po,
	oac.payout,
    d.postback_status
	from (select * from cl_fresh 
			where org_id = 9 -- and geo in ('ID') 
			and modifydate::date >= '2023-01-01' and cp_id not in (504, 505)
			and case when lead_status = 4 or (lead_status = 5 and assigned = 0) then 1 else 0 end = 0
		) d
	left join (select * from bp_partner where geo = 'ID' ) o on d.agc_id = o.pn_id -- and d.geo = o.geo
	--left join bp_partner f on e.ffm_id = f.pn_id
	--left join bp_partner o on d.agc_id = o.pn_id
	left join ( SELECT
                    a_1.so_id,
                    a_1.org_id,
                    a_1.geo,
                    a_1.cp_id,
                    a_1.lead_id,
                    a_1.amount,
                    a_1.payment_method,
                    a_1.status,
                    a_1.createdate,
                    a_1.creation_date,
                    a_1.validated_rn,
                    a_1.rn,
                    a_1.final_rn
                   FROM ( SELECT
                            oso.so_id,
                            oso.org_id,
                            oso.geo,
                            oso.cp_id,
                            oso.lead_id,
                            oso.amount,
                            oso.payment_method,
                            oso.status,
                            oso.createdate,
                            oso.creation_date,
                            sum(
                                CASE
                                    WHEN oso.status = ANY (ARRAY[43, 357]) THEN 1
                                    ELSE NULL::integer
                                END) OVER (PARTITION BY oso.lead_id) AS validated_rn,
                            row_number() OVER (PARTITION BY oso.lead_id ORDER BY oso.createdate DESC) AS rn,
                                CASE
                                    WHEN row_number() OVER (PARTITION BY oso.lead_id ORDER BY oso.createdate DESC) = 1 AND sum(
                                    CASE
									WHEN oso.status = ANY (ARRAY[43, 357]) THEN 1
									ELSE NULL::integer
                                    END) OVER (PARTITION BY oso.lead_id) > 0 AND (oso.status <> ALL (ARRAY[43, 357])) THEN 2::bigint
                                    WHEN row_number() OVER (PARTITION BY oso.lead_id ORDER BY oso.createdate DESC) <> 1 AND (oso.status = ANY (ARRAY[43, 357])) THEN 1::bigint
                                    ELSE row_number() OVER (PARTITION BY oso.lead_id ORDER BY oso.createdate DESC)
                                END AS final_rn
                           FROM od_sale_order oso
                          WHERE org_id = 9 -- and oso.geo in ('ID') 
                          and oso.createdate::date >= '2023-01-01'
                          and oso.status <> 46
                          ) a_1
                  WHERE a_1.final_rn = 1) od on od.lead_id = d.lead_id -- and od.geo = d.geo
	left join (select * from od_do_new where org_id = 9 and createdate::date >= '2023-01-01') del on del.so_id = od.so_id -- and del.geo = od.geo
	left join (select * from bp_warehouse where  geo = 'ID') j on del.warehouse_id = j.warehouse_id -- and del.geo = j.geo
	left join (select * from bp_partner where  geo = 'ID')  k on del.carrier_id = k.pn_id -- and del.geo = k.geo
	left join (select * from lc_district where  geo = 'ID')  e on cast(e.dt_id as varchar)=cast(d.district as varchar) -- and e.geo = d.geo
	left join (select * from cf_synonym where type ='lead status' and geo = 'ID') g on d.lead_status=g.value -- and d.geo = g.geo
	left join (select * from cf_synonym where type ='sale order status' and geo = 'ID') h on od.status=h.value -- and od.geo = h.geo
	left join (select * from cf_synonym where type ='delivery order status' and geo = 'ID') i on del.status=i.value -- and del.geo = i.geo
	left join (select * from or_user where  geo = 'ID')   p on p.user_id=d.assigned -- and p.geo = d.geo
	-- care for integer error input here
	left join (select * from lc_province where  geo = 'ID')  l on cast(l.prv_id as varchar) = cast(d.province as varchar) -- and l.geo = d.geo
	--left join lc_district m on cast(m.dt_id as varchar) = cast(d.district as varchar)
	--left join lc_subdistrict n on cast(n.sdt_id as varchar) = cast(d.subdistrict as varchar)
	left join (select * from cp_campaign where  geo = 'ID')   q on q.cp_id = d.cp_id -- and q.geo = d.geo
	left join (select * from cl_calling_list where  geo = 'ID')  r on r.callinglist_id = d.callinglist_id -- and r.geo = d.geo
	left join (  select createdate,lead_id,affiliate,sub_id1,offer,max_po,payout,profit,transaction_id
	  from ods_affscale_conversion
	  where geo = 'ID' and createdate::date >= '2023-01-01'
	  ) oac 
	  on d.click_id = oac.transaction_id
	  left join
	(with temp_so as (
		SELECT oi_id, osi.geo,
		so_id,
		quantity,
		item_no,
		osi.prod_id,
		pp.name as product_name,
		row_number() over(partition by so_id order by item_no) as item_no_new
		FROM (select * from od_so_item where geo = 'ID'
		     and createdate::date >= '2023-01-01' ) osi 
		left join (select * from pd_product where geo = 'ID')  pp
		on osi.prod_id = pp.prod_id -- and osi.geo = pp.geo
--		where osi.geo in ('ID')
--		and osi.createdate::date >= '2023-01-01'
		)
		SELECT so_id,-- geo,
		max((case when item_no_new = 1 then product_name end)) as product1,
		SUM(quantity) no_quantity,
		COUNT(DISTINCT prod_id) as no_product 
		FROM temp_so
		group by so_id --, geo
--		order by so_id desc
		) osi
	on od.so_id = osi.so_id -- and od.geo = osi.geo
--	where d.createdate::date >= '2023-01-01'
--	and d.cp_id not in (504, 505) -- and d.geo in ('ID')
--	and CASE
--            WHEN d.lead_status = 4 OR d.lead_status = 5 AND d.assigned = 0 THEN 1
--            ELSE 0
--        END <> 1
	) d 
--	where d.orgid = 9 --Indo
	)-- final select
    , cte_final as ( 
	select
	date_used::date, sourcename, sourcename_fnl, agname, wholesale_name, leadtype, product_name, affiliateid, cpname, subid_fnl, subid, province, district, carrier, paymentmethod, warehouse,
	count(distinct leadid) as leads, sum(approved) as approve, sum(validated) as validate, sum(trash) as trash, sum(callback) as callback, sum(uncall) as uncall,
	sum(case when lower(leadstatus) = 'approved' and lower(orderstatus) = 'validated' and lower(status_transport) in ('delivered') then amount else null end) as delivered_amount,
	sum(case when lower(leadstatus) = 'approved' and lower(orderstatus) = 'validated' and lower(status_transport) in ('delivered') then no_quantity else null end) as delivered_qty,
	sum(case when lower(leadstatus) = 'approved' and lower(orderstatus) = 'validated' and lower(status_transport) in ('delivered') then delivered else null end) as delivered,
	sum(case when lower(leadstatus) = 'approved' and lower(orderstatus) in ('validated', 'delay') then amount else null end) as validated_amount,
	sum(case when lower(leadstatus) = 'approved' and lower(orderstatus) in ('validated', 'delay') then no_quantity else null end) as validated_qty,
	sum(case when lower(leadstatus) = 'approved' and lower(orderstatus) in ('validated', 'delay') then validated else null end) as validated,
	sum(reject) as rejected,
	sum(cancelled) as cancelled, 
	sum(other_deli) as other_deli,
	count(distinct case when lower(leadstatus) = 'approved' and lower(orderstatus) in ('validated', 'delay') then leadid else null end) as total_do,
    count(distinct case when postback_status = 'approved' then leadid else null end) as total_approved_postback,
	count(distinct case when lower(leadstatus) = 'approved' and lower(orderstatus) in ('validated', 'delay') and postback_status in ('pending_postback', 'pending_pb') then leadid else null end) as total_pending_postback,
	count(distinct case when lower(orderstatus) in ('validated', 'delay') and lower(status_transport) in ('intransit', 'delivering') then tracking_code else null end) as total_intransit,
	sum(amount) as total_amount, sum(no_quantity) as quantity, leadstatus, status_transport, adjusted_status_transport, team, 'ID' as "Geo", avg(max_po) max_po, avg(payout) payout
	from a
    where a.filters = 0
--	where date_used::date >= '2023-01-01'
	group by date_used, sourcename, sourcename_fnl, agname, wholesale_name, leadtype, product_name, affiliateid, cpname, subid_fnl, subid, province, district, 
	carrier, paymentmethod, warehouse, leadstatus, status_transport, adjusted_status_transport, team
    )
	select  * , 
			case when product_name::text ~~ '%cpl%'::text THEN leads - trash 
			else null::bigint 
			end as cpl_lead
	from cte_final     
    """
    df: pd.DataFrame = extract_from_dwh(query, oltp01_conn)
    return df


@asset(group_name="push_dim_finance", retry_policy=RetryPolicy(max_retries=3))
def push_dim_finance_agg_th(oltp01_conn: PostgresConnection) -> pd.DataFrame:
    query = f"""
	--- Finance Rebuild 
	--- Thai DWH 2023
	with a as
	(select  d.orgid, d.soid, d.tracking_code, d.do_code,
	d.leadid,d.leadname ,d.leadphone,
	--case when d.prod_name is null or d.prod_name = '' then lower(product1)
	--	else lower(d.prod_name)
	--end as product_name,
	--b.product productcrosssell , 
	d.amount ,
	d.sourcename,
	case when sourcename = 'AFS' then affiliateid else sourcename end as sourcename_fnl, -- lead_date::date >= '2021-04-01' and 
	d.sourcecode ,d.agid , d.agname,
	case
			when lower(d.agname) like 'r%' then 'CIT'
			when lower(d.agname) like 'a%' then 'Fresh'
			else 'Others'
		end as team,
	case when lower(d.lstatus) = 'approved' then 1 else 0 end as approved,
	case when lower(d.lstatus) = 'trash' then 1 else 0 end as trash,
	case when lower(d.lstatus) in ('callback consulting','callback not prospect','callback potential') then 1 else 0 end as callback,
	case when lower(d.lstatus) in ('noanswer','unreachable') then 1 else 0 end as uncall,
	case when lower(d.sostatus) in ('validated','delay') then 1 else 0 end as validated,
	d.province,
	d.district,
	--d.comment ,coalesce(d.address||'###'||n.name||'-'||m.name||'-'||l.name ,d.address) as address,
	carrier, warehouse, status_transport, delivered, null delivering, cancelled, reject, --unassigned,
	CASE
            WHEN trim(lower(status_transport)) IN ('new') THEN 'New'
            WHEN trim(lower(status_transport)) IN ('packed','picking','in preparation','ready to pick') THEN 'Preparing'
            WHEN trim(lower(status_transport)) IN ('pending') THEN 'Pending'
            WHEN trim(lower(status_transport)) IN ('intransit','picked up','pending delivery') THEN 'In-transit'
            WHEN trim(lower(status_transport)) IN ('pre-delivery','delivering') THEN 'Delivering'
            WHEN trim(lower(status_transport))  IN ('delivery fail') THEN 'Failed'
			WHEN trim(lower(status_transport)) IN ('delivered') THEN 'Delivered'
			WHEN trim(lower(status_transport)) IN ('reject') THEN 'Reject'
			WHEN trim(lower(status_transport)) IN ('returning','returned') THEN 'Return'
			WHEN trim(lower(status_transport)) IN ('cancel') THEN 'Cancel'
			WHEN trim(lower(status_transport)) IN ('unassigned') THEN 'Unassigned'
    	   ELSE 'New'
	END AS adjusted_status_transport,
	--e.ffm_id ffmid,f.shortname ffmname ,e.warehouse_id warehouseid,j.warehouse_shortname warehousename , 
	--k.shortname lastmilename ,
	case d.payment_method when 1 then 'COD' when 2 then 'Bank Transfer' end as paymentmethod,
	d.other_deli,
	--d.lead_status leadstatusid,
	d.lstatus as leadstatus ,
	--a.status sostatusid ,
	d.sostatus as orderstatus ,
	--e.status dostatusid ,i.name deliverystatus ,
	--d.leadtype,
	case when d.leadtype = 'S' then 'M' else d.leadtype end as leadtype,
	--d.createdate d.lead_date,
	d.modifydate, --coalesce(e.updatedate, a.modifydate,d.modifydate) modify_date 
	d.so_date,
	d. product_name,
	d.totalcall,
	--d.cp_id cpid,
	d.cpname ,
	d.subid,
	--d.callinglist_id callinglistid,r.cl_name callinglistname ,1  groupid, 'null' groupname--t.group_id, t.short_name group_name
	case when d.sourcename = 'AFS' then d.affiliateid else d.sourcename end as affiliateid,
	--d.affiliateid, 
	--d.user_defin_05 reason, 
	d.click_id clickid, d.no_quantity,
	case when sourcename = 'AFS' then subid
		else affiliateid
	end as subid_fnl,
	null wholesale_name,
	case when leadtype = 'A' then lead_date else so_date end as date_used,
	max_po,
	payout,
    d.postback_status,
    case when leadtype = 'M' and sourcename is not null and cpname = 'HC OS' then 1 else 0 end filters
	from (
	select d.org_id as orgid, d.lead_id as leadid, d.name as leadname, d.phone as leadphone,
	prod_id, prod_name, d.total_call as totalcall,lead_status, lead_type as leadtype, agc_id, agc_code as sourcecode, --comment,
	od.so_id as soid, od.payment_method, od.createdate as so_date,
	del.tracking_code, e.code as do_code, od.amount,
	p.user_name as agname, q.name as cpname, osi.no_quantity,
	e.name as district, l.name as province,
	k.shortname as carrier, --del.carrier_id as carrier, 
	j.warehouse_name as warehouse, --del.warehouse_id as warehouse, 
	i.name as status_transport,
	case when lower(i.name) in ('delivered') and lower(h.name) not in ('unassigned') then 1 else 0 end as delivered,
	case when lower(i.name) in ('intransit', 'delivering') and lower(h.name) not in ('unassigned') then 1 else 0 end as delivering,
	case when lower(i.name) in ('cancel') and lower(h.name) not in ('unassigned') then 1 else 0 end as cancelled,
	case when lower(i.name) in ('returned', 'returning') and lower(h.name) not in ('unassigned') then 1 else 0 end as reject,
	case when (lower(i.name) not in ('delivered', 'intransit', 'delivering', 'cancel', 'returned', 'returning')
			and lower(g.name) in ('approved') 
			and lower(h.name) in ('validated', 'delay'))
		or
			(lower(g.name) in ('approved') 
			and lower(h.name) in ('validated', 'delay') 
			and lower(i.name) is null)
		then 1 else 0 end as other_deli,
	d.address, assigned as agid, d.createdate as lead_date, d.modifydate, d.cp_id, d.callinglist_id, affiliate_id as affiliateid, user_defin_05,click_id,subid1 as subid,
	coalesce(o.shortname,d.agc_code) as sourcename,
	case when d.prod_name is null or d.prod_name = '' then lower(product1) else lower(d.prod_name) end as product_name,
	g.name as lstatus, h.name as sostatus,
	oac.max_po,
	oac.payout,
    d.postback_status
	from (select * 
			from cl_fresh 
			where org_id = 10 --Thai 
			and modifydate::date >= '2023-01-01'
			and CASE
            WHEN lead_status = 4 OR lead_status = 5 AND assigned = 0 THEN 1
            ELSE 0
        END <> 1 
	) d 
	left join (select * from bp_partner where geo = 'TH') o on d.agc_id = o.pn_id -- and d.geo = o.geo
	--left join bp_partner f on e.ffm_id = f.pn_id
	--left join bp_partner o on d.agc_id = o.pn_id
	left join ( SELECT
                    a_1.so_id,
                    a_1.org_id,
                    a_1.geo,
                    a_1.cp_id,
                    a_1.lead_id,
                    a_1.amount,
                    a_1.payment_method,
                    a_1.status,
                    a_1.createdate,
                    a_1.creation_date,
                    a_1.validated_rn,
                    a_1.rn,
                    a_1.final_rn
                   FROM ( SELECT
                            oso.so_id,
                            oso.org_id,
                            oso.geo,
                            oso.cp_id,
                            oso.lead_id,
                            oso.amount,
                            oso.payment_method,
                            oso.status,
                            oso.createdate,
                            oso.creation_date,
                            sum(
                                CASE
                                    WHEN oso.status = ANY (ARRAY[43, 357]) THEN 1
                                    ELSE NULL::integer
                                END) OVER (PARTITION BY oso.lead_id) AS validated_rn,
                            row_number() OVER (PARTITION BY oso.lead_id ORDER BY oso.createdate DESC) AS rn,
                                CASE
                                    WHEN row_number() OVER (PARTITION BY oso.lead_id ORDER BY oso.createdate DESC) = 1 AND sum(
                                    CASE
WHEN oso.status = ANY (ARRAY[43, 357]) THEN 1
ELSE NULL::integer
                                    END) OVER (PARTITION BY oso.lead_id) > 0 AND (oso.status <> ALL (ARRAY[43, 357])) THEN 2::bigint
                                    WHEN row_number() OVER (PARTITION BY oso.lead_id ORDER BY oso.createdate DESC) <> 1 AND (oso.status = ANY (ARRAY[43, 357])) THEN 1::bigint
                                    ELSE row_number() OVER (PARTITION BY oso.lead_id ORDER BY oso.createdate DESC)
                                END AS final_rn
                           FROM od_sale_order oso
                          where oso.org_id = 10 and createdate::date >= '2023-01-01' and  oso.status <> 46
                          ) a_1
                  WHERE a_1.final_rn = 1) od on od.lead_id = d.lead_id -- and od.geo = d.geo
	left join (select * from od_do_new where org_id = 10 and createdate::date >= '2023-01-01') del on del.so_id = od.so_id -- and del.geo = od.geo
	left join (select * from bp_warehouse where geo = 'TH') j on del.warehouse_id = j.warehouse_id -- and del.geo = j.geo
	left join (select * from bp_partner where geo = 'TH')  k on del.carrier_id = k.pn_id -- and del.geo = k.geo
	left join (select * from lc_district where geo = 'TH')  e on cast(e.dt_id as varchar)=cast(d.district as varchar) -- and e.geo = d.geo
	left join (select * from cf_synonym where type ='lead status' and geo = 'TH') g on d.lead_status=g.value -- and d.geo = g.geo
	left join (select * from cf_synonym where type ='sale order status'and geo = 'TH' ) h on od.status=h.value -- and od.geo = h.geo
	left join (select * from cf_synonym where type ='delivery order status' and geo = 'TH') i on del.status=i.value -- and del.geo = i.geo
	left join (select * from or_user where geo = 'TH')  p on p.user_id=d.assigned -- and p.geo = d.geo
	-- care for integer error input here
	left join (select * from lc_province where geo = 'TH')  l on cast(l.prv_id as varchar) = cast(d.province as varchar) -- and l.geo = d.geo
	--left join lc_district m on cast(m.dt_id as varchar) = cast(d.district as varchar)
	--left join lc_subdistrict n on cast(n.sdt_id as varchar) = cast(d.subdistrict as varchar)
	left join (select * from cp_campaign where geo = 'TH')   q on q.cp_id = d.cp_id -- and q.geo = d.geo
	left join (select * from public.cl_calling_list where geo = 'TH')  r on r.callinglist_id = d.callinglist_id -- and r.geo = d.geo
	left join (  select createdate,lead_id,affiliate,sub_id1,offer,max_po,payout,profit,transaction_id
	  from ods_affscale_conversion
	  where geo = 'TH' and createdate::date >= '2023-01-01'
	  ) oac 
	  on d.click_id = oac.transaction_id
	left join
	(with temp_so as (
		SELECT oi_id, osi.geo,
		so_id,
		quantity,
		item_no,
		osi.prod_id,
		pp.name as product_name,
		row_number() over(partition by so_id order by item_no) as item_no_new
		FROM (select * from od_so_item where geo = 'TH'
		     and createdate::date >= '2023-01-01' and prod_id not in (460, 461)  ) osi 
		left join (select * from pd_product where geo = 'TH' ) pp 
		on osi.prod_id = pp.prod_id -- and osi.geo = pp.geo
--		where osi.prod_id not in (460, 461)
--		and osi.geo = 'TH'
--		and osi.createdate::date >= '2023-01-01'
	--	order by osi.so_id 
		)
		SELECT so_id,-- geo,
		max((case when item_no_new = 1 then product_name end)) as product1,
		SUM(quantity) no_quantity,
		COUNT(DISTINCT prod_id) as no_product 
		FROM temp_so
		group by so_id --, geo
--		order by so_id desc
		) osi
	on od.so_id = osi.so_id -- and od.geo = osi.geo
	) d
	) 
	-- final select
    , cte_final as (
	select
	date_used::date date_used, sourcename, sourcename_fnl, agname, wholesale_name, leadtype, product_name, affiliateid, cpname, subid_fnl, subid, province, district, carrier, paymentmethod, warehouse,
	count(distinct leadid) as leads, sum(approved) as approve, 
	sum(validated) as validate, 
	sum(trash) as trash, sum(callback) as callback, sum(uncall) as uncall,
	sum(case when lower(leadstatus) = 'approved' and lower(orderstatus) = 'validated' and lower(status_transport) in ('delivered') then amount else null end) as delivered_amount,
	sum(case when lower(leadstatus) = 'approved' and lower(orderstatus) = 'validated' and lower(status_transport) in ('delivered') then no_quantity else null end) as delivered_qty,
	sum(case when lower(leadstatus) = 'approved' and lower(orderstatus) = 'validated' and lower(status_transport) in ('delivered') then delivered else null end) as delivered,
	sum(case when lower(leadstatus) = 'approved' and lower(orderstatus) in ('validated', 'delay') then amount else null end) as validated_amount,
	sum(case when lower(leadstatus) = 'approved' and lower(orderstatus) in ('validated', 'delay') then no_quantity else null end) as validated_qty,
	sum(case when lower(leadstatus) = 'approved' and lower(orderstatus) in ('validated', 'delay') then validated else null end) as validated,
	sum(reject) as rejected,
	sum(cancelled) as cancelled, 
	sum(other_deli) as other_deli,
	count(distinct case when lower(leadstatus) = 'approved' and lower(orderstatus) in ('validated', 'delay') then leadid else null end) as total_do,
	count(distinct case when postback_status = 'approved'  then leadid else null end) as total_approved_postback,
	count(distinct case when lower(leadstatus) = 'approved' and lower(orderstatus) in ('validated', 'delay') and postback_status in ('pending_postback', 'pending_pb') then leadid else null end) as total_pending_postback,
	count(distinct case when lower(orderstatus) in ('validated', 'delay') and lower(status_transport) in ('intransit', 'delivering') then tracking_code else null end) as total_intransit,
	sum(amount) as total_amount, sum(no_quantity) as quantity, leadstatus, status_transport, adjusted_status_transport, team, 'TH' as "Geo", avg(max_po) max_po, avg(payout) payout
	from a
    where a.filters = 0
--	where date_used::date >= '2023-01-01'
	group by date_used, sourcename, sourcename_fnl, agname, wholesale_name, leadtype, product_name, affiliateid, cpname, subid_fnl, subid, province, district, carrier, paymentmethod, 
	warehouse, leadstatus, status_transport, adjusted_status_transport,team	
        )
	select  * , 
			case when product_name::text ~~ '%cpl%'::text THEN leads - trash 
			else null::bigint 
			end as cpl_lead
	from cte_final     
    """
    df: pd.DataFrame = extract_from_dwh(query, oltp01_conn)
    return df


@asset(group_name="push_dim_finance", retry_policy=RetryPolicy(max_retries=3))
def push_dim_finance_agg_th2(oltp01_conn: PostgresConnection) -> pd.DataFrame:
    query = f"""
	with a as
	(
	select  d.orgid, d.soid, d.tracking_code, d.do_code,
	d.leadid,d.leadname ,d.leadphone,
	--case when d.prod_name is null or d.prod_name = '' then lower(product1)
	--	else lower(d.prod_name)
	--end as product_name,
	--b.product productcrosssell , 
	d.amount ,
	d.sourcename,
	case when  sourcename = 'AFS' then affiliateid else sourcename end as sourcename_fnl, -- lead_date::date >= '2021-04-01' and
	d.sourcecode ,d.agid , d.agname,
	case
			when lower(d.agname) like 'r%' then 'CIT'
			when lower(d.agname) like 'a%' then 'Fresh'
			else 'Others'
		end as team,
	case when lower(d.lstatus) = 'approved' then 1 else 0 end as approved,
	case when lower(d.lstatus) = 'trash' then 1 else 0 end as trash,
	case when lower(d.lstatus) in ('callback consulting','callback not prospect','callback potential') then 1 else 0 end as callback,
	case when lower(d.lstatus) in ('noanswer','unreachable') then 1 else 0 end as uncall,
	case when lower(d.sostatus) in ('validated','delay') then 1 else 0 end as validated,
	d.province,
	d.district,
	--d.comment ,coalesce(d.address||'###'||n.name||'-'||m.name||'-'||l.name ,d.address) as address,
	carrier, warehouse, status_transport, delivered, null delivering, cancelled, reject, --unassigned,
	CASE
            WHEN trim(lower(status_transport)) IN ('new') THEN 'New'
            WHEN trim(lower(status_transport)) IN ('packed','picking','in preparation','ready to pick') THEN 'Preparing'
            WHEN trim(lower(status_transport)) IN ('pending') THEN 'Pending'
            WHEN trim(lower(status_transport)) IN ('intransit','picked up','pending delivery') THEN 'In-transit'
            WHEN trim(lower(status_transport)) IN ('pre-delivery','delivering') THEN 'Delivering'
            WHEN trim(lower(status_transport))  IN ('delivery fail') THEN 'Failed'
			WHEN trim(lower(status_transport)) IN ('delivered') THEN 'Delivered'
			WHEN trim(lower(status_transport)) IN ('reject') THEN 'Reject'
			WHEN trim(lower(status_transport)) IN ('returning','returned') THEN 'Return'
			WHEN trim(lower(status_transport)) IN ('cancel') THEN 'Cancel'
			WHEN trim(lower(status_transport)) IN ('unassigned') THEN 'Unassigned'
    	   ELSE 'New'
	END AS adjusted_status_transport,
	--e.ffm_id ffmid,f.shortname ffmname ,e.warehouse_id warehouseid,j.warehouse_shortname warehousename , 
	--k.shortname lastmilename ,
	case d.payment_method when 1 then 'COD' when 2 then 'Bank Transfer' end as paymentmethod,
	d.other_deli,
	--d.lead_status leadstatusid,
	d.lstatus as leadstatus ,
	--a.status sostatusid ,
	d.sostatus as orderstatus ,
	--e.status dostatusid ,i.name deliverystatus ,
	--d.leadtype,
	case when d.leadtype = 'S' then 'M' else d.leadtype end as leadtype,
	--d.createdate d.lead_date,
	d.modifydate, --coalesce(e.updatedate, a.modifydate,d.modifydate) modify_date 
	d.so_date,
	d. product_name,
	d.totalcall,
	--d.cp_id cpid,
	d.cpname ,
	d.subid,
	--d.callinglist_id callinglistid,r.cl_name callinglistname ,1  groupid, 'null' groupname--t.group_id, t.short_name group_name
	case when d.sourcename = 'AFS' then d.affiliateid else d.sourcename end as affiliateid,
	--d.affiliateid, 
	--d.user_defin_05 reason, 
	d.click_id clickid, d.no_quantity,
	case when sourcename = 'AFS' then subid --  lead_date >= '2021-04-01' and
		else affiliateid
	end as subid_fnl,
	null wholesale_name,
	case when leadtype = 'A' then lead_date else so_date end as date_used,
	max_po,
	payout,
    d.postback_status,
    case when leadtype = 'M' and sourcename is not null and cpname = 'HC OS' then 1 else 0 end filters
	from (
	select d.org_id as orgid, d.lead_id as leadid, d.name as leadname, d.phone as leadphone,
	prod_id, prod_name, d.total_call as totalcall,lead_status, lead_type as leadtype, agc_id, agc_code as sourcecode, --comment,
	od.so_id as soid, od.payment_method, od.createdate as so_date,
	del.tracking_code, e.code as do_code, od.amount,
	p.user_name as agname, q.name as cpname, osi.no_quantity,
	e.name as district, l.name as province,
	k.shortname as carrier, --del.carrier_id as carrier, 
	j.warehouse_name as warehouse, --del.warehouse_id as warehouse, 
	i.name as status_transport,
	case when lower(i.name) in ('delivered') and lower(h.name) not in ('unassigned') then 1 else 0 end as delivered,
	case when lower(i.name) in ('intransit', 'delivering') and lower(h.name) not in ('unassigned') then 1 else 0 end as delivering,
	case when lower(i.name) in ('cancel') and lower(h.name) not in ('unassigned') then 1 else 0 end as cancelled,
	case when lower(i.name) in ('returned', 'returning') and lower(h.name) not in ('unassigned') then 1 else 0 end as reject,
	case when (lower(i.name) not in ('delivered', 'intransit', 'delivering', 'cancel', 'returned', 'returning')
			and lower(g.name) in ('approved') 
			and lower(h.name) in ('validated', 'delay'))
		or
			(lower(g.name) in ('approved') 
			and lower(h.name) in ('validated', 'delay') 
			and lower(i.name) is null)
		then 1 else 0 end as other_deli,
	d.address, assigned as agid, d.createdate as lead_date, d.modifydate, d.cp_id, d.callinglist_id, affiliate_id as affiliateid, user_defin_05,click_id,subid1 as subid,
	coalesce(o.shortname,d.agc_code) as sourcename,
	case when d.prod_name is null or d.prod_name = '' then lower(product1) else lower(d.prod_name) end as product_name,
	g.name as lstatus, h.name as sostatus,
	oac.max_po,
	oac.payout,
    d.postback_status
	from (
        select * from cl_fresh 
		where org_id = 12  -- 'TH2' 
		and modifydate::date >= '2023-01-01'
		and CASE
            WHEN cl_fresh.lead_status = 4 OR cl_fresh.lead_status = 5 AND cl_fresh.assigned = 0 THEN 1
            ELSE 0
        END <> 1
	) d
	left join (select * from bp_partner where geo = 'TH2' ) o on d.agc_id = o.pn_id -- and d.geo = o.geo
	--left join bp_partner f on e.ffm_id = f.pn_id
	--left join bp_partner o on d.agc_id = o.pn_id
	left join ( SELECT
                    a_1.so_id,
                    a_1.org_id,
                    a_1.geo,
                    a_1.cp_id,
                    a_1.lead_id,
                    a_1.amount,
                    a_1.payment_method,
                    a_1.status,
                    a_1.createdate,
                    a_1.creation_date,
                    a_1.validated_rn,
                    a_1.rn,
                    a_1.final_rn
                   FROM ( SELECT
                            oso.so_id,
                            oso.org_id,
                            oso.geo,
                            oso.cp_id,
                            oso.lead_id,
                            oso.amount,
                            oso.payment_method,
                            oso.status,
                            oso.createdate,
                            oso.creation_date,
                            sum(
                                CASE
                                    WHEN oso.status = ANY (ARRAY[43, 357]) THEN 1
                                    ELSE NULL::integer
                                END) OVER (PARTITION BY oso.lead_id) AS validated_rn,
                            row_number() OVER (PARTITION BY oso.lead_id ORDER BY oso.createdate DESC) AS rn,
                                CASE
                                    WHEN row_number() OVER (PARTITION BY oso.lead_id ORDER BY oso.createdate DESC) = 1 AND sum(
                                    CASE
	WHEN oso.status = ANY (ARRAY[43, 357]) THEN 1
	ELSE NULL::integer
                                    END) OVER (PARTITION BY oso.lead_id) > 0 AND (oso.status <> ALL (ARRAY[43, 357])) THEN 2::bigint
                                    WHEN row_number() OVER (PARTITION BY oso.lead_id ORDER BY oso.createdate DESC) <> 1 AND (oso.status = ANY (ARRAY[43, 357])) THEN 1::bigint
                                    ELSE row_number() OVER (PARTITION BY oso.lead_id ORDER BY oso.createdate DESC)
                                END AS final_rn
                           FROM od_sale_order oso
                          WHERE oso.org_id = 12 -- 'TH2'
                          and oso.createdate::date >= '2023-01-01'
                          and oso.status <> 46 
                          ) a_1
                  WHERE a_1.final_rn = 1) od on od.lead_id = d.lead_id -- and od.geo = d.geo
	left join (select * from od_do_new where org_id = 12 and createdate::date >= '2023-01-01') del on del.so_id = od.so_id -- and del.geo = od.geo
	left join (select * from bp_warehouse where geo = 'TH2') j on del.warehouse_id = j.warehouse_id -- and del.geo = j.geo
	left join (select * from bp_partner where geo = 'TH2') k on del.carrier_id = k.pn_id -- and del.geo = k.geo
	left join (select * from lc_district where geo = 'TH2') e on cast(e.dt_id as varchar)=cast(d.district as varchar) -- and e.geo = d.geo
	left join (select * from cf_synonym where type ='lead status' and geo = 'TH2') g on d.lead_status=g.value -- and d.geo = g.geo
	left join (select * from cf_synonym where type ='sale order status' and geo = 'TH2') h on od.status=h.value -- and od.geo = h.geo
	left join (select * from cf_synonym where type ='delivery order status' and geo = 'TH2') i on del.status=i.value -- and del.geo = i.geo
	left join (select * from or_user where geo = 'TH2') p on p.user_id=d.assigned -- and p.geo = d.geo
	-- care for integer error input here
	left join (select * from lc_province where geo = 'TH2') l on cast(l.prv_id as varchar) = cast(d.province as varchar) -- and l.geo = d.geo
	--left join lc_district m on cast(m.dt_id as varchar) = cast(d.district as varchar)
	--left join lc_subdistrict n on cast(n.sdt_id as varchar) = cast(d.subdistrict as varchar)
	left join (select * from cp_campaign where geo = 'TH2') q on q.cp_id = d.cp_id -- and q.geo = d.geo
	left join (select * from public.cl_calling_list where geo = 'TH2')  r on r.callinglist_id = d.callinglist_id -- and r.geo = d.geo
	left join (  select createdate,lead_id,affiliate,sub_id1,offer,max_po,payout,profit,transaction_id
	  from ods_affscale_conversion
	  where geo = 'TH' and createdate::date >= '2023-01-01'
	  ) oac 
	  on d.click_id = oac.transaction_id
	left join
	(with temp_so as 
		(
			SELECT oi_id, osi.geo,
			so_id,
			quantity,
			item_no,
			osi.prod_id,
			pp.name as product_name,
			row_number() over(partition by so_id order by item_no) as item_no_new
			FROM (select * from od_so_item where geo = 'TH2'
			     and createdate::date >= '2023-01-01' and prod_id not in (460, 461)  ) osi 
			left join (select * from pd_product where geo = 'TH2' )  pp 
			on osi.prod_id = pp.prod_id 
	--	order by osi.so_id 
		)
		SELECT so_id, -- geo,
		max((case when item_no_new = 1 then product_name end)) as product1,
		SUM(quantity) no_quantity,
		COUNT(DISTINCT prod_id) as no_product 
		FROM temp_so
		group by so_id --, geo
--		order by so_id desc
		) osi
	on od.so_id = osi.so_id --and od.geo = osi.geo
	) d 
--	where d.orgid = 12 --Thai2
	)
	-- final select
    , cte_final as ( 
	select
	date_used::date, sourcename, sourcename_fnl, agname, wholesale_name, leadtype, product_name, affiliateid, cpname, subid_fnl, subid, province, district, carrier, paymentmethod, warehouse,
	count(distinct leadid) as leads, sum(approved) as approve, sum(validated) as validate, sum(trash) as trash, sum(callback) as callback, sum(uncall) as uncall,
	sum(case when lower(leadstatus) = 'approved' and lower(orderstatus) = 'validated' and lower(status_transport) in ('delivered') then amount else null end) as delivered_amount,
	sum(case when lower(leadstatus) = 'approved' and lower(orderstatus) = 'validated' and lower(status_transport) in ('delivered') then no_quantity else null end) as delivered_qty,
	sum(case when lower(leadstatus) = 'approved' and lower(orderstatus) = 'validated' and lower(status_transport) in ('delivered') then delivered else null end) as delivered,
	sum(case when lower(leadstatus) = 'approved' and lower(orderstatus) in ('validated', 'delay') then amount else null end) as validated_amount,
	sum(case when lower(leadstatus) = 'approved' and lower(orderstatus) in ('validated', 'delay') then no_quantity else null end) as validated_qty,
	sum(case when lower(leadstatus) = 'approved' and lower(orderstatus) in ('validated', 'delay') then validated else null end) as validated,
	sum(reject) as rejected,
	sum(cancelled) as cancelled, 
	sum(other_deli) as other_deli,
	count(distinct case when lower(leadstatus) = 'approved' and lower(orderstatus) in ('validated', 'delay') then leadid else null end) as total_do,
	count(distinct case when postback_status = 'approved' then leadid else null end) as total_approved_postback,
	count(distinct case when lower(leadstatus) = 'approved' and lower(orderstatus) in ('validated', 'delay') and postback_status in ('pending_postback', 'pending_pb') then leadid else null end) as total_pending_postback,
	count(distinct case when lower(orderstatus) in ('validated', 'delay') and lower(status_transport) in ('intransit', 'delivering') then tracking_code else null end) as total_intransit,
	sum(amount) as total_amount, sum(no_quantity) as quantity, leadstatus, status_transport, adjusted_status_transport, team, 'TH2' as "Geo", avg(max_po) max_po, avg(payout) payout
	from a
    where a.filters = 0
--	where date_used::date >= '2023-01-01'
	group by date_used, sourcename, sourcename_fnl, agname, wholesale_name, leadtype, product_name, affiliateid, cpname, subid_fnl, subid, 
	province, district, carrier, paymentmethod, warehouse, leadstatus, status_transport, adjusted_status_transport,team
    )
	select  * , 
			case when product_name::text ~~ '%cpl%'::text THEN leads - trash 
			else null::bigint 
			end as cpl_lead
	from cte_final     
    """
    df: pd.DataFrame = extract_from_dwh(query, oltp01_conn)
    return df


@asset(group_name="push_dim_finance", retry_policy=RetryPolicy(max_retries=3))
def push_dim_finance_agg_my(oltp01_conn: PostgresConnection) -> pd.DataFrame:
    query = f"""
--- Finance Rebuild 
	--- MY DWH 2023
	with a as
	(select  d.orgid, d.soid, d.tracking_code, d.do_code,
	d.leadid,d.leadname ,d.leadphone,
	--case when d.prod_name is null or d.prod_name = '' then lower(product1)
	--	else lower(d.prod_name)
	--end as product_name,
	--b.product productcrosssell , 
	d.amount ,
	d.sourcename,
	case when sourcename = 'AFS' then affiliateid else sourcename end as sourcename_fnl, -- lead_date::date >= '2021-04-01' and 
	d.sourcecode ,d.agid , d.agname,
	case
			when lower(d.agname) like 'r%' then 'CIT'
			when lower(d.agname) like 'a%' then 'Fresh'
			else 'Others'
		end as team,
	case when lower(d.lstatus) = 'approved' then 1 else 0 end as approved,
	case when lower(d.lstatus) = 'trash' then 1 else 0 end as trash,
	case when lower(d.lstatus) in ('callback consulting','callback not prospect','callback potential') then 1 else 0 end as callback,
	case when lower(d.lstatus) in ('noanswer','unreachable') then 1 else 0 end as uncall,
	case when lower(d.sostatus) in ('validated','delay') then 1 else 0 end as validated,
	d.province,
	d.district,
	--d.comment ,coalesce(d.address||'###'||n.name||'-'||m.name||'-'||l.name ,d.address) as address,
	carrier, warehouse, status_transport, delivered, null delivering, cancelled, reject, --unassigned,
	CASE
            WHEN trim(lower(status_transport)) IN ('new') THEN 'New'
            WHEN trim(lower(status_transport)) IN ('packed','picking','in preparation','ready to pick') THEN 'Preparing'
            WHEN trim(lower(status_transport)) IN ('pending') THEN 'Pending'
            WHEN trim(lower(status_transport)) IN ('intransit','picked up','pending delivery') THEN 'In-transit'
            WHEN trim(lower(status_transport)) IN ('pre-delivery','delivering') THEN 'Delivering'
            WHEN trim(lower(status_transport))  IN ('delivery fail') THEN 'Failed'
			WHEN trim(lower(status_transport)) IN ('delivered') THEN 'Delivered'
			WHEN trim(lower(status_transport)) IN ('reject') THEN 'Reject'
			WHEN trim(lower(status_transport)) IN ('returning','returned') THEN 'Return'
			WHEN trim(lower(status_transport)) IN ('cancel') THEN 'Cancel'
			WHEN trim(lower(status_transport)) IN ('unassigned') THEN 'Unassigned'
    	   ELSE 'New'
	END AS adjusted_status_transport,
	--e.ffm_id ffmid,f.shortname ffmname ,e.warehouse_id warehouseid,j.warehouse_shortname warehousename , 
	--k.shortname lastmilename ,
	case d.payment_method when 1 then 'COD' when 2 then 'Bank Transfer' end as paymentmethod,
	d.other_deli,
	--d.lead_status leadstatusid,
	d.lstatus as leadstatus ,
	--a.status sostatusid ,
	d.sostatus as orderstatus ,
	--e.status dostatusid ,i.name deliverystatus ,
	--d.leadtype,
	case when d.leadtype = 'S' then 'M' else d.leadtype end as leadtype,
	--d.createdate d.lead_date,
	d.modifydate, --coalesce(e.updatedate, a.modifydate,d.modifydate) modify_date 
	d.so_date,
	d. product_name,
	d.totalcall,
	--d.cp_id cpid,
	d.cpname ,
	d.subid,
	--d.callinglist_id callinglistid,r.cl_name callinglistname ,1  groupid, 'null' groupname--t.group_id, t.short_name group_name
	case when d.sourcename = 'AFS' then d.affiliateid else d.sourcename end as affiliateid,
	--d.affiliateid, 
	--d.user_defin_05 reason, 
	d.click_id clickid, d.no_quantity,
	case when  sourcename = 'AFS' then subid -- lead_date >= '2021-04-01' and
		else affiliateid
	end as subid_fnl,
	null wholesale_name,
	case when leadtype = 'A' then lead_date else so_date end as date_used,
	max_po,
	payout,
    d.postback_status,
    case when leadtype = 'M' and sourcename is not null and cpname = 'HC OS' then 1 else 0 end filters
	from (
	select d.org_id as orgid, d.lead_id as leadid, d.name as leadname, d.phone as leadphone,
	prod_id, prod_name, d.total_call as totalcall,lead_status, lead_type as leadtype, agc_id, agc_code as sourcecode, --comment,
	od.so_id as soid, od.payment_method, od.createdate as so_date,
	del.tracking_code, e.code as do_code, od.amount,
	p.user_name as agname, q.name as cpname, osi.no_quantity,
	e.name as district, l.name as province,
	k.shortname as carrier, --del.carrier_id as carrier, 
	j.warehouse_name as warehouse, --del.warehouse_id as warehouse, 
	i.name as status_transport,
	case when lower(i.name) in ('delivered') and lower(h.name) not in ('unassigned') then 1 else 0 end as delivered,
	case when lower(i.name) in ('picked up', 'picking',
			'delivering',
			'delivery fail',
			'intransit'
			) and lower(h.name) not in ('unassigned') then 1 else 0 end as delivering,
	case when lower(i.name) in ('cancel') and lower(h.name) not in ('unassigned') then 1 else 0 end as cancelled,
	case when lower(i.name) in ('returned', 'returning') and lower(h.name) not in ('unassigned') then 1 else 0 end as reject,
	case when (lower(i.name) not in ('delivered', 'intransit', 'delivering','picked up','packed','ready to pick', 'cancel', 'returned', 'returning','delivery fail')
			and lower(g.name) in ('approved') 
			and lower(h.name) in ('validated', 'delay'))
		or
			(lower(g.name) in ('approved') 
			and lower(h.name) in ('validated', 'delay') 
			and lower(i.name) is null)
		then 1 else 0 end as other_deli,
	d.address, assigned as agid, d.createdate as lead_date, d.modifydate, d.cp_id, d.callinglist_id, affiliate_id as affiliateid, user_defin_05,click_id,subid1 as subid,
	coalesce(o.shortname,d.agc_code) as sourcename,
	case when d.prod_name is null or d.prod_name = '' then lower(product1) else lower(d.prod_name) end as product_name,
	g.name as lstatus, h.name as sostatus,
	oac.max_po,
	oac.payout,
    d.postback_status
	from (select * from cl_fresh where 
					org_id = 11 and createdate::date >= '2023-01-01' 
					and CASE
			            WHEN lead_status = 4 OR lead_status = 5 AND assigned = 0 THEN 1
			            ELSE 0
			        END <> 1
		) d
	left join (select * from bp_partner where geo = 'MY' ) o on d.agc_id = o.pn_id -- and d.geo = o.geo
	--left join bp_partner f on e.ffm_id = f.pn_id
	--left join bp_partner o on d.agc_id = o.pn_id
	left join ( SELECT
                    a_1.so_id,
                    a_1.org_id,
                    a_1.geo,
                    a_1.cp_id,
                    a_1.lead_id,
                    a_1.amount,
                    a_1.payment_method,
                    a_1.status,
                    a_1.createdate,
                    a_1.creation_date,
                    a_1.validated_rn,
                    a_1.rn,
                    a_1.final_rn
                   FROM ( SELECT
                            oso.so_id,
                            oso.org_id,
                            oso.geo,
                            oso.cp_id,
                            oso.lead_id,
                            oso.amount,
                            oso.payment_method,
                            oso.status,
                            oso.createdate,
                            oso.creation_date,
                            sum(
                                CASE
                                    WHEN oso.status = ANY (ARRAY[43, 357]) THEN 1
                                    ELSE NULL::integer
                                END) OVER (PARTITION BY oso.lead_id) AS validated_rn,
                            row_number() OVER (PARTITION BY oso.lead_id ORDER BY oso.createdate DESC) AS rn,
                                CASE
                                    WHEN row_number() OVER (PARTITION BY oso.lead_id ORDER BY oso.createdate DESC) = 1 AND sum(
                                    CASE
WHEN oso.status = ANY (ARRAY[43, 357]) THEN 1
ELSE NULL::integer
                                    END) OVER (PARTITION BY oso.lead_id) > 0 AND (oso.status <> ALL (ARRAY[43, 357])) THEN 2::bigint
                                    WHEN row_number() OVER (PARTITION BY oso.lead_id ORDER BY oso.createdate DESC) <> 1 AND (oso.status = ANY (ARRAY[43, 357])) THEN 1::bigint
                                    ELSE row_number() OVER (PARTITION BY oso.lead_id ORDER BY oso.createdate DESC)
                                END AS final_rn
                           FROM od_sale_order oso
                          WHERE oso.org_id = 11 -- MY
                          and oso.createdate::date >= '2023-01-01'
                          and oso.status <> 46
                          ) a_1
                  WHERE a_1.final_rn = 1) od on od.lead_id = d.lead_id -- and od.geo = d.geo
	left join (select * from od_do_new where org_id = 11 and createdate::date >= '2023-01-01') del on del.so_id = od.so_id -- and del.geo = od.geo
	left join (select * from bp_warehouse where geo = 'MY')  j on del.warehouse_id = j.warehouse_id -- and del.geo = j.geo
	left join (select * from bp_partner where geo = 'MY')  k on del.carrier_id = k.pn_id -- and del.geo = k.geo
	left join (select * from lc_district where geo = 'MY')   e on cast(e.dt_id as varchar)=cast(d.district as varchar) -- and e.geo = d.geo
	left join (select * from cf_synonym where type ='lead status' and geo = 'MY') g on d.lead_status=g.value -- and d.geo = g.geo
	left join (select * from cf_synonym where type ='sale order status' and geo = 'MY') h on od.status=h.value -- and od.geo = h.geo
	left join (select * from cf_synonym where type ='delivery order status' and geo = 'MY') i on del.status=i.value -- and del.geo = i.geo
	left join (select * from or_user where geo = 'MY')  p on p.user_id=d.assigned -- and p.geo = d.geo
	-- care for integer error input here
	left join (select * from lc_province where geo = 'MY')  l on cast(l.prv_id as varchar) = cast(d.province as varchar) -- and l.geo = d.geo
	--left join lc_district m on cast(m.dt_id as varchar) = cast(d.district as varchar)
	--left join lc_subdistrict n on cast(n.sdt_id as varchar) = cast(d.subdistrict as varchar)
	left join (select * from cp_campaign where geo = 'MY')   q on q.cp_id = d.cp_id -- and q.geo = d.geo
	left join (select * from public.cl_calling_list where geo = 'MY')   r on r.callinglist_id = d.callinglist_id -- and r.geo = d.geo
		left join (  select createdate,lead_id,affiliate,sub_id1,offer,max_po,payout,profit,transaction_id
	  from ods_affscale_conversion
	  where geo = 'MY' and createdate::date >= '2023-01-01'
	  ) oac 
	  on d.click_id = oac.transaction_id
--	left join (select * from ods_affscale_conversion where geo = 'MY' and createdate::date >= '2023-01-01') oac on d.lead_id = oac.lead_id and d.geo = oac.geo
	left join
	(with temp_so as (
		SELECT oi_id, osi.geo,
		so_id,
		quantity,
		item_no,
		osi.prod_id,
		pp.name as product_name,
		row_number() over(partition by so_id order by item_no) as item_no_new
		FROM (select * from od_so_item where geo = 'MY'
		     and createdate::date >= '2023-01-01' and prod_id not in (460, 461) ) osi 
		left join (select * from pd_product where geo = 'MY')  pp 
		on osi.prod_id = pp.prod_id -- and osi.geo = pp.geo
--		where osi.prod_id not in (460, 461)
--		and osi.geo = 'MY'
--		and osi.createdate::date >= '2023-01-01'
	--	order by osi.so_id 
		)
		SELECT so_id, geo,
		max((case when item_no_new = 1 then product_name end)) as product1,
		SUM(quantity) no_quantity,
		COUNT(DISTINCT prod_id) as no_product 
		FROM temp_so
		group by so_id, geo
		order by so_id desc) osi
	on od.so_id = osi.so_id and od.geo = osi.geo
	--where d.modifydate::date >= '2022-01-01'
--	and d.geo = 'MY'
--	and CASE
--            WHEN d.lead_status = 4 OR d.lead_status = 5 AND d.assigned = 0 THEN 1
--            ELSE 0
--        END <> 1
	) d 
--	where d.orgid = 11 --Malay
	)
	-- final select
, cte_final as (
	select
	date_used::date, sourcename, sourcename_fnl, agname, wholesale_name, leadtype, product_name, affiliateid, cpname, subid_fnl, subid, province, district, carrier, paymentmethod, warehouse,
	count(distinct leadid) as leads, sum(approved) as approve, sum(validated) as validate, sum(trash) as trash, sum(callback) as callback, sum(uncall) as uncall,
	sum(case when lower(leadstatus) = 'approved' and lower(orderstatus) = 'validated' and lower(status_transport) in ('delivered') then amount else null end) as delivered_amount,
	sum(case when lower(leadstatus) = 'approved' and lower(orderstatus) = 'validated' and lower(status_transport) in ('delivered') then no_quantity else null end) as delivered_qty,
	sum(case when lower(leadstatus) = 'approved' and lower(orderstatus) = 'validated' and lower(status_transport) in ('delivered') then delivered else null end) as delivered,
	sum(case when lower(leadstatus) = 'approved' and lower(orderstatus) in ('validated', 'delay') then amount else null end) as validated_amount,
	sum(case when lower(leadstatus) = 'approved' and lower(orderstatus) in ('validated', 'delay') then no_quantity else null end) as validated_qty,
	sum(case when lower(leadstatus) = 'approved' and lower(orderstatus) in ('validated', 'delay') then validated else null end) as validated,
	sum(reject) as rejected,
	sum(cancelled) as cancelled, 
	sum(other_deli) as other_deli,
	count(distinct case when lower(leadstatus) = 'approved' and lower(orderstatus) in ('validated', 'delay') then leadid else null end) as total_do,
	count(distinct case when postback_status = 'approved'  then leadid else null end) as total_approved_postback,
	count(distinct case when lower(leadstatus) = 'approved' and lower(orderstatus) in ('validated', 'delay') and postback_status in ('pending_postback', 'pending_pb') then leadid else null end) as total_pending_postback,
	count(distinct case when lower(orderstatus) in ('validated', 'delay') and lower(adjusted_status_transport) in ('intransit', 'delivering') then tracking_code else null end) as total_intransit,
	sum(amount) as total_amount, sum(no_quantity) as quantity, leadstatus, status_transport, adjusted_status_transport, team, 'MY' as "Geo", avg(max_po) max_po, avg(payout) payout
	from a
    where a.filters = 0
--	where date_used::date >= '2023-01-01'
	group by date_used, sourcename, sourcename_fnl, agname, wholesale_name, leadtype, product_name, affiliateid, cpname, subid_fnl, subid, province, district, carrier, paymentmethod, warehouse, leadstatus, status_transport, adjusted_status_transport,team
	    )
	select  * , 
			case when product_name::text ~~ '%cpl%'::text THEN leads - trash 
			else null::bigint 
			end as cpl_lead
	from cte_final   
    """
    df: pd.DataFrame = extract_from_dwh(query, oltp01_conn)
    return df


@asset(group_name="push_dim_finance", retry_policy=RetryPolicy(max_retries=3))
def push_dim_finance_agg_ph(oltp01_conn: PostgresConnection) -> pd.DataFrame:
    query = f"""
--- Finance Rebuild - Philipines Optimized
	--- PH DWH 2023 -- 2024 testing
	with a as
	(select  d.orgid, d.soid, d.tracking_code, d.do_code,
	d.leadid,d.leadname ,d.leadphone,
	d.amount ,
	d.sourcename,
	case when sourcename = 'AFS' then affiliateid else sourcename end as sourcename_fnl, 
	d.sourcecode ,d.agid , d.agname,
	case
			when lower(d.agname) like 'r%' then 'CIT'
			when lower(d.agname) like 'a%' then 'Fresh'
			else 'Others'
		end as team,
	case when lower(d.lstatus) = 'approved' then 1 else 0 end as approved,
	case when lower(d.lstatus) = 'trash' then 1 else 0 end as trash,
	case when lower(d.lstatus) in ('callback consulting','callback not prospect','callback potential') then 1 else 0 end as callback,
	case when lower(d.lstatus) in ('noanswer','unreachable') then 1 else 0 end as uncall,
	case when lower(d.sostatus) in ('validated','delay') then 1 else 0 end as validated,
	d.province,
	d.district,
	carrier, warehouse, status_transport, delivered, null delivering, cancelled, reject, 
	CASE
            WHEN trim(lower(status_transport)) IN ('new') THEN 'New'
            WHEN trim(lower(status_transport)) IN ('packed','picking','in preparation','ready to pick') THEN 'Preparing'
            WHEN trim(lower(status_transport)) IN ('pending') THEN 'Pending'
            WHEN trim(lower(status_transport)) IN ('intransit','picked up','pending delivery') THEN 'In-transit'
            WHEN trim(lower(status_transport)) IN ('pre-delivery','delivering') THEN 'Delivering'
            WHEN trim(lower(status_transport))  IN ('delivery fail') THEN 'Failed'
			WHEN trim(lower(status_transport)) IN ('delivered') THEN 'Delivered'
			WHEN trim(lower(status_transport)) IN ('reject') THEN 'Reject'
			WHEN trim(lower(status_transport)) IN ('returning','returned') THEN 'Return'
			WHEN trim(lower(status_transport)) IN ('cancel') THEN 'Cancel'
			WHEN trim(lower(status_transport)) IN ('unassigned') THEN 'Unassigned'
    	   ELSE 'New'
	END AS adjusted_status_transport,
	case d.payment_method when 1 then 'COD' when 2 then 'Bank Transfer' end as paymentmethod,
	d.other_deli,
	d.lstatus as leadstatus ,
	d.sostatus as orderstatus ,
	case when d.leadtype = 'S' then 'M' else d.leadtype end as leadtype,
	d.modifydate, 
	d.so_date,
	d. product_name,
	d.totalcall,
	d.cpname ,
	d.subid,
	case when d.sourcename = 'AFS' then d.affiliateid else d.sourcename end as affiliateid,
	d.click_id clickid, d.no_quantity,
	case when  sourcename = 'AFS' then subid
		else affiliateid
	end as subid_fnl,
	null wholesale_name,
	case when leadtype = 'A' then lead_date else so_date end as date_used,
	max_po,
	payout,
    d.postback_status,
    case when leadtype = 'M' and sourcename is not null and cpname = 'HC OS' then 1 else 0 end filters
	from (
	select d.org_id as orgid, d.lead_id as leadid, d.name as leadname, d.phone as leadphone,
	prod_id, prod_name, d.total_call as totalcall,lead_status, lead_type as leadtype, agc_id, agc_code as sourcecode, 
	od.so_id as soid, od.payment_method, od.createdate as so_date,
	del.tracking_code, e.code as do_code, od.amount,
	p.user_name as agname, q.name as cpname, osi.no_quantity,
	e.name as district, l.name as province,
	k.shortname as carrier, 
	j.warehouse_name as warehouse, 
	i.name as status_transport,
	case when lower(i.name) in ('delivered') and lower(h.name) not in ('unassigned') then 1 else 0 end as delivered,
	case when lower(i.name) in ('picked up', 'picking',
			'delivering',
			'delivery fail',
			'intransit'
			) and lower(h.name) not in ('unassigned') then 1 else 0 end as delivering,
	case when lower(i.name) in ('cancel') and lower(h.name) not in ('unassigned') then 1 else 0 end as cancelled,
	case when lower(i.name) in ('returned', 'returning') and lower(h.name) not in ('unassigned') then 1 else 0 end as reject,
	case when (lower(i.name) not in ('delivered', 'intransit', 'delivering','picked up','packed','ready to pick', 'cancel', 'returned', 'returning','delivery fail')
			and lower(g.name) in ('approved') 
			and lower(h.name) in ('validated', 'delay'))
		or
			(lower(g.name) in ('approved') 
			and lower(h.name) in ('validated', 'delay') 
			and lower(i.name) is null)
		then 1 else 0 end as other_deli,
	d.address, assigned as agid, d.createdate as lead_date, d.modifydate, d.cp_id, d.callinglist_id, affiliate_id as affiliateid, user_defin_05,click_id,subid1 as subid,
	coalesce(o.shortname,d.agc_code) as sourcename,
	case when d.prod_name is null or d.prod_name = '' then lower(product1) else lower(d.prod_name) end as product_name,
	g.name as lstatus, h.name as sostatus,
	oac.max_po,
	oac.payout,
    d.postback_status
	from (
			select * 
			from cl_fresh 
			where org_id = 14  
			and
				case when lead_status = 4 or (lead_status = 5 and assigned = 0) then 1 else 0 end = 0
			and createdate::date >= '2024-01-01'
			) d
	left join (select * from bp_partner where geo = 'PH' ) o on d.agc_id = o.pn_id and d.geo = o.geo
	left join ( SELECT
                    a_1.so_id,
                    a_1.org_id,
                    a_1.geo,
                    a_1.cp_id,
                    a_1.lead_id,
                    a_1.amount,
                    a_1.payment_method,
                    a_1.status,
                    a_1.createdate,
                    a_1.creation_date,
                    a_1.validated_rn,
                    a_1.rn,
                    a_1.final_rn
                   FROM ( SELECT
                            oso.so_id,
                            oso.org_id,
                            oso.geo,
                            oso.cp_id,
                            oso.lead_id,
                            oso.amount,
                            oso.payment_method,
                            oso.status,
                            oso.createdate,
                            oso.creation_date,
                            sum(
                                CASE
                                    WHEN oso.status = ANY (ARRAY[43, 357]) THEN 1
                                    ELSE NULL::integer
                                END) OVER (PARTITION BY oso.lead_id) AS validated_rn,
                            row_number() OVER (PARTITION BY oso.lead_id ORDER BY oso.createdate DESC) AS rn,
                                CASE
                                    WHEN row_number() OVER (PARTITION BY oso.lead_id ORDER BY oso.createdate DESC) = 1 AND sum(
                                    CASE
WHEN oso.status = ANY (ARRAY[43, 357]) THEN 1
ELSE NULL::integer
                                    END) OVER (PARTITION BY oso.lead_id) > 0 AND (oso.status <> ALL (ARRAY[43, 357])) THEN 2::bigint
                                    WHEN row_number() OVER (PARTITION BY oso.lead_id ORDER BY oso.createdate DESC) <> 1 AND (oso.status = ANY (ARRAY[43, 357])) THEN 1::bigint
                                    ELSE row_number() OVER (PARTITION BY oso.lead_id ORDER BY oso.createdate DESC)
                                END AS final_rn
                          FROM od_sale_order oso
                          WHERE org_id = 14  -- PH 
                          and oso.status <> 46
                          ) a_1
                  WHERE a_1.final_rn = 1) od on od.lead_id = d.lead_id 
	left join (select * from od_do_new where org_id = 14 and createdate::date >= '2023-01-01') del on del.so_id = od.so_id 
	left join (select * from bp_warehouse where  geo = 'PH')  j on del.warehouse_id = j.warehouse_id 
	left join (select * from bp_partner where  geo = 'PH') k on del.carrier_id = k.pn_id 
	left join (select * from lc_district where  geo = 'PH') e on cast(e.dt_id as varchar)=cast(d.district as varchar) 
	left join (select * from cf_synonym where type ='lead status' and geo = 'PH') g on d.lead_status=g.value 
	left join (select * from cf_synonym where type ='sale order status' and geo = 'PH') h on od.status=h.value 
	left join (select * from cf_synonym where type ='delivery order status' and geo = 'PH') i on del.status=i.value 
	left join (select * from or_user where  geo = 'PH')  p on p.user_id = d.assigned
	left join (select * from lc_province where  geo = 'PH') l on cast(l.prv_id as varchar) = cast(d.province as varchar) 
	left join (select * from cp_campaign where  geo = 'PH') q on q.cp_id = d.cp_id 
	left join (select * from cl_calling_list where  geo = 'PH') r on r.callinglist_id = d.callinglist_id 
	left join (select * from ods_affscale_conversion where geo = 'PH' 
			) oac on d.click_id = oac.transaction_id 
	left join
	(with temp_so as (
		SELECT oi_id, osi.geo,
		so_id,
		quantity,
		item_no,
		osi.prod_id,
		pp.name as product_name,
		row_number() over(partition by so_id order by item_no) as item_no_new
		FROM (select * from od_so_item where geo = 'PH' and prod_id not in (460, 461)) osi
		left join (select * from pd_product where geo = 'PH')  pp 
		on osi.prod_id = pp.prod_id 
		)
		SELECT so_id,
		max((case when item_no_new = 1 then product_name end)) as product1,
		SUM(quantity) no_quantity,
		COUNT(DISTINCT prod_id) as no_product 
		FROM temp_so
		group by so_id 
		) osi
	on od.so_id = osi.so_id 
	) d 
	)
	-- final select
    , cte_final as ( 
	select
	date_used::date, sourcename, sourcename_fnl, agname, wholesale_name, leadtype, product_name, affiliateid, cpname, subid_fnl, subid, province, district, carrier, paymentmethod, warehouse,
	count(distinct leadid) as leads, sum(approved) as approve, sum(validated) as validate, sum(trash) as trash, sum(callback) as callback, sum(uncall) as uncall,
	sum(case when lower(leadstatus) = 'approved' and lower(orderstatus) = 'validated' and lower(status_transport) in ('delivered') then amount else null end) as delivered_amount,
	sum(case when lower(leadstatus) = 'approved' and lower(orderstatus) = 'validated' and lower(status_transport) in ('delivered') then no_quantity else null end) as delivered_qty,
	sum(case when lower(leadstatus) = 'approved' and lower(orderstatus) = 'validated' and lower(status_transport) in ('delivered') then delivered else null end) as delivered,
	sum(case when lower(leadstatus) = 'approved' and lower(orderstatus) in ('validated', 'delay') then amount else null end) as validated_amount,
	sum(case when lower(leadstatus) = 'approved' and lower(orderstatus) in ('validated', 'delay') then no_quantity else null end) as validated_qty,
	sum(case when lower(leadstatus) = 'approved' and lower(orderstatus) in ('validated', 'delay') then validated else null end) as validated,
	sum(reject) as rejected,
	sum(cancelled) as cancelled, 
	count(distinct case when lower(leadstatus) = 'approved' and lower(orderstatus) in ('validated', 'delay') then leadid else null end) as total_do,
    	count(distinct case when postback_status = 'approved'  then leadid else null end) as total_approved_postback,
	count(distinct case when lower(leadstatus) = 'approved' and lower(orderstatus) in ('validated', 'delay') and postback_status in ('pending_postback', 'pending_pb') then leadid else null end) as total_pending_postback,
	count(distinct case when lower(orderstatus) in ('validated', 'delay') and lower(adjusted_status_transport) in ('intransit', 'delivering') then tracking_code else null end) as total_intransit,
	sum(amount) as total_amount, sum(no_quantity) as quantity, leadstatus, status_transport, adjusted_status_transport, team, 'PH' as "Geo", avg(max_po) max_po, avg(payout) payout
	from a
    where a.filters = 0
	group by date_used, sourcename, sourcename_fnl, agname, wholesale_name, leadtype, product_name, affiliateid, cpname, subid_fnl, subid, 
			province, district, carrier, paymentmethod, warehouse, leadstatus, status_transport, adjusted_status_transport,team
	    )
	select  * , 
			case when product_name::text ~~ '%cpl%'::text THEN leads - trash 
			else null::bigint 
			end as cpl_lead
	from cte_final     
    """
    df: pd.DataFrame = extract_from_dwh(query, oltp01_conn)
    return df


@asset(group_name="push_dim_finance", retry_policy=RetryPolicy(max_retries=3))
def push_dim_finance_agg_vn2(oltp01_conn: PostgresConnection) -> pd.DataFrame:
    query = f"""
	--- Finance Rebuild 
	--- Vietnam 2 DWH 2023
	with a as
	(select  d.orgid, d.soid, d.tracking_code, d.do_code,
	d.leadid,d.leadname ,d.leadphone,
	--case when d.prod_name is null or d.prod_name = '' then lower(product1)
	--	else lower(d.prod_name)
	--end as product_name,
	--b.product productcrosssell , 
	d.amount ,	
	d.sourcename,
	case when d.sourcename <>  'AFS' then d.sourcename
	when d.sourcename = 'AFS' and d.affiliateid = '122' then 'RTK' --  d.lead_date >= '2021-04-01' and
	when d.sourcename = 'AFS' and d.affiliateid = '165' then 'TSM' --  d.lead_date >= '2021-04-01' and
	when d.sourcename = 'AFS' and d.affiliateid = '169' then 'AKM' -- d.lead_date >= '2021-04-01' and
	when d.sourcename = 'AFS' and d.affiliateid = '243' then 'LOL' --  d.lead_date >= '2021-04-01' and
	when d.sourcename = 'AFS' and d.affiliateid = '250' then 'TEX' --  d.lead_date >= '2021-04-01' and
	when d.sourcename = 'AFS' and d.affiliateid = '1' then '' --  d.lead_date >= '2021-04-01' and
	--	when d.lead_date >= '2021-04-01' and sourcename = 'AFS' and affiliateid = '' then 'ART'
	when d.sourcename = 'AFS' and d.product_name like '%penirumaplus-vn%' and d.subid = '591' and d.affiliateid <> 'EMC' then 'ARB' -- d.lead_date::date = '2021-05-18' and 
	when d.sourcename = 'AFS' then d.affiliateid else d.sourcename --  d.lead_date >= '2021-04-01' and
	end as sourcename_fnl,--coalesce(o.shortname,d.agc_code) as sourcename ,
	d.sourcecode ,d.agid , d.agname,
	case
			when lower(d.agname) like '%cit%' then 'CIT'
			when lower(d.agname) not like '%cit%' then 'Fresh'
			else 'Others'
		end as team,
	case when lower(d.lstatus) = 'approved' then 1 else 0 end as approved,
	case when lower(d.lstatus) = 'trash' then 1 else 0 end as trash,
	case when lower(d.lstatus) in ('callback consulting','callback not prospect','callback potential') then 1 else 0 end as callback,
	case when lower(d.lstatus) in ('noanswer','unreachable') then 1 else 0 end as uncall,
	case when lower(d.sostatus) in ('validated','delay') then 1 else 0 end as validated,
	d.province,
	d.district,
	--d.comment ,coalesce(d.address||'###'||n.name||'-'||m.name||'-'||l.name ,d.address) as address,
	carrier, warehouse, status_transport, delivered, null delivering, cancelled, reject, --unassigned,
	CASE
            WHEN trim(lower(status_transport)) IN ('new') THEN 'New'
            WHEN trim(lower(status_transport)) IN ('packed','picking','in preparation','ready to pick') THEN 'Preparing'
            WHEN trim(lower(status_transport)) IN ('pending') THEN 'Pending'
            WHEN trim(lower(status_transport)) IN ('intransit','picked up','pending delivery') THEN 'In-transit'
            WHEN trim(lower(status_transport)) IN ('pre-delivery','delivering') THEN 'Delivering'
            WHEN trim(lower(status_transport))  IN ('delivery fail') THEN 'Failed'
			WHEN trim(lower(status_transport)) IN ('delivered') THEN 'Delivered'
			WHEN trim(lower(status_transport)) IN ('reject') THEN 'Reject'
			WHEN trim(lower(status_transport)) IN ('returning','returned') THEN 'Return'
			WHEN trim(lower(status_transport)) IN ('cancel') THEN 'Cancel'
			WHEN trim(lower(status_transport)) IN ('unassigned') THEN 'Unassigned'
    	   ELSE 'New'
	END AS adjusted_status_transport,
	--e.ffm_id ffmid,f.shortname ffmname ,e.warehouse_id warehouseid,j.warehouse_shortname warehousename , 
	--k.shortname lastmilename ,
	case d.payment_method when 1 then 'COD' when 2 then 'Bank Transfer' end as paymentmethod,
	case when trim(lower(status_transport)) not in ('delivered', 'reject', 'cancelled', 'unassigned', 'intransit') 
				or (status_transport is null and lower(d.sostatus) in ('validated','delay'))  
				or (status_transport = '' and lower(d.sostatus) in ('validated','delay')) 
				then 1 else 0 end as other_deli,
	--d.lead_status leadstatusid,
	d.lstatus as leadstatus ,
	--a.status sostatusid ,
	d.sostatus as orderstatus ,
	--e.status dostatusid ,i.name deliverystatus ,
	case when d.leadtype = 'S' then 'M' else d.leadtype end as leadtype,
	--d.createdate d.lead_date,
	d.modifydate, --coalesce(e.updatedate, a.modifydate,d.modifydate) modify_date 
	d.so_date,
	d. product_name,
	d.totalcall,
	--d.cp_id cpid,
	d.cpname ,
	d.subid,
	--d.callinglist_id callinglistid,r.cl_name callinglistname ,1  groupid, 'null' groupname--t.group_id, t.short_name group_name
	case when d.sourcename <> 'AFS' then d.sourcename else d.affiliateid end as affiliateid,
	--d.affiliateid, 
	--d.user_defin_05 reason, 
	d.click_id clickid, d.no_quantity,
	case when sourcename <> 'AFS' then affiliateid  -- lead_date >= '2021-04-01' and 
		else subid
	end as subid_fnl,
	case when leadphone like '%907688686%' then 'RS Lâm Xã Hào'
	when leadphone like '%936619478%' or leadphone like '%779132207%' then 'Nguyễn Nhạc Phi'
	when leadphone like '%367735682%' then 'chị Nhung'
	when leadphone like '%393241858%' then 'chị Phương'
	when leadphone like '%396591650%' then 'cô Hà Thị Nguyên'
	when leadphone like '%902472587%' then 'anh Duẩn'
	when leadphone like '%987311215%' then 'Trần Thiên Bình'
	when leadphone like '%912162091%' then 'anh Vinh Lương'
	when leadphone like '%913855881%' then 'Lý Thị Phong Mỹ'
	when leadphone like '%777880077%' then 'chị Trang'
	when leadphone like '%902477285%' then 'Dương Thế Sang'
	when leadphone like '%919714970%' then 'Trần Hiếu Hoàng'
	when leadphone like '%932673877%' then 'Nguyễn Vĩ'
	when leadphone like '%909937576%' then 'Nguyễn Thị Thu Dung'
	when leadphone like '%354077088%' then 'anh Lâm'
	when leadphone like '%347997537%' then 'anh Nam'
	when leadphone like '%903817576%' then 'anh Tiến Phong'
	when leadphone like '%522336938%' or leadphone like '%927502822%' then 'Nguyễn Lộc'
	when leadphone like '%923814400%' then 'Chiến Nguyễn'
	when leadphone like '%989264795%' then 'anh Tuấn'
	when leadphone like '%977153375%' or leadphone like '%982137818%' then 'anh Thanh'
	when leadphone like '%915998888%' then 'CIT Lã Tuấn Hưng'
	when leadphone like '%986761033%' then 'CIT cô Hoa'
	when leadphone like '%913848759%' then 'CIT anh Tuấn'
	when leadphone like '%936115314%' then 'CIT Đào Xuân Hoan'
	when leadphone like '%336850121%' then 'Nguyễn Văn Toàn'
	when leadphone like '%963093895%' then 'CIT chị Mai'
	when leadphone like '%975477516%' then 'Trịnh Minh Trung'
	when leadphone like '%827779911%' then 'Nguyễn Thị Đẹp'
	when leadphone like '%989796234%' then 'anh Hải'
	else 'Not wholesale' end as wholesale_name,
	case when leadtype = 'A' then lead_date else so_date end as date_used,
	max_po,
	payout,
    d.postback_status,
    case when leadtype = 'M' and sourcename is not null and cpname = 'HC OS' then 1 else 0 end filters
	from (
	select d.org_id as orgid, d.lead_id as leadid, d.name as leadname, d.phone as leadphone,
	prod_id, prod_name, d.total_call as totalcall,lead_status, lead_type as leadtype, agc_id, agc_code as sourcecode, --comment,
	od.so_id as soid, od.payment_method, od.createdate as so_date,
	del.tracking_code, 
--	e.ma_don_goc as do_code, 
	del.tracking_code as do_code,
	od.amount,
	p.user_name as agname, q.name as cpname, osi.no_quantity,
--	e.quan_huyen as district,
	m.name as district, l.name as province,
--	carrier, warehouse, 
	k.shortname as carrier,
	warehouse_name as warehouse,
	i.name as status_transport, 
--	delivered, null delivering, cancelled, reject,
	case when g.name in ('approved') and lower(h.name) in ('validated', 'delay') and lower(i.name) in ('refund', 'delivered') then 1 else null end as delivered,
	null delivering,
	case when g.name in ('approved') and lower(h.name) in ('validated', 'delay') and lower(i.name) in ('cancelled') then 1 else null end as cancelled,
	case when g.name in ('approved') and lower(h.name) in ('validated', 'delay') and lower(i.name) in ('reject') then 1 else null end as reject,
	d.address, assigned as agid, d.createdate as lead_date, d.modifydate, d.cp_id, d.callinglist_id, affiliate_id as affiliateid, user_defin_05,click_id,subid1 as subid,
	coalesce(o.shortname,d.agc_code) as sourcename,
	case when d.prod_name is null or d.prod_name = '' then lower(product1) else lower(d.prod_name) end as product_name,
	g.name as lstatus, h.name as sostatus,
	oac.max_po,
	oac.payout,
    d.postback_status
	from (
--			select * 
--			from cl_fresh 
--			where 
--				case when lead_status = 4 or (lead_status = 5 and assigned = 0) then 1 else 0 end = 0 
--				and geo = 'VN2'
--				and modifydate::date >= '2023-01-01'
			select * 
			from cl_fresh 
			where 
			CASE
                WHEN cl_fresh.lead_status = 4 OR cl_fresh.lead_status = 5 AND cl_fresh.assigned = 0 THEN 1
                ELSE 0
            END <> 1
			and org_id = 5 --  geo = 'VN2'
			and modifydate::date >= '2023-01-01'	
		) d
	left join ( SELECT
                    a_1.so_id,
                    a_1.org_id,
                    a_1.geo,
                    a_1.cp_id,
                    a_1.lead_id,
                    a_1.amount,
                    a_1.payment_method,
                    a_1.status,
                    a_1.createdate,
                    a_1.creation_date,
                    a_1.validated_rn,
                    a_1.rn,
                    a_1.final_rn
                   FROM ( SELECT
                            oso.so_id,
                            oso.org_id,
                            oso.geo,
                            oso.cp_id,
                            oso.lead_id,
                            oso.amount,
                            oso.payment_method,
                            oso.status,
                            oso.createdate,
                            oso.creation_date,
                            sum(
                                CASE
                                    WHEN oso.status = ANY (ARRAY[43, 357]) THEN 1
                                    ELSE NULL::integer
                                END) OVER (PARTITION BY oso.lead_id) AS validated_rn,
                            row_number() OVER (PARTITION BY oso.lead_id ORDER BY oso.createdate DESC) AS rn,
                                CASE
                                    WHEN row_number() OVER (PARTITION BY oso.lead_id ORDER BY oso.createdate DESC) = 1 AND sum(
                                    CASE
                                    WHEN oso.status = ANY (ARRAY[43, 357]) THEN 1
                                    ELSE NULL::integer
                                    END) OVER (PARTITION BY oso.lead_id) > 0 AND (oso.status <> ALL (ARRAY[43, 357])) THEN 2::bigint
                                    WHEN row_number() OVER (PARTITION BY oso.lead_id ORDER BY oso.createdate DESC) <> 1 AND (oso.status = ANY (ARRAY[43, 357])) THEN 1::bigint
                                    ELSE row_number() OVER (PARTITION BY oso.lead_id ORDER BY oso.createdate DESC)
                                END AS final_rn
                           FROM od_sale_order oso
                          WHERE oso.status <> 46
                          and oso.geo = 'VN2' and oso.createdate::date >= '2023-01-01'
                          ) a_1
                  WHERE a_1.final_rn = 1) od on od.lead_id = d.lead_id -- and od.geo = d.geo
	left join (select * from od_do_new where org_id = 5 and createdate::date >= '2023-01-01') del on del.so_id = od.so_id--  and del.geo = od.geo
--	left join (select * from log_data_main_2 where trim(lower(status_transport)) <> 'unassigned' and ma_don_goc not like 'ULT%') e on e.ma_don_hang::varchar = od.so_id::varchar and od.geo = 'VN2'
--	left join bp_partner o on d.agc_id = o.pn_id and d.geo = o.geo
--	left join bp_partner f on e.ffm_id = f.pn_id and e.geo = f.geo
	left join (select * from bp_warehouse where geo = 'VN2') j on del.warehouse_id = j.warehouse_id --  and del.geo = j.geo
	left join (select * from bp_partner where geo = 'VN2') k on del.carrier_id = k.pn_id -- and del.geo = k.geo
	left join (select * from bp_partner where geo = 'VN2') o on d.agc_id = o.pn_id -- and d.geo = o.geo
	left join (select * from cf_synonym where type ='lead status' and geo = 'VN2') g on d.lead_status=g.value -- and d.geo = g.geo
	left join (select * from cf_synonym where type ='sale order status' and geo = 'VN2') h on od.status=h.value -- and od.geo = h.geo
	left join (select * from cf_synonym where type ='delivery order status' and geo = 'VN2') i on del.status=i.value --  and del.geo = i.geo
	left join (select * from or_user where geo = 'VN2') p on p.user_id=d.assigned --  and p.geo = d.geo
	-- care for integer error input here
	left join (select * from lc_province where geo = 'VN2')  l on cast(l.prv_id as varchar) = cast(d.province as varchar) -- and l.geo = d.geo
	left join (select * from lc_district where geo = 'VN2')  m on cast(m.dt_id as varchar) = cast(d.district as varchar) -- and m.geo = d.geo
	left join (select * from lc_subdistrict where geo = 'VN2')  n on cast(n.sdt_id as varchar) = cast(d.subdistrict as varchar) -- and n.geo = d.geo
	left join (select * from cp_campaign where geo = 'VN2')  q on q.cp_id = d.cp_id -- and q.geo = d.geo
	left join (select * from cl_calling_list where geo = 'VN2')  r on r.callinglist_id = d.callinglist_id -- and r.geo = d.geo
	left join (  select createdate,lead_id,affiliate,sub_id1,offer,max_po,payout,profit,transaction_id
	  from ods_affscale_conversion
	  where geo = 'VN' and createdate::date >= '2023-01-01' -- -- 2023-10-25 - VN4 starts
	  ) oac 
	  on d.click_id = oac.transaction_id
	left join
	(with temp_so as (
		SELECT oi_id, osi.geo,
		so_id,
		quantity,
		item_no, osi.createdate::date,
		osi.prod_id,
		pp.name as product_name,
		row_number() over(partition by so_id order by item_no) as item_no_new
		FROM (select * from od_so_item where geo = 'VN2' and createdate::date >= '2023-01-01' and prod_id not in (5031, 5032, 5037, 5038, 5039)) osi 
		left join (select * from pd_product where org_id = 5 ) pp 
		on osi.prod_id = pp.prod_id -- and osi.geo = pp.geo
--		where osi.prod_id not in (5031, 5032, 5037, 5038, 5039)
--		and osi.geo = 'VN2'
--		and osi.createdate::date >= '2023-01-01'
	--	order by osi.so_id 
		)
		SELECT so_id,--  geo,
		max((case when item_no_new = 1 then product_name end)) as product1,
		SUM(quantity) no_quantity,
		COUNT(DISTINCT prod_id) as no_product 
		FROM temp_so
		group by so_id -- , geo
		order by so_id desc) osi
	on od.so_id = osi.so_id -- and od.geo = osi.geo
--	where d.createdate::date >= '2023-01-01'
--	and CASE
--            WHEN d.lead_status = 4 OR d.lead_status = 5 AND d.assigned = 0 THEN 1
--            ELSE 0
--        END <> 1
	) d 
	)
	-- final select
    , cte_final as ( 
	select
	date_used::date, sourcename, sourcename_fnl, agname, wholesale_name, leadtype, product_name, affiliateid, cpname, subid_fnl, subid, province, district, carrier, paymentmethod, warehouse,
	count(distinct leadid) as leads, sum(approved) as approve, sum(validated) as validate, sum(trash) as trash, sum(callback) as callback, sum(uncall) as uncall,
	sum(case when a.leadstatus = 'approved' and a.orderstatus = 'validated' and a.status_transport in ('Delivered', 'delivered') then a.amount else null end) as delivered_amount,
	sum(case when a.leadstatus = 'approved' and a.orderstatus = 'validated' and a.status_transport in ('Delivered', 'delivered') then no_quantity else null end) as delivered_qty,
	sum(case when a.leadstatus = 'approved' and a.orderstatus = 'validated' and a.status_transport in ('Delivered', 'delivered') then delivered else null end) as delivered,
	sum(case when a.leadstatus = 'approved' and lower(a.orderstatus) in ('validated', 'delay') and (status_transport != 'Unassigned' or status_transport is null) then a.amount else null end) as validated_amount,
	sum(case when a.leadstatus = 'approved' and lower(a.orderstatus) in ('validated', 'delay') and (status_transport != 'Unassigned' or status_transport is null) then no_quantity else null end) as validated_qty,
	sum(case when a.leadstatus = 'approved' and lower(a.orderstatus) in ('validated', 'delay') and (status_transport != 'Unassigned' or status_transport is null) then validated else null end) as validated,
	sum(reject) as rejected,
	sum(cancelled) as cancelled,
	sum(other_deli) as other_deli,
--	count(distinct case when lower(orderstatus) in ('validated','delay') and (status_transport != 'Unassigned' or status_transport is null) then tracking_code else null end) as total_do, 
	-- rule changed (Hai and Daniel requested on 1 Jun 2022)
	count(distinct case when lower(leadstatus) = 'approved' and lower(orderstatus) in ('validated', 'delay') then leadid else null end) as total_do,
	count(distinct case when postback_status = 'approved'  then leadid else null end) as total_approved_postback,
	count(distinct case when lower(leadstatus) = 'approved' and lower(orderstatus) in ('validated', 'delay') and postback_status in ('pending_postback', 'pending_pb') then leadid else null end) as total_pending_postback,
	count(distinct case when lower(orderstatus) in ('validated','delay') and lower(status_transport) = 'intransit' then tracking_code else null end) as total_intransit,
	sum(amount) as total_amount, sum(no_quantity) as quantity, a.leadstatus, status_transport, adjusted_status_transport, team, 'VN2' as "Geo", avg(max_po) max_po, avg(payout) payout
	from a
    where a.filters = 0
--	where date_used::date >= '2023-01-01'
	group by date_used, sourcename, sourcename_fnl, agname, wholesale_name, leadtype, product_name, affiliateid, cpname, subid_fnl, subid, province, district, carrier
	, paymentmethod, warehouse, a.leadstatus, status_transport, adjusted_status_transport, team
	    )
	select  * , 
			case when product_name::text ~~ '%cpl%'::text THEN leads - trash 
			else null::bigint 
			end as cpl_lead
	from cte_final     
    """
    df: pd.DataFrame = extract_from_dwh(query, oltp01_conn)
    return df


@asset(group_name="push_dim_finance", retry_policy=RetryPolicy(max_retries=3))
def push_dim_finance_agg_vn3(oltp01_conn: PostgresConnection) -> pd.DataFrame:
    query = f"""
	--- Finance Rebuild 
	--- Vietnam 3 DWH 2023
	with a as
	(select  d.orgid, d.soid, d.tracking_code, d.do_code,
	d.leadid,d.leadname ,d.leadphone,
	--case when d.prod_name is null or d.prod_name = '' then lower(product1)
	--	else lower(d.prod_name)
	--end as product_name,
	--b.product productcrosssell , 
	d.amount ,	
	d.sourcename,
	case when d.sourcename <>  'AFS' then d.sourcename
	when d.sourcename = 'AFS' and d.affiliateid = '122' then 'RTK' --  d.lead_date >= '2021-04-01' and
	when d.sourcename = 'AFS' and d.affiliateid = '165' then 'TSM' --  d.lead_date >= '2021-04-01' and
	when d.sourcename = 'AFS' and d.affiliateid = '169' then 'AKM' -- d.lead_date >= '2021-04-01' and
	when d.sourcename = 'AFS' and d.affiliateid = '243' then 'LOL' --  d.lead_date >= '2021-04-01' and
	when d.sourcename = 'AFS' and d.affiliateid = '250' then 'TEX' --  d.lead_date >= '2021-04-01' and
	when d.sourcename = 'AFS' and d.affiliateid = '1' then '' --  d.lead_date >= '2021-04-01' and
	--	when d.lead_date >= '2021-04-01' and sourcename = 'AFS' and affiliateid = '' then 'ART'
	when d.sourcename = 'AFS' and d.product_name like '%penirumaplus-vn%' and d.subid = '591' and d.affiliateid <> 'EMC' then 'ARB' -- d.lead_date::date = '2021-05-18' and 
	when d.sourcename = 'AFS' then d.affiliateid else d.sourcename --  d.lead_date >= '2021-04-01' and
	end as sourcename_fnl,--coalesce(o.shortname,d.agc_code) as sourcename ,
	d.sourcecode ,d.agid , d.agname,
	case
			when lower(d.agname) like '%cit%' then 'CIT'
			when lower(d.agname) not like '%cit%' then 'Fresh'
			else 'Others'
		end as team,
	case when lower(d.lstatus) = 'approved' then 1 else 0 end as approved,
	case when lower(d.lstatus) = 'trash' then 1 else 0 end as trash,
	case when lower(d.lstatus) in ('callback consulting','callback not prospect','callback potential') then 1 else 0 end as callback,
	case when lower(d.lstatus) in ('noanswer','unreachable') then 1 else 0 end as uncall,
	case when lower(d.sostatus) in ('validated','delay') then 1 else 0 end as validated,
	d.province,
	d.district,
	--d.comment ,coalesce(d.address||'###'||n.name||'-'||m.name||'-'||l.name ,d.address) as address,
	carrier, warehouse, status_transport, delivered, null delivering, cancelled, reject, --unassigned,
	CASE
            WHEN trim(lower(status_transport)) IN ('new') THEN 'New'
            WHEN trim(lower(status_transport)) IN ('packed','picking','in preparation','ready to pick') THEN 'Preparing'
            WHEN trim(lower(status_transport)) IN ('pending') THEN 'Pending'
            WHEN trim(lower(status_transport)) IN ('intransit','picked up','pending delivery') THEN 'In-transit'
            WHEN trim(lower(status_transport)) IN ('pre-delivery','delivering') THEN 'Delivering'
            WHEN trim(lower(status_transport))  IN ('delivery fail') THEN 'Failed'
			WHEN trim(lower(status_transport)) IN ('delivered') THEN 'Delivered'
			WHEN trim(lower(status_transport)) IN ('reject') THEN 'Reject'
			WHEN trim(lower(status_transport)) IN ('returning','returned') THEN 'Return'
			WHEN trim(lower(status_transport)) IN ('cancel') THEN 'Cancel'
			WHEN trim(lower(status_transport)) IN ('unassigned') THEN 'Unassigned'
    	   ELSE 'New'
	END AS adjusted_status_transport,              
	--e.ffm_id ffmid,f.shortname ffmname ,e.warehouse_id warehouseid,j.warehouse_shortname warehousename , 
	--k.shortname lastmilename ,
	case d.payment_method when 1 then 'COD' when 2 then 'Bank Transfer' end as paymentmethod,
	case when trim(lower(status_transport)) not in ('delivered', 'reject', 'cancelled', 'unassigned', 'intransit') 
				or (status_transport is null and lower(d.sostatus) in ('validated','delay'))  
				or (status_transport = '' and lower(d.sostatus) in ('validated','delay')) 
				then 1 else 0 end as other_deli,
	--d.lead_status leadstatusid,
	d.lstatus as leadstatus ,
	--a.status sostatusid ,
	d.sostatus as orderstatus ,
	--e.status dostatusid ,i.name deliverystatus ,
	case when d.leadtype = 'S' then 'M' else d.leadtype end as leadtype,
	--d.createdate d.lead_date,
	d.modifydate, --coalesce(e.updatedate, a.modifydate,d.modifydate) modify_date 
	d.so_date,
	d. product_name,
	d.totalcall,
	--d.cp_id cpid,
	d.cpname ,
	d.subid,
	--d.callinglist_id callinglistid,r.cl_name callinglistname ,1  groupid, 'null' groupname--t.group_id, t.short_name group_name
	case when d.sourcename <> 'AFS' then d.sourcename else d.affiliateid end as affiliateid,
	--d.affiliateid, 
	--d.user_defin_05 reason, 
	d.click_id clickid, d.no_quantity,
	case when sourcename <> 'AFS' then affiliateid  -- lead_date >= '2021-04-01' and 
		else subid
	end as subid_fnl,
	case when leadphone like '%907688686%' then 'RS Lâm Xã Hào'
	when leadphone like '%936619478%' or leadphone like '%779132207%' then 'Nguyễn Nhạc Phi'
	when leadphone like '%367735682%' then 'chị Nhung'
	when leadphone like '%393241858%' then 'chị Phương'
	when leadphone like '%396591650%' then 'cô Hà Thị Nguyên'
	when leadphone like '%902472587%' then 'anh Duẩn'
	when leadphone like '%987311215%' then 'Trần Thiên Bình'
	when leadphone like '%912162091%' then 'anh Vinh Lương'
	when leadphone like '%913855881%' then 'Lý Thị Phong Mỹ'
	when leadphone like '%777880077%' then 'chị Trang'
	when leadphone like '%902477285%' then 'Dương Thế Sang'
	when leadphone like '%919714970%' then 'Trần Hiếu Hoàng'
	when leadphone like '%932673877%' then 'Nguyễn Vĩ'
	when leadphone like '%909937576%' then 'Nguyễn Thị Thu Dung'
	when leadphone like '%354077088%' then 'anh Lâm'
	when leadphone like '%347997537%' then 'anh Nam'
	when leadphone like '%903817576%' then 'anh Tiến Phong'
	when leadphone like '%522336938%' or leadphone like '%927502822%' then 'Nguyễn Lộc'
	when leadphone like '%923814400%' then 'Chiến Nguyễn'
	when leadphone like '%989264795%' then 'anh Tuấn'
	when leadphone like '%977153375%' or leadphone like '%982137818%' then 'anh Thanh'
	when leadphone like '%915998888%' then 'CIT Lã Tuấn Hưng'
	when leadphone like '%986761033%' then 'CIT cô Hoa'
	when leadphone like '%913848759%' then 'CIT anh Tuấn'
	when leadphone like '%936115314%' then 'CIT Đào Xuân Hoan'
	when leadphone like '%336850121%' then 'Nguyễn Văn Toàn'
	when leadphone like '%963093895%' then 'CIT chị Mai'
	when leadphone like '%975477516%' then 'Trịnh Minh Trung'
	when leadphone like '%827779911%' then 'Nguyễn Thị Đẹp'
	when leadphone like '%989796234%' then 'anh Hải'
	else 'Not wholesale' end as wholesale_name,
	case when leadtype = 'A' then lead_date else so_date end as date_used,
	max_po,
	payout,
    d.postback_status,
    case when leadtype = 'M' and sourcename is not null and cpname = 'HC OS' then 1 else 0 end filters
	from (
	select d.org_id as orgid, d.lead_id as leadid, d.name as leadname, d.phone as leadphone,
	prod_id, prod_name, d.total_call as totalcall,lead_status, lead_type as leadtype, agc_id, agc_code as sourcecode, --comment,
	od.so_id as soid, od.payment_method, od.createdate as so_date,
	del.tracking_code, 
--	e.ma_don_goc as do_code, 
	del.tracking_code as do_code,
	od.amount,
	p.user_name as agname, q.name as cpname, osi.no_quantity,
--	e.quan_huyen as district,
	m.name as district, l.name as province,
--	carrier, warehouse, 
	k.shortname as carrier,
	warehouse_name as warehouse,
	i.name as status_transport, 
--	delivered, null delivering, cancelled, reject,
	case when g.name in ('approved') and lower(h.name) in ('validated', 'delay') and lower(i.name) in ('refund', 'delivered') then 1 else null end as delivered,
	null delivering,
	case when g.name in ('approved') and lower(h.name) in ('validated', 'delay') and lower(i.name) in ('cancelled') then 1 else null end as cancelled,
	case when g.name in ('approved') and lower(h.name) in ('validated', 'delay') and lower(i.name) in ('reject') then 1 else null end as reject,
	d.address, assigned as agid, d.createdate as lead_date, d.modifydate, d.cp_id, d.callinglist_id, affiliate_id as affiliateid, user_defin_05,click_id,subid1 as subid,
	coalesce(o.shortname,d.agc_code) as sourcename,
	case when d.prod_name is null or d.prod_name = '' then lower(product1) else lower(d.prod_name) end as product_name,
	g.name as lstatus, h.name as sostatus,
	oac.max_po,
	oac.payout,
    d.postback_status
	from (
			select  *
			from cl_fresh 
			where 
				case when lead_status = 4 or (lead_status = 5 and assigned = 0) then 1 else 0 end = 0 
				and org_id = 6 --  geo = 'VN3'
			) d
	left join ( SELECT
                    a_1.so_id,
                    a_1.org_id,
                    a_1.geo,
                    a_1.cp_id,
                    a_1.lead_id,
                    a_1.amount,
                    a_1.payment_method,
                    a_1.status,
                    a_1.createdate,
                    a_1.creation_date,
                    a_1.validated_rn,
                    a_1.rn,
                    a_1.final_rn
                   FROM ( SELECT
                            oso.so_id,
                            oso.org_id,
                            oso.geo,
                            oso.cp_id,
                            oso.lead_id,
                            oso.amount,
                            oso.payment_method,
                            oso.status,
                            oso.createdate,
                            oso.creation_date,
                            sum(
                                CASE
                                    WHEN oso.status = ANY (ARRAY[43, 357]) THEN 1
                                    ELSE NULL::integer
                                END) OVER (PARTITION BY oso.lead_id) AS validated_rn,
                            row_number() OVER (PARTITION BY oso.lead_id ORDER BY oso.createdate DESC) AS rn,
                                CASE
                                    WHEN row_number() OVER (PARTITION BY oso.lead_id ORDER BY oso.createdate DESC) = 1 AND sum(
                                    CASE
									WHEN oso.status = ANY (ARRAY[43, 357]) THEN 1
									ELSE NULL::integer
                                    END) OVER (PARTITION BY oso.lead_id) > 0 AND (oso.status <> ALL (ARRAY[43, 357])) THEN 2::bigint
                                    WHEN row_number() OVER (PARTITION BY oso.lead_id ORDER BY oso.createdate DESC) <> 1 AND (oso.status = ANY (ARRAY[43, 357])) THEN 1::bigint
                                    ELSE row_number() OVER (PARTITION BY oso.lead_id ORDER BY oso.createdate DESC)
                                END AS final_rn
                           FROM od_sale_order oso
                          WHERE oso.status <> 46 
			  				and oso.org_id = 6 -- geo = 'VN3'
                         ) a_1
                  WHERE a_1.final_rn = 1
                ) od on od.lead_id = d.lead_id -- and od.geo = d.geo
	left join (select * from od_do_new where org_id = 6 and createdate::date >= '2023-01-01') del on del.so_id = od.so_id -- and del.geo = od.geo
--	left join (select * from log_data_main_3 where trim(lower(status_transport)) <> 'unassigned' and ma_don_goc not like 'ULT%') e on e.ma_don_hang::varchar = od.so_id::varchar and od.geo = 'VN3'
--	left join bp_partner o on d.agc_id = o.pn_id and d.geo = o.geo
--	left join bp_partner f on e.ffm_id = f.pn_id and e.geo = f.geo
	left join (select * from bp_warehouse where geo = 'VN3') j on del.warehouse_id = j.warehouse_id --  and del.geo = j.geo
	left join (select * from bp_partner where geo = 'VN3') k on del.carrier_id = k.pn_id -- and del.geo = k.geo
	left join (select * from bp_partner where geo = 'VN3') o on d.agc_id = o.pn_id -- and d.geo = o.geo
	left join (select * from cf_synonym where type ='lead status' and geo = 'VN3') g on d.lead_status=g.value -- and d.geo = g.geo
	left join (select * from cf_synonym where type ='sale order status' and geo = 'VN3') h on od.status=h.value -- and od.geo = h.geo
	left join (select * from cf_synonym where type ='delivery order status' and geo = 'VN3') i on del.status=i.value --  and del.geo = i.geo
	left join (select * from or_user where geo = 'VN3') p on p.user_id=d.assigned --  and p.geo = d.geo
	-- care for integer error input here
	left join (select * from lc_province where geo = 'VN3')  l on cast(l.prv_id as varchar) = cast(d.province as varchar) -- and l.geo = d.geo
	left join (select * from lc_district where geo = 'VN3')  m on cast(m.dt_id as varchar) = cast(d.district as varchar) -- and m.geo = d.geo
	left join (select * from lc_subdistrict where geo = 'VN3')  n on cast(n.sdt_id as varchar) = cast(d.subdistrict as varchar) -- and n.geo = d.geo
	left join (select * from cp_campaign where geo = 'VN3')  q on q.cp_id = d.cp_id -- and q.geo = d.geo
	left join (select * from cl_calling_list where geo = 'VN3')  r on r.callinglist_id = d.callinglist_id -- and r.geo = d.geo
	left join (  select createdate,lead_id,affiliate,sub_id1,offer,max_po,payout,profit,transaction_id
	  from ods_affscale_conversion
	  where geo = 'VN' and createdate::date >= '2023-01-01' -- -- 
	  ) oac 
	  on d.click_id = oac.transaction_id
	left join
	(with temp_so as (
		SELECT oi_id, osi.geo,
		so_id,
		quantity,
		item_no,
		osi.prod_id,
		pp.name as product_name,
		row_number() over(partition by so_id order by item_no) as item_no_new
		FROM (select * from od_so_item where geo = 'VN3' ) osi 
		left join (select * from pd_product where org_id = 6 ) pp 
		on osi.prod_id = pp.prod_id -- and osi.geo = pp.geo
		where osi.prod_id not in (5031, 5032, 5037, 5038, 5039)
--		and osi.geo = 'VN3'
	--	order by osi.so_id 
		)
		SELECT so_id, -- geo,
		max((case when item_no_new = 1 then product_name end)) as product1,
		SUM(quantity) no_quantity,
		COUNT(DISTINCT prod_id) as no_product 
		FROM temp_so
		group by so_id --, geo
		order by so_id desc) osi
	on od.so_id = osi.so_id -- and od.geo = osi.geo
--	where d.createdate::date >= '2023-01-01'
--	and CASE
--            WHEN d.lead_status = 4 OR d.lead_status = 5 AND d.assigned = 0 THEN 1
--            ELSE 0
--        END <> 1
	) d 
	)
	-- final select
    , cte_final as ( 
	select
	date_used::date, sourcename, sourcename_fnl, agname, wholesale_name, leadtype, product_name, affiliateid, cpname, subid_fnl, subid, province, district, carrier, paymentmethod, warehouse,
	count(distinct leadid) as leads, sum(approved) as approve, sum(validated) as validate, sum(trash) as trash, sum(callback) as callback, sum(uncall) as uncall,
	sum(case when a.leadstatus = 'approved' and a.orderstatus = 'validated' and a.status_transport in ('Delivered', 'delivered') then a.amount else null end) as delivered_amount,
	sum(case when a.leadstatus = 'approved' and a.orderstatus = 'validated' and a.status_transport in ('Delivered', 'delivered') then no_quantity else null end) as delivered_qty,
	sum(case when a.leadstatus = 'approved' and a.orderstatus = 'validated' and a.status_transport in ('Delivered', 'delivered') then delivered else null end) as delivered,
	sum(case when a.leadstatus = 'approved' and lower(a.orderstatus) in ('validated', 'delay') and (status_transport != 'Unassigned' or status_transport is null) then a.amount else null end) as validated_amount,
	sum(case when a.leadstatus = 'approved' and lower(a.orderstatus) in ('validated', 'delay') and (status_transport != 'Unassigned' or status_transport is null) then no_quantity else null end) as validated_qty,
	sum(case when a.leadstatus = 'approved' and lower(a.orderstatus) in ('validated', 'delay') and (status_transport != 'Unassigned' or status_transport is null) then validated else null end) as validated,
	sum(reject) as rejected,
	sum(cancelled) as cancelled,
	sum(other_deli) as other_deli,
--	count(distinct case when lower(orderstatus) in ('validated','delay') and (status_transport != 'Unassigned' or status_transport is null) then tracking_code else null end) as total_do, 
	-- rule changed (Hai and Daniel requested on 1 Jun 2022)
	count(distinct case when lower(leadstatus) = 'approved' and lower(orderstatus) in ('validated', 'delay') then leadid else null end) as total_do,
    	count(distinct case when postback_status = 'approved'  then leadid else null end) as total_approved_postback,
	count(distinct case when lower(leadstatus) = 'approved' and lower(orderstatus) in ('validated', 'delay') and postback_status in ('pending_postback', 'pending_pb') then leadid else null end) as total_pending_postback,
	count(distinct case when lower(orderstatus) in ('validated','delay') and lower(status_transport) = 'intransit' then tracking_code else null end) as total_intransit,
	sum(amount) as total_amount, sum(no_quantity) as quantity, a.leadstatus, status_transport, adjusted_status_transport, team, 'VN3' as "Geo", avg(max_po) max_po, avg(payout) payout
	from a
    where a.filters = 0
--	where date_used::date >= '2023-01-01'
	group by date_used, sourcename, sourcename_fnl, agname, wholesale_name, leadtype, product_name, affiliateid, cpname, subid_fnl, subid, province, district, carrier
	, paymentmethod, warehouse, a.leadstatus, status_transport, adjusted_status_transport, team
    )
	select  * , 
			case when product_name::text ~~ '%cpl%'::text THEN leads - trash 
			else null::bigint 
			end as cpl_lead
	from cte_final     
    """
    df: pd.DataFrame = extract_from_dwh(query, oltp01_conn)
    return df


@asset(group_name="push_dim_finance", retry_policy=RetryPolicy(max_retries=3))
def push_dim_finance_agg_vn4(oltp01_conn: PostgresConnection) -> pd.DataFrame:
    query = f"""
	-- Finance Rebuild 
	-- Vietnam 4 DWH 2023
	with a as
	(select  d.orgid, d.soid, d.tracking_code, d.do_code,
	d.leadid,d.leadname ,d.leadphone,
	--case when d.prod_name is null or d.prod_name = '' then lower(product1)
	--	else lower(d.prod_name)
	--end as product_name,
	--b.product productcrosssell , 
	d.amount ,	
	d.sourcename,
	case when d.sourcename <>  'AFS' then d.sourcename
	when d.sourcename = 'AFS' and d.affiliateid = '122' then 'RTK' --  d.lead_date >= '2021-04-01' and
	when d.sourcename = 'AFS' and d.affiliateid = '165' then 'TSM' --  d.lead_date >= '2021-04-01' and
	when d.sourcename = 'AFS' and d.affiliateid = '169' then 'AKM' -- d.lead_date >= '2021-04-01' and
	when d.sourcename = 'AFS' and d.affiliateid = '243' then 'LOL' --  d.lead_date >= '2021-04-01' and
	when d.sourcename = 'AFS' and d.affiliateid = '250' then 'TEX' --  d.lead_date >= '2021-04-01' and
	when d.sourcename = 'AFS' and d.affiliateid = '1' then '' --  d.lead_date >= '2021-04-01' and
	--	when d.lead_date >= '2021-04-01' and sourcename = 'AFS' and affiliateid = '' then 'ART'
	when d.sourcename = 'AFS' and d.product_name like '%penirumaplus-vn%' and d.subid = '591' and d.affiliateid <> 'EMC' then 'ARB' -- d.lead_date::date = '2021-05-18' and 
	when d.sourcename = 'AFS' then d.affiliateid else d.sourcename --  d.lead_date >= '2021-04-01' and
	end as sourcename_fnl,--coalesce(o.shortname,d.agc_code) as sourcename ,
	d.sourcecode ,d.agid , d.agname,
	case
			when lower(d.agname) like '%cit%' then 'CIT'
			when lower(d.agname) not like '%cit%' then 'Fresh'
			else 'Others'
		end as team,
	case when lower(d.lstatus) = 'approved' then 1 else 0 end as approved,
	case when lower(d.lstatus) = 'trash' then 1 else 0 end as trash,
	case when lower(d.lstatus) in ('callback consulting','callback not prospect','callback potential') then 1 else 0 end as callback,
	case when lower(d.lstatus) in ('noanswer','unreachable') then 1 else 0 end as uncall,
	case when lower(d.sostatus) in ('validated','delay') then 1 else 0 end as validated,
	d.province,
	d.district,
	--d.comment ,coalesce(d.address||'###'||n.name||'-'||m.name||'-'||l.name ,d.address) as address,
	carrier, warehouse, status_transport, delivered, null delivering, cancelled, reject, --unassigned,
	CASE
            WHEN trim(lower(status_transport)) IN ('new') THEN 'New'
            WHEN trim(lower(status_transport)) IN ('packed','picking','in preparation','ready to pick') THEN 'Preparing'
            WHEN trim(lower(status_transport)) IN ('pending') THEN 'Pending'
            WHEN trim(lower(status_transport)) IN ('intransit','picked up','pending delivery') THEN 'In-transit'
            WHEN trim(lower(status_transport)) IN ('pre-delivery','delivering') THEN 'Delivering'
            WHEN trim(lower(status_transport))  IN ('delivery fail') THEN 'Failed'
			WHEN trim(lower(status_transport)) IN ('delivered') THEN 'Delivered'
			WHEN trim(lower(status_transport)) IN ('reject') THEN 'Reject'
			WHEN trim(lower(status_transport)) IN ('returning','returned') THEN 'Return'
			WHEN trim(lower(status_transport)) IN ('cancel') THEN 'Cancel'
			WHEN trim(lower(status_transport)) IN ('unassigned') THEN 'Unassigned'
    	   ELSE 'New'
	END AS adjusted_status_transport,
	--e.ffm_id ffmid,f.shortname ffmname ,e.warehouse_id warehouseid,j.warehouse_shortname warehousename , 
	--k.shortname lastmilename ,
	case d.payment_method when 1 then 'COD' when 2 then 'Bank Transfer' end as paymentmethod,
	case when trim(lower(status_transport)) not in ('delivered', 'reject', 'cancelled', 'unassigned', 'intransit') 
				or (status_transport is null and lower(d.sostatus) in ('validated','delay'))  
				or (status_transport = '' and lower(d.sostatus) in ('validated','delay')) 
				then 1 else 0 end as other_deli,
	--d.lead_status leadstatusid,
	d.lstatus as leadstatus ,
	--a.status sostatusid ,
	d.sostatus as orderstatus ,
	--e.status dostatusid ,i.name deliverystatus ,
	case when d.leadtype = 'S' then 'M' else d.leadtype end as leadtype,
	--d.createdate d.lead_date,
	d.modifydate, --coalesce(e.updatedate, a.modifydate,d.modifydate) modify_date 
	d.so_date,
	d. product_name,
	d.totalcall,
	--d.cp_id cpid,
	d.cpname ,
	d.subid,
	--d.callinglist_id callinglistid,r.cl_name callinglistname ,1  groupid, 'null' groupname--t.group_id, t.short_name group_name
	case when d.sourcename <> 'AFS' then d.sourcename else d.affiliateid end as affiliateid,
	--d.affiliateid, 
	--d.user_defin_05 reason, 
	d.click_id clickid, d.no_quantity,
	case when sourcename <> 'AFS' then affiliateid  -- lead_date >= '2021-04-01' and 
		else subid
	end as subid_fnl,
	case when leadphone like '%907688686%' then 'RS Lâm Xã Hào'
	when leadphone like '%936619478%' or leadphone like '%779132207%' then 'Nguyễn Nhạc Phi'
	when leadphone like '%367735682%' then 'chị Nhung'
	when leadphone like '%393241858%' then 'chị Phương'
	when leadphone like '%396591650%' then 'cô Hà Thị Nguyên'
	when leadphone like '%902472587%' then 'anh Duẩn'
	when leadphone like '%987311215%' then 'Trần Thiên Bình'
	when leadphone like '%912162091%' then 'anh Vinh Lương'
	when leadphone like '%913855881%' then 'Lý Thị Phong Mỹ'
	when leadphone like '%777880077%' then 'chị Trang'
	when leadphone like '%902477285%' then 'Dương Thế Sang'
	when leadphone like '%919714970%' then 'Trần Hiếu Hoàng'
	when leadphone like '%932673877%' then 'Nguyễn Vĩ'
	when leadphone like '%909937576%' then 'Nguyễn Thị Thu Dung'
	when leadphone like '%354077088%' then 'anh Lâm'
	when leadphone like '%347997537%' then 'anh Nam'
	when leadphone like '%903817576%' then 'anh Tiến Phong'
	when leadphone like '%522336938%' or leadphone like '%927502822%' then 'Nguyễn Lộc'
	when leadphone like '%923814400%' then 'Chiến Nguyễn'
	when leadphone like '%989264795%' then 'anh Tuấn'
	when leadphone like '%977153375%' or leadphone like '%982137818%' then 'anh Thanh'
	when leadphone like '%915998888%' then 'CIT Lã Tuấn Hưng'
	when leadphone like '%986761033%' then 'CIT cô Hoa'
	when leadphone like '%913848759%' then 'CIT anh Tuấn'
	when leadphone like '%936115314%' then 'CIT Đào Xuân Hoan'
	when leadphone like '%336850121%' then 'Nguyễn Văn Toàn'
	when leadphone like '%963093895%' then 'CIT chị Mai'
	when leadphone like '%975477516%' then 'Trịnh Minh Trung'
	when leadphone like '%827779911%' then 'Nguyễn Thị Đẹp'
	when leadphone like '%989796234%' then 'anh Hải'
	else 'Not wholesale' end as wholesale_name,
	case when leadtype = 'A' then lead_date else so_date end as date_used,
	max_po,
	payout,
    d.postback_status,
    case when leadtype = 'M' and sourcename is not null and cpname = 'HC OS' then 1 else 0 end filters
	from (
	select d.org_id as orgid, d.lead_id as leadid, d.name as leadname, d.phone as leadphone,
	prod_id, prod_name, d.total_call as totalcall,lead_status, lead_type as leadtype, agc_id, agc_code as sourcecode, --comment,
	od.so_id as soid, od.payment_method, od.createdate as so_date,
	del.tracking_code, 
--	e.ma_don_goc as do_code, 
	del.tracking_code as do_code,
	od.amount,
	p.user_name as agname, q.name as cpname, osi.no_quantity,
--	e.quan_huyen as district,
	m.name as district, l.name as province,
--	carrier, warehouse, 
	k.shortname as carrier,
	warehouse_name as warehouse,
	i.name as status_transport, 
--	delivered, null delivering, cancelled, reject,
	case when g.name in ('approved') and lower(h.name) in ('validated', 'delay') and lower(i.name) in ('refund', 'delivered') then 1 else null end as delivered,
	null delivering,
	case when g.name in ('approved') and lower(h.name) in ('validated', 'delay') and lower(i.name) in ('cancelled') then 1 else null end as cancelled,
	case when g.name in ('approved') and lower(h.name) in ('validated', 'delay') and lower(i.name) in ('reject') then 1 else null end as reject,
	d.address, assigned as agid, d.createdate as lead_date, d.modifydate, d.cp_id, d.callinglist_id, affiliate_id as affiliateid, user_defin_05,click_id,subid1 as subid,
	coalesce(o.shortname,d.agc_code) as sourcename,
	case when d.prod_name is null or d.prod_name = '' then lower(product1) else lower(d.prod_name) end as product_name,
	g.name as lstatus, h.name as sostatus,
	oac.max_po,
	oac.payout,
    d.postback_status
	from ( 
--	select * 
--			from cl_fresh 
--			where 
--				case when lead_status = 4 or (lead_status = 5 and assigned = 0) then 1 else 0 end = 0 
--				and geo = 'VN4'
			select * 
			from cl_fresh 
			where 
			CASE
                WHEN cl_fresh.lead_status = 4 OR cl_fresh.lead_status = 5 AND cl_fresh.assigned = 0 THEN 1
                ELSE 0
            END <> 1
			and org_id = 15 --  geo = 'VN4'	
			) d
	left join ( SELECT
                    a_1.so_id,
                    a_1.org_id,
                    a_1.geo,
                    a_1.cp_id,
                    a_1.lead_id,
                    a_1.amount,
                    a_1.payment_method,
                    a_1.status,
                    a_1.createdate,
                    a_1.creation_date,
                    a_1.validated_rn,
                    a_1.rn,
                    a_1.final_rn
                   FROM ( SELECT
                            oso.so_id,
                            oso.org_id,
                            oso.geo,
                            oso.cp_id,
                            oso.lead_id,
                            oso.amount,
                            oso.payment_method,
                            oso.status,
                            oso.createdate,
                            oso.creation_date,
                            sum(
                                CASE
                                    WHEN oso.status = ANY (ARRAY[43, 357]) THEN 1
                                    ELSE NULL::integer
                                END) OVER (PARTITION BY oso.lead_id) AS validated_rn,
                            row_number() OVER (PARTITION BY oso.lead_id ORDER BY oso.createdate DESC) AS rn,
                                CASE
                                    WHEN row_number() OVER (PARTITION BY oso.lead_id ORDER BY oso.createdate DESC) = 1 AND sum(
                                    CASE
									WHEN oso.status = ANY (ARRAY[43, 357]) THEN 1
									ELSE NULL::integer
                                    END) OVER (PARTITION BY oso.lead_id) > 0 AND (oso.status <> ALL (ARRAY[43, 357])) THEN 2::bigint
                                    WHEN row_number() OVER (PARTITION BY oso.lead_id ORDER BY oso.createdate DESC) <> 1 AND (oso.status = ANY (ARRAY[43, 357])) THEN 1::bigint
                                    ELSE row_number() OVER (PARTITION BY oso.lead_id ORDER BY oso.createdate DESC)
                                END AS final_rn
                           FROM od_sale_order oso
                          WHERE oso.status <> 46 
			  				and oso.org_id = 15  -- geo = 'VN4'
                         ) a_1
                  WHERE a_1.final_rn = 1
                ) od on od.lead_id = d.lead_id and od.org_id = d.org_id
	left join (select * from od_do_new where org_id = 15 and createdate::date >= '2023-01-01') del on del.so_id = od.so_id and del.org_id = od.org_id
--	left join (select * from log_data_main_3 where trim(lower(status_transport)) <> 'unassigned' and ma_don_goc not like 'ULT%') e on e.ma_don_hang::varchar = od.so_id::varchar and od.geo = 'VN3'
--	left join bp_partner o on d.agc_id = o.pn_id and d.geo = o.geo
--	left join bp_partner f on e.ffm_id = f.pn_id and e.geo = f.geo
	left join bp_warehouse j on del.warehouse_id = j.warehouse_id and del.geo = j.geo
	left join bp_partner k on del.carrier_id = k.pn_id and del.geo = k.geo
	left join bp_partner o on d.agc_id = o.pn_id and d.geo = o.geo
	left join (select * from cf_synonym where type ='lead status' and geo = 'VN4') g on d.lead_status=g.value and d.geo = g.geo
	left join (select * from cf_synonym where type ='sale order status' and geo = 'VN4') h on od.status=h.value and od.geo = h.geo
	left join (select * from cf_synonym where type ='delivery order status' and geo = 'VN4') i on del.status=i.value and del.geo = i.geo
	left join (select * from or_user where geo = 'VN4') p on p.user_id=d.assigned and p.geo = d.geo
	-- care for integer error input here
	left join lc_province l on cast(l.prv_id as varchar) = cast(d.province as varchar) and l.geo = d.geo
	left join lc_district m on cast(m.dt_id as varchar) = cast(d.district as varchar) and m.geo = d.geo
	left join lc_subdistrict n on cast(n.sdt_id as varchar) = cast(d.subdistrict as varchar) and n.geo = d.geo
	left join cp_campaign q on q.cp_id = d.cp_id and q.geo = d.geo
	left join cl_calling_list r on r.callinglist_id = d.callinglist_id and r.geo = d.geo
	left join (  select createdate,lead_id,affiliate,sub_id1,offer,max_po,payout,profit,transaction_id
	  from ods_affscale_conversion
	  where geo = 'VN' and createdate::date >= '2023-10-01' -- -- 2023-10-25 - VN4 starts
	  ) oac 
	  on d.click_id = oac.transaction_id
	left join
	(with temp_so as (
		SELECT oi_id, osi.geo,
		so_id,
		quantity,
		item_no,
		osi.prod_id,
		pp.name as product_name,
		row_number() over(partition by so_id order by item_no) as item_no_new
		FROM od_so_item osi 
		left join pd_product pp 
		on osi.prod_id = pp.prod_id and osi.geo = pp.geo
		where osi.prod_id not in (5031, 5032, 5037, 5038, 5039)
		and osi.geo = 'VN4'
	--	order by osi.so_id 
		)
		SELECT so_id, geo,
		max((case when item_no_new = 1 then product_name end)) as product1,
		SUM(quantity) no_quantity,
		COUNT(DISTINCT prod_id) as no_product 
		FROM temp_so
		group by so_id, geo
		order by so_id desc) osi
	on od.so_id = osi.so_id and od.geo = osi.geo
	) d 
	)
	-- final select
    , cte_final as ( 
	select
	date_used::date, sourcename, sourcename_fnl, agname, wholesale_name, leadtype, product_name, affiliateid, cpname, subid_fnl, subid, province, district, carrier, paymentmethod, warehouse,
	count(distinct leadid) as leads, sum(approved) as approve, sum(validated) as validate, sum(trash) as trash, sum(callback) as callback, sum(uncall) as uncall,
	sum(case when a.leadstatus = 'approved' and a.orderstatus = 'validated' and a.status_transport in ('Delivered', 'delivered') then a.amount else null end) as delivered_amount,
	sum(case when a.leadstatus = 'approved' and a.orderstatus = 'validated' and a.status_transport in ('Delivered', 'delivered') then no_quantity else null end) as delivered_qty,
	sum(case when a.leadstatus = 'approved' and a.orderstatus = 'validated' and a.status_transport in ('Delivered', 'delivered') then delivered else null end) as delivered,
	sum(case when a.leadstatus = 'approved' and lower(a.orderstatus) in ('validated', 'delay') and (status_transport != 'Unassigned' or status_transport is null) then a.amount else null end) as validated_amount,
	sum(case when a.leadstatus = 'approved' and lower(a.orderstatus) in ('validated', 'delay') and (status_transport != 'Unassigned' or status_transport is null) then no_quantity else null end) as validated_qty,
	sum(case when a.leadstatus = 'approved' and lower(a.orderstatus) in ('validated', 'delay') and (status_transport != 'Unassigned' or status_transport is null) then validated else null end) as validated,
	sum(reject) as rejected,
	sum(cancelled) as cancelled,
	sum(other_deli) as other_deli,
--	count(distinct case when lower(orderstatus) in ('validated','delay') and (status_transport != 'Unassigned' or status_transport is null) then tracking_code else null end) as total_do, 
	-- rule changed (Hai and Daniel requested on 1 Jun 2022)
	count(distinct case when lower(leadstatus) = 'approved' and lower(orderstatus) in ('validated', 'delay') then leadid else null end) as total_do,
    	count(distinct case when postback_status = 'approved'  then leadid else null end) as total_approved_postback,
	count(distinct case when lower(leadstatus) = 'approved' and lower(orderstatus) in ('validated', 'delay') and postback_status in ('pending_postback', 'pending_pb') then leadid else null end) as total_pending_postback,
	count(distinct case when lower(orderstatus) in ('validated','delay') and lower(status_transport) = 'intransit' then tracking_code else null end) as total_intransit,
	sum(amount) as total_amount, sum(no_quantity) as quantity, a.leadstatus, status_transport, adjusted_status_transport, team, 'VN4' as "Geo", avg(max_po) max_po, avg(payout) payout
	from a
    where a.filters = 0
    
	-- where date_used::date >= '2023-10-01' -- -- 2023-10-25
	group by date_used, sourcename, sourcename_fnl, agname, wholesale_name, leadtype, product_name, affiliateid, cpname, subid_fnl, subid, province, district, carrier
	, paymentmethod, warehouse, a.leadstatus, status_transport, adjusted_status_transport, team
        )
	select  * , 
			case when product_name::text ~~ '%cpl%'::text THEN leads - trash 
			else null::bigint 
			end as cpl_lead
	from cte_final     
    """
    df: pd.DataFrame = extract_from_dwh(query, oltp01_conn)
    return df


@asset(group_name="push_dim_finance", retry_policy=RetryPolicy(max_retries=3))
def push_dim_finance_agg_vnid(oltp01_conn: PostgresConnection) -> pd.DataFrame:
    query = f"""
	-- Finance Rebuild 
	-- VNID DWH 2023
	with a as
	(select  d.orgid, d.soid, d.tracking_code, d.do_code,
	d.leadid,d.leadname ,d.leadphone,
	--case when d.prod_name is null or d.prod_name = '' then lower(product1)
	--	else lower(d.prod_name)
	--end as product_name,
	--b.product productcrosssell , 
	d.amount ,	
	d.sourcename,
	case when d.sourcename <>  'AFS' then d.sourcename
	when d.sourcename = 'AFS' and d.affiliateid = '122' then 'RTK' --  d.lead_date >= '2021-04-01' and
	when d.sourcename = 'AFS' and d.affiliateid = '165' then 'TSM' --  d.lead_date >= '2021-04-01' and
	when d.sourcename = 'AFS' and d.affiliateid = '169' then 'AKM' -- d.lead_date >= '2021-04-01' and
	when d.sourcename = 'AFS' and d.affiliateid = '243' then 'LOL' --  d.lead_date >= '2021-04-01' and
	when d.sourcename = 'AFS' and d.affiliateid = '250' then 'TEX' --  d.lead_date >= '2021-04-01' and
	when d.sourcename = 'AFS' and d.affiliateid = '1' then '' --  d.lead_date >= '2021-04-01' and
	--	when d.lead_date >= '2021-04-01' and sourcename = 'AFS' and affiliateid = '' then 'ART'
	when d.sourcename = 'AFS' and d.product_name like '%penirumaplus-vn%' and d.subid = '591' and d.affiliateid <> 'EMC' then 'ARB' -- d.lead_date::date = '2021-05-18' and 
	when d.sourcename = 'AFS' then d.affiliateid else d.sourcename --  d.lead_date >= '2021-04-01' and
	end as sourcename_fnl,--coalesce(o.shortname,d.agc_code) as sourcename ,
	d.sourcecode ,d.agid , d.agname,
	case
			when lower(d.agname) like '%cit%' then 'CIT'
			when lower(d.agname) not like '%cit%' then 'Fresh'
			else 'Others'
		end as team,
	case when lower(d.lstatus) = 'approved' then 1 else 0 end as approved,
	case when lower(d.lstatus) = 'trash' then 1 else 0 end as trash,
	case when lower(d.lstatus) in ('callback consulting','callback not prospect','callback potential') then 1 else 0 end as callback,
	case when lower(d.lstatus) in ('noanswer','unreachable') then 1 else 0 end as uncall,
	case when lower(d.sostatus) in ('validated','delay') then 1 else 0 end as validated,
	d.province,
	d.district,
	--d.comment ,coalesce(d.address||'###'||n.name||'-'||m.name||'-'||l.name ,d.address) as address,
	carrier, warehouse, status_transport, delivered, null delivering, cancelled, reject, --unassigned,
	CASE
            WHEN trim(lower(status_transport)) IN ('new') THEN 'New'
            WHEN trim(lower(status_transport)) IN ('packed','picking','in preparation','ready to pick') THEN 'Preparing'
            WHEN trim(lower(status_transport)) IN ('pending') THEN 'Pending'
            WHEN trim(lower(status_transport)) IN ('intransit','picked up','pending delivery') THEN 'In-transit'
            WHEN trim(lower(status_transport)) IN ('pre-delivery','delivering') THEN 'Delivering'
            WHEN trim(lower(status_transport))  IN ('delivery fail') THEN 'Failed'
			WHEN trim(lower(status_transport)) IN ('delivered') THEN 'Delivered'
			WHEN trim(lower(status_transport)) IN ('reject') THEN 'Reject'
			WHEN trim(lower(status_transport)) IN ('returning','returned') THEN 'Return'
			WHEN trim(lower(status_transport)) IN ('cancel') THEN 'Cancel'
			WHEN trim(lower(status_transport)) IN ('unassigned') THEN 'Unassigned'
    	   ELSE 'New'
	END AS adjusted_status_transport,
	--e.ffm_id ffmid,f.shortname ffmname ,e.warehouse_id warehouseid,j.warehouse_shortname warehousename , 
	--k.shortname lastmilename ,
	case d.payment_method when 1 then 'COD' when 2 then 'Bank Transfer' end as paymentmethod,
	case when trim(lower(status_transport)) not in ('delivered', 'reject', 'cancelled', 'unassigned', 'intransit') 
				or (status_transport is null and lower(d.sostatus) in ('validated','delay'))  
				or (status_transport = '' and lower(d.sostatus) in ('validated','delay')) 
				then 1 else 0 end as other_deli,
	--d.lead_status leadstatusid,
	d.lstatus as leadstatus ,
	--a.status sostatusid ,
	d.sostatus as orderstatus ,
	--e.status dostatusid ,i.name deliverystatus ,
	case when d.leadtype = 'S' then 'M' else d.leadtype end as leadtype,
	--d.createdate d.lead_date,
	d.modifydate, --coalesce(e.updatedate, a.modifydate,d.modifydate) modify_date 
	d.so_date,
	d. product_name,
	d.totalcall,
	--d.cp_id cpid,
	d.cpname ,
	d.subid,
	--d.callinglist_id callinglistid,r.cl_name callinglistname ,1  groupid, 'null' groupname--t.group_id, t.short_name group_name
	case when d.sourcename <> 'AFS' then d.sourcename else d.affiliateid end as affiliateid,
	--d.affiliateid, 
	--d.user_defin_05 reason, 
	d.click_id clickid, d.no_quantity,
	case when sourcename <> 'AFS' then affiliateid  -- lead_date >= '2021-04-01' and 
		else subid
	end as subid_fnl,
	case when leadphone like '%907688686%' then 'RS Lâm Xã Hào'
	when leadphone like '%936619478%' or leadphone like '%779132207%' then 'Nguyễn Nhạc Phi'
	when leadphone like '%367735682%' then 'chị Nhung'
	when leadphone like '%393241858%' then 'chị Phương'
	when leadphone like '%396591650%' then 'cô Hà Thị Nguyên'
	when leadphone like '%902472587%' then 'anh Duẩn'
	when leadphone like '%987311215%' then 'Trần Thiên Bình'
	when leadphone like '%912162091%' then 'anh Vinh Lương'
	when leadphone like '%913855881%' then 'Lý Thị Phong Mỹ'
	when leadphone like '%777880077%' then 'chị Trang'
	when leadphone like '%902477285%' then 'Dương Thế Sang'
	when leadphone like '%919714970%' then 'Trần Hiếu Hoàng'
	when leadphone like '%932673877%' then 'Nguyễn Vĩ'
	when leadphone like '%909937576%' then 'Nguyễn Thị Thu Dung'
	when leadphone like '%354077088%' then 'anh Lâm'
	when leadphone like '%347997537%' then 'anh Nam'
	when leadphone like '%903817576%' then 'anh Tiến Phong'
	when leadphone like '%522336938%' or leadphone like '%927502822%' then 'Nguyễn Lộc'
	when leadphone like '%923814400%' then 'Chiến Nguyễn'
	when leadphone like '%989264795%' then 'anh Tuấn'
	when leadphone like '%977153375%' or leadphone like '%982137818%' then 'anh Thanh'
	when leadphone like '%915998888%' then 'CIT Lã Tuấn Hưng'
	when leadphone like '%986761033%' then 'CIT cô Hoa'
	when leadphone like '%913848759%' then 'CIT anh Tuấn'
	when leadphone like '%936115314%' then 'CIT Đào Xuân Hoan'
	when leadphone like '%336850121%' then 'Nguyễn Văn Toàn'
	when leadphone like '%963093895%' then 'CIT chị Mai'
	when leadphone like '%975477516%' then 'Trịnh Minh Trung'
	when leadphone like '%827779911%' then 'Nguyễn Thị Đẹp'
	when leadphone like '%989796234%' then 'anh Hải'
	else 'Not wholesale' end as wholesale_name,
	case when leadtype = 'A' then lead_date else so_date end as date_used,
	max_po,
	payout,
    d.postback_status,
    case when leadtype = 'M' and sourcename is not null and cpname = 'HC OS' then 1 else 0 end filters
	from (
	select d.org_id as orgid, d.lead_id as leadid, d.name as leadname, d.phone as leadphone,
	prod_id, prod_name, d.total_call as totalcall,lead_status, lead_type as leadtype, agc_id, agc_code as sourcecode, --comment,
	od.so_id as soid, od.payment_method, od.createdate as so_date,
	del.tracking_code, 
--	e.ma_don_goc as do_code, 
	del.tracking_code as do_code,
	od.amount,
	p.user_name as agname, q.name as cpname, osi.no_quantity,
--	e.quan_huyen as district,
	m.name as district, l.name as province,
--	carrier, warehouse, 
	k.shortname as carrier,
	warehouse_name as warehouse,
	i.name as status_transport, 
--	delivered, null delivering, cancelled, reject,
	case when g.name in ('approved') and lower(h.name) in ('validated', 'delay') and lower(i.name) in ('refund', 'delivered') then 1 else null end as delivered,
	null delivering,
	case when g.name in ('approved') and lower(h.name) in ('validated', 'delay') and lower(i.name) in ('cancelled') then 1 else null end as cancelled,
	case when g.name in ('approved') and lower(h.name) in ('validated', 'delay') and lower(i.name) in ('reject') then 1 else null end as reject,
	d.address, assigned as agid, d.createdate as lead_date, d.modifydate, d.cp_id, d.callinglist_id, affiliate_id as affiliateid, user_defin_05,click_id,subid1 as subid,
	coalesce(o.shortname,d.agc_code) as sourcename,
	case when d.prod_name is null or d.prod_name = '' then lower(product1) else lower(d.prod_name) end as product_name,
	g.name as lstatus, h.name as sostatus,
	oac.max_po,
	oac.payout,
    d.postback_status
	from ( 
--	select * 
--			from cl_fresh 
--			where 
--				case when lead_status = 4 or (lead_status = 5 and assigned = 0) then 1 else 0 end = 0 
--				and geo = 'VNID'
			select * 
			from cl_fresh 
			where 
			CASE
                WHEN cl_fresh.lead_status = 4 OR cl_fresh.lead_status = 5 AND cl_fresh.assigned = 0 THEN 1
                ELSE 0
            END <> 1
			and org_id = 16 --  geo = 'VNID'	
			) d
	left join ( SELECT
                    a_1.so_id,
                    a_1.org_id,
                    a_1.geo,
                    a_1.cp_id,
                    a_1.lead_id,
                    a_1.amount,
                    a_1.payment_method,
                    a_1.status,
                    a_1.createdate,
                    a_1.creation_date,
                    a_1.validated_rn,
                    a_1.rn,
                    a_1.final_rn
                   FROM ( SELECT
                            oso.so_id,
                            oso.org_id,
                            oso.geo,
                            oso.cp_id,
                            oso.lead_id,
                            oso.amount,
                            oso.payment_method,
                            oso.status,
                            oso.createdate,
                            oso.creation_date,
                            sum(
                                CASE
                                    WHEN oso.status = ANY (ARRAY[43, 357]) THEN 1
                                    ELSE NULL::integer
                                END) OVER (PARTITION BY oso.lead_id) AS validated_rn,
                            row_number() OVER (PARTITION BY oso.lead_id ORDER BY oso.createdate DESC) AS rn,
                                CASE
                                    WHEN row_number() OVER (PARTITION BY oso.lead_id ORDER BY oso.createdate DESC) = 1 AND sum(
                                    CASE
									WHEN oso.status = ANY (ARRAY[43, 357]) THEN 1
									ELSE NULL::integer
                                    END) OVER (PARTITION BY oso.lead_id) > 0 AND (oso.status <> ALL (ARRAY[43, 357])) THEN 2::bigint
                                    WHEN row_number() OVER (PARTITION BY oso.lead_id ORDER BY oso.createdate DESC) <> 1 AND (oso.status = ANY (ARRAY[43, 357])) THEN 1::bigint
                                    ELSE row_number() OVER (PARTITION BY oso.lead_id ORDER BY oso.createdate DESC)
                                END AS final_rn
                           FROM od_sale_order oso
                          WHERE oso.status <> 46 
			  				and oso.org_id = 16  -- geo = 'VNID'
                         ) a_1
                  WHERE a_1.final_rn = 1
                ) od on od.lead_id = d.lead_id and od.org_id = d.org_id
	left join (select * from od_do_new where org_id = 16 and createdate::date >= '2023-01-01') del on del.so_id = od.so_id and del.org_id = od.org_id
--	left join (select * from log_data_main_3 where trim(lower(status_transport)) <> 'unassigned' and ma_don_goc not like 'ULT%') e on e.ma_don_hang::varchar = od.so_id::varchar and od.geo = 'VNID'
--	left join bp_partner o on d.agc_id = o.pn_id and d.geo = o.geo
--	left join bp_partner f on e.ffm_id = f.pn_id and e.geo = f.geo
	left join bp_warehouse j on del.warehouse_id = j.warehouse_id and del.geo = j.geo
	left join bp_partner k on del.carrier_id = k.pn_id and del.geo = k.geo
	left join bp_partner o on d.agc_id = o.pn_id and d.geo = o.geo
	left join (select * from cf_synonym where type ='lead status' and geo = 'VNID') g on d.lead_status=g.value and d.geo = g.geo
	left join (select * from cf_synonym where type ='sale order status' and geo = 'VNID') h on od.status=h.value and od.geo = h.geo
	left join (select * from cf_synonym where type ='delivery order status' and geo = 'VNID') i on del.status=i.value and del.geo = i.geo
	left join (select * from or_user where geo = 'VNID') p on p.user_id=d.assigned and p.geo = d.geo
	-- care for integer error input here
	left join lc_province l on cast(l.prv_id as varchar) = cast(d.province as varchar) and l.geo = d.geo
	left join lc_district m on cast(m.dt_id as varchar) = cast(d.district as varchar) and m.geo = d.geo
	left join lc_subdistrict n on cast(n.sdt_id as varchar) = cast(d.subdistrict as varchar) and n.geo = d.geo
	left join cp_campaign q on q.cp_id = d.cp_id and q.geo = d.geo
	left join cl_calling_list r on r.callinglist_id = d.callinglist_id and r.geo = d.geo
	left join (  select createdate,lead_id,affiliate,sub_id1,offer,max_po,payout,profit,transaction_id
	  from ods_affscale_conversion
	  where geo = 'VN' and createdate::date >= '2023-10-01' -- -- 2023-10-25 - VNID starts
	  ) oac 
	  on d.click_id = oac.transaction_id
	left join
	(with temp_so as (
		SELECT oi_id, osi.geo,
		so_id,
		quantity,
		item_no,
		osi.prod_id,
		pp.name as product_name,
		row_number() over(partition by so_id order by item_no) as item_no_new
		FROM od_so_item osi 
		left join pd_product pp 
		on osi.prod_id = pp.prod_id and osi.geo = pp.geo
		where osi.prod_id not in (5031, 5032, 5037, 5038, 5039)
		and osi.geo = 'VNID'
	--	order by osi.so_id 
		)
		SELECT so_id, geo,
		max((case when item_no_new = 1 then product_name end)) as product1,
		SUM(quantity) no_quantity,
		COUNT(DISTINCT prod_id) as no_product 
		FROM temp_so
		group by so_id, geo
		order by so_id desc) osi
	on od.so_id = osi.so_id and od.geo = osi.geo
	) d 
	)
	-- final select
    , cte_final as ( 
	select
	date_used::date, sourcename, sourcename_fnl, agname, wholesale_name, leadtype, product_name, affiliateid, cpname, subid_fnl, subid, province, district, carrier, paymentmethod, warehouse,
	count(distinct leadid) as leads, sum(approved) as approve, sum(validated) as validate, sum(trash) as trash, sum(callback) as callback, sum(uncall) as uncall,
	sum(case when a.leadstatus = 'approved' and a.orderstatus = 'validated' and a.status_transport in ('Delivered', 'delivered') then a.amount else null end) as delivered_amount,
	sum(case when a.leadstatus = 'approved' and a.orderstatus = 'validated' and a.status_transport in ('Delivered', 'delivered') then no_quantity else null end) as delivered_qty,
	sum(case when a.leadstatus = 'approved' and a.orderstatus = 'validated' and a.status_transport in ('Delivered', 'delivered') then delivered else null end) as delivered,
	sum(case when a.leadstatus = 'approved' and lower(a.orderstatus) in ('validated', 'delay') and (status_transport != 'Unassigned' or status_transport is null) then a.amount else null end) as validated_amount,
	sum(case when a.leadstatus = 'approved' and lower(a.orderstatus) in ('validated', 'delay') and (status_transport != 'Unassigned' or status_transport is null) then no_quantity else null end) as validated_qty,
	sum(case when a.leadstatus = 'approved' and lower(a.orderstatus) in ('validated', 'delay') and (status_transport != 'Unassigned' or status_transport is null) then validated else null end) as validated,
	sum(reject) as rejected,
	sum(cancelled) as cancelled,
	sum(other_deli) as other_deli,
--	count(distinct case when lower(orderstatus) in ('validated','delay') and (status_transport != 'Unassigned' or status_transport is null) then tracking_code else null end) as total_do, 
	-- rule changed (Hai and Daniel requested on 1 Jun 2022)
	count(distinct case when lower(leadstatus) = 'approved' and lower(orderstatus) in ('validated', 'delay') then leadid else null end) as total_do,
    	count(distinct case when postback_status = 'approved'  then leadid else null end) as total_approved_postback,
	count(distinct case when lower(leadstatus) = 'approved' and lower(orderstatus) in ('validated', 'delay') and postback_status in ('pending_postback', 'pending_pb') then leadid else null end) as total_pending_postback,
	count(distinct case when lower(orderstatus) in ('validated','delay') and lower(status_transport) = 'intransit' then tracking_code else null end) as total_intransit,
	sum(amount) as total_amount, sum(no_quantity) as quantity, a.leadstatus, status_transport, adjusted_status_transport, team, 'VNID' as "Geo", avg(max_po) max_po, avg(payout) payout
	from a
    where a.filters = 0
	-- where date_used::date >= '2023-10-01' -- -- 2023-10-25
	group by date_used, sourcename, sourcename_fnl, agname, wholesale_name, leadtype, product_name, affiliateid, cpname, subid_fnl, subid, province, district, carrier
	, paymentmethod, warehouse, a.leadstatus, status_transport, adjusted_status_transport, team
        )
	select  * , 
			case when product_name::text ~~ '%cpl%'::text THEN leads - trash 
			else null::bigint 
			end as cpl_lead
	from cte_final     
    """
    df: pd.DataFrame = extract_from_dwh(query, oltp01_conn)
    return df


@asset(group_name="push_dim_finance")
def push_dim_finance_agg_all(
    push_dim_finance_agg_vn: pd.DataFrame,
    push_dim_finance_agg_id2: pd.DataFrame,
    push_dim_finance_agg_id: pd.DataFrame,
    push_dim_finance_agg_th: pd.DataFrame,
    push_dim_finance_agg_th2: pd.DataFrame,
    push_dim_finance_agg_my: pd.DataFrame,
    push_dim_finance_agg_ph: pd.DataFrame,
    push_dim_finance_agg_vn2: pd.DataFrame,
    push_dim_finance_agg_vn3: pd.DataFrame,
    push_dim_finance_agg_vn4: pd.DataFrame,
    push_dim_finance_agg_vnid: pd.DataFrame,
) -> pd.DataFrame:
    full_agg = pd.concat(
        [
            push_dim_finance_agg_vn,
            push_dim_finance_agg_id2,
            push_dim_finance_agg_id,
            push_dim_finance_agg_th,
            push_dim_finance_agg_th2,
            push_dim_finance_agg_my,
            push_dim_finance_agg_ph,
            push_dim_finance_agg_vn2,
            push_dim_finance_agg_vn3,
            push_dim_finance_agg_vn4,
            push_dim_finance_agg_vnid,
        ]
    )
    full_agg = full_agg.dropna(subset=["date_used"])
    full_agg = full_agg.fillna(np.nan).replace([np.nan], [None])

    return full_agg


class CopyConfig(Config):
    table_name: str = "cmd_dim_finance"


@asset(group_name="push_dim_finance")
def load_push_dim_finance_to_postgres(
    push_dim_finance_agg_all: pd.DataFrame,
    oltp01_conn: PostgresConnection,
    config: CopyConfig,
) -> MaterializeResult:
    df = push_dim_finance_agg_all
    buffer = io.BytesIO()
    df.to_csv(buffer, index=False, encoding="utf-8")
    buffer.seek(0)
    with oltp01_conn.get_connection() as connection:
        with connection.cursor() as cursor:
            table_name = config.table_name
            delete_query = f"delete from {table_name} where date_used >= '2023-01-01' "
            cursor.execute(delete_query)
            with cursor.copy(
                f"""copy "{table_name}" from stdin with (format csv, header)"""
            ) as copy:
                copy.write(buffer.read())
    pass


update_push_dim_finance_job = define_asset_job(
    name="update_push_dim_finance_job",
    selection=AssetSelection.assets(
        push_dim_finance_agg_vn,
        push_dim_finance_agg_id2,
        push_dim_finance_agg_id,
        push_dim_finance_agg_th,
        push_dim_finance_agg_th2,
        push_dim_finance_agg_my,
        push_dim_finance_agg_ph,
        push_dim_finance_agg_vn2,
        push_dim_finance_agg_vn3,
        push_dim_finance_agg_vn4,
        push_dim_finance_agg_vnid,
        load_push_dim_finance_to_postgres,
    ),
    config={
        "execution": {
            "config": {
                "multiprocess": {
                    "max_concurrent": 1,
                },
            }
        }
    },
)

update_push_dim_finance_schedule = ScheduleDefinition(
    job=update_push_dim_finance_job,
    cron_schedule=["00 3 * * *"],
    execution_timezone="Asia/Bangkok",
)
