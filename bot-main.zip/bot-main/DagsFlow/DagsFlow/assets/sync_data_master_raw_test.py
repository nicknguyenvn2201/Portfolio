import pandas as pd
import os
from dagster import (
    Config,
    get_dagster_logger,
    asset,
    AssetExecutionContext,
    MetadataValue,
    define_asset_job,
    DailyPartitionsDefinition,
    ScheduleDefinition,
    AssetSelection
)
import io
import psycopg as pg
from DagsFlow.assets.utls import func
from typing import Iterator
import requests as rq
from datetime import date
from datetime import timedelta
from pandas import DataFrame
import pyarrow as pa
from DagsFlow.assets.utls.func import (
    add_blocking_checks_to_asset,
    create_load_to_postgres_asset_db_master,
    create_download_from_sharepoint_asset_base_layer,
)
import psycopg2

logger = get_dagster_logger()


oltp01_conn = os.getenv("PG_LIBPQ_CONN_CONFIG")

class sync_data_master_fully(Config):
    sql_query_truncate_cl_fresh: str = "TRUNCATE dareport.cl_fresh_temp;"
    sql_query_insert_cl_fresh: str = '''insert into dareport.cl_fresh_temp 
    select 
     cl_fresh.geo,
            cl_fresh.lead_id,
            cl_fresh.org_id,
            cl_fresh.cp_id,
            cl_fresh.lead_status,
            cl_fresh.createdate,
            cl_fresh.modifydate,
            cl_fresh.name,
            cl_fresh.phone,
            agc_id,
            agc_code,
            cl_fresh.affiliate_id,
            cl_fresh.prod_name,
            cl_fresh.first_call_status,
            cl_fresh.first_call_time,
            cl_fresh.lead_type,
            cl_fresh.subid1,
            cl_fresh.postback_status,
            cl_fresh.total_call,
            cl_fresh.actual_call,
            cl_fresh.click_id,
            cl_fresh.province,
            cl_fresh.district,
            cl_fresh.subdistrict,
            cl_fresh.assigned,
            first_call_click 
     from public.cl_fresh where modifydate >= now() - interval '1 hour' '''
    sql_query_truncate_od_sale_order: str = "TRUNCATE dareport.od_sale_order_temp;"
    sql_query_insert_od_sale_order: str = "insert into dareport.od_sale_order_temp select * from public.od_sale_order where modifydate >= now() - interval '1 hour';"

    sql_query_truncate_od_do_new: str = "TRUNCATE dareport.od_do_new_temp;"
    sql_query_insert_od_do_new: str = "insert into dareport.od_do_new_temp select * from public.od_do_new where updatedate >= now() - interval '1 hour';"



@asset(group_name="data_master_full_v2")
def truncate_table_cl_fresh_temp_v2(config: sync_data_master_fully):
    conn_details = psycopg2.connect(oltp01_conn)
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_truncate_cl_fresh)
    conn_details.commit()
    cursor.close()
    conn_details.close()

@asset(group_name="data_master_full_v2", deps=[truncate_table_cl_fresh_temp_v2])
def insert_new_data_table_cl_fresh_temp_v2(config: sync_data_master_fully):
    conn_details = psycopg2.connect(oltp01_conn)
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_insert_cl_fresh)
    conn_details.commit()
    cursor.close()
    conn_details.close()

@asset(group_name="data_master_full_v2")
def truncate_table_od_sale_order_temp_v2(config: sync_data_master_fully):
    conn_details = psycopg2.connect(oltp01_conn)
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_truncate_od_sale_order)
    conn_details.commit()
    cursor.close()
    conn_details.close()

@asset(group_name="data_master_full_v2", deps=[truncate_table_od_sale_order_temp_v2])
def insert_new_data_table_od_sale_order_temp_v2(config: sync_data_master_fully):
    conn_details = psycopg2.connect(oltp01_conn)
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_insert_od_sale_order)
    conn_details.commit()
    cursor.close()
    conn_details.close()

@asset(group_name="data_master_full_v2")
def truncate_table_od_do_new_temp_v2(config: sync_data_master_fully):
    conn_details = psycopg2.connect(oltp01_conn)
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_truncate_od_do_new)
    conn_details.commit()
    cursor.close()
    conn_details.close()

@asset(group_name="data_master_full_v2", deps=[truncate_table_od_do_new_temp_v2])
def insert_new_data_table_od_do_new_temp_v2(config: sync_data_master_fully):
    conn_details = psycopg2.connect(oltp01_conn)
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_insert_od_do_new)
    conn_details.commit()
    cursor.close()
    conn_details.close()


@asset(group_name="data_master_full_v2", deps = [insert_new_data_table_cl_fresh_temp_v2, insert_new_data_table_od_sale_order_temp_v2, insert_new_data_table_od_do_new_temp_v2])
def load_data_master_raw_full(context: AssetExecutionContext) -> None:
    target_table='"dareport"."data_master_raw_test_v2"'
    templater = func.SqlStore()
    with pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG")) as connection:
        with connection.cursor() as cursor:
            insert_statement = templater.get("data_master_raw_test").render()
            logger.info("Start inserting into target table")
            cursor.execute(insert_statement)
            logger.info("Completed inserting into target table")

@asset(group_name="data_master_full_v2", deps=[load_data_master_raw_full])
def load_data_master_agg_full(context: AssetExecutionContext) -> None:
    target_table='"dareport"."data_master_agg_test_v1"'
    templater = func.SqlStore()
    with pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG")) as connection:
        with connection.cursor() as cursor:
            insert_statement = templater.get("data_master_agg_test").render()
            logger.info("Start inserting into target table")
            cursor.execute(insert_statement)
            logger.info("Completed inserting into target table")


sync_data_master_full = define_asset_job(
    name="sync_data_master_full",
    selection=AssetSelection.groups("data_master_full_v2"),
)

sync_data_master_full_schedule = ScheduleDefinition(
    job=sync_data_master_full,
    cron_schedule= "0 2 * * *", 
    execution_timezone="Asia/Bangkok",
)


