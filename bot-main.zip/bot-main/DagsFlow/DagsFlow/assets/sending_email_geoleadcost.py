import pandas as pd
import os
from dagster import (
    get_dagster_logger,
    asset,
    AssetExecutionContext,
    define_asset_job,
    ScheduleDefinition,
    AssetSelection
)
import psycopg as pg
from datetime import date
import numpy as np
import pandas as pd
import os
from dateutil.relativedelta import *
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from pathlib import Path


logger = get_dagster_logger()

path = Path(__file__).parent / "email_list"

def send_mail(recipient,ccRecipient, subject, message,lastmonth_month):  
    username = os.getenv("EMAIL_USERNAME_CONN_CONFIG")
    password = os.getenv("EMAIL_PASSWORD_CONN_CONFIG")

    msg = MIMEMultipart()
    msg['From'] = username
    msg['To'] = ', '.join(recipient) 
    msg["Cc"] = ', '.join(ccRecipient) 
    msg['Subject'] = subject
    msg.attach(MIMEText(message, 'plain'))

    file_path = path / f"Fin_data_{lastmonth_month}.xlsx"
    with open(file_path, "rb") as file:
        part = MIMEBase('application', "octet-stream")
        part.set_payload(file.read())
        encoders.encode_base64(part)
        part.add_header('Content-Disposition', f'attachment; filename="{file_path.name}"')
        msg.attach(part)

    try:
        logger.info(f'Sending email to {", ".join(recipient)} with subject "{subject}".')

        all_recipients = recipient + ccRecipient
        mailServer = smtplib.SMTP('smtp-mail.outlook.com', 587)
        mailServer.ehlo()
        mailServer.starttls()
        mailServer.ehlo()
        mailServer.login(username, password)
        mailServer.sendmail(username, all_recipients, msg.as_string())
        mailServer.close()

        logger.info('Email sent successfully.')

    except Exception  as e:
        logger.error(f"Error sending email: {str(e)}")

def read_emails_commission_my_from_file(file_path):
    with open(file_path, 'r') as file:
        return [line.strip() for line in file if line.strip()]

def ar_data_extract(month):
    q_PH = f"""
WITH raw_data AS (
    SELECT
        dmr.country_code,
        dmr.etp_code AS geo,
        dmr.network,
        dmr.offer,
        dmr.lead_date::date AS createdate,
        COUNT(DISTINCT 
            CASE
                WHEN dmr.so_status::text = ANY (ARRAY['validated', 'delay']) THEN dmr.lead_id 
                ELSE NULL 
            END) AS validated,
        COUNT(DISTINCT dmr.lead_id) AS leads,
        SUM(
            CASE
                WHEN dmr.so_status::text = ANY (ARRAY['validated', 'delay']) THEN dmr.so_amount
                ELSE 0::numeric
            END) AS amt_validated,
        COUNT(DISTINCT 
            CASE
                WHEN dmr.do_status::text = 'delivered' THEN dmr.lead_id 
                ELSE NULL 
            END) AS delivered,
        SUM(
            CASE
                WHEN dmr.lead_type::text = 'A' AND dmr.postback_status::text = 'approved' THEN dmr.payout
                ELSE 0::double precision
            END) AS approved_payout,
        SUM(
            CASE
                WHEN dmr.do_status::text = 'delivered' THEN dmr.so_amount
                ELSE 0::numeric
            END) AS amt_delivered
    FROM data_master_raw dmr
    WHERE dmr.lead_type::text = 'A' 
      AND dmr.name !~~ '%test%'
      AND NOT (dmr.lead_status::text IN ('duplicated', 'trash') AND dmr.assigned = 0)
    GROUP BY 1, 2, 3, 4, 5
)
SELECT 
    a.country_code,
    a.geo,
    a.network,
    a.offer,
    a.createdate,
    a.leads,
    round((a.validated::float / NULLIF(a.leads, 0))::numeric, 2) AS ar_qa,
    round((a.amt_validated / NULLIF(rate.exchange, 0) / NULLIF(a.validated, 0))::numeric, 2) AS aov,
    round((a.delivered::float / NULLIF(a.validated, 0))::numeric, 2) AS dr,
    a.approved_payout,
    round((a.amt_delivered / NULLIF(rate.exchange, 0))::numeric, 2) AS delivered_amt
FROM raw_data a
LEFT JOIN dim_exchange_rate rate ON 
    a.country_code = rate.geo 
    AND a.createdate >= rate.started_date::date 
    AND a.createdate <= rate.ending_date::date
WHERE date_trunc('month',a.createdate) = '{month}'
ORDER BY createdate
    """
    conn = pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG"))
    cur = conn.cursor()
    df = pd.read_sql_query(q_PH,conn)
    conn.commit()
    cur.close()
    conn.close()
    return df


@asset(group_name="send_commission_email_geo_lead_cost")
def sending_email_commission_geo_lead_cost(context: AssetExecutionContext) -> None:
    today = date.today()
    lastmonth_date = (today.replace(day=1) + relativedelta(months=-1)).strftime("%Y-%m-%d")
    lastmonth_month = (today.replace(day=1) + relativedelta(months=-1)).strftime("%b-%y")
    df = ar_data_extract(lastmonth_date)
    df.to_excel(os.path.join(path, f"Fin_data_{lastmonth_month}.xlsx"))   
    path_to = path / "ToCommissionMonthly_Geo.txt"
    recipient = read_emails_commission_my_from_file(path_to)
    path_cc = path / "CcCommissionMonthly_Geo.txt"
    ccRecipient = read_emails_commission_my_from_file(path_cc)
    subject = 'Fin Data for '+lastmonth_month
    message = '''Dear all,
    Please find attached to this email the Excel file of Fin Data for the month.
    Thanks & Best Regards,'''
    send_mail(recipient,ccRecipient, subject, message,lastmonth_month)


send_email_commission_geo_lead_cost_jobs = define_asset_job(
    name="send_email_commission_geo_lead_cost_jobs",
    selection=AssetSelection.groups("send_commission_email_geo_lead_cost"),
)

send_email_commission_geo_lead_cost_schedule = ScheduleDefinition(
    job=send_email_commission_geo_lead_cost_jobs,
    cron_schedule= "0 7 20 * *", 
    execution_timezone="Asia/Bangkok",
)
