import pandas as pd
from datetime import datetime, date
from dagster import (
    asset,
    get_dagster_logger,
    Output,
    MetadataValue,
    define_asset_job,
    AssetSelection,
    ScheduleDefinition,
    Config,
)

from DagsFlow.assets.utls.func import (
    add_blocking_checks_to_asset,
    create_load_to_postgres_asset,
    create_download_from_sharepoint_asset,
    create_download_from_sharepoint_ass_input,
)
from DagsFlow.assets.utls.checks import CheckDupDateRange, CheckDupDim, CheckNullColumn
from DagsFlow.assets.utls.func import extract_from_dwh
import pyarrow as pa
import numpy as np
from DagsFlow.resources.msgraph import MSSiteClient
from DagsFlow.resources.postgres import PostgresConnection
import io
import os
import psycopg as pg

logger = get_dagster_logger()


def _df_col_convert_to_float(
    df: pd.DataFrame, col_name: str, is_percentage: bool = False
):
    df = df.copy()
    if is_percentage:
        df[col_name] = df[col_name].str.replace("%", "")
    df[col_name] = df[col_name].str.replace("-", "")
    df[col_name] = df[col_name].str.replace(",", "")
    df[col_name] = pd.to_numeric(df[col_name])
    if is_percentage:
        df[col_name] = df[col_name] / 100
    return df


def _trim_all_columns(df: pd.DataFrame) -> pd.DataFrame:
    """
    Trim whitespace from ends of each value across all series in dataframe
    """
    trim_strings = lambda x: x.strip() if isinstance(x, str) else x
    return df.applymap(trim_strings)


@asset(group_name="dim_user_input")
def extract_bd_aov_target() -> Output[pa.Table]:
    """
    Ingest Bd Aov Target from Web
    """
    df = pd.read_csv(
        r"https://docs.google.com/spreadsheets/d/e/2PACX-1vTsKC77L1DlOcUuta7bflrrRAusPQbOWSM0OggYBFEQ-sYrVBOqL_JRDJTWWX7w7caMEKWyOYE0xzqm/pub?gid=544925897&single=true&output=csv",
        dtype=str,
    )
    df = df.dropna(how="all")
    df = df.rename(
        columns={
            "OFFER": "offer",
            "PUB": "pub",
            "DEAL": "deal",
            "GEO": "geo",
            "AOV TARGET": "aov_target",
            "FROM": "from_date",
            "TO": "to_date",
        },
        errors="raise",
    )
    df["aov_target"] = df["aov_target"].apply(lambda x: float(x.replace(",", ".")))
    df["from_date"] = pd.to_datetime(
        df["from_date"],
        format="%d/%m/%Y",
        errors="ignore",
    )
    df["to_date"] = pd.to_datetime(
        df["to_date"],
        format="%d/%m/%Y",
        errors="ignore",
    )
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("offer", "string"),
                ("pub", "string"),
                ("deal", "string"),
                ("geo", "string"),
                ("aov_target", "float32"),
                ("from_date", "date32"),
                ("to_date", "date32"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


extract_bd_aov_target = add_blocking_checks_to_asset(
    extract_bd_aov_target,
    checks=[
        CheckDupDateRange(
            from_date_col="from_date",
            to_date_col="to_date",
            partitions="geo,pub,offer",
        ),
    ],
)

load_bd_aov_target = create_load_to_postgres_asset(
    asset_name="load_bd_aov_target",
    source_assets=[extract_bd_aov_target],
    target_table="dim_bd_aov_target",
)


@asset(group_name="dim_user_input")
def extract_cit_target() -> Output[pa.Table]:
    """
    Ingest Cit Target from Web
    """
    df = pd.read_csv(
        r"https://docs.google.com/spreadsheets/d/e/2PACX-1vQjgwjHZeGCbun3VYGGDA7RacB1x-F70zbT90PXU6AmUi66WLUytyDb5ih0j7rNKWb-AttV9FZJNFW6/pub?output=csv"
    )
    df = df.dropna(how="all")
    df = df.rename(
        columns={
            "GEO": "geo",
            "# AGENT": "agents",
            "Validated Revenue /agent/day": "valid_revenue_per_agent_per_day",
            "DR": "delivery_ratio",
            "WORKING DATE": "working_date",
            "TAX": "tax",
            "Gross Rev target": "gross_revenue_target",
            "Net Rev Target": "net_revenue_target",
            "From": "from_date",
            "To": "to_date",
        },
        errors="raise",
    )
    df["delivery_ratio"] = df["delivery_ratio"].apply(lambda x: int(x[:-1]) / 100)
    df["tax"] = df["tax"].apply(lambda x: int(x[:-1]) / 100)
    df["working_date"] = df["working_date"].apply(lambda x: float(x.replace(",", ".")))
    df["from_date"] = pd.to_datetime(
        df["from_date"], format="%d/%m/%Y", errors="ignore"
    )
    df["to_date"] = pd.to_datetime(df["to_date"], format="%d/%m/%Y", errors="ignore")
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("geo", "string"),
                ("agents", "int32"),
                ("valid_revenue_per_agent_per_day", "int32"),
                ("delivery_ratio", "float32"),
                ("working_date", "float32"),
                ("tax", "float32"),
                ("gross_revenue_target", "int32"),
                ("net_revenue_target", "int32"),
                ("from_date", "date32"),
                ("to_date", "date32"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


extract_cit_target = add_blocking_checks_to_asset(
    extract_cit_target,
    checks=[
        CheckDupDateRange(
            from_date_col="from_date",
            to_date_col="to_date",
            partitions="geo",
        ),
        CheckNullColumn(),
    ],
)

load_cit_target = create_load_to_postgres_asset(
    asset_name="load_cit_target",
    source_assets=[extract_cit_target],
    target_table="dim_cit_target",
)


@asset(group_name="dim_user_input")
def extract_cpl_target() -> Output[pa.Table]:
    """
    Ingest Cpl Target from Web
    """
    df = pd.read_csv(
        r"https://docs.google.com/spreadsheets/d/e/2PACX-1vTsKC77L1DlOcUuta7bflrrRAusPQbOWSM0OggYBFEQ-sYrVBOqL_JRDJTWWX7w7caMEKWyOYE0xzqm/pub?gid=1385585103&single=true&output=csv",
        dtype=str,
    )
    df = df.dropna(how="all")
    df = df.rename(
        columns={
            "Offer": "offer",
            "Pub": "pub",
            "AR_Target": "ar_target",
            "DR_target": "dr_target",
            "AOV_Target": "aov_target",
            "SPL_MRP": "spl_mrp",
            "FROM": "from_date",
            "TO": "to_date",
        },
        errors="raise",
    )
    df["ar_target"] = df["ar_target"].apply(lambda x: int(x[:-1]) / 100)
    df["dr_target"] = df["dr_target"].apply(lambda x: int(x[:-1]) / 100)
    df["aov_target"] = df["aov_target"].apply(lambda x: float(x.replace(",", ".")))
    df["spl_mrp"] = df["spl_mrp"].apply(lambda x: float(x.replace(",", ".")))
    df["from_date"] = pd.to_datetime(df["from_date"], format="%d/%m/%Y")
    df["to_date"] = pd.to_datetime(df["to_date"], format="%d/%m/%Y")
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("offer", "string"),
                ("pub", "string"),
                ("ar_target", "float32"),
                ("dr_target", "float32"),
                ("aov_target", "float32"),
                ("spl_mrp", "float32"),
                ("from_date", "date32"),
                ("to_date", "date32"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


extract_cpl_target = add_blocking_checks_to_asset(
    extract_cpl_target,
    checks=[
        CheckDupDateRange(
            from_date_col="from_date",
            to_date_col="to_date",
            partitions="pub,offer",
        ),
        CheckNullColumn(),
    ],
)

load_cpl_target = create_load_to_postgres_asset(
    asset_name="load_cpl_target",
    source_assets=[extract_cpl_target],
    target_table="dim_cpl_target",
)


@asset(group_name="dim_user_input")
def extract_mb_target() -> Output[pa.Table]:
    """
    Ingest Mb Target from Web
    """
    df = pd.read_csv(
        r"https://docs.google.com/spreadsheets/d/e/2PACX-1vQWYxsron-Q3hM19lA02i-sf5plr4pHjAVqCuFasi29EJwMLZzYDBp76Bzns5hkdsNacdOrKvpqpsBz/pub?gid=2062631324&single=true&output=csv",
        dtype=str,
    )
    df = df.dropna(how="all")
    df = df.rename(
        columns={
            "Buyer_Type": "buyer_type",
            "Buyer": "buyer",
            "Spent": "spent",
            "Revenue_target": "revenue_target",
            "ROI_target": "roi_target",
            "From": "from_date",
            "To": "to_date",
        },
        errors="raise",
    )

    df["spent"] = df["spent"].apply(
        lambda x: float(x.replace(",", "")) if not pd.isna(x) else None
    )
    df["revenue_target"] = df["revenue_target"].apply(
        lambda x: float(x.replace(",", "")) if not pd.isna(x) else None
    )
    df["roi_target"] = df["roi_target"].apply(
        lambda x: (int(x[:-1]) / 100) if not pd.isna(x) else None
    )
    df["from_date"] = pd.to_datetime(df["from_date"], format="%d/%m/%Y")
    df["to_date"] = pd.to_datetime(df["from_date"], format="%d/%m/%Y")
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("buyer_type", "string"),
                ("buyer", "string"),
                ("spent", "int32"),
                ("revenue_target", "int32"),
                ("roi_target", "float32"),
                ("from_date", "date32"),
                ("to_date", "date32"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


load_mb_target = create_load_to_postgres_asset(
    asset_name="load_mb_target",
    source_assets=[extract_mb_target],
    target_table="dim_mb_target",
)


@asset(group_name="dim_user_input")
def extract_product_cat() -> Output[pa.Table]:
    """
    Ingest Product Category from Web
    """
    df = pd.read_csv(
        r"https://docs.google.com/spreadsheets/d/e/2PACX-1vTcG-kxHSLF6EFbP8Z9GfaRxhZuABuWFZRNfag4dq_IXM5AF050A_THx9Egu7xaog/pub?gid=162579363&single=true&output=csv",
        dtype=str,
    )
    df = df.dropna(how="all")
    df = df.rename(
        columns={
            "productname": "product_name",
            "Category": "category",
        },
        errors="raise",
    )
    df["last_update"] = datetime.now().strftime("%Y-%m-%d, %H:%M")

    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("product_name", "string"),
                ("category", "string"),
                ("geo", "string"),
                ("FIN camp", "string"),
                ("last_update", "string"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


load_product_cat = create_load_to_postgres_asset(
    asset_name="load_product_cat",
    source_assets=[extract_product_cat],
    target_table="cdm_dim_product_cat",
)


download_pub_perf_monitor_input = create_download_from_sharepoint_asset(
    asset_name="download_pub_perf_monitor_input",
    path_to_file="BD - Finance/Publisher performance monitoring input.xlsx",
    link="https://neyucom.sharepoint.com/sites/DATANEYU/_layouts/15/Doc.aspx?sourcedoc=%7B2468F994-DC64-4DE2-9A8C-929354A093ED%7D&file=Publisher%20performance%20monitoring%20input.xlsx&action=default&mobileredirect=true",
)


@asset(group_name="dim_user_input")
def extract_max_po(download_pub_perf_monitor_input: bytes) -> Output[pa.Table]:
    df = pd.read_excel(download_pub_perf_monitor_input, sheet_name="Sheet1")
    df = df[
        [
            "geo",
            "start_date",
            "partner",
            "sub",
            "offer",
            "daily_leads_target",
            "ar_qa_target",
            "max_po_target",
            "dr_target",
            "aov_target",
            "1st_week_action",
            "2nd_week_action",
            "3rd_week_action",
            "4th_week_action",
        ]
    ]
    df = df.dropna(how="all")
    df["start_date"] = pd.to_datetime(df["start_date"], format="%m-%d-%Y")
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("geo", "string"),
                ("partner", "string"),
                ("sub", "string"),
                ("offer", "string"),
                ("daily_leads_target", "float32"),
                ("ar_qa_target", "float32"),
                ("max_po_target", "float32"),
                ("dr_target", "float32"),
                ("aov_target", "float32"),
                ("1st_week_action", "string"),
                ("2nd_week_action", "string"),
                ("3rd_week_action", "string"),
                ("4th_week_action", "string"),
                ("start_date", "date32"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


load_max_po = create_load_to_postgres_asset(
    asset_name="load_max_po",
    source_assets=[extract_max_po],
    target_table="dim_max_po",
)


@asset(group_name="dim_user_input")
def extract_mb_vn_manager() -> Output[pa.Table]:
    """
    Ingest MB VN+UA from Web
    I dropped this and nothing changes ...
    """
    df = pd.read_csv(
        r"https://docs.google.com/spreadsheets/d/e/2PACX-1vSc5d-pXXVqsXYSk_reLf3rgXygl2rILZuUDqFT4lcgXtQGy9fv3fBQ7enij1HrluW59LIimMSM6FME/pub?gid=161806506&single=true&output=csv",
        dtype=str,
    )
    df = df.dropna(how="all")
    df["index"] = df.index
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("index", "int32"),
                ("manager", "string"),
                ("network", "string"),
                ("product_name", "string"),
                ("pub", "string"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


load_mb_vn_manager = create_load_to_postgres_asset(
    asset_name="load_mb_vn_manager",
    source_assets=[extract_mb_vn_manager],
    target_table="cdm_dim_mb_vn_manager",
)

download_weekly_marketing_rate_fin_target = create_download_from_sharepoint_asset(
    asset_name="download_weekly_marketing_rate_fin_target",
    path_to_file="BD - Finance/Weekly_Marketing rate_Finance Target.xlsx",
    link=r"https://neyucom.sharepoint.com/sites/DATANEYU/_layouts/15/Doc.aspx?sourcedoc=%7B0F318990-6573-4FA2-944E-F9BC5154D270%7D&file=Weekly_Marketing%20rate_Finance%20Target.xlsx&action=default&mobileredirect=true",
)


@asset(group_name="dim_user_input")
def extract_cdm_dim_ar_target() -> Output[pa.Table]:
    """
    Ingest cdm_dim_ar_target from Web
    """
    df_id = pd.read_csv(
        r"https://docs.google.com/spreadsheets/d/e/2PACX-1vQx3spioQ_6LaszHk8C3IvU7Vt8tjYygsoAkyInOF0letQEI3qJhVu-KI2ScaTPwlie2WQDotokfzFX/pub?gid=986690898&single=true&output=csv",
        dtype=str,
    )
    df_vn = pd.read_csv(
        r"https://docs.google.com/spreadsheets/d/e/2PACX-1vQx3spioQ_6LaszHk8C3IvU7Vt8tjYygsoAkyInOF0letQEI3qJhVu-KI2ScaTPwlie2WQDotokfzFX/pub?gid=1530620373&single=true&output=csv",
        dtype=str,
    )
    df_th = pd.read_csv(
        r"https://docs.google.com/spreadsheets/d/e/2PACX-1vQx3spioQ_6LaszHk8C3IvU7Vt8tjYygsoAkyInOF0letQEI3qJhVu-KI2ScaTPwlie2WQDotokfzFX/pub?gid=1775168424&single=true&output=csv",
        dtype=str,
    )
    df = pd.concat([df_id, df_vn, df_th])
    df.rename(
        columns={
            "VIP": "vip",
            "AFF": "network",
            "SUB": "subid",
            "OFFER": "product_name",
            "AR_QA MRP": "ar_target",
            "UPDATE DATE": "bd_updatedate",
        },
        inplace=True,
    )
    df["bd_updatedate"] = df["bd_updatedate"].astype(float)
    df["ar_target"] = (
        df["ar_target"].str.replace(",", ".").str.strip("%").astype("float") / 100
    )
    df["vip"] = np.where(df["vip"] == "x", 1, 0)
    df["geo"] = df["product_name"].str[-2:].str.upper()
    df["target_key"] = np.where(
        df["subid"].isnull(),
        df["network"] + "_" + df["product_name"],
        df["network"] + "_" + df["subid"] + "_" + df["product_name"],
    )
    df["last_update"] = datetime.now().strftime("%Y-%m-%d, %H:%M")
    df["index"] = df.index
    df = df.dropna(how="all")
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("index", "int32"),
                ("vip", "int32"),
                ("network", "string"),
                ("subid", "string"),
                ("product_name", "string"),
                ("ar_target", "float32"),
                ("bd_updatedate", "float32"),
                ("geo", "string"),
                ("target_key", "string"),
                ("last_update", "string"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


load_cdm_dim_ar_target = create_load_to_postgres_asset(
    asset_name="load_cdm_dim_ar_target",
    source_assets=[extract_cdm_dim_ar_target],
    target_table="cdm_dim_ar_target",
)


@asset(group_name="dim_user_input")
def extract_cdm_dim_mkt_manager() -> Output[pa.Table]:
    """
    Ingest cdm_dim_mkt_manager from Web
    """
    df = pd.read_csv(
        r"https://docs.google.com/spreadsheets/d/1jFq-8288kWuacNrCeSxR3F-R648I2GaLi3B9CtloDdk/export?format=csv",
        dtype=str,
    )
    df.rename(
        columns={
            "VIP": "vip",
            "AFF": "network",
            "SUB": "subid",
            "OFFER": "product_name",
            "AR_QA MRP": "ar_target",
            "UPDATE DATE": "bd_updatedate",
        },
        inplace=True,
    )
    df["week_num_target"] = df["week_num_target"].astype(int)
    df["index"] = df.index
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("index", "int32"),
                ("week_num_target", "int32"),
                ("network", "string"),
                ("manager", "string"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


load_cdm_dim_mkt_manager = create_load_to_postgres_asset(
    asset_name="load_cdm_dim_mkt_manager",
    source_assets=[extract_cdm_dim_mkt_manager],
    target_table="cdm_dim_mkt_manager",
)


@asset(group_name="dim_user_input")
def extract_cdm_dim_mkt_expense_target_roi_version2() -> Output[pa.Table]:
    """
    Ingest cdm_dim_mkt_expense_target_roi_version2 from Web
    """
    df = pd.read_csv(
        r"https://docs.google.com/spreadsheets/d/e/2PACX-1vQIoot3T9_7V37_s3QM-5KManAcENfb0ZPTn7GVZyaLuXtEtaCUOuEU3ts1sUU_z4mqjFQRe9tKKDmN/pub?gid=0&single=true&output=csv",
        dtype=str,
    )
    df["mkt_expense_target"] = (
        df["mkt_expense_target"].str.strip("%").astype("float") / 100
    )
    df["geo"] = df["product_name"].str[-2:].str.upper()
    df["week_num_target"] = df["week_num_target"].astype(int)
    df["last_update"] = datetime.now().strftime("%Y-%m-%d, %H:%M")
    df["index"] = df.index
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("index", "int32"),
                ("updated_at", "string"),
                ("product_name", "string"),
                ("category", "string"),
                ("network", "string"),
                ("mkt_expense_target", "float32"),
                ("week_num_target", "int32"),
                ("geo", "string"),
                ("last_update", "string"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


load_cdm_dim_mkt_expense_target_roi_version2 = create_load_to_postgres_asset(
    asset_name="load_cdm_dim_mkt_expense_target_roi_version2",
    source_assets=[extract_cdm_dim_mkt_expense_target_roi_version2],
    target_table="cdm_dim_mkt_expense_target_roi_version2",
)


@asset(group_name="dim_user_input")
def extract_cdm_dim_ar_target_version2() -> Output[pa.Table]:
    """
    Ingest cdm_dim_ar_target_version2 from Web
    """
    df_id = pd.read_csv(
        r"https://docs.google.com/spreadsheets/d/e/2PACX-1vQIoot3T9_7V37_s3QM-5KManAcENfb0ZPTn7GVZyaLuXtEtaCUOuEU3ts1sUU_z4mqjFQRe9tKKDmN/pub?gid=349033459&single=true&output=csv",
        dtype=str,
    )
    df_vn = pd.read_csv(
        r"https://docs.google.com/spreadsheets/d/e/2PACX-1vQIoot3T9_7V37_s3QM-5KManAcENfb0ZPTn7GVZyaLuXtEtaCUOuEU3ts1sUU_z4mqjFQRe9tKKDmN/pub?gid=721272527&single=true&output=csv",
        dtype=str,
    )
    df_th = pd.read_csv(
        r"https://docs.google.com/spreadsheets/d/e/2PACX-1vQIoot3T9_7V37_s3QM-5KManAcENfb0ZPTn7GVZyaLuXtEtaCUOuEU3ts1sUU_z4mqjFQRe9tKKDmN/pub?gid=1290877754&single=true&output=csv",
        dtype=str,
    )
    df = pd.concat([df_id, df_vn, df_th])
    df.rename(
        columns={
            "VIP": "vip",
            "AFF": "network",
            "SUB": "subid",
            "OFFER": "product_name",
            "AR_QA MRP": "ar_target",
            "UPDATE DATE": "bd_updatedate",
        },
        inplace=True,
    )
    df["bd_updatedate"] = df["bd_updatedate"].astype(float)
    df["week_num_target"] = df["week_num_target"].astype(int)
    df["ar_target"] = df["ar_target"].str.strip("%").astype("float") / 100
    df["vip"] = np.where(df["vip"] == "x", 1, 0)
    df["geo"] = df["product_name"].str[-2:].str.upper()
    df["target_key"] = np.where(
        df["subid"].isnull(),
        df["network"] + "_" + df["product_name"],
        df["network"] + "_" + df["subid"] + "_" + df["product_name"],
    )
    df["target_key"].value_counts()
    df.drop_duplicates(
        subset=["target_key", "week_num_target"], inplace=True, ignore_index=True
    )
    df["last_update"] = datetime.now().strftime("%Y-%m-%d, %H:%M")
    df["index"] = df.index
    df = df.dropna(how="all")
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("index", "int32"),
                ("vip", "int32"),
                ("network", "string"),
                ("subid", "string"),
                ("product_name", "string"),
                ("ar_target", "float32"),
                ("bd_updatedate", "float32"),
                ("week_num_target", "int32"),
                ("geo", "string"),
                ("target_key", "string"),
                ("last_update", "string"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


load_cdm_dim_ar_target_version2 = create_load_to_postgres_asset(
    asset_name="load_cdm_dim_ar_target_version2",
    source_assets=[extract_cdm_dim_ar_target_version2],
    target_table="cdm_dim_ar_target_version2",
)


@asset(group_name="dim_user_input")
def extract_cdm_dim_mb_fixed_cost() -> Output[pa.Table]:
    """
    Ingest cdm_dim_mb_fixed_cost from Web
    """
    df = pd.read_csv(
        r"https://docs.google.com/spreadsheets/d/e/2PACX-1vR30_GPFtpQ0aEEtfPuGDflf06hS6KDWZU14s4ycG5j60eNVMZzPazH6HGUrSFd-AzJfVH0_E2so1py/pub?gid=2113991623&single=true&output=csv",
        dtype=int,
    )
    df["index"] = df.index
    data = pa.Table.from_pandas(
        df,
        pa.schema([("index", "int32"), ("week_num", "int32"), ("fixed_cost", "int32")]),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


load_cdm_dim_mb_fixed_cost = create_load_to_postgres_asset(
    asset_name="load_cdm_dim_mb_fixed_cost",
    source_assets=[extract_cdm_dim_mb_fixed_cost],
    target_table="cdm_dim_mb_fixed_cost",
)


@asset(group_name="dim_user_input")
def extract_cdm_dim_mb_aff_rev() -> Output[pa.Table]:
    """
    Ingest cdm_dim_mb_aff_rev from Web
    """
    df = pd.read_csv(
        r"https://docs.google.com/spreadsheets/d/e/2PACX-1vR30_GPFtpQ0aEEtfPuGDflf06hS6KDWZU14s4ycG5j60eNVMZzPazH6HGUrSFd-AzJfVH0_E2so1py/pub?gid=1011584251&single=true&output=csv",
        dtype={"week_num": int, "manager": str, "aff_target": int},
    )
    df["index"] = df.index
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("index", "int32"),
                ("week_num", "int32"),
                ("manager", "string"),
                ("aff_target", "int32"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


load_cdm_dim_mb_aff_rev = create_load_to_postgres_asset(
    asset_name="load_cdm_dim_mb_aff_rev",
    source_assets=[extract_cdm_dim_mb_aff_rev],
    target_table="cdm_dim_mb_aff_rev",
)


download_fin_input_roi = create_download_from_sharepoint_asset(
    asset_name="download_fin_input_roi",
    path_to_file="BD - Finance/[Global] Finance Input - ROI.xlsx",
    link=r"https://neyucom.sharepoint.com/sites/DATANEYU/_layouts/15/Doc.aspx?sourcedoc=%7B0F358821-88C2-485A-ADA7-0DF147E3327F%7D&file=[Global]%20Finance%20Input%20-%20ROI.xlsx&action=default&mobileredirect=true",
)


@asset(compute_kind="postgres", group_name="dim_user_input")
def extract_dim_bd_aov_dr_target(download_fin_input_roi: bytes) -> Output[pa.Table]:
    df = pd.read_excel(download_fin_input_roi, sheet_name="AOV&DR&Lead")
    df = _trim_all_columns(df)
    df["Daily_approved_Target"] = (
        df["Daily_approved_Target"].astype(str).str.replace(",", "").astype(int)
    )
    df["week_num_target"] = df["week_num_target"].astype(int)
    df["target_year"] = df["target_year"].astype(int)
    df = df.dropna(how="all")
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("CATEGORY", "string"),
                ("GEO", "string"),
                ("AOV_TARGET", "float32"),
                ("DR_TARGET", "float32"),
                ("Daily_approved_Target", "int32"),
                ("week_num_target", "int32"),
                ("target_year", "int32"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


load_dim_bd_aov_dr_target = create_load_to_postgres_asset(
    asset_name="dim_bd_aov_dr_target",
    source_assets=[extract_dim_bd_aov_dr_target],
    target_table="dim_bd_aov_dr_target",
)

load_dim_bd_aov_dr_target = create_load_to_postgres_asset(
    asset_name="load_dim_bd_aov_dr_target",
    source_assets=[extract_dim_bd_aov_dr_target],
    target_table="dim_bd_aov_dr_target",
)

download_bd_kpi_input = create_download_from_sharepoint_asset(
    asset_name="download_bd_kpi_input",
    path_to_file="BD - Finance/BD - KPI Input.xlsx",
    link=r"https://neyucom.sharepoint.com/sites/DATANEYU/_layouts/15/Doc.aspx?sourcedoc=%7B32D3E2D9-9171-45E9-8653-87F8D688D36C%7D&file=BD%20-%20KPI%20Input.xlsx&action=default&mobileredirect=true",
)


@asset(group_name="dim_user_input")
def extract_dim_bd_kpi(download_bd_kpi_input: bytes) -> Output[pa.Table]:
    df = pd.read_excel(download_bd_kpi_input, sheet_name="Sheet1")
    df = df[
        [
            "start_date",
            "end_date",
            "geo",
            "manager",
            "daily_lead_target",
            "total_po_gap",
            "po_gap_target",
        ]
    ]
    df = df.dropna(how="all")
    df["index"] = df.index
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("index", "int32"),
                ("start_date", "date32"),
                ("end_date", "date32"),
                ("geo", "string"),
                ("manager", "string"),
                ("daily_lead_target", "int32"),
                ("total_po_gap", "int32"),
                ("po_gap_target", "float32"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


load_dim_bd_kpi = create_load_to_postgres_asset(
    asset_name="load_dim_bd_kpi",
    source_assets=[extract_dim_bd_kpi],
    target_table="dim_bd_kpi",
)


@asset(group_name="dim_user_input")
def extract_dim_bd_daily_lead_target(download_fin_input_roi: bytes) -> Output[pa.Table]:
    df = pd.read_excel(download_fin_input_roi, sheet_name="Daily lead target")
    df = _trim_all_columns(df)
    df = df[
        [
            "target_year",
            "week_num_target",
            "bd_manager",
            "network",
            "bd_level",
            "lead_level",
            "CIS",
        ]
    ]
    df["week_num_target"] = df["week_num_target"].astype(int)
    df["target_year"] = df["target_year"].astype(int)
    df["network"] = df["network"].astype(str)
    df = df.dropna(how="all")
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("target_year", "int32"),
                ("week_num_target", "int32"),
                ("bd_manager", "string"),
                ("network", "string"),
                ("bd_level", "string"),
                ("lead_level", "string"),
                ("CIS", "string"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


extract_dim_bd_daily_lead_target = add_blocking_checks_to_asset(
    extract_dim_bd_daily_lead_target,
    checks=[
        CheckDupDim(
            "target_year,week_num_target,bd_manager,network,bd_level,lead_level"
        )
    ],
)


load_dim_bd_daily_lead_target = create_load_to_postgres_asset(
    asset_name="load_dim_bd_daily_lead_target",
    source_assets=[extract_dim_bd_daily_lead_target],
    target_table="dim_bd_daily_lead_target",
)


@asset(group_name="dim_user_input")
def extract_dim_bd_lead_level_by_date(
    download_fin_input_roi: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(download_fin_input_roi, sheet_name="Lead level by date")
    df = _trim_all_columns(df)
    df["Started_date"] = pd.to_datetime(df["Started_date"])
    df["Ending_date"] = pd.to_datetime(df["Ending_date"])
    df["Official Approval"] = pd.to_datetime(df["Official Approval"])
    df["network"] = df["network"].astype(str)
    df["Manager"] = df["Manager"].astype(str)
    df["lead_level"] = df["lead_level"].astype(str)
    df = df.dropna(how="all")
    df = df[
        [
            "network",
            "Manager",
            "lead_level",
            "Official Approval",
            "Started_date",
            "Ending_date",
        ]
    ]
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("network", "string"),
                ("Manager", "string"),
                ("lead_level", "string"),
                ("Official Approval", "date32"),
                ("Started_date", "date32"),
                ("Ending_date", "date32"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


load_dim_bd_lead_level_by_date = create_load_to_postgres_asset(
    asset_name="load_dim_bd_lead_level_by_date",
    source_assets=[extract_dim_bd_lead_level_by_date],
    target_table="dim_bd_lead_level_by_date",
)


@asset(group_name="dim_user_input")
def extract_dim_bd_bonus_scheme(download_fin_input_roi: bytes) -> Output[pa.Table]:
    df = pd.read_excel(download_fin_input_roi, sheet_name="Bonus Scheme")
    df = _trim_all_columns(df)
    df["week_num_target"] = df["week_num_target"].astype(int)
    df["target_year"] = df["target_year"].astype(int)
    df["level50"] = df["level50"].astype(str).str.strip("%").astype("float") / 100
    df["level65"] = df["level65"].astype(str).str.strip("%").astype("float") / 100
    df["level75"] = df["level75"].astype(str).str.strip("%").astype("float") / 100
    df["level95"] = df["level95"].astype(str).str.strip("%").astype("float") / 100
    df = df.dropna(how="all")
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("week_num_target", "int32"),
                ("bd_level", "string"),
                ("lead_level", "string"),
                ("level50", "float32"),
                ("level65", "float32"),
                ("level75", "float32"),
                ("level95", "float32"),
                ("target_year", "int32"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


load_dim_bd_bonus_scheme = create_load_to_postgres_asset(
    asset_name="load_dim_bd_bonus_scheme",
    source_assets=[extract_dim_bd_bonus_scheme],
    target_table="dim_bd_bonus_scheme",
)


@asset(group_name="dim_user_input")
def extract_dim_bd_aff_revenue_target(
    download_fin_input_roi: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(download_fin_input_roi, sheet_name="Aff revenue target")
    df = _trim_all_columns(df)
    df["week_num_target"] = df["week_num_target"].astype(int)
    df["target_year"] = df["target_year"].astype(int)
    df["aff_revenue_target"] = (
        df["aff_revenue_target"].astype(str).str.replace(",", "").astype(int)
    )
    df["estimate_daily_lead"] = (
        df["estimate_daily_lead"].astype(str).str.replace(",", "").astype(int)
    )
    df["daily_approved_lead"] = (
        df["daily_approved_lead"].astype(str).str.replace(",", "").astype(int)
    )
    df["daily_delivered_lead"] = (
        df["daily_delivered_lead"].astype(str).str.replace(",", "").astype(int)
    )
    df = df.dropna(how="all")
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("target_year", "int32"),
                ("week_num_target", "int32"),
                ("bd_manager", "string"),
                ("aff_revenue_target", "int32"),
                ("estimate_daily_lead", "int32"),
                ("daily_approved_lead", "int32"),
                ("daily_delivered_lead", "int32"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


load_dim_bd_aff_revenue_target = create_load_to_postgres_asset(
    asset_name="load_dim_bd_aff_revenue_target",
    source_assets=[extract_dim_bd_aff_revenue_target],
    target_table="dim_bd_aff_revenue_target",
)


@asset(group_name="dim_user_input")
def extract_dim_bd_gm_input(download_fin_input_roi: bytes) -> Output[pa.Table]:
    df = pd.read_excel(download_fin_input_roi, sheet_name="GM Input")
    df = _trim_all_columns(df)
    df = df.dropna(how="all")
    df["index"] = df.index
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("index", "int32"),
                ("started_date", "date32"),
                ("ending_date", "date32"),
                ("geo", "string"),
                ("tax_rate", "float32"),
                ("tele_rate", "float32"),
                ("commission_rate", "float32"),
                ("bd_comm_rate", "float32"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


extract_dim_bd_gm_input = add_blocking_checks_to_asset(
    extract_dim_bd_gm_input,
    checks=[
        CheckDupDateRange(
            from_date_col="started_date",
            to_date_col="ending_date",
            partitions="geo",
        ),
    ],
)


load_dim_bd_gm_input = create_load_to_postgres_asset(
    asset_name="load_dim_bd_gm_input",
    source_assets=[extract_dim_bd_gm_input],
    target_table="dim_bd_gm_input",
)


@asset(group_name="dim_user_input")
def extract_dim_bd_unit_cost(download_fin_input_roi: bytes) -> Output[pa.Table]:
    df = pd.read_excel(download_fin_input_roi, sheet_name="Unit Cost")
    df = _trim_all_columns(df)
    df = df.dropna(how="all")
    df["index"] = df.index
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("index", "int32"),
                ("started_date", "date32"),
                ("geo", "string"),
                ("offer", "string"),
                ("unit_cost", "float32"),
                ("ending_date", "date32"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


load_dim_bd_unit_cost = create_load_to_postgres_asset(
    asset_name="load_dim_bd_unit_cost",
    source_assets=[extract_dim_bd_unit_cost],
    target_table="dim_bd_unit_cost",
)


@asset(group_name="dim_user_input")
def extract_dim_bd_log_cost(download_fin_input_roi: bytes) -> Output[pa.Table]:
    df = pd.read_excel(download_fin_input_roi, sheet_name="Log cost")
    df = _trim_all_columns(df)
    df = df[
        [
            "started_date",
            "ending_date",
            "geo",
            "courier",
            "ffm_fee",
            "lm_fee",
            "return_rate",
            "cod_rate",
            "portion",
        ]
    ]
    df = df.dropna(how="all")
    df["index"] = df.index
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("index", "int32"),
                ("started_date", "date32"),
                ("ending_date", "date32"),
                ("geo", "string"),
                ("courier", "string"),
                ("ffm_fee", "float32"),
                ("lm_fee", "float32"),
                ("return_rate", "float32"),
                ("cod_rate", "float32"),
                ("portion", "int32"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


load_dim_bd_log_cost = create_load_to_postgres_asset(
    asset_name="load_dim_bd_log_cost",
    source_assets=[extract_dim_bd_log_cost],
    target_table="dim_bd_log_cost",
)


@asset(group_name="dim_user_input")
def extract_dim_bd_agent_cost(download_fin_input_roi: bytes) -> Output[pa.Table]:
    df = pd.read_excel(download_fin_input_roi, sheet_name="Agent cost")
    df = _trim_all_columns(df)
    df = df.dropna(how="all")
    df["index"] = df.index
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("index", "int32"),
                ("started_date", "date32"),
                ("ending_date", "date32"),
                ("geo", "string"),
                ("sale_campaign", "string"),
                ("capacity", "int32"),
                ("agent_cost_2", "float32"),
                ("agent_cost_3", "float32"),
                ("per_agent_cost_trash", "float32"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


load_dim_bd_agent_cost = create_load_to_postgres_asset(
    asset_name="load_dim_bd_agent_cost",
    source_assets=[extract_dim_bd_agent_cost],
    target_table="dim_bd_agent_cost",
)


@asset(group_name="dim_user_input")
def extract_dim_bd_fixed_cost(download_fin_input_roi: bytes) -> Output[pa.Table]:
    df = pd.read_excel(download_fin_input_roi, sheet_name="Fixed cost")
    df = _trim_all_columns(df)
    df = df.dropna(how="all")
    df["index"] = str(df.index)
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("index", "string"),
                ("started_date", "string"),
                ("ending_date", "string"),
                ("geo", "string"),
                ("Fixed cost", "string"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


load_dim_bd_fixed_cost = create_load_to_postgres_asset(
    asset_name="load_dim_bd_fixed_cost",
    source_assets=[extract_dim_bd_fixed_cost],
    target_table="dim_bd_fixed_cost",
)


@asset(group_name="dim_user_input")
def extract_dim_bd_revenue_input(download_fin_input_roi: bytes) -> Output[pa.Table]:
    df = pd.read_excel(download_fin_input_roi, sheet_name="Revenue input")
    df = _trim_all_columns(df)
    df = df.dropna(how="all")
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("started_date", "date32"),
                ("ending_date", "date32"),
                ("geo", "string"),
                ("revenue_percentage", "float32"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


load_dim_bd_revenue_input = create_load_to_postgres_asset(
    asset_name="load_dim_bd_revenue_input",
    source_assets=[extract_dim_bd_revenue_input],
    target_table="dim_bd_revenue_input",
)
download_sales_n_ops_input = create_download_from_sharepoint_asset(
    asset_name="download_sales_n_ops_input",
    path_to_file="BD - Finance/Sale and Operation.xlsx",
    link=r"https://neyucom.sharepoint.com/sites/DATANEYU/_layouts/15/Doc.aspx?sourcedoc=%7B033CC2A2-3F2E-4818-98B3-FAF27130C117%7D&file=Sale%20and%20Operation.xlsx&action=default&mobileredirect=true",
)


@asset(group_name="dim_user_input")
def extract_dim_agent_probation(download_sales_n_ops_input: bytes) -> Output[pa.Table]:
    df = pd.read_excel(
        download_sales_n_ops_input, sheet_name="dim_agent_probation", dtype=str
    )
    df = _trim_all_columns(df)
    df = df.dropna(how="all")
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("geo", "string"),
                ("user", "string"),
                ("started_date", "string"),
                ("ending_date", "string"),
                ("result", "string"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


load_dim_agent_probation = create_load_to_postgres_asset(
    asset_name="load_dim_agent_probation",
    source_assets=[extract_dim_agent_probation],
    target_table="dim_agent_probation",
)

download_finance_daily_view_dr = create_download_from_sharepoint_asset(
    asset_name="download_finance_daily_view_dr",
    path_to_file="Finance Cost Input/finance_daily_view_dr.xlsx",
    link=r"https://neyucom.sharepoint.com/sites/DATANEYU/_layouts/15/Doc.aspx?sourcedoc=%7B0E216F6A-0166-4C72-843B-B79349B51AEF%7D&file=finance_daily_view_dr.xlsx&action=default&mobileredirect=true",
)


@asset(group_name="dim_user_input")
def extract_finance_daily_view_dr(
    download_finance_daily_view_dr: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(
        download_finance_daily_view_dr,
        sheet_name="fresh",
        index_col=False,
        dtype={
            "start_date": str,
            "end_date": str,
            "geo": str,
            "pub": str,
            "offer_product": str,
            "sale_camp": str,
            "dr": float,
        },
    )
    df = df.dropna(how="all")
    df["start_date"] = pd.to_datetime(df["start_date"])
    df["end_date"] = pd.to_datetime(df["end_date"])
    df["index"] = df.index
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("index", "int32"),
                ("start_date", "date32"),
                ("end_date", "date32"),
                ("geo", "string"),
                ("pub", "string"),
                ("offer_product", "string"),
                ("sale_camp", "string"),
                ("dr", "float32"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


extract_finance_daily_view_dr = add_blocking_checks_to_asset(
    extract_finance_daily_view_dr,
    checks=[
        CheckDupDateRange(
            from_date_col="start_date",
            to_date_col="end_date",
            partitions="geo,pub,offer_product,sale_camp",
        ),
    ],
)

load_finance_daily_view_dr = create_load_to_postgres_asset(
    asset_name="load_finance_daily_view_dr",
    source_assets=[extract_finance_daily_view_dr],
    target_table="finance_daily_view_dr",
)


@asset(group_name="dim_user_input")
def extract_finance_daily_view_dr_resell(
    download_finance_daily_view_dr: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(
        download_finance_daily_view_dr,
        sheet_name="resell",
        index_col=False,
        dtype={
            "start_date": str,
            "end_date": str,
            "geo": str,
            "product": str,
            "campaign": str,
            "dr": float,
        },
    )
    df = df.dropna(how="all")
    df["start_date"] = pd.to_datetime(df["start_date"])
    df["end_date"] = pd.to_datetime(df["end_date"])
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("start_date", "date32"),
                ("end_date", "date32"),
                ("geo", "string"),
                ("product", "string"),
                ("campaign", "string"),
                ("dr", "float32"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


extract_finance_daily_view_dr_resell = add_blocking_checks_to_asset(
    extract_finance_daily_view_dr_resell,
    checks=[
        CheckDupDateRange(
            from_date_col="start_date",
            to_date_col="end_date",
            partitions="geo,product,campaign",
        ),
    ],
)

load_finance_daily_view_dr_resell = create_load_to_postgres_asset(
    asset_name="load_finance_daily_view_dr_resell",
    source_assets=[extract_finance_daily_view_dr_resell],
    target_table="finance_daily_view_dr_resell",
)
download_vn_market_target = create_download_from_sharepoint_asset(
    asset_name="download_vn_market_target",
    path_to_file="BD - Finance/VN Market_Target.xlsx",
    link=r"https://neyucom.sharepoint.com/sites/DATANEYU/_layouts/15/Doc.aspx?sourcedoc=%7BF45CABEC-DB5C-4EF8-BBCC-A55E6867237D%7D&file=VN%20Market_Target.xlsx&action=default&mobileredirect=true",
)


@asset(group_name="dim_user_input")
def extract_dim_vn_fin_target(download_vn_market_target: bytes) -> Output[pa.Table]:
    df = pd.read_excel(download_vn_market_target, sheet_name="Target")
    df = df[
        [
            "started_date",
            "geo",
            "sales_camp",
            "daily_lead",
            "ar_qa_target",
            "dr_target",
            "aov_target",
            "rank",
            "ending_date",
        ]
    ]
    df["started_date"] = pd.to_datetime(df["started_date"], format="%m-%d-%Y")
    df["ending_date"] = pd.to_datetime(df["ending_date"], format="%m-%d-%Y")
    df = df.dropna(how="all")
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("started_date", "date32"),
                ("geo", "string"),
                ("sales_camp", "string"),
                ("daily_lead", "float32"),
                ("ar_qa_target", "float32"),
                ("dr_target", "float32"),
                ("aov_target", "float32"),
                ("rank", "int32"),
                ("ending_date", "date32"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


load_dim_vn_fin_target = create_load_to_postgres_asset(
    asset_name="load_dim_vn_fin_target",
    source_assets=[extract_dim_vn_fin_target],
    target_table="dim_vn_fin_target",
)


download_fin_product_name_mapping = create_download_from_sharepoint_asset(
    asset_name="download_fin_product_name_mapping",
    path_to_file="Finance Cost Input/Mapping Product Name.xlsx",
    link=r"https://neyucom.sharepoint.com/sites/DATANEYU/_layouts/15/Doc.aspx?sourcedoc=%7BA2523D22-3B5F-41C4-B7AD-2278D8320AA9%7D&file=Mapping%20Product%20Name.xlsx&action=default&mobileredirect=true",
)


@asset(compute_kind="postgres", group_name="dim_user_input")
def extract_dim_finance_product_salescamp(
    download_fin_product_name_mapping: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(
        download_fin_product_name_mapping, sheet_name="Sheet1", index_col=False
    )
    df = df.reset_index(drop=True)
    df = df[~df["offer"].isnull()]
    df.rename(columns={"Sales Camp": "sales_camp"}, inplace=True)
    df["sales_camp"] = df["sales_camp"].str.replace("\n", "")
    df["index"] = df.index
    df = df.dropna(how="all")
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("index", "int32"),
                ("geo", "string"),
                ("offer", "string"),
                ("product_name", "string"),
                ("sales_camp", "string"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


load_dim_finance_product_salescamp = create_load_to_postgres_asset(
    asset_name="load_dim_finance_product_salescamp",
    source_assets=[extract_dim_finance_product_salescamp],
    target_table="dim_finance_product_salescamp",
)


@asset(group_name="dim_user_input")
def extract_dim_bd_new_pub() -> Output[pa.Table]:
    """
    Ingest dim_bd_new_pub from Web
    """
    df = pd.read_csv(
        r"https://docs.google.com/spreadsheets/d/e/2PACX-1vQt8xTIm3TElr4hWqy0MHjIFS1SYh9dh4lybhgVa1STjhBx6NM8Q3h3ldcfPVNChwHz4ELM-NIX3tGc/pub?output=csv",
        dtype=str,
    )
    df = _trim_all_columns(df)
    df.drop_duplicates(inplace=True)
    df = df.dropna(axis=1, how="all")
    header_row = df.iloc[0]
    df = pd.DataFrame(df.values[1:], columns=header_row)
    df["First approved date"] = pd.to_datetime(
        df["First approved date"], format="%d/%m/%Y"
    )
    df["Activate date"] = pd.to_datetime(df["Activate date"], format="%d/%m/%Y")
    df["Last Hot day"] = pd.to_datetime(df["Last Hot day"], format="%d/%m/%Y")
    df.rename(
        columns={
            "Manager": "manager",
            "New partner": "new_pub",
            "First approved date": "first_approved_date",
            "Activate date": "activate_date",
            "Last Hot day": "last_hot_day",
            "Email sent": "email_sent",
            "Note": "note",
        },
        inplace=True,
    )
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("manager", "string"),
                ("new_pub", "string"),
                ("first_approved_date", "date32"),
                ("activate_date", "date32"),
                ("last_hot_day", "date32"),
                ("email_sent", "string"),
                ("note", "string"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


load_dim_bd_new_pub = create_load_to_postgres_asset(
    asset_name="load_dim_bd_new_pub",
    source_assets=[extract_dim_bd_new_pub],
    target_table="dim_bd_new_pub",
)


@asset(group_name="dim_user_input")
def extract_mkt_budget_plan() -> Output[pa.Table]:
    """
    Ingest mkt_budget_plan from Web
    """
    df = pd.read_csv(
        r"https://docs.google.com/spreadsheets/d/e/2PACX-1vTsKC77L1DlOcUuta7bflrrRAusPQbOWSM0OggYBFEQ-sYrVBOqL_JRDJTWWX7w7caMEKWyOYE0xzqm/pub?gid=2015455593&single=true&output=csv",
        dtype=str,
    )
    df = _trim_all_columns(df)
    df.rename(
        columns={
            "GEO": "geo",
            "sales camp": "sales_camp",
            "SPL PLAN": "spl_plan",
            "LEAD COST BUDGET": "lead_cost_budget",
            "MKT BUDGET": "mkt_budget",
            "FROM DATE": "from_date",
            "TO DATE": "to_date",
        },
        inplace=True,
    )
    df["spl_plan"] = df["spl_plan"].str.replace("-", "0")
    df = df.astype({"spl_plan": float})
    df["lead_cost_budget"] = df["lead_cost_budget"].str.replace("%", "")
    df = df.astype({"lead_cost_budget": float})
    df["lead_cost_budget"] = df["lead_cost_budget"] / 100
    df["mkt_budget"] = df["mkt_budget"].str.replace("%", "")
    df = df.astype({"mkt_budget": float})
    df["mkt_budget"] = df["mkt_budget"] / 100
    df["from_date"] = pd.to_datetime(df["from_date"], infer_datetime_format=True)
    df["to_date"] = pd.to_datetime(df["to_date"], infer_datetime_format=True)
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("geo", "string"),
                ("sales_camp", "string"),
                ("product_name", "string"),
                ("network", "string"),
                ("spl_plan", "float32"),
                ("lead_cost_budget", "float32"),
                ("mkt_budget", "float32"),
                ("from_date", "date32"),
                ("to_date", "date32"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


load_mkt_budget_plan = create_load_to_postgres_asset(
    asset_name="load_mkt_budget_plan",
    source_assets=[extract_mkt_budget_plan],
    target_table="mkt_budget_plan",
)


@asset(group_name="dim_user_input")
def extract_mkt_budget_default() -> Output[pa.Table]:
    """
    Ingest mkt_budget_default from Web
    """
    df = pd.read_csv(
        r"https://docs.google.com/spreadsheets/d/e/2PACX-1vTsKC77L1DlOcUuta7bflrrRAusPQbOWSM0OggYBFEQ-sYrVBOqL_JRDJTWWX7w7caMEKWyOYE0xzqm/pub?gid=1503499729&single=true&output=csv",
        dtype=str,
    )
    df = _trim_all_columns(df)
    df.rename(
        columns={
            "GEO": "geo",
            "SPL PLAN": "spl_plan",
            "LEAD COST BUDGET": "lead_cost_budget",
            "MKT BUDGET": "mkt_budget",
            "FROM DATE": "from_date",
            "TO DATE": "to_date",
        },
        inplace=True,
    )
    df["spl_plan"] = df["spl_plan"].str.replace("-", "0")
    df = df.astype({"spl_plan": float})
    df["lead_cost_budget"] = df["lead_cost_budget"].str.replace("%", "")
    df = df.astype({"lead_cost_budget": float})
    df["lead_cost_budget"] = df["lead_cost_budget"] / 100
    df["mkt_budget"] = df["mkt_budget"].str.replace("%", "")
    df = df.astype({"mkt_budget": float})
    df["mkt_budget"] = df["mkt_budget"] / 100
    df["from_date"] = pd.to_datetime(df["from_date"], infer_datetime_format=True)
    df["to_date"] = pd.to_datetime(df["to_date"], infer_datetime_format=True)
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("geo", "string"),
                ("sales_camp", "string"),
                ("spl_plan", "float32"),
                ("lead_cost_budget", "float32"),
                ("mkt_budget", "float32"),
                ("from_date", "date32"),
                ("to_date", "date32"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


load_mkt_budget_default = create_load_to_postgres_asset(
    asset_name="load_mkt_budget_default",
    source_assets=[extract_mkt_budget_default],
    target_table="mkt_budget_default",
)

download_provinces_dr_target = create_download_from_sharepoint_asset(
    asset_name="download_provinces_dr_target",
    path_to_file="Finance Cost Input/provinces_dr_target.xlsx",
    link=r"https://neyucom.sharepoint.com/sites/DATANEYU/_layouts/15/Doc.aspx?sourcedoc=%7BD57DDCE4-B604-4245-8CBB-C62C90CB642F%7D&file=provinces_dr_target.xlsx&action=default&mobileredirect=true",
)


@asset(group_name="dim_user_input")
def extract_dr_target_by_province(
    download_provinces_dr_target: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(download_provinces_dr_target, sheet_name="provinces")
    df.rename(columns={"Year": "year", "Month": "month", "Geo": "geo"}, inplace=True)
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("year", "int32"),
                ("month", "int32"),
                ("geo", "string"),
                ("province", "string"),
                ("dr_target", "float32"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


load_dr_target_by_province = create_load_to_postgres_asset(
    asset_name="load_dr_target_by_province",
    source_assets=[extract_dr_target_by_province],
    target_table="dr_target_by_province",
)

download_fin_assumption_input = create_download_from_sharepoint_asset(
    asset_name="download_fin_assumption_input",
    path_to_file="Finance Cost Input/Assumption_Input.xlsx",
    link=r"https://neyucom.sharepoint.com/sites/DATANEYU/_layouts/15/Doc.aspx?sourcedoc=%7BEBD45E21-4A6B-4BD9-8142-4AE8BE6E4514%7D&file=Assumption_Input.xlsx&action=default&mobileredirect=true",
)


@asset(group_name="dim_user_input")
def extract_dim_production_cost(
    download_fin_assumption_input: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(download_fin_assumption_input, sheet_name="PD")
    df = df[["started_date", "GEO", "product", "Unit Cost (Local Cur.)", "ending_date"]]
    df = df.dropna(how="all")
    df = df.rename(
        columns={
            "started_date": "start_date",
            "GEO": "geo",
            "product": "product",
            "Unit Cost (Local Cur.)": "unit_cost_local_currenncy",
            "ending_date": "ending_date",
        },
        errors="raise",
    )
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("start_date", "date32"),
                ("geo", "string"),
                ("product", "string"),
                ("unit_cost_local_currenncy", "float32"),
                ("ending_date", "date32"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


extract_dim_production_cost = add_blocking_checks_to_asset(
    extract_dim_production_cost,
    checks=[
        CheckDupDateRange(
            from_date_col="start_date",
            to_date_col="ending_date",
            partitions="upper(geo),upper(product)",
        ),
        CheckNullColumn(),
    ],
)


load_dim_production_cost = create_load_to_postgres_asset(
    asset_name="load_dim_production_cost",
    source_assets=[extract_dim_production_cost],
    target_table="dim_production_cost",
)

download_geo_tracking_target = create_download_from_sharepoint_asset(
    asset_name="download_geo_tracking_target",
    file_id="01JEQARU4SBMRMEHTGJNHL3UWURRYLHOUO",
    path_to_file="BD - Finance/[Global] Geo Tracking Target.xlsx",
    link=r"https://neyucom.sharepoint.com/sites/DATANEYU/_layouts/15/Doc.aspx?sourcedoc=%7BC2220B92-661E-4E4B-BDD2-D48C70B3BA8E%7D&file=[Global]%20Geo%20Tracking%20Target.xlsx&action=default&mobileredirect=true",
)


@asset(
    group_name="dim_user_input",
    metadata={
        "Owner": "daniel.ha@neyu.co",
        "Backup": "trang.trinh@neyu.co",
    },
)
def extract_dim_geo_tracking_target(
    download_geo_tracking_target: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(
        download_geo_tracking_target,
        sheet_name="monthly_target",
        dtype={
            "geo": str,
            "target_year": int,
            "target_month": int,
            "daily_lead_target": int,
            "fresh_daily_revenue_target": float,
            "resell_daily_revenue_target": float,
            "fresh_working_days": float,
            "resell_working_days": float,
        },
    )
    df = df.dropna(how="all")
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("geo", "string"),
                ("target_year", "int32"),
                ("target_month", "int32"),
                ("daily_lead_target", "int32"),
                ("fresh_daily_revenue_target", "float64"),
                ("resell_daily_revenue_target", "float64"),
                ("fresh_working_days", "float32"),
                ("resell_working_days", "float32"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


load_dim_geo_tracking_target = create_load_to_postgres_asset(
    asset_name="load_dim_geo_tracking_target",
    source_assets=[extract_dim_geo_tracking_target],
    target_table="dim_geo_tracking_target",
)

download_bd_fin_forecast_target = create_download_from_sharepoint_asset(
    asset_name="download_bd_fin_forecast_target",
    path_to_file="BD - Finance/Forecast- target special deal.xlsx",
    link=r"https://neyucom.sharepoint.com/sites/DATANEYU/_layouts/15/Doc.aspx?sourcedoc=%7B74A04C95-5C1A-46E3-8C6C-9898039B93A8%7D&file=Forecast-%20target%20special%20deal.xlsx&action=default&mobileredirect=true",
)


@asset(group_name="dim_user_input", metadata={"Owner": "anh.ngo.2@neyu.co"})
def extract_dim_follow_up_deal_target(
    download_bd_fin_forecast_target: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(
        download_bd_fin_forecast_target,
        sheet_name="Target- follow up deal",
        dtype={
            "Geo": str,
            "Pub": str,
            "Offer": str,
            "Type": str,
            "Start date": str,
            "end date": str,
            "Lead MRP": int,
            "AR_QA": float,
            "AR_QC": float,
            "AOV_MRP": float,
            "SPL target": float,
            "DR_MRP": float,
            r"%Lead cost MRP": float,
            r"PO": float,
        },
    )
    df = df.dropna(how="all")
    df["Start date"] = pd.to_datetime(df["Start date"], infer_datetime_format=True)
    df["end date"] = pd.to_datetime(df["end date"], infer_datetime_format=True)
    df["AR_MRP"] = 0  
    df["%GM1 MRP"] = 0 
    df["%GM2 MRP"] = 0 
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("Geo", "string"),
                ("Pub", "string"),
                ("Offer", "string"),
                ("Type", "string"),
                ("Start date", "date32"),
                ("end date", "date32"),
                ("Lead MRP", "int32"),
                ("AR_QA", "float32"),
                ("AR_QC", "float32"),
                ("AOV_MRP", "float64"),
                ("SPL target", "float64"),
                ("DR_MRP", "float32"),
                (r"%Lead cost MRP", "float32"),
                (r"PO", "float32"),
                (r"AR_MRP", "float32"),
                (r"%GM1 MRP", "float32"),
                (r"%GM2 MRP", "float32"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


extract_dim_follow_up_deal_target = add_blocking_checks_to_asset(
    extract_dim_follow_up_deal_target,
    checks=[
        CheckDupDateRange(
            from_date_col='"Start date"',
            to_date_col='"end date"',
            partitions="Geo,Pub,Offer",
        ),
    ],
)

load_dim_follow_up_deal_target = create_load_to_postgres_asset(
    asset_name="load_dim_follow_up_deal_target",
    source_assets=[extract_dim_follow_up_deal_target],
    target_table="dim_follow_up_deal_target",
)


@asset(group_name="dim_user_input")
def extract_dim_follow_up_deal_forecast(
    download_bd_fin_forecast_target: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(
        download_bd_fin_forecast_target,
        sheet_name="Forecast- follow up deal",
        dtype={
            "Geo": str,
            "Pub": str,
            "Offer": str,
            "Type": str,
            "Start date": str,
            "end date": str,
            "AR Forecast": float,
            "AOV Forecast": float,
            "DR_Forecast": float,
            "SPL Forecast": float,
            r"%Lead cost FC": float,
            r"%GM1 FC": float,
            r"%GM2 FC": float,
        },
    )
    df = df.dropna(how="all")
    df["Start date"] = pd.to_datetime(df["Start date"], infer_datetime_format=True)
    df["end date"] = pd.to_datetime(df["end date"], infer_datetime_format=True)
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("Geo", "string"),
                ("Pub", "string"),
                ("Offer", "string"),
                ("Type", "string"),
                ("Start date", "date32"),
                ("end date", "date32"),
                ("AR Forecast", "float32"),
                ("AOV Forecast", "float64"),
                ("DR_Forecast", "float32"),
                ("SPL Forecast", "float64"),
                (r"%Lead cost FC", "float32"),
                (r"%GM1 FC", "float32"),
                (r"%GM2 FC", "float32"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


extract_dim_follow_up_deal_forecast = add_blocking_checks_to_asset(
    extract_dim_follow_up_deal_forecast,
    checks=[
        CheckDupDateRange(
            from_date_col='"Start date"',
            to_date_col='"end date"',
            partitions="Geo,Pub,Offer",
        ),
    ],
)
load_dim_follow_up_deal_forecast = create_load_to_postgres_asset(
    asset_name="load_dim_follow_up_deal_forecast",
    source_assets=[extract_dim_follow_up_deal_forecast],
    target_table="dim_follow_up_deal_forecast",
)


@asset(group_name="dim_user_input")
def extract_dim_lead_cost_target(
    download_bd_fin_forecast_target: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(
        download_bd_fin_forecast_target,
        sheet_name="Lead cost target",
        dtype={
            "country_code": str,
            "startdate": str,
            "enddate": str,
            "lead_cost_target": float,
        },
    )
    df = df.dropna(how="all")
    df["startdate"] = pd.to_datetime(df["startdate"], infer_datetime_format=True)
    df["enddate"] = pd.to_datetime(df["enddate"], infer_datetime_format=True)
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("country_code", "string"),
                ("startdate", "date32"),
                ("enddate", "date32"),
                ("lead_cost_target", "float32"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


extract_dim_lead_cost_target = add_blocking_checks_to_asset(
    extract_dim_lead_cost_target,
    checks=[
        CheckDupDateRange(
            from_date_col='"startdate"',
            to_date_col='"enddate"',
            partitions="country_code",
        ),
    ],
)
load_dim_lead_cost_target = create_load_to_postgres_asset(
    asset_name="load_dim_lead_cost_target",
    source_assets=[extract_dim_lead_cost_target],
    target_table="dim_lead_cost_target",
)


@asset(group_name="dim_user_input")
def extract_dim_lead_cost_target_adj_score(
    download_bd_fin_forecast_target: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(
        download_bd_fin_forecast_target,
        sheet_name="Lead cost target - Adj score",
        dtype={
            "adj_level_from": float,
            "adj_level_to": float,
            "score": float,
        },
    )
    df = df.dropna(how="all")
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("adj_level_from", "float32"),
                ("adj_level_to", "float32"),
                ("score", "float32"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


load_dim_lead_cost_target_adj_score = create_load_to_postgres_asset(
    asset_name="load_dim_lead_cost_target_adj_score",
    source_assets=[extract_dim_lead_cost_target_adj_score],
    target_table="dim_lead_cost_target_adj_score",
)


download_th_log_mapping = create_download_from_sharepoint_asset(
    asset_name="download_th_log_mapping",
    path_to_file="[TH] - Logistics/TH_Log_Mapping.xlsx",
    link=r"https://neyucom.sharepoint.com/sites/DATANEYU/_layouts/15/Doc.aspx?sourcedoc=%7BA470867B-F248-4ACF-B3B1-FA9EC1C7AE96%7D&file=TH_Log_Mapping.xlsx&action=default&mobileredirect=true",
)


@asset(
    group_name="dim_user_input",
    metadata={
        "Owner": "panupan@nutralife.asia | yupin@enforte.asia",
        "Backup": "logistics.th@neyu.co",
    },
)
def extract_dim_logistics_product_mapping_th(
    download_th_log_mapping: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(download_th_log_mapping, sheet_name="Product", dtype=str)
    df.rename(
        columns={
            "PRODUCT NAME": "product_name",
            "DB Name": "db_name",
            "Category": "category",
            "Sub-Category": "sub_category",
        },
        inplace=True,
    )
    df["barcode"] = None
    df["country_code"] = "TH"
    df = df[
        [
            "country_code",
            "barcode",
            "product_name",
            "db_name",
            "category",
            "sub_category",
        ]
    ]
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("country_code", "string"),
                ("product_name", "string"),
                ("db_name", "string"),
                ("category", "string"),
                ("sub_category", "string"),
                ("barcode", "string"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


download_vn_log_mapping = create_download_from_sharepoint_asset(
    asset_name="download_vn_log_mapping",
    path_to_file="[VN] - Logistics/VN_Log_Mapping.xlsx",
    link=r"https://neyucom.sharepoint.com/sites/DATANEYU/_layouts/15/Doc.aspx?sourcedoc=%7BA9F606B4-1096-4591-8136-02B5608125DA%7D&file=VN_Log_Mapping.xlsx&action=default&mobileredirect=true",
)


@asset(
    group_name="dim_user_input",
    metadata={
        "Owner": "tien.nguyen.3@kiwi-eco.com",
    },
)
def extract_dim_logistics_product_mapping_vn(
    download_vn_log_mapping: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(download_vn_log_mapping, sheet_name="Product", dtype=str)
    df.rename(
        columns={
            "Barcode": "barcode",
            "PRODUCT NAME": "product_name",
            "DB Name": "db_name",
            "Category": "category",
            "Sub-Category": "sub_category",
        },
        inplace=True,
    )
    df["country_code"] = "VN"
    df = df[
        [
            "country_code",
            "barcode",
            "product_name",
            "db_name",
            "category",
            "sub_category",
        ]
    ]
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("country_code", "string"),
                ("product_name", "string"),
                ("db_name", "string"),
                ("category", "string"),
                ("sub_category", "string"),
                ("barcode", "string"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


load_dim_logistics_product_mapping = create_load_to_postgres_asset(
    asset_name="load_dim_logistics_product_mapping",
    source_assets=[
        extract_dim_logistics_product_mapping_th,
        extract_dim_logistics_product_mapping_vn,
    ],
    target_table="dim_logistics_product_mapping",
)


@asset(
    group_name="dim_user_input",
    metadata={
        "Owner": "tien.nguyen.3@kiwi-eco.com",
    },
)
def extract_dim_logistics_reason_mapping_vn(
    download_vn_log_mapping: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(download_vn_log_mapping, sheet_name="Mapping reason", dtype=str)
    df = df.rename(
        columns={
            "Type": "type",
        },
    )
    df = df[
        [
            "type",
            "system_status",
            "pbi_status",
        ]
    ]
    df = df.drop_duplicates(subset=["type", "system_status"])
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("type", "string"),
                ("system_status", "string"),
                ("pbi_status", "string"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


load_dim_logistics_reason_mapping_vn = create_load_to_postgres_asset(
    asset_name="load_dim_logistics_reason_mapping_vn",
    source_assets=[extract_dim_logistics_reason_mapping_vn],
    target_table="dim_logistics_reason_mapping_vn",
)


@asset(group_name="dim_user_input")
def extract_dim_agent_vn() -> Output[pa.Table]:
    """
    Ingest dim_agent VN from Web
    """
    source_url = {
        "VN": r"https://docs.google.com/spreadsheets/d/e/2PACX-1vRfB7GrkGEtwHTM_Ii_BrSdIOo2eW7SUAtLlvWCP8h5WR7U6tX8mtTsl2lSdZxuww/pub?gid=1767163213&single=true&output=csv",
    }
    df = pd.read_csv(source_url["VN"])
    df = _trim_all_columns(df)
    df.drop_duplicates(inplace=True)
    df["geo"] = "VN"
    df = df[["agent_name", "email", "team", "team_lead", "sup", "geo"]]
    # df = df.dropna(subset=["agent_name", "email"])
    df = df.drop_duplicates(subset=["geo", "email"])
    df["index"] = df.index
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("index", "int32"),
                ("agent_name", "string"),
                ("email", "string"),
                ("team", "string"),
                ("team_lead", "string"),
                ("sup", "string"),
                ("geo", "string"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


@asset(group_name="dim_user_input")
def extract_dim_agent_id() -> Output[pa.Table]:
    """
    Ingest dim_agent ID from Web
    """
    source_url = {
        "ID": r"https://docs.google.com/spreadsheets/d/e/2PACX-1vT4xuxpk4HhC9O6WFAdCsoJPCqieqvZt1WExuFUxMFtOpxgf_R2H1pBU0_MnxlL_A/pub?gid=1177032992&single=true&output=csv",
    }
    df = pd.read_csv(source_url["ID"])
    df = df[~df["Agent ID"].isnull()]
    df = _trim_all_columns(df)
    df.drop_duplicates(inplace=True)
    df["geo"] = "ID"
    df = df[["agent_name", "email", "team", "team_lead", "sup", "geo"]]
    df = df.dropna(subset=["agent_name", "email"])
    df = df.drop_duplicates(subset=["geo", "email"])
    df["index"] = df.index
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("index", "int32"),
                ("agent_name", "string"),
                ("email", "string"),
                ("team", "string"),
                ("team_lead", "string"),
                ("sup", "string"),
                ("geo", "string"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


@asset(group_name="dim_user_input")
def extract_dim_agent_th() -> Output[pa.Table]:
    """
    Ingest dim_agent TH from Web
    """
    source_url = {
        "TH": r"https://docs.google.com/spreadsheets/d/e/2PACX-1vSTTzQp74ytvJyV7d51jkAwrIH4YaYWrpCxIoAQWohDn5knFGc_m7WcMgDyiskxXQ/pub?gid=1474627709&single=true&output=csv",
    }
    df = pd.read_csv(source_url["TH"])
    df = _trim_all_columns(df)
    df.drop_duplicates(inplace=True)
    df["geo"] = "TH"
    df = df[["agent_name", "email", "team", "team_lead", "sup", "geo"]]
    df = df.dropna(subset=["agent_name", "email"])
    df = df.drop_duplicates(subset=["geo", "email"])
    df["index"] = df.index
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("index", "int32"),
                ("agent_name", "string"),
                ("email", "string"),
                ("team", "string"),
                ("team_lead", "string"),
                ("sup", "string"),
                ("geo", "string"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


@asset(group_name="dim_user_input")
def extract_dim_agent_my() -> Output[pa.Table]:
    """
    Ingest dim_agent MY from Web
    """
    source_url = {
        "MY": r"https://docs.google.com/spreadsheets/d/e/2PACX-1vTlnUYFDMTgntDtYij5bdgjBwM7wEtzkRfWy9NOocwEiR9ZYvhVYTxsZe-lkFn8Rg/pub?gid=1799419456&single=true&output=csv",
    }
    df = pd.read_csv(source_url["MY"])
    df = _trim_all_columns(df)
    df.drop_duplicates(inplace=True)
    df["geo"] = "MY"
    df = df[["agent_name", "email", "team", "team_lead", "sup", "geo"]]
    df = df.dropna(subset=["agent_name", "email"])
    df = df.drop_duplicates(subset=["geo", "email"])
    df["index"] = df.index
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("index", "int32"),
                ("agent_name", "string"),
                ("email", "string"),
                ("team", "string"),
                ("team_lead", "string"),
                ("sup", "string"),
                ("geo", "string"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


download_dim_agent_vnid = create_download_from_sharepoint_ass_input(
    asset_name="download_dim_agent_vnid",
    path_to_file="Data team/Data Source - SALES/dim_agent_VNID.xlsx",
    link=r"https://neyucom.sharepoint.com/:x:/r/sites/DATANEYU/_layouts/15/Doc.aspx?sourcedoc=%7B2E632988-13B6-499E-84C3-3188FA04BA19%7D&file=Book.xlsx&actio=",
)

@asset(group_name="dim_user_input")
def extract_dim_agent_vnid(
    download_dim_agent_vnid: bytes,
) -> Output[pa.Table]:
    """
    Ingest dim_agent VNID from Web
    """
    # source_url = {
    #     "VNID": r"https://docs.google.com/spreadsheets/d/e/2PACX-1vTrhK8jyTB81-ardYLD0pYzDY2gdUD49z94z58auMy1N6xQeDJU5TMF89iWUMWiXNIf2WhvLRknuDfP/pub?gid=2027973915&single=true&output=csv",
    # }
    df = pd.read_excel(download_dim_agent_vnid, sheet_name="VNID", dtype=str)
    df = _trim_all_columns(df)
    df.drop_duplicates(inplace=True)
    df["geo"] = "VNID"
    df = df[["agent_name", "email", "team", "team_lead", "sup", "geo"]]
    df = df.dropna(subset=["agent_name", "email"])
    df = df.drop_duplicates(subset=["geo", "email"])
    df["index"] = df.index
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("index", "int32"),
                ("agent_name", "string"),
                ("email", "string"),
                ("team", "string"),
                ("team_lead", "string"),
                ("sup", "string"),
                ("geo", "string"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


load_dim_agent = create_load_to_postgres_asset(
    asset_name="load_dim_agent",
    source_assets=[
        extract_dim_agent_vn,
        extract_dim_agent_th,
        extract_dim_agent_id,
        extract_dim_agent_my,
        extract_dim_agent_vnid,
    ],
    target_table="dim_agent",
)


@asset(group_name="dim_user_input")
def extract_dim_logistics_location_mapping_th(
    download_th_log_mapping: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(
        download_th_log_mapping,
        sheet_name="Region",
        dtype=str,
    )
    df = df.dropna(how="all")
    df["country_code"] = "TH"
    df["island"] = None
    df = df.rename(
        columns={
            "Region": "region",
            "Thai Name": "cl_fresh_province",
            "English Name": "english_name",
        },
        errors="raise",
    )
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("country_code", "string"),
                ("region", "string"),
                ("cl_fresh_province", "string"),
                ("english_name", "string"),
                ("island", "string"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


download_ph_log_mapping = create_download_from_sharepoint_asset(
    asset_name="download_ph_log_mapping",
    path_to_file="[PH] - Logistics/PH_Log_Mapping.xlsx",
    link=r"https://neyucom.sharepoint.com/sites/DATANEYU/_layouts/15/Doc.aspx?sourcedoc=%7BE68F07D0-F56B-4A96-9214-88759982259D%7D&file=PH_Log_Mapping.xlsx&action=default&mobileredirect=true",
)


@asset(group_name="dim_user_input")
def extract_dim_logistics_location_mapping_ph(
    download_ph_log_mapping: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(
        download_ph_log_mapping,
        sheet_name="Region",
        dtype=str,
    )
    df = df.dropna(how="all")
    df["country_code"] = "PH"
    df["english_name"] = None
    df = df.rename(
        columns={
            "Region": "region",
            "English Name": "cl_fresh_province",
            "Island": "island",
        },
        errors="raise",
    )
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("country_code", "string"),
                ("region", "string"),
                ("cl_fresh_province", "string"),
                ("english_name", "string"),
                ("island", "string"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


load_dim_logistics_location_mapping = create_load_to_postgres_asset(
    asset_name="load_dim_logistics_location_mapping",
    source_assets=[
        extract_dim_logistics_location_mapping_th,
        extract_dim_logistics_location_mapping_ph,
    ],
    target_table="dim_logistics_location_mapping",
)


@asset(
    group_name="dim_user_input",
    metadata={
        "Owner": "daniel.ha@neyu.co",
    },
)
def extract_dim_finance_plan_figure(
    download_fin_perf_monitor_input: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(
        download_fin_perf_monitor_input,
        sheet_name="plan_figure",
        dtype={
            "country_code": str,
            "sales_camp": str,
            "offer": str,
            "partner": str,
            "daily_lead_plan": float,
            "ar_qa_plan": float,
            "aov_plan": float,
            "dr_plan": float,
            "month": int,
            "year": int,
            "gp_target": float,
        },
    )
    df = df.dropna(how="all")
    df["country_code"] = df["country_code"].str.upper()
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("country_code", "string"),
                ("sales_camp", "string"),
                ("offer", "string"),
                ("partner", "string"),
                ("daily_lead_plan", "float64"),
                ("ar_qa_plan", "float64"),
                ("aov_plan", "float64"),
                ("dr_plan", "float32"),
                ("month", "int32"),
                ("year", "int32"),
                ("gp_target", "float32"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


extract_dim_finance_plan_figure = add_blocking_checks_to_asset(
    extract_dim_finance_plan_figure,
    checks=[
        CheckDupDim("country_code,sales_camp,offer,partner,month,year"),
        CheckNullColumn(["country_code", "sales_camp", "offer", "partner"]),
    ],
)


load_dim_finance_plan_figure = create_load_to_postgres_asset(
    asset_name="load_dim_finance_plan_figure",
    source_assets=[extract_dim_finance_plan_figure],
    target_table="dim_finance_plan_figure",
)


@asset(
    group_name="dim_user_input",
    metadata={
        "Owner": "linh.nguyen@neyu.co",
    },
)
def extract_dim_finance_markup(
    download_fin_perf_monitor_input: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(
        download_fin_perf_monitor_input,
        sheet_name="markup",
        dtype={
            "country_code": str,
            "month": int,
            "year": int,
            "markup": float,
        },
    )
    df = df.dropna(how="any")
    df["country_code"] = df["country_code"].str.upper()
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("country_code", "string"),
                ("month", "int32"),
                ("year", "int32"),
                ("markup", "float32"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


load_dim_finance_markup = create_load_to_postgres_asset(
    asset_name="load_dim_finance_markup",
    source_assets=[extract_dim_finance_markup],
    target_table="dim_finance_markup",
)


@asset(
    group_name="dim_user_input",
    metadata={
        "Owner": "daniel.ha@neyu.co",
    },
)
def extract_dim_finance_bd_logistics_cost(
    download_fin_perf_monitor_input: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(
        download_fin_perf_monitor_input,
        sheet_name="logistics_cost",
        dtype={
            "country_code": str,
            "start_date": str,
            "end_date": str,
            "logistics_cost_per_validated_order_usd": float,
        },
    )
    df = df.dropna(how="any")
    df["country_code"] = df["country_code"].str.upper()
    df["start_date"] = pd.to_datetime(df["start_date"], infer_datetime_format=True)
    df["end_date"] = pd.to_datetime(df["end_date"], infer_datetime_format=True)
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("country_code", "string"),
                ("start_date", "date32"),
                ("end_date", "date32"),
                ("logistics_cost_per_validated_order_usd", "float32"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


load_dim_finance_bd_logistics_cost = create_load_to_postgres_asset(
    asset_name="load_dim_finance_bd_logistics_cost",
    source_assets=[extract_dim_finance_bd_logistics_cost],
    target_table="dim_finance_bd_logistics_cost",
)

download_fin_target_source = create_download_from_sharepoint_asset(
    asset_name="download_fin_target_source",
    path_to_file="BD - Finance/TARGET SOURCE FILE.xlsx",
    link=r"https://neyucom.sharepoint.com/sites/DATANEYU/_layouts/15/Doc.aspx?sourcedoc=%7BB072D6C2-6965-46EA-9B88-F12845F7D9ED%7D&file=TARGET%20SOURCE%20FILE.xlsx&action=default&mobileredirect=true",
)


@asset(
    group_name="dim_user_input",
    metadata={
        "Owner": "linh.nguyen@neyu.co",
    },
)
def extract_dim_lead_cost_rev_plan(
    download_fin_target_source: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(
        download_fin_target_source,
        sheet_name="Sheet1",
        dtype={
            "Geo": str,
            "Pub": str,
            "Offer": str,
            "Lead Target": int,
            "AR target": float,
            "Validated target": int,
            "DR target": float,
            "AOV target": int,
            "Revenue target": int,
            "Month": int,
            "Year": int,
            "Lead cost Plan": float,
        },
    )
    df = df.dropna(how="any")
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("Geo", "string"),
                ("Pub", "string"),
                ("Offer", "string"),
                ("Lead Target", "int32"),
                ("AR target", "float32"),
                ("Validated target", "int32"),
                ("DR target", "float32"),
                ("AOV target", "int32"),
                ("Revenue target", "int32"),
                ("Month", "int32"),
                ("Year", "int32"),
                ("Lead cost Plan", "float32"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


extract_dim_lead_cost_rev_plan = add_blocking_checks_to_asset(
    extract_dim_lead_cost_rev_plan, checks=[CheckDupDim("Month,Year,Pub,Offer")]
)


load_dim_lead_cost_rev_plan = create_load_to_postgres_asset(
    asset_name="load_dim_lead_cost_rev_plan",
    source_assets=[extract_dim_lead_cost_rev_plan],
    target_table="dim_lead_cost_rev_plan",
)
download_dim_mb_camp_category = create_download_from_sharepoint_asset(
    asset_name="download_dim_mb_camp_category",
    path_to_file="BD - Finance/BD_INPUT/dim_mb_camp_category.xlsx",
    link=r"https://neyucom.sharepoint.com/sites/DATANEYU/_layouts/15/Doc.aspx?sourcedoc=%7B9ACB9733-1502-4E0C-BA7E-3664A1CA253E%7D&file=dim_mb_camp_category.xlsx&action=default&mobileredirect=true",
)


@asset(
    group_name="dim_user_input",
    metadata={
        "Owner": "david@neyu.co",
    },
)
def extract_dim_mb_camp_category(
    download_dim_mb_camp_category: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(
        download_dim_mb_camp_category,
        sheet_name="dim_mb_camp_category",
        dtype={
            "camp_id": int,
            "start_date": str,
            "stage": str,
            "camp_category": str,
            "budget": float,
            "status": str,
        },
    )
    df = df.dropna(how="all")
    df["start_date"] = pd.to_datetime(df["start_date"], infer_datetime_format=True)
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("camp_id", "int16"),
                ("start_date", "date32"),
                ("stage", "string"),
                ("camp_category", "string"),
                ("budget", "float32"),
                ("status", "string"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


load_dim_mb_camp_category = create_load_to_postgres_asset(
    asset_name="load_dim_mb_camp_category",
    source_assets=[extract_dim_mb_camp_category],
    target_table="dim_mb_camp_category",
)


@asset(group_name="dim_user_input")
def extract_dim_fin_commission(
    download_fin_assumption_input: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(download_fin_assumption_input, sheet_name="COM.BO | FO")
    df = df[["started_date", "GEO", "Fresh", "ending_date"]]
    df = df.rename(
        columns={
            "started_date": "start_date",
            "GEO": "country_code",
            "ending_date": "end_date",
            "Fresh": "commission_rate_fresh",
        },
        errors="raise",
    )
    df = df.dropna(how="all")
    df["country_code"] = df["country_code"].str.upper()
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("start_date", "date32"),
                ("country_code", "string"),
                ("end_date", "date32"),
                ("commission_rate_fresh", "float32"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


extract_dim_fin_commission = add_blocking_checks_to_asset(
    extract_dim_fin_commission,
    checks=[
        CheckDupDateRange(
            from_date_col="start_date",
            to_date_col="end_date",
            partitions="country_code",
        ),
        CheckNullColumn(),
    ],
)

load_dim_fin_commission = create_load_to_postgres_asset(
    asset_name="load_dim_fin_commission",
    source_assets=[extract_dim_fin_commission],
    target_table="dim_fin_commission",
)


@asset(
    group_name="dim_user_input",
    metadata={
        "Owner": "daniel.ha@neyu.co",
    },
)
def extract_dim_finance_agent_type(
    download_fin_perf_monitor_input: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(
        download_fin_perf_monitor_input,
        sheet_name="dim_agent_type",
        dtype={
            "country_code": str,
            "agent_name": str,
            "type": str,
            "resell_account": str,
        },
    )
    df = df.dropna(how="all")
    df["type"] = df["type"].str.upper()
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("country_code", "string"),
                ("agent_name", "string"),
                ("type", "string"),
                ("resell_account", "string"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


load_dim_finance_agent_type = create_load_to_postgres_asset(
    asset_name="load_dim_finance_agent_type",
    source_assets=[extract_dim_finance_agent_type],
    target_table="dim_finance_agent_type",
)

download_fin_perf_monitor_input = create_download_from_sharepoint_asset(
    asset_name="download_fin_perf_monitor_input",
    path_to_file="BD - Finance/Performance Monitoring Input.xlsx",
    link=r"https://neyucom.sharepoint.com/sites/DATANEYU/_layouts/15/Doc.aspx?sourcedoc=%7B37640033-D271-47EF-8DC7-93CBA11557B8%7D&file=Performance%20Monitoring%20Input.xlsx&action=default&mobileredirect=true",
)


@asset(
    group_name="dim_user_input",
    metadata={
        "Owner": "daniel.ha@neyu.co",
    },
)
def extract_dim_finance_salary_cost(
    download_fin_perf_monitor_input: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(
        download_fin_perf_monitor_input,
        sheet_name="salary_cost",
        dtype={
            "country_code": str,
            "start_date": str,
            "end_date": str,
            "team": str,
            "total_monthly_cost_usd": float,
        },
    )
    df = df.dropna(how="any")
    df["team"] = df["team"].str.upper()
    df["start_date"] = pd.to_datetime(df["start_date"], infer_datetime_format=True)
    df["end_date"] = pd.to_datetime(df["end_date"], infer_datetime_format=True)
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("country_code", "string"),
                ("start_date", "date32"),
                ("end_date", "date32"),
                ("team", "string"),
                ("total_monthly_cost_usd", "float32"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


load_dim_finance_salary_cost = create_load_to_postgres_asset(
    asset_name="load_dim_finance_salary_cost",
    source_assets=[extract_dim_finance_salary_cost],
    target_table="dim_finance_salary_cost",
)


@asset(
    group_name="dim_user_input",
    metadata={
        "Owner": "thuong.dinh@neyu.co",
    },
)
def extract_dim_finance_tel_cost(
    download_fin_assumption_input: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(download_fin_assumption_input, sheet_name="TEL")
    df = df[
        [
            "started_date",
            "GEO",
            "Sales-Type",
            "TEL/order (Local Cur.)",
            "TEL/Lead (Local Cur.)",
            "ending_date",
        ]
    ]
    df = df.rename(
        columns={
            "started_date": "start_date",
            "GEO": "country_code",
            "ending_date": "end_date",
            "Sales-Type": "lead_type",
            "TEL/order (Local Cur.)": "tel_cost_per_so_local_cur",
            "TEL/Lead (Local Cur.)": "tel_cost_per_lead_local_cur",
        },
        errors="raise",
    )
    df = df.dropna(how="all")
    df["country_code"] = df["country_code"].str.upper()
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("start_date", "date32"),
                ("end_date", "date32"),
                ("country_code", "string"),
                ("lead_type", "string"),
                ("tel_cost_per_lead_local_cur", "float32"),
                ("tel_cost_per_so_local_cur", "float32"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


extract_dim_finance_tel_cost = add_blocking_checks_to_asset(
    extract_dim_finance_tel_cost,
    checks=[
        CheckDupDateRange(
            from_date_col="start_date",
            to_date_col="end_date",
            partitions="country_code,lead_type",
        ),
    ],
)
load_dim_finance_tel_cost = create_load_to_postgres_asset(
    asset_name="load_dim_finance_tel_cost",
    source_assets=[extract_dim_finance_tel_cost],
    target_table="dim_finance_tel_cost",
)


@asset(group_name="dim_user_input")
def extract_dim_mkt_budget_target_geo() -> Output[pa.Table]:
    """
    Ingest dim_mkt_budget_target_geo from Web
    """
    df = pd.read_csv(
        r"https://docs.google.com/spreadsheets/d/e/2PACX-1vTsKC77L1DlOcUuta7bflrrRAusPQbOWSM0OggYBFEQ-sYrVBOqL_JRDJTWWX7w7caMEKWyOYE0xzqm/pub?gid=1909492228&single=true&output=csv",
        dtype=str,
    )
    df = _trim_all_columns(df)
    df.rename(
        columns={
            "GEO": "geo",
            "LEAD TARGET": "lead_target",
            "SPL TARGET": "spl_target",
            r"% LEAD COST TARGET": "percentage_lead_cost_target",
            "FROM": "from_date",
            "TO": "to_date",
        },
        inplace=True,
    )
    df = _df_col_convert_to_float(df, "lead_target")
    df = _df_col_convert_to_float(df, "spl_target")
    df = _df_col_convert_to_float(df, "percentage_lead_cost_target", True)
    df["from_date"] = pd.to_datetime(df["from_date"], infer_datetime_format=True)
    df["to_date"] = pd.to_datetime(df["to_date"], infer_datetime_format=True)
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("geo", "string"),
                ("lead_target", "float32"),
                ("spl_target", "float32"),
                ("percentage_lead_cost_target", "float32"),
                ("from_date", "date32"),
                ("to_date", "date32"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


load_dim_mkt_budget_target_geo = create_load_to_postgres_asset(
    asset_name="load_dim_mkt_budget_target_geo",
    source_assets=[extract_dim_mkt_budget_target_geo],
    target_table="dim_mkt_budget_target_geo",
)


@asset(group_name="dim_user_input")
def extract_dim_mkt_budget_target_camp() -> Output[pa.Table]:
    """
    Ingest dim_mkt_budget_target_camp from Web
    """
    df = pd.read_csv(
        r"https://docs.google.com/spreadsheets/d/e/2PACX-1vTsKC77L1DlOcUuta7bflrrRAusPQbOWSM0OggYBFEQ-sYrVBOqL_JRDJTWWX7w7caMEKWyOYE0xzqm/pub?gid=1575141522&single=true&output=csv",
        dtype=str,
    )
    df = _trim_all_columns(df)
    df.rename(
        columns={
            "GEO": "geo",
            "CAMP": "camp",
            "LEAD TARGET": "lead_target",
            "SPL TARGET": "spl_target",
            r"% LEAD COST TARGET": "percentage_lead_cost_target",
            "FROM": "from_date",
            "TO": "to_date",
        },
        inplace=True,
    )
    df = _df_col_convert_to_float(df, "lead_target")
    df = _df_col_convert_to_float(df, "spl_target")
    df = _df_col_convert_to_float(df, "percentage_lead_cost_target", True)
    df["from_date"] = pd.to_datetime(df["from_date"], infer_datetime_format=True)
    df["to_date"] = pd.to_datetime(df["to_date"], infer_datetime_format=True)
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("geo", "string"),
                ("camp", "string"),
                ("lead_target", "float32"),
                ("spl_target", "float32"),
                ("percentage_lead_cost_target", "float32"),
                ("from_date", "date32"),
                ("to_date", "date32"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


load_dim_mkt_budget_target_camp = create_load_to_postgres_asset(
    asset_name="load_dim_mkt_budget_target_camp",
    source_assets=[extract_dim_mkt_budget_target_camp],
    target_table="dim_mkt_budget_target_camp",
)


@asset(group_name="dim_user_input")
def extract_dim_mkt_budget_target_offer() -> Output[pa.Table]:
    """
    Ingest dim_mkt_budget_target_offer from Web
    """
    df = pd.read_csv(
        r"https://docs.google.com/spreadsheets/d/e/2PACX-1vTsKC77L1DlOcUuta7bflrrRAusPQbOWSM0OggYBFEQ-sYrVBOqL_JRDJTWWX7w7caMEKWyOYE0xzqm/pub?gid=1332960078&single=true&output=csv",
        dtype=str,
    )
    df = _trim_all_columns(df)
    df.rename(
        columns={
            "OFFER": "offer",
            "LEAD TARGET": "lead_target",
            "SPL TARGET": "spl_target",
            r"% LEAD COST TARGET": "percentage_lead_cost_target",
            "FROM": "from_date",
            "TO": "to_date",
        },
        inplace=True,
    )
    df = _df_col_convert_to_float(df, "lead_target")
    df = _df_col_convert_to_float(df, "spl_target")
    df = _df_col_convert_to_float(df, "percentage_lead_cost_target", True)
    df["from_date"] = pd.to_datetime(df["from_date"], infer_datetime_format=True)
    df["to_date"] = pd.to_datetime(df["to_date"], infer_datetime_format=True)
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("offer", "string"),
                ("lead_target", "float32"),
                ("spl_target", "float32"),
                ("percentage_lead_cost_target", "float32"),
                ("from_date", "date32"),
                ("to_date", "date32"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


load_dim_mkt_budget_target_offer = create_load_to_postgres_asset(
    asset_name="load_dim_mkt_budget_target_offer",
    source_assets=[extract_dim_mkt_budget_target_offer],
    target_table="dim_mkt_budget_target_offer",
)
download_fin_sales_input = create_download_from_sharepoint_asset(
    asset_name="download_fin_sales_input",
    path_to_file="Finance Cost Input/dim_finance_sales_input.xlsx",
    link=r"https://neyucom.sharepoint.com/sites/DATANEYU/_layouts/15/Doc.aspx?sourcedoc=%7BB2658275-2920-4319-BB1B-83ED5E45F1DB%7D&file=dim_finance_sales_input.xlsx&action=default&mobileredirect=true",
)


@asset(
    group_name="dim_user_input",
    metadata={
        "Owner": "thuong.dinh@neyu.co",
    },
)
def extract_dim_sales_plan_figure(
    download_fin_sales_input: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(
        download_fin_sales_input,
        sheet_name="plan_figure",
        dtype={
            "country_code": str,
            "sales_camp": str,
            "offer": str,
            "partner": str,
            "daily_lead_plan": float,
            "ar_qa_plan": float,
            "aov_plan": float,
            "dr_plan": float,
            "month": int,
            "year": int,
            "gp_target": float,
        },
    )
    df = df.dropna(how="all")
    df["country_code"] = df["country_code"].str.upper()
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("country_code", "string"),
                ("sales_camp", "string"),
                ("offer", "string"),
                ("partner", "string"),
                ("daily_lead_plan", "float64"),
                ("ar_qa_plan", "float64"),
                ("aov_plan", "float64"),
                ("dr_plan", "float32"),
                ("month", "int32"),
                ("year", "int32"),
                ("gp_target", "float32"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


extract_dim_sales_plan_figure = add_blocking_checks_to_asset(
    extract_dim_sales_plan_figure,
    checks=[
        CheckDupDim("country_code,sales_camp,offer,partner,month,year"),
        CheckNullColumn(["country_code", "sales_camp", "offer", "partner"]),
    ],
)

load_dim_sales_plan_figure = create_load_to_postgres_asset(
    asset_name="load_dim_sales_plan_figure",
    source_assets=[extract_dim_sales_plan_figure],
    target_table="dim_sales_plan_figure",
)


@asset(
    group_name="dim_user_input",
    metadata={
        "Owner": "thuong.dinh@neyu.co",
    },
)
def extract_dim_sales_team_am(
    download_fin_sales_input: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(
        download_fin_sales_input,
        sheet_name="vn_sales_team",
        dtype={
            "or_team_name": str,
            "area_manager": str,
        },
    )
    df = df.dropna(how="all")
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("or_team_name", "string"),
                ("area_manager", "string"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


load_dim_sales_team_am = create_load_to_postgres_asset(
    asset_name="load_dim_sales_team_am",
    source_assets=[extract_dim_sales_team_am],
    target_table="dim_sales_team_am",
)

download_dr_forecast_mapping = create_download_from_sharepoint_asset(
    asset_name="download_dr_forecast_mapping",
    path_to_file="BD - Finance/DR_Forecast_mapping.xlsx",
    link=r"https://neyucom.sharepoint.com/:x:/r/sites/DATANEYU/_layouts/15/Doc.aspx?sourcedoc=%7B33366926-6A38-49D4-8B5E-D82DB1C69E52%7D&file=DR_Forecast_mapping.xlsx&action=default&mobileredirect=true&refreshcount=3",
)


@asset(
    group_name="dim_user_input",
    metadata={
        "Owner": "linh.nguyen@neyu.co",
    },
)
def extract_dim_sale_to_fin_camp(
    download_dr_forecast_mapping: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(
        download_dr_forecast_mapping,
        sheet_name="sale_camp to fin_camp",
    )
    df = df.dropna(how="all")
    df = df.drop_duplicates(subset=["country_code", "sale_camp"])
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("country_code", "string"),
                ("sale_camp", "string"),
                ("fin_camp", "string"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


load_dim_sale_to_fin_camp = create_load_to_postgres_asset(
    asset_name="load_dim_sale_to_fin_camp",
    source_assets=[extract_dim_sale_to_fin_camp],
    target_table="dim_sale_to_fin_camp",
)
# dim_vn_reason_mapping
download_vn_reason_mapping = create_download_from_sharepoint_asset(
    asset_name="download_vn_reason_mapping",
    path_to_file="[VN] - Logistics/VN_Log_Mapping.xlsx",
    link=r"https://neyucom.sharepoint.com/:x:/r/sites/DATANEYU/_layouts/15/Doc.aspx?sourcedoc=%7BA9F606B4-1096-4591-8136-02B5608125DA%7D&file=VN_Log_Mapping.xlsx&action=default&mobileredirect=true&refreshcount=3",
)


@asset(
    group_name="dim_user_input",
    metadata={
        "Owner": "tien.nguyen.3@kiwi-eco.com",
    },
)
def extract_dim_vn_reason_mapping(
    download_vn_reason_mapping: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(
        download_vn_reason_mapping,
        sheet_name="Mapping reason",
    )
    df["country_code"] = "VN"
    df = df.dropna(how="all")
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("country_code", "string"),
                ("type", "string"),
                ("system_status", "string"),
                ("pbi_status", "string"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


load_dim_vn_reason_mapping = create_load_to_postgres_asset(
    asset_name="load_dim_vn_reason_mapping",
    source_assets=[extract_dim_vn_reason_mapping],
    target_table="dim_vn_reason_mapping",
)


download_dim_bd_team_level_input = create_download_from_sharepoint_asset(
    asset_name="download_dim_bd_team_level_input",
    path_to_file="BD - Finance/BD_INPUT/bd_team_level_input.xlsx",
    link=r"https://neyucom.sharepoint.com/:x:/r/sites/DATANEYU/_layouts/15/Doc.aspx?sourcedoc=%7B6e16d33a-d8a0-4cea-9b63-2b6640f2b2bc%7D&action=editnew",
)


@asset(
    group_name="dim_user_input",
    metadata={
        "Owner": "jane@neyu.co",
    },
)
def extract_dim_bd_team_level_input(
    download_dim_bd_team_level_input: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(
        download_dim_bd_team_level_input,
        sheet_name="bd_level",
    )
    df = df.dropna(how="all")
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("bd_level_1", "string"),
                ("bd_level_2", "string"),
                ("bd_level_3", "string"),
                ("head_level", "string"),
                ("manager", "string"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


extract_dim_bd_team_level_input = add_blocking_checks_to_asset(
    extract_dim_bd_team_level_input,
    checks=[
        CheckDupDim("bd_level_1,bd_level_2,bd_level_3,head_level,manager"),
        CheckNullColumn(),
    ],
)

load_dim_bd_team_level_input = create_load_to_postgres_asset(
    asset_name="load_dim_bd_team_level_input",
    source_assets=[extract_dim_bd_team_level_input],
    target_table="dim_bd_team_level_input",
)


@asset(
    group_name="dim_user_input",
    metadata={
        "Owner": "jane@neyu.co",
    },
)
def extract_dim_bd_hot_lead(
    download_dim_bd_team_level_input: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(
        download_dim_bd_team_level_input,
        sheet_name="hot_lead",
    )
    df = df.dropna(how="all")
    df["new_partner"] = df["new_partner"].astype(str)
    # df["first_approved_date"] = pd.to_datetime(
    #     df["first_approved_date"], infer_datetime_format=True
    # )
    df["first_approved_date"] = pd.to_datetime(
        df["first_approved_date"], format="%d/%m/%Y"
    )
    df["activate_date"] = pd.to_datetime(df["activate_date"], format="%d/%m/%Y")
    df["last_hot_day"] = pd.to_datetime(df["last_hot_day"], format="%d/%m/%Y")
    df["first_approve_date"] = pd.to_datetime(
        df["first_approve_date"], format="%d/%m/%Y"
    )
    # df["activate_date"] = pd.to_datetime(
    #     df["activate_date"], infer_datetime_format=True
    # )
    # df["last_hot_day"] = pd.to_datetime(df["last_hot_day"], infer_datetime_format=True)
    # df["test"] = pd.to_datetime(df["test"], format="%d/%m/%Y")
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("manager", "string"),
                ("new_partner", "string"),
                ("first_approved_date", "date32"),
                ("activate_date", "date32"),
                ("last_hot_day", "date32"),
                ("email_sent", "string"),
                ("first_approve_date", "date32"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


extract_dim_bd_hot_lead = add_blocking_checks_to_asset(
    extract_dim_bd_hot_lead,
    checks=[
        CheckDupDim("manager,new_partner"),
        CheckNullColumn(
            [
                "manager",
                "new_partner",
                "first_approved_date",
                "activate_date",
                "last_hot_day",
            ]
        ),
    ],
)

load_dim_bd_hot_lead = create_load_to_postgres_asset(
    asset_name="load_dim_bd_hot_lead",
    source_assets=[extract_dim_bd_hot_lead],
    target_table="dim_bd_hot_lead",
)


@asset(
    group_name="dim_user_input",
    metadata={
        "Owner": "jane@neyu.co",
    },
)
def extract_dim_bd_email(
    download_dim_bd_team_level_input: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(
        download_dim_bd_team_level_input,
        sheet_name="bd_email",
    )
    df = df.dropna(how="all")
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("manager", "string"),
                ("bd_email", "string"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


extract_dim_bd_email = add_blocking_checks_to_asset(
    extract_dim_bd_email,
    checks=[
        CheckDupDim("manager,bd_email"),
        CheckNullColumn(),
    ],
)

load_dim_bd_email = create_load_to_postgres_asset(
    asset_name="load_dim_bd_email",
    source_assets=[extract_dim_bd_email],
    target_table="dim_bd_team_email_mapping",
)


@asset(
    group_name="dim_user_input",
    metadata={
        "Owner": "jane@neyu.co",
    },
)
def extract_dim_junior_bd_target(
    download_dim_bd_team_level_input: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(
        download_dim_bd_team_level_input,
        sheet_name="junior_bd_target",
        dtype={
            "bd": str,
            "lead_target": float,
            "ar_target": float,
            "approved_lead_target": float,
            "month": int,
            "year": int,
            "aff_rev_target": float,
        },
    )
    df = df.dropna(how="all")
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("bd", "string"),
                ("lead_target", "float64"),
                ("ar_target", "float64"),
                ("approved_lead_target", "float64"),
                ("month", "int32"),
                ("year", "int32"),
                ("aff_rev_target", "float64"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


extract_dim_junior_bd_target = add_blocking_checks_to_asset(
    extract_dim_junior_bd_target,
    checks=[
        CheckDupDim("bd,month,year"),
        CheckNullColumn(),
    ],
)

load_dim_junior_bd_target = create_load_to_postgres_asset(
    asset_name="load_dim_junior_bd_target",
    source_assets=[extract_dim_junior_bd_target],
    target_table="dim_junior_bd_target",
)


#
# class BD_RLS(Config):
#     sql_query: str = "select * from dim_bd_team_level_input"  ##


# # load_dim_bd_team_level_input =


# @asset(
#     group_name="dim_user_input",
#     metadata={
#         "Owner": "khue.le@neyu.co",
#     },
# )
# def extract_dim_bd_team_level_input_rls(
#     oltp01_conn: PostgresConnection, config: BD_RLS
# ) -> Output[pa.Table]:
#     df = extract_from_dwh(config.sql_query, oltp01_conn, return_type="pandas")
#     df = df.dropna(how="all")
#     df["bd_level_1"] = df["bd_level_1"].astype(str)
#     df["bd_level_2"] = df["bd_level_2"].astype(str)
#     df["bd_level_3"] = df["bd_level_3"].astype(str)
#     df["head_level"] = df["head_level"].astype(str)

#     # Dictionary to store managers and their subordinates
#     def transform_dim_bd_team_level_input():
#         managers_dict = {}
#         for index, row in df.iterrows():
#             head = row["head_level"]
#             manager_2 = row["bd_level_2"]
#             manager_3 = row["bd_level_3"]
#             bd_level_1 = row["bd_level_1"]

#             if manager_2 not in managers_dict:
#                 managers_dict[manager_2] = []
#             managers_dict[manager_2].append(bd_level_1)

#             if manager_3 not in managers_dict:
#                 managers_dict[manager_3] = []
#             managers_dict[manager_3].append(bd_level_1)

#             if head not in managers_dict:
#                 managers_dict[head] = []
#             managers_dict[head].append(bd_level_1)

#             if bd_level_1 not in managers_dict:
#                 managers_dict[bd_level_1] = []
#             managers_dict[bd_level_1].append(bd_level_1)

#         return managers_dict

#     # Function to generate manager-subordinates relationships DataFrame
#     def generate_manager_subordinates(manager):
#         managers_dict = transform_dim_bd_team_level_input()
#         subordinates = managers_dict.get(manager, [])
#         data = [
#             {"manager": manager, "subordinates": subordinate}
#             for subordinate in subordinates
#         ]
#         return pd.DataFrame(data)

#     # Generate the Manager-Subordinates DataFrame
#     def load_manager_subordinates():
#         managers_dict = transform_dim_bd_team_level_input()
#         result_df = pd.concat(
#             [
#                 generate_manager_subordinates(manager)
#                 for manager in managers_dict.keys()
#             ],
#             ignore_index=True,
#         )
#         # result_df = result_df.drop_duplicates()

#         return result_df

#     final_df = load_manager_subordinates()

#     data = pa.Table.from_pandas(
#         final_df,
#         pa.schema(
#             [
#                 ("manager", "string"),
#                 ("subordinates", "string"),
#             ]
#         ),
#     )

#     return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


# extract_dim_bd_team_level_input_rls = add_blocking_checks_to_asset(
#     extract_dim_bd_team_level_input_rls,
#     checks=[
#         CheckDupDim("manager,subordinates"),
#         CheckNullColumn(),
#     ],
# )

# load_dim_bd_team_level_input_rls = create_load_to_postgres_asset(
#     asset_name="load_dim_bd_team_level_input_rls",
#     source_assets=[extract_dim_bd_team_level_input_rls],
#     target_table="dim_bd_team_level_input_rls",
# )
# KPI tracking input

### lead cost target geo

download_dim_kpi_tracking_lead_cost_target = create_download_from_sharepoint_asset(
    asset_name="download_dim_kpi_tracking_lead_cost_target",
    path_to_file="BD - Finance/kpi_tracking_input.xlsx",
    link=r"https://neyucom.sharepoint.com/:x:/r/sites/DATANEYU/_layouts/15/Doc.aspx?sourcedoc=%7B6B110B81-EF73-420D-B7E5-8202FA006B96%7D&file=kpi_tracking_input.xlsx&action=default&mobileredirect=true",
)


@asset(
    group_name="dim_user_input",
    metadata={
        "Owner": "hai.nguyen@neyu.co",
    },
)
def extract_dim_kpi_tracking_lead_cost_target(
    download_dim_kpi_tracking_lead_cost_target: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(
        download_dim_kpi_tracking_lead_cost_target,
        sheet_name="lead_cost_target_geo",
        dtype={
            "geo": str,
            "lc_tg": float,
            "from": str,
            "to": str,
        },
    )
    df = df.dropna(how="all")
    df["from"] = pd.to_datetime(df["from"], infer_datetime_format=True)
    df["to"] = pd.to_datetime(df["to"], infer_datetime_format=True)
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("geo", "string"),
                ("lc_tg", "float32"),
                ("from", "date32"),
                ("to", "date32"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


extract_dim_kpi_tracking_lead_cost_target = add_blocking_checks_to_asset(
    extract_dim_kpi_tracking_lead_cost_target,
    checks=[
        CheckDupDateRange(
            from_date_col='"from"',
            to_date_col='"to"',
            partitions="geo",
        ),
    ],
)


load_dim_kpi_tracking_lead_cost_target = create_load_to_postgres_asset(
    asset_name="load_dim_kpi_tracking_lead_cost_target",
    source_assets=[extract_dim_kpi_tracking_lead_cost_target],
    target_table="dim_kpi_tracking_lead_cost_target",
)

### comm percentage

download_dim_kpi_tracking_comm_percentage = create_download_from_sharepoint_asset(
    asset_name="download_dim_kpi_tracking_comm_percentage",
    path_to_file="BD - Finance/kpi_tracking_input.xlsx",
    link=r"https://neyucom.sharepoint.com/:x:/r/sites/DATANEYU/_layouts/15/Doc.aspx?sourcedoc=%7B6B110B81-EF73-420D-B7E5-8202FA006B96%7D&file=kpi_tracking_input.xlsx&action=default&mobileredirect=true",
)


@asset(
    group_name="dim_user_input",
    metadata={
        "Owner": "hai.nguyen@neyu.co",
    },
)
def extract_dim_kpi_tracking_comm_percentage(
    download_dim_kpi_tracking_comm_percentage: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(
        download_dim_kpi_tracking_comm_percentage,
        sheet_name="com_percentage",
        dtype={
            "geo": str,
            "lc_from": float,
            "lc_to": float,
            "comm_po_bd": float,
            "comm_po_head": float,
            "comm_po_hot_lead": float,
            "from": str,
            "to": str,
        },
    )
    df = df.dropna(how="all")
    df["from"] = pd.to_datetime(df["from"], infer_datetime_format=True)
    df["to"] = pd.to_datetime(df["to"], infer_datetime_format=True)
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("geo", "string"),
                ("lc_from", "float32"),
                ("lc_to", "float32"),
                ("comm_po_bd", "float32"),
                ("comm_po_head", "float32"),
                ("comm_po_hot_lead", "float32"),
                ("from", "date32"),
                ("to", "date32"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


extract_dim_kpi_tracking_comm_percentage = add_blocking_checks_to_asset(
    extract_dim_kpi_tracking_comm_percentage,
    checks=[
        CheckDupDateRange(
            from_date_col='"from"',
            to_date_col='"to"',
            partitions="geo,lc_from,lc_to",
        ),
    ],
)

load_dim_kpi_tracking_comm_percentage = create_load_to_postgres_asset(
    asset_name="load_dim_kpi_tracking_comm_percentage",
    source_assets=[extract_dim_kpi_tracking_comm_percentage],
    target_table="dim_kpi_tracking_comm_percentage",
)


## ##
download_dim_agent_mrp = create_download_from_sharepoint_asset(
    asset_name="download_dim_agent_mrp",
    path_to_file="Sale/agent_mrp.xlsx",
    link=r"https://neyucom.sharepoint.com/:x:/r/sites/DATANEYU/_layouts/15/Doc.aspx?sourcedoc=%7BED4DF01F-FD1F-4374-894D-C154F3F83816%7D&file=agent_mrp.xlsx&action=default&mobileredirect=true",
)


@asset(
    group_name="dim_user_input",
    metadata={
        "Owner": "hai.nguyen@neyu.co",
    },
)
def extract_dim_agent_mrp_rpl(
    download_dim_agent_mrp: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(
        download_dim_agent_mrp,
        sheet_name="dim_agent_armrp_rpl",
        dtype={
            "geo": str,
            "camp": str,
            "armrp": float,
            "rpl": float,
            "max_cap": int,
            "optimum_cap": int,
            "from": str,
            "to": str,
        },
    )
    df = df.dropna(how="all")
    df["from"] = pd.to_datetime(df["from"], infer_datetime_format=True)
    df["to"] = pd.to_datetime(df["to"], infer_datetime_format=True)
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("geo", "string"),
                ("camp", "string"),
                ("armrp", "float32"),
                ("rpl", "float32"),
                ("max_cap", "int32"),
                ("optimum_cap", "int32"),
                ("from", "date32"),
                ("to", "date32"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


extract_dim_agent_mrp_rpl = add_blocking_checks_to_asset(
    extract_dim_agent_mrp_rpl,
    checks=[
        CheckDupDateRange(
            from_date_col='"from"',
            to_date_col='"to"',
            partitions="geo,camp",
        ),
    ],
)


load_dim_agent_mrp_rpl = create_load_to_postgres_asset(
    asset_name="load_dim_agent_mrp_rpl",
    source_assets=[extract_dim_agent_mrp_rpl],
    target_table="dim_agent_mrp_rpl",
)

#####

## ##
download_dim_mb_input = create_download_from_sharepoint_asset(
    asset_name="download_dim_mb_target_input",
    path_to_file="BD - Finance/BD_INPUT/mb_input.xlsx",
    link=r"https://neyucom.sharepoint.com/sites/DATANEYU/_layouts/15/Doc.aspx?sourcedoc=%7B9ACB9733-1502-4E0C-BA7E-3664A1CA253E%7D&file=mb_input.xlsx&action=default&mobileredirect=true",
)


@asset(
    group_name="dim_user_input",
    metadata={
        "Owner": "hai.nguyen@neyu.co",
    },
)
def extract_dim_mb_target_input(
    download_dim_mb_target_input: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(
        download_dim_mb_target_input,
        sheet_name="target",
        dtype={
            "pub": str,
            "lead": float,
            "ar_qa": float,
            "po": float,
            "traffic_cost": float,
            "salary": float,
            "tool": float,
            "roi": float,
            "from": str,
            "to": str,
        },
    )
    df = df.dropna(how="all")
    df["from"] = pd.to_datetime(df["from"], infer_datetime_format=True)
    df["to"] = pd.to_datetime(df["to"], infer_datetime_format=True)
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("pub", "string"),
                ("lead", "float32"),
                ("ar_qa", "float32"),
                ("po", "float32"),
                ("traffic_cost", "float32"),
                ("salary", "float32"),
                ("tool", "float32"),
                ("roi", "float32"),
                ("from", "date32"),
                ("to", "date32"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


extract_dim_mb_target_input = add_blocking_checks_to_asset(
    extract_dim_mb_target_input,
    checks=[
        CheckDupDateRange(
            from_date_col='"from"',
            to_date_col='"to"',
            partitions="pub",
        ),
    ],
)


load_dim_mb_target_input = create_load_to_postgres_asset(
    asset_name="load_dim_mb_target_input",
    source_assets=[extract_dim_mb_target_input],
    target_table="dim_mb_target_input",
)
#####

download_dim_product_input = create_download_from_sharepoint_asset(
    asset_name="download_dim_product_mapping_sale_vn",
    path_to_file="Data team/Data Source - SALES/dim_product_mapping_sale_vn.xlsx",
    link=r"https://neyucom.sharepoint.com/sites/DATANEYU/_layouts/15/Doc.aspx?sourcedoc=%7B3B227325-6DBB-40CC-8F6A-00C2F047A9EB%7D&file=dim_product_mapping_sale_vn.xlsx&action=default&mobileredirect=true",
)

@asset(
    group_name="dim_user_input",
    metadata={
        "Owner": "sale.vn@neyu.co",
    },
)
def extract_dim_product_mapping_sale_vn(
    download_dim_product_mapping_sale_vn: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(
        download_dim_product_mapping_sale_vn,
        sheet_name="product_name",
        dtype={
            "raw_product_name": str,
            "product_name": str,
        },
    )
    df = df.dropna(how="all")
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("raw_product_name", "string"),
                ("product_name", "string"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


extract_dim_product_mapping_sale_vn = add_blocking_checks_to_asset(
    extract_dim_product_mapping_sale_vn,
    checks=[
        CheckDupDim(
            "raw_product_name"
        )
    ],
)


load_dim_product_mapping_sale_vn = create_load_to_postgres_asset(
    asset_name="load_dim_product_mapping_sale_vn",
    source_assets=[extract_dim_product_mapping_sale_vn],
    target_table="dim_product_mapping_sale_vn",
)

#####

download_dim_bod_target_input = create_download_from_sharepoint_asset(
    asset_name="download_dim_bod_target_input",
    path_to_file="BD - Finance/BOD Summary Report Target.xlsx",
    link=r"https://neyucom.sharepoint.com/:x:/s/DATANEYU/ETTyXY-sxDlEqWJGLWzS_o4Bk6VhuJ46gWO2mUPzXXfzOA?e=5MXayv",
)

@asset(
    group_name="dim_user_input",
    metadata={
        "Owner": "daniel.ha@neyu.co",
    },
)
def extract_dim_bod_target_input(
    download_dim_bod_target_input: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(
        download_dim_bod_target_input,   									
        sheet_name="target",
        dtype={
            "year_month": str,
            "country_code": str,
            "daily_lead_target": float,
            "validated_revenue_target_fresh": float,
            "validated_revenue_target_cit": float,
            "delivered_revenue_target_fresh": float,
            "delivered_revenue_target_cit": float,
            "aov_target": float,
            "lc_percentage_target": float,
            "dr_target": float,
        },
    )
    df = df.dropna(how="all")
    df["year_month"] = pd.to_datetime(df["year_month"], infer_datetime_format=True)
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("year_month", "date32"),
                ("country_code", "string"),
                ("daily_lead_target", "float32"),
                ("validated_revenue_target_fresh", "float32"),
                ("validated_revenue_target_cit", "float32"),
                ("delivered_revenue_target_fresh", "float32"),
                ("delivered_revenue_target_cit", "float32"),
                ("aov_target", "float32"),
                ("lc_percentage_target", "float32"),
                ("dr_target", "float32"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


extract_dim_bod_target_input = add_blocking_checks_to_asset(
    extract_dim_bod_target_input,
    checks=[
        CheckDupDim(
            "year_month,country_code"
        )
    ],
)


load_dim_bod_target_input = create_load_to_postgres_asset(
    asset_name="load_dim_bod_target_input",
    source_assets=[extract_dim_bod_target_input],
    target_table="dim_bod_target_input",
)

#####

download_dim_gbs_tracking_target = create_download_from_sharepoint_asset(
    asset_name="download_dim_gbs_tracking_target",
    path_to_file="BD - Finance/gbs_tracking_target.xlsx",
    link=r"https://neyucom.sharepoint.com/:x:/r/sites/DATANEYU/_layouts/15/Doc.aspx?sourcedoc=%7B44F78032-B8C7-44F8-8222-303CB8DFDB18%7D&file=gbs_tracking_target.xlsx&action=default&mobileredirect=true",
)

@asset(
    group_name="dim_user_input",
    metadata={
        "Owner": "daniel.ha@neyu.co",
    },
)
def extract_dim_gbs_tracking_target(
    download_dim_gbs_tracking_target: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(
        download_dim_gbs_tracking_target,   									
        sheet_name="Sheet1",  					  	 		  			 																	
        dtype={
            "geo": str,
            "start_date": str,
            "end_date": str,
            "Daily lead": float,
            "AR MRP": float,
            "AR_QA": float,
            "E-AR": float,
            "Uncall": float,
            "Trash": float,
            "AOV": float,
            "lead_cost_percent": float,
            "Lead/agent": float,
            "Total Headcount": float,
            "agent_type_1": float,
            "agent_type_2": float,
            "agent_type_3": float,
            "agent_type_4": float,
            "headcount": float,
            "lead_usable": float,
            "talktime": float,
            "lead_per_agent": float,
            "attempt_call": float,
            "aov": float,
            "upsell": float,
            "rev/agent/day": float,
            "price_per_pcs": float,
            "dr_cit": float,
            "net_aov": float,
            "net_price_per_pcs": float,
            "ar": float,
            "validated revenue": float,
            "lead_time": float,
            "so/ar": float,
            "so/cs": float,
            "dr_fresh": float,
            "dr_resell": float
        },
    )
    df = df.dropna(how="all")
    df["start_date"] = pd.to_datetime(df["start_date"], infer_datetime_format=True)
    df["end_date"] = pd.to_datetime(df["end_date"], infer_datetime_format=True)
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("geo", "string"),
                ("start_date", "date32"),
                ("end_date", "date32"),
                ("Daily lead", "float32"),
                ("AR MRP", "float32"),
                ("AR_QA", "float32"),
                ("E-AR", "float32"),
                ("Uncall", "float32"),
                ("Trash", "float32"),
                ("AOV", "float32"),
                ("lead_cost_percent", "float32"),
                ("Lead/agent", "float32"),
                ("Total Headcount", "float32"),
                ("agent_type_1", "float32"),
                ("agent_type_2", "float32"),
                ("agent_type_3", "float32"),
                ("agent_type_4", "float32"),
                ("headcount", "float32"),
                ("lead_usable", "float32"),
                ("talktime", "float32"),
                ("lead_per_agent", "float32"),
                ("attempt_call", "float32"),
                ("aov", "float32"),
                ("upsell", "float32"),
                ("rev/agent/day", "float32"),
                ("price_per_pcs", "float32"),
                ("dr_cit", "float32"),
                ("net_aov", "float32"),
                ("net_price_per_pcs", "float32"),
                ("ar", "float32"),
                ("validated revenue", "float32"),
                ("lead_time", "float32"),
                ("so/ar", "float32"),
                ("so/cs", "float32"),
                ("dr_fresh", "float32"),
                ("dr_resell", "float32")
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


extract_dim_gbs_tracking_target = add_blocking_checks_to_asset(
    extract_dim_gbs_tracking_target,
    checks=[
        CheckDupDateRange(
            from_date_col='"start_date"',
            to_date_col='"end_date"',
            partitions="geo",
        ),
    ],
)


load_dim_gbs_tracking_target = create_load_to_postgres_asset(
    asset_name="load_dim_gbs_tracking_target",
    source_assets=[extract_dim_gbs_tracking_target],
    target_table="dim_gbs_tracking_target",
)

#####
download_dim_sale_input = create_download_from_sharepoint_asset(
    asset_name="download_dim_mb_sal_input",
    path_to_file="BD - Finance/BD_INPUT/mb_input.xlsx",
    link=r"https://neyucom.sharepoint.com/sites/DATANEYU/_layouts/15/Doc.aspx?sourcedoc=%7B9ACB9733-1502-4E0C-BA7E-3664A1CA253E%7D&file=mb_input.xlsx&action=default&mobileredirect=true",
)


@asset(
    group_name="dim_user_input",
    metadata={
        "Owner": "hai.nguyen@neyu.co",
    },
)
def extract_dim_mb_sal_input(
    download_dim_mb_sal_input: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(
        download_dim_mb_sal_input,
        sheet_name="sal_tool_input",
        dtype={
            "pub": str,
            "salary": float,
            "tool": float,
            "from": str,
            "to": str,
        },
    )
    df = df.dropna(how="all")
    df["from"] = pd.to_datetime(df["from"], infer_datetime_format=True)
    df["to"] = pd.to_datetime(df["to"], infer_datetime_format=True)
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("pub", "string"),
                ("salary", "float32"),
                ("tool", "float32"),
                ("from", "date32"),
                ("to", "date32"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


extract_dim_mb_sal_input = add_blocking_checks_to_asset(
    extract_dim_mb_sal_input,
    checks=[
        CheckDupDateRange(
            from_date_col='"from"',
            to_date_col='"to"',
            partitions="pub",
        ),
    ],
)


load_dim_mb_sal_input = create_load_to_postgres_asset(
    asset_name="load_dim_mb_sal_input",
    source_assets=[extract_dim_mb_sal_input],
    target_table="dim_mb_sal_input",
)

#####


@asset(
    group_name="dim_user_input",
    metadata={
        "Owner": "hai.nguyen@neyu.co",
    },
)
def extract_dim_agent_dr_aov_mrp(
    download_dim_agent_mrp: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(
        download_dim_agent_mrp,
        sheet_name="dim_agent_dr_aov_mrp",
        dtype={
            "geo": str,
            "camp": str,
            "dr_mrp": float,
            "aov_mrp": float,
            "from": str,
            "to": str,
        },
    )
    df = df.dropna(how="all")
    df["from"] = pd.to_datetime(df["from"], infer_datetime_format=True)
    df["to"] = pd.to_datetime(df["to"], infer_datetime_format=True)
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("geo", "string"),
                ("camp", "string"),
                ("dr_mrp", "float32"),
                ("aov_mrp", "float32"),
                ("from", "date32"),
                ("to", "date32"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


extract_dim_agent_dr_aov_mrp = add_blocking_checks_to_asset(
    extract_dim_agent_dr_aov_mrp,
    checks=[
        CheckDupDateRange(
            from_date_col='"from"',
            to_date_col='"to"',
            partitions="geo,camp",
        ),
    ],
)


load_dim_agent_dr_aov_mrp = create_load_to_postgres_asset(
    asset_name="load_dim_agent_dr_aov_mrp",
    source_assets=[extract_dim_agent_dr_aov_mrp],
    target_table="dim_agent_dr_aov_mrp",
)


## #
download_bd_fin_dr_forecast_mapping = create_download_from_sharepoint_asset(
    asset_name="download_bd_fin_dr_forecast_mapping",
    path_to_file="BD - Finance/DR_Forecast_mapping.xlsx",
    link=r"https://neyucom.sharepoint.com/:x:/r/sites/DATANEYU/_layouts/15/Doc.aspx?sourcedoc=%7B33366926-6A38-49D4-8B5E-D82DB1C69E52%7D&file=DR_Forecast_mapping.xlsx&action=default&mobileredirect=true",
)


@asset(group_name="dim_user_input", metadata={"Owner": "linh.nguyen@neyu.co"})
def extract_dim_dr_manual_forecast(
    download_bd_fin_dr_forecast_mapping: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(
        download_bd_fin_dr_forecast_mapping,
        sheet_name="dr_forecast_manual",
        dtype={
            "country_code": str,
            "network": str,
            "offer": str,
            "dr_forecast": float,
            "from": str,
            "to": str,
        },
    )
    df = df.dropna(how="all")
    df["from"] = pd.to_datetime(df["from"], infer_datetime_format=True)
    df["to"] = pd.to_datetime(df["to"], infer_datetime_format=True)
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("country_code", "string"),
                ("network", "string"),
                ("offer", "string"),
                ("dr_forecast", "float32"),
                ("from", "date32"),
                ("to", "date32"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


extract_dim_dr_manual_forecast = add_blocking_checks_to_asset(
    extract_dim_dr_manual_forecast,
    checks=[
        CheckDupDateRange(
            from_date_col='"from"',
            to_date_col='"to"',
            partitions="country_code,network,offer",
        ),
    ],
)

load_dim_dr_manual_forecast = create_load_to_postgres_asset(
    asset_name="load_dim_dr_manual_forecast",
    source_assets=[extract_dim_dr_manual_forecast],
    target_table="dim_dr_manual_forecast",
)
### FPB DRFC input Fresh 
@asset(group_name="dim_user_input", metadata={"Owner": "linh.nguyen@neyu.co"})
def extract_dim_fpb_fresh_dr_manual_forecast(
    download_bd_fin_dr_forecast_mapping: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(
        download_bd_fin_dr_forecast_mapping,
        sheet_name="fpa_dr_forecast_manual_fresh",
        dtype={
            "country_code": str,
            "network": str,
            "offer": str,
            "dr_forecast": float,
            "from": str,
            "to": str,
        },
    )
    df = df.dropna(how="all")
    df["from"] = pd.to_datetime(df["from"], infer_datetime_format=True)
    df["to"] = pd.to_datetime(df["to"], infer_datetime_format=True)
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("country_code", "string"),
                ("network", "string"),
                ("offer", "string"),
                ("dr_forecast", "float32"),
                ("from", "date32"),
                ("to", "date32"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


extract_dim_fpb_fresh_dr_manual_forecast = add_blocking_checks_to_asset(
    extract_dim_fpb_fresh_dr_manual_forecast,
    checks=[
        CheckDupDateRange(
            from_date_col='"from"',
            to_date_col='"to"',
            partitions="country_code,network,offer",
        ),
    ],
)

load_dim_fpb_fresh_dr_manual_forecast = create_load_to_postgres_asset(
    asset_name="load_dim_fpb_fresh_dr_manual_forecast",
    source_assets=[extract_dim_fpb_fresh_dr_manual_forecast],
    target_table="dim_fpb_fresh_dr_manual_forecast",
)


### FPB DRFC input Resell  
@asset(group_name="dim_user_input", metadata={"Owner": "linh.nguyen@neyu.co"})
def extract_dim_fpb_resell_dr_manual_forecast(
    download_bd_fin_dr_forecast_mapping: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(
        download_bd_fin_dr_forecast_mapping,
        sheet_name="fpa_dr_forecast_manual_resell",
        dtype={
            "country_code": str,
            "dr_forecast": float,
            "from": str,
            "to": str,
        },
    )
    df = df.dropna(how="all")
    df["from"] = pd.to_datetime(df["from"], infer_datetime_format=True)
    df["to"] = pd.to_datetime(df["to"], infer_datetime_format=True)
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("country_code", "string"),
                ("dr_forecast", "float32"),
                ("from", "date32"),
                ("to", "date32"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


extract_dim_fpb_resell_dr_manual_forecast = add_blocking_checks_to_asset(
    extract_dim_fpb_resell_dr_manual_forecast,
    checks=[
        CheckDupDateRange(
            from_date_col='"from"',
            to_date_col='"to"',
            partitions="country_code",
        ),
    ],
)

load_dim_fpb_resell_dr_manual_forecast = create_load_to_postgres_asset(
    asset_name="load_dim_fpb_resell_dr_manual_forecast",
    source_assets=[extract_dim_fpb_resell_dr_manual_forecast],
    target_table="dim_fpb_resell_dr_manual_forecast",
)


###
## cit performance input
download_cit_finance_mapping = create_download_from_sharepoint_asset(
    asset_name="download_cit_finance_mapping",
    path_to_file="BD - Finance/CIT_public_holiday.xlsx",
    link=r"https://neyucom.sharepoint.com/:x:/r/sites/DATANEYU/_layouts/15/Doc.aspx?sourcedoc=%7BE4105642-6754-49AD-8B70-25597BE41C15%7D&file=CIT_public_holiday.xlsx&action=default&mobileredirect=true",
)


@asset(group_name="dim_user_input", metadata={"Owner": "daniel.ha@neyu.co"})
def extract_dim_cit_performance(
    download_cit_finance_mapping: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(
        download_cit_finance_mapping,
        sheet_name="public_holiday",
        dtype={"geo": str, "public_holiday": str},
    )
    df = df.dropna(how="all")
    df["public_holiday"] = pd.to_datetime(
        df["public_holiday"], infer_datetime_format=True
    )
    data = pa.Table.from_pandas(
        df,
        pa.schema([("geo", "string"), ("public_holiday", "date32")]),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


extract_dim_cit_performance = add_blocking_checks_to_asset(
    extract_dim_cit_performance,
    checks=[],
)

load_dim_cit_performance = create_load_to_postgres_asset(
    asset_name="load_dim_cit_performance",
    source_assets=[extract_dim_cit_performance],
    target_table="dim_cit_performance",
)

## Contribution tracking holiday
download_contribution_tracking_holiday = create_download_from_sharepoint_asset(
    asset_name="download_contribution_tracking_holiday",
    path_to_file="BD - Finance/Contribution tracking target.xlsx",
    link=r"https://neyucom.sharepoint.com/:x:/r/sites/DATANEYU/_layouts/15/Doc.aspx?sourcedoc=%7BA134F7B0-B5C9-4A15-9C18-FD831AFF413D%7D&file=Contribution%20tracking%20target.xlsx&action=default&mobileredirect=true",
)


@asset(group_name="dim_user_input", metadata={"Owner": "daniel.ha@neyu.co"})
def extract_dim_contribution_tracking_holiday(
    download_contribution_tracking_holiday: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(
        download_contribution_tracking_holiday,
        sheet_name="public_holiday",
        dtype={"geo": str, "public_holiday": str},
    )
    df = df.dropna(how="all")
    df["public_holiday"] = pd.to_datetime(
        df["public_holiday"], infer_datetime_format=True
    )
    data = pa.Table.from_pandas(
        df,
        pa.schema([("geo", "string"), ("public_holiday", "date32")]),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


extract_dim_contribution_tracking_holiday = add_blocking_checks_to_asset(
    extract_dim_contribution_tracking_holiday,
    checks=[],
)

load_dim_contribution_tracking_holiday = create_load_to_postgres_asset(
    asset_name="load_dim_contribution_tracking_holiday",
    source_assets=[extract_dim_contribution_tracking_holiday],
    target_table="dim_contribution_tracking_holiday",
)

## Contribution tracking target
download_contribution_tracking_target = create_download_from_sharepoint_asset(
    asset_name="download_contribution_tracking_target",
    path_to_file="BD - Finance/Contribution tracking target.xlsx",
    link=r"https://neyucom.sharepoint.com/:x:/r/sites/DATANEYU/_layouts/15/Doc.aspx?sourcedoc=%7BA134F7B0-B5C9-4A15-9C18-FD831AFF413D%7D&file=Contribution%20tracking%20target.xlsx&action=default&mobileredirect=true",
)


@asset(group_name="dim_user_input", metadata={"Owner": "daniel.ha@neyu.co"})
def extract_dim_contribution_tracking_target(
    download_contribution_tracking_target: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(
        download_contribution_tracking_target,
        sheet_name="Target",
        dtype={
            "type": str,
            "lead_year_month": str,
            "country_code": str,
            "daily_lead": str,
            "AR_QA_target": str,
            "AR_QC_target": str,
            "DR_target": str,
            "AOV_target": str,
            "Days_target": str,
            "VAT": str,
            "Revenue_target": str,
            "Marketing_target": str,
            "MKT_target": str,
            "Contribution_target": str,
            "Contribute_target": str,
        },
    )
    df = df.dropna(how="all")
    df["lead_year_month"] = pd.to_datetime(
        df["lead_year_month"], infer_datetime_format=True
    )
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("type", "string"),
                ("lead_year_month", "date32"),
                ("country_code", "string"),
                ("daily_lead", "string"),
                ("AR_QA_target", "string"),
                ("AR_QC_target", "string"),
                ("DR_target", "string"),
                ("AOV_target", "string"),
                ("Days_target", "string"),
                ("VAT", "string"),
                ("Revenue_target", "string"),
                ("Marketing_target", "string"),
                ("MKT_target", "string"),
                ("Contribution_target", "string"),
                ("Contribute_target", "string"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


extract_dim_contribution_tracking_target = add_blocking_checks_to_asset(
    extract_dim_contribution_tracking_target,
    checks=[],
)

load_dim_contribution_tracking_target = create_load_to_postgres_asset(
    asset_name="load_dim_contribution_tracking_target",
    source_assets=[extract_dim_contribution_tracking_target],
    target_table="dim_contribution_tracking_target",
)
#-------------------------------------------------------
# dim_lm_cost
download_ass_input_mapping = create_download_from_sharepoint_ass_input(
    asset_name="download_ass_input_mapping",
    path_to_file="Finance Cost Input/Assumption_Input.xlsx",
    link=r"https://neyucom.sharepoint.com/:x:/s/DATANEYU/ESFe1OtrStlLgUJK6L5uRRQBPvTrCQzGQ98CNlIpiw4uLA?e=VyvW7Z",
)


@asset(group_name="dim_user_input")
def extract_dim_lm_cost(
    download_ass_input_mapping: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(
        download_ass_input_mapping,
        sheet_name="LOG_LM",
        dtype=str,
    )
    df = df.dropna(how="all")
    df = df.rename(
        columns={
            "started_date": "started_date",
            "GEO": "geo",
            "LM/Order (Local Cur.)": "order_local_cur",
            "Rank": "rank",
            "ending_date": "ending_date",
            "Duplicate check": "duplicate_check",
        },
        errors="raise",
    )
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("started_date", "string"),
                ("geo", "string"),
                ("order_local_cur", "string"),
                ("rank", "string"),
                ("ending_date", "string"),
                ("duplicate_check", "string"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


load_dim_lm_cost = create_load_to_postgres_asset(
    asset_name="load_dim_lm_cost",
    source_assets=[extract_dim_lm_cost],
    target_table="dim_lm_cost",
)


# dim_ffm_cost
@asset(group_name="dim_user_input")
def extract_dim_ffm_cost(
    download_ass_input_mapping: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(
        download_ass_input_mapping,
        sheet_name="LOG_FFM",
        dtype=str,
    )
    df = df.dropna(how="all")
    df = df.rename(
        columns={
            "started_date": "started_date",
            "GEO": "geo",
            "FFM/Order (Local Cur.)": "order_local_cur",
            "FFM/Pcs (Local Cur.)": "pcs_local_cur",
            "Rank": "rank",
            "ending_date": "ending_date",
            "Duplicate check": "duplicate_check",
        },
        errors="raise",
    )
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("started_date", "string"),
                ("geo", "string"),
                ("order_local_cur", "string"),
                ("pcs_local_cur", "string"),
                ("rank", "string"),
                ("ending_date", "string"),
                ("duplicate_check", "string"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


load_dim_ffm_cost = create_load_to_postgres_asset(
    asset_name="load_dim_ffm_cost",
    source_assets=[extract_dim_ffm_cost],
    target_table="dim_ffm_cost",
)


# dim_log_cod
@asset(group_name="dim_user_input")
def extract_dim_log_cod(
    download_ass_input_mapping: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(
        download_ass_input_mapping,
        sheet_name="LOG_COD %",
        dtype=str,
    )
    df = df.dropna(how="all")
    df = df.rename(
        columns={
            "started_date": "started_date",
            "GEO": "geo",
            "COD %": "cod",
            "Rank": "rank",
            "ending_date": "ending_date",
            "Duplicate check": "duplicate_check",
        },
        errors="raise",
    )
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("started_date", "string"),
                ("geo", "string"),
                ("cod", "string"),
                ("rank", "string"),
                ("ending_date", "string"),
                ("duplicate_check", "string"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


load_dim_log_cod = create_load_to_postgres_asset(
    asset_name="load_dim_log_cod",
    source_assets=[extract_dim_log_cod],
    target_table="dim_log_cod",
)


# dim_log_rtn
@asset(group_name="dim_user_input")
def extract_dim_log_rtn(
    download_ass_input_mapping: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(
        download_ass_input_mapping,
        sheet_name="LOG_RTN %",
        dtype=str,
    )
    df = df.dropna(how="all")
    df = df.rename(
        columns={
            "started_date": "started_date",
            "GEO": "geo",
            "% RTN": "rtn",
            "Rank": "rank",
            "ending_date": "ending_date",
            "Duplicate check": "duplicate_check",
        },
        errors="raise",
    )
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("started_date", "string"),
                ("geo", "string"),
                ("rtn", "string"),
                ("rank", "string"),
                ("ending_date", "string"),
                ("duplicate_check", "string"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


load_dim_log_rtn = create_load_to_postgres_asset(
    asset_name="load_dim_log_rtn",
    source_assets=[extract_dim_log_rtn],
    target_table="dim_log_rtn",
)


# dim_tel_cost
@asset(group_name="dim_user_input")
def extract_dim_tel_cost(
    download_ass_input_mapping: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(
        download_ass_input_mapping,
        sheet_name="TEL",
        dtype=str,
    )
    df = df.dropna(how="all")
    df = df.rename(
        columns={
            "started_date": "started_date",
            "GEO": "geo",
            "TEL/order (Local Cur.)": "order_local_cur",
            "TEL/Lead (Local Cur.)": "lead_local_cur",
            "Rank": "rank",
            "ending_date": "ending_date",
            "Duplicate check": "duplicate_check",
        },
        errors="raise",
    )
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("started_date", "string"),
                ("geo", "string"),
                ("order_local_cur", "string"),
                ("lead_local_cur", "string"),
                ("rank", "string"),
                ("ending_date", "string"),
                ("duplicate_check", "string"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


load_dim_tel_cost = create_load_to_postgres_asset(
    asset_name="load_dim_tel_cost",
    source_assets=[extract_dim_tel_cost],
    target_table="dim_tel_cost",
)

# dim_commision_cost
@asset(group_name="dim_user_input")
def extract_dim_commision_cost(
    download_ass_input_mapping: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(
        download_ass_input_mapping,
        sheet_name="COM.BO | FO",
        dtype=str,
    )
    df = df.dropna(how="all")
    df = df.rename(
        columns={
            "started_date": "started_date",
            "GEO": "geo",
            "Fresh": "fresh",
            "Resell": "resell",
            "QA-QC": "qa_qc",
            "CS": "cs",
            "Logistics": "logistics",
            "Others": "others",
            "Rank": "rank",
            "ending_date": "ending_date",
            "Duplicate check": "duplicate_check",
        },
        errors="raise",
    )
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("started_date", "string"),
                ("geo", "string"),
                ("fresh", "string"),
                ("resell", "string"),
                ("qa_qc", "string"),
                ("cs", "string"),
                ("logistics", "string"),
                ("others", "string"),
                ("rank", "string"),
                ("ending_date", "string"),
                ("duplicate_check", "string"),
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})


load_dim_commision_cost = create_load_to_postgres_asset(
    asset_name="load_dim_commision_cost",
    source_assets=[extract_dim_commision_cost],
    target_table="dim_commision_cost",
)

#------------------------------------------------------------------------------------------------------------------
import functools
def disjunction(*conditions):
    return functools.reduce(np.logical_or, conditions)


#-------------------------------------------------------------------------------------
# not use this source anymore

# @asset(group_name="dim_user_input")
# def extract_approved_payout() -> Output[pa.Table]:
#     """
#     Ingest Mb Target from Web
#     """
#     df = pd.read_csv(
#         r"https://docs.google.com/spreadsheets/d/e/2PACX-1vS6xWu7MBKFfdIcSZuaYmVVvfgxnP6N5fV27ZFjnHpsIyPr9dltfguPcVkt0EdMKRExQwE_k_o8coFQ/pub?gid=1626919676&single=true&output=csv",
#         dtype=str,
#     )
#     df = df[df['Apply'].notna()]
#     df['Apply'] = df['Apply'].str.replace('.', '/')
#     df['Apply'] = df['Apply'].str.replace('//', '/')
#     df[['day', 'month', 'year', 'other']]  = df["Apply"].str.split(pat="/", expand=True)
#     c2 = df.year == '2024'
#     data_y= df[disjunction(c2)]
#     m2 = df.month == '05'
#     data_m= data_y[disjunction(m2)]
#     data = data_m[['alp','AM','Pub','Sub','Offer','GEO','PO','Act Max PO','Lead_MRP','End','Head approve','NOTE',	'day','month','year']]
#     data['date'] = data['month'] + '/' + data['day'].astype(str) + '/' + data['year']
#     data_df = data[['alp','AM','Pub','Sub','Offer','GEO','PO','Act Max PO','Lead_MRP','End','Head approve','NOTE','date']]
#     data_df['End'] = data_df['End'].str.replace('.', '/')
#     data_df['End'] = data_df['End'].str.replace('//', '/')
#     data_df[['day_end', 'month_end', 'year_end']]  = data_df["End"].str.split(pat="/", expand=True)
#     c2_end = data_df.year_end != '24'
#     data_end= data_df[disjunction(c2_end)]
#     data = data_end[['alp','AM','Pub','Sub','Offer','GEO','PO','Act Max PO','Lead_MRP','Head approve','NOTE','day_end','month_end','year_end', 'date']]
#     data['end'] = data['month_end'] + '/' + data['day_end'].astype(str) + '/' + data['year_end']
#     data_df = data[['AM','Pub','Sub','Offer','GEO','PO','Act Max PO','Lead_MRP','Head approve','NOTE','date', 'end']]
#     data_df = data_df.rename(
#         columns={
#             "AM": "am", 
#             "Pub": "pub",
#             "Sub": "sub",
#             "Offer": "offer",
#             "GEO": "geo",
#             "PO": "po",
#             "Act Max PO": "act_max_po",
#             "Lead_MRP": "lead_mrp",
#             "Head approve": "head_approve",
#             "NOTE": "note",
#             "date": "apply",
#             "end": "end"
#         },
#         errors="raise",
#     )
#     data_df['act_max_po'] = data_df['act_max_po'].str.replace(',', '.')
#     data_df['act_max_po'] = data_df['act_max_po'].str.replace('$', '')
#     data_df['apply'] = pd.to_datetime(data_df['apply'])
#     data_df['end'] = data_df['end'].fillna(datetime.today())
#     # create a dictionary of replacements
#     replacements = {'04/31/2024': '04/30/2024'}
#     # replace values using the .map() method
#     data_df['end'] = data_df['end'].map(replacements).fillna(data_df['end'])
#     data_df['end'] = pd.to_datetime(data_df['end'])
#     data_df['sub'] = data_df['sub'].astype('string')
#     data_df['am'] = data_df['am'].astype('string')
#     data_df['pub'] = data_df['pub'].astype('string')
#     data_df['offer'] = data_df['offer'].astype('string')
#     data_df['geo'] = data_df['geo'].astype('string')
#     data_df['head_approve'] = data_df['head_approve'].astype('string')
#     data_df['note'] = data_df['note'].astype('string')
#     data = data_df.astype({"po": float,
#                 "act_max_po": float,
#                 "lead_mrp": 'Int32'
#               })
#     data['am'] = data['am'].str.strip()
#     data['pub'] = data['pub'].str.strip()
#     data['sub'] = data['sub'].str.strip()
#     data['offer'] = data['offer'].str.strip()
#     data['geo'] = data['geo'].str.strip()
#     data['head_approve'] = data['head_approve'].str.strip()
#     data['note'] = data['note'].str.strip()
#     data_final = pa.Table.from_pandas(
#         data,
#         pa.schema(
#             [
#                 ("am", "string"),
#                 ("pub", "string"),
#                 ("sub", "string"),
#                 ("offer", "string"),
#                 ("geo", "string"),
#                 ("po", "float32"),
#                 ("act_max_po", "float32"),
#                 ("lead_mrp", "int32"),
#                 ("head_approve", "string"),
#                 ("note", "string"),
#                 ("apply", "date32"),
#                 ("end", "date32")
#             ]
#         ),
#     )
#     return Output(value=data_final, metadata={"Count": MetadataValue.int(data_final.num_rows)})


#load_approved_payout = create_load_to_postgres_asset(
#    asset_name="load_approved_payout",
#    source_assets=[extract_approved_payout],
#    target_table="dim_approved_payout",
#)
#--------------------------------------------------------------------------------------------------

download_Assumption_Input_mapping = create_download_from_sharepoint_asset(
    asset_name="download_Assumption_Input_mapping",
    path_to_file="Finance Cost Input/Assumption_Input.xlsx",
    link=r"https://neyucom.sharepoint.com/:x:/r/sites/DATANEYU/_layouts/15/doc2.aspx?sourcedoc=%7BEBD45E21-4A6B-4BD9-8142-4AE8BE6E4514%7D&file=Assumption_Input.xlsx&action=default&mobileredirect=true",
)

import pandas as pd
import pyarrow as pa
from dagster import asset, Output, MetadataValue

#--------------------------------------------------------------------------------------------------
# dim_fin_weekly_position
@asset(
    group_name="dim_user_input"
)
def extract_dim_fin_weekly_position(
    download_Assumption_Input_mapping: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(download_Assumption_Input_mapping, sheet_name="weekly_position")
    df.rename(
        columns={
            "country_code": "country_code",
            "position": "position",
            "date_applied": "date_applied",
            "fte_per_day": "fte_per_day",
            "cost_per_fte_per_day": "cost_per_fte_per_day",
            "fte_per_day_default":"fte_per_day_default"
        },
        inplace=True,
    )
    print(df)
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("country_code", "string"),
                ("position", "string"),
                ("date_applied", "date32"),
                ("fte_per_day", "float32"),
                ("cost_per_fte_per_day", "float32"),
                ("fte_per_day_default", "float32")
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})

extract_dim_fin_weekly_position = add_blocking_checks_to_asset(
    extract_dim_fin_weekly_position,
    checks=[
        CheckDupDim(
            "date_applied,position,country_code"
        )
    ],
)

load_dim_fin_weekly_position = create_load_to_postgres_asset(
    asset_name="load_dim_fin_weekly_position",
    source_assets=[extract_dim_fin_weekly_position],
    target_table="dim_fin_weekly_position",
)

#--------------------------------------------------------------------------------------------------
# dim_fin_weekly_country_fixed
@asset(
    group_name="dim_user_input"
)
def extract_dim_fin_weekly_country_fixed(
    download_Assumption_Input_mapping: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(download_Assumption_Input_mapping, sheet_name="weekly_country_fixed")
    df.rename(
        columns={
            "country_code": "country_code",
            "vat": "vat",
            "fct": "fct",
            "markup": "markup"
        },
        inplace=True,
    )
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("country_code", "string"),
                ("vat", "float32"),
                ("fct", "float32"),
                ("markup", "float32")
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})

extract_dim_fin_weekly_country_fixed = add_blocking_checks_to_asset(
    extract_dim_fin_weekly_country_fixed,
    checks=[
        CheckDupDim(
            "country_code"
        )
    ],
)

load_dim_fin_weekly_country_fixed = create_load_to_postgres_asset(
    asset_name="load_dim_fin_weekly_country_fixed",
    source_assets=[extract_dim_fin_weekly_country_fixed],
    target_table="dim_fin_weekly_country_fixed",
)

#--------------------------------------------------------------------------------------------------
# dim_fin_weekly_type
@asset(
    group_name="dim_user_input"
)
def extract_dim_fin_weekly_type(
    download_Assumption_Input_mapping: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(download_Assumption_Input_mapping, sheet_name="weekly_type")
    df.rename(
        columns={
            "country_code": "country_code",
            "start_date": "start_date",
            "end_date": "end_date",
            "commission_IBS-FIT": "commission_ibs_fit",
            "commission_IBS-HC": "commission_ibs_hc",
            "commission_IBS-ME": "commission_ibs_me",
            "commission_IBS-SL&BT": "commission_ibs_sl_bt",
            "commission_CIT": "commission_cit",
            "commission_IBS-SLIMMNING": "commission_ibs_slimming",
            "commission_IBS-WP": "commission_ibs_wp",
            "commission_IBS-OTHERS": "commission_ibs_others"
        },
        inplace=True,
    )
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("country_code", "string"),
                ("start_date", "date32"),
                ("end_date", "date32"),
                ("commission_ibs_fit", "float32"),
                ("commission_ibs_hc", "float32"),
                ("commission_ibs_me", "float32"),
                ("commission_ibs_sl_bt", "float32"),
                ("commission_cit", "float32"),
                ("commission_ibs_slimming", "float32"),
                ("commission_ibs_wp", "float32"),
                ("commission_ibs_others", "float32")
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})

extract_dim_fin_weekly_type = add_blocking_checks_to_asset(
    extract_dim_fin_weekly_type,
    checks=[
        CheckDupDateRange(
            from_date_col='"start_date"',
            to_date_col='"end_date"',
            partitions="country_code",
        ),
    ],
)

load_dim_fin_weekly_type = create_load_to_postgres_asset(
    asset_name="load_dim_fin_weekly_type",
    source_assets=[extract_dim_fin_weekly_type],
    target_table="dim_fin_weekly_type",
)

#--------------------------------------------------------------------------------------------------
# dim_fin_weekly_country_variable
@asset(
    group_name="dim_user_input"
)
def extract_dim_fin_weekly_country_variable(
    download_Assumption_Input_mapping: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(download_Assumption_Input_mapping, sheet_name="weekly_country_variable")
    df.rename(
        columns={
            "country_code": "country_code",
            "start_date": "start_date",
            "end_date": "end_date",
            "telecom_fee": "telecom_fee",
            "logistics_fee": "logistics_fee",
            "ga": "ga",
            "ss_smgt_cost": "ss_smgt_cost"
        },
        inplace=True,
    )
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("country_code", "string"),
                ("start_date", "date32"),
                ("end_date", "date32"),
                ("telecom_fee", "float32"),
                ("logistics_fee", "float32"),
                ("ga", "float32"),
                ("ss_smgt_cost", "float32")
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})

extract_dim_fin_weekly_country_variable = add_blocking_checks_to_asset(
    extract_dim_fin_weekly_country_variable,
    checks=[
        CheckDupDateRange(
            from_date_col='"start_date"',
            to_date_col='"end_date"',
            partitions="country_code",
        ),
    ],
)

load_dim_fin_weekly_country_variable = create_load_to_postgres_asset(
    asset_name="load_dim_fin_weekly_country_variable",
    source_assets=[extract_dim_fin_weekly_country_variable],
    target_table="dim_fin_weekly_country_variable"
)

#--------------------------------------------------------------------------------------------------
# dim_fin_weekly_offer
@asset(
    group_name="dim_user_input"
)
def extract_dim_fin_weekly_offer(
    download_Assumption_Input_mapping: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(download_Assumption_Input_mapping, sheet_name="weekly_offer")
    df['offer'] = df['offer'].str.lower().str.strip()
    df.rename(
        columns={
            "country_code": "country_code",
            "offer": "offer",
            "start_date": "start_date",
            "end_date": "end_date",
            "pd_unit_cost": "pd_unit_cost"
        },
        inplace=True,
    )
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("country_code", "string"),
                ("offer", "string"),
                ("start_date", "date32"),
                ("end_date", "date32"),
                ("pd_unit_cost", "float32")
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})

extract_dim_fin_weekly_offer = add_blocking_checks_to_asset(
    extract_dim_fin_weekly_offer,
    checks=[
        CheckDupDateRange(
            from_date_col='"start_date"',
            to_date_col='"end_date"',
            partitions="country_code,offer",
        ),
    ],
)

load_dim_fin_weekly_offer = create_load_to_postgres_asset(
    asset_name="load_dim_fin_weekly_offer",
    source_assets=[extract_dim_fin_weekly_offer],
    target_table="dim_fin_weekly_offer",
)

#--------------------------------------------------------------------------------------------------
# dim_fin_weekly_pub_fin_camp
@asset(
    group_name="dim_user_input"
)
def extract_dim_fin_weekly_pub_fin_camp(
    download_Assumption_Input_mapping: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(download_Assumption_Input_mapping, sheet_name="weekly_pub_fin_camp", dtype=str)
    df['offer'] = df['offer'].str.lower().str.strip()
    df.rename(
        columns={
            "country_code": "country_code",
            "offer": "offer",
            "fin_cp": "fin_cp"
        },
        inplace=True,
    )
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("country_code", "string"),
                ("offer", "string"),
                ("fin_cp", "string")
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})

extract_dim_fin_weekly_pub_fin_camp = add_blocking_checks_to_asset(
    extract_dim_fin_weekly_pub_fin_camp,
    checks=[
        CheckDupDim(
            "country_code,offer,fin_cp"
        )
    ],
)

load_dim_fin_weekly_pub_fin_camp = create_load_to_postgres_asset(
    asset_name="load_dim_fin_weekly_pub_fin_camp",
    source_assets=[extract_dim_fin_weekly_pub_fin_camp],
    target_table="dim_fin_weekly_pub_fin_camp",
)

#--------------------------------------------------------------------------------------------------
# dim_fin_weekly_position_pivot
import psycopg2
import os
oltp01_conn = os.getenv("PG_LIBPQ_CONN_CONFIG")

@asset(group_name="dim_user_input", deps=[load_dim_fin_weekly_position])
def truncate_table_dim_fin_weekly_position_pivot():
    sql_query_truncate_dim_fin_weekly_position_pivot = '''TRUNCATE dareport.dim_fin_weekly_position_pivot; '''
    conn_details = psycopg2.connect(oltp01_conn)
    cursor = conn_details.cursor()
    cursor.execute(sql_query_truncate_dim_fin_weekly_position_pivot)
    conn_details.commit()
    cursor.close()
    conn_details.close()

@asset(group_name="dim_user_input",  deps=[truncate_table_dim_fin_weekly_position_pivot])
def insert_table_dim_fin_weekly_position_pivot():
    sql_query_truncate_dim_fin_weekly_position_pivot = '''
    insert into dareport.dim_fin_weekly_position_pivot(
        country_code,
        date_applied,
        "IBS_Agent_fte_per_day",
        "IBS_AM_fte_per_day",
        "IBS_SM_fte_per_day",
        "IBS_Sup_fte_per_day",
        "CIT_Agent_fte_per_day",
        "CIT_AM_fte_per_day",
        "CIT_SM_fte_per_day",
        "CIT_Sup_fte_per_day",
        "IBS_Agent_fte_per_day_default",
        "IBS_AM_fte_per_day_default",
        "IBS_SM_fte_per_day_default",
        "IBS_Sup_fte_per_day_default",
        "CIT_Agent_fte_per_day_default",
        "CIT_AM_fte_per_day_default",
        "CIT_SM_fte_per_day_default",
        "CIT_Sup_fte_per_day_default",
        "IBS_Agent_cost_per_fte_per_day",
        "IBS_AM_cost_per_fte_per_day",
        "IBS_SM_cost_per_fte_per_day",
        "IBS_Sup_cost_per_fte_per_day",
        "CIT_Agent_cost_per_fte_per_day",
        "CIT_AM_cost_per_fte_per_day",
        "CIT_SM_cost_per_fte_per_day",
        "CIT_Sup_cost_per_fte_per_day"
        )
    (select country_code , date_applied,
        max(case when upper(position) = upper('IBS - Agent') then fte_per_day else null end) "IBS_Agent_fte_per_day",
        max(case when upper(position) = upper('IBS - AM') then fte_per_day else null end) "IBS_AM_fte_per_day",
        max(case when upper(position) = upper('IBS - SM') then fte_per_day else null end) "IBS_SM_fte_per_day",
        max(case when upper(position) = upper('IBS - Sup') then fte_per_day else null end) "IBS_Sup_fte_per_day",
        max(case when upper(position) = upper('CIT - Agent') then fte_per_day else null end) "CIT_Agent_fte_per_day",
        max(case when upper(position) = upper('CIT - AM') then fte_per_day else null end) "CIT_AM_fte_per_day",
        max(case when upper(position) = upper('CIT - SM') then fte_per_day else null end) "CIT_SM_fte_per_day",
        max(case when upper(position) = upper('CIT - Sup') then fte_per_day else null end) "CIT_Sup_fte_per_day",
        max(case when upper(position) = upper('IBS - Agent') then fte_per_day_default else null end) "IBS_Agent_fte_per_day_default",
        max(case when upper(position) = upper('IBS - AM') then fte_per_day_default else null end) "IBS_AM_fte_per_day_default",
        max(case when upper(position) = upper('IBS - SM') then fte_per_day_default else null end) "IBS_SM_fte_per_day_default",
        max(case when upper(position) = upper('IBS - Sup') then fte_per_day_default else null end) "IBS_Sup_fte_per_day_default",
        max(case when upper(position) = upper('CIT - Agent') then fte_per_day_default else null end) "CIT_Agent_fte_per_day_default",
        max(case when upper(position) = upper('CIT - AM') then fte_per_day_default else null end) "CIT_AM_fte_per_day_default",
        max(case when upper(position) = upper('CIT - SM') then fte_per_day_default else null end) "CIT_SM_fte_per_day_default",
        max(case when upper(position) = upper('CIT - Sup') then fte_per_day_default else null end) "CIT_Sup_fte_per_day_default",
        max(case when upper(position) = upper('IBS - Agent') then cost_per_fte_per_day else null end) "IBS_Agent_cost_per_fte_per_day",
        max(case when upper(position) = upper('IBS - AM') then cost_per_fte_per_day else null end) "IBS_AM_cost_per_fte_per_day",
        max(case when upper(position) = upper('IBS - SM') then cost_per_fte_per_day else null end) "IBS_SM_cost_per_fte_per_day",
        max(case when upper(position) = upper('IBS - Sup') then cost_per_fte_per_day else null end) "IBS_Sup_cost_per_fte_per_day",
        max(case when upper(position) = upper('CIT - Agent') then cost_per_fte_per_day else null end) "CIT_Agent_cost_per_fte_per_day",
        max(case when upper(position) = upper('CIT - AM') then cost_per_fte_per_day else null end) "CIT_AM_cost_per_fte_per_day",
        max(case when upper(position) = upper('CIT - SM') then cost_per_fte_per_day else null end) "CIT_SM_cost_per_fte_per_day",
        max(case when upper(position) = upper('CIT - Sup') then cost_per_fte_per_day else null end) "CIT_Sup_cost_per_fte_per_day"
    from dim_fin_weekly_position
    group by 1,2)
    '''
    conn_details = psycopg2.connect(oltp01_conn)
    cursor = conn_details.cursor()
    cursor.execute(sql_query_truncate_dim_fin_weekly_position_pivot)
    conn_details.commit()
    cursor.close()
    conn_details.close()

#---------------------------------------------------------------------------------------------------------------------

download_Product_category_mapping = create_download_from_sharepoint_ass_input(
    asset_name="download_Product_category_mapping",
    path_to_file="Data team/Data Source - Logistics/Product_category.xlsx",
    link=r"https://neyucom.sharepoint.com/:x:/s/DATANEYU/EU9TizIuAmlKgO3a1ufJ8LIBknXOLBz4ujfr3XxI-CmBvw?e=AU3a77",
)
#---------------------------------------------------------------------------------------------------------------------
# dim_prod_category
@asset(
    group_name="dim_user_input"
)
def extract_dim_prod_category(
    download_Product_category_mapping: bytes,
) -> Output[pa.Table]:
    df_ID = pd.read_excel(download_Product_category_mapping, sheet_name="ID")
    df_TH = pd.read_excel(download_Product_category_mapping, sheet_name="TH")
    df_MY = pd.read_excel(download_Product_category_mapping, sheet_name="MY")
    df_PH = pd.read_excel(download_Product_category_mapping, sheet_name="PH")
    df_VN = pd.read_excel(download_Product_category_mapping, sheet_name="VN")
    df_IN = pd.read_excel(download_Product_category_mapping, sheet_name="IN")
    df = pd.concat([df_ID, df_TH, df_MY, df_PH, df_VN, df_IN], ignore_index=True)
    df.rename(
        columns={
            "country_code": "country_code",
            "prod_name": "prod_name",
            "prod_category": "prod_category"
        },
        inplace=True,
    )
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("country_code", "string"),
                ("prod_name", "string"),
                ("prod_category", "string")
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})

extract_dim_prod_category = add_blocking_checks_to_asset(
    extract_dim_prod_category,
    checks=[
        CheckDupDim(
            "country_code,prod_name"
        )
    ],
)

load_dim_prod_category = create_load_to_postgres_asset(
    asset_name="load_dim_prod_category",
    source_assets=[extract_dim_prod_category],
    target_table="dim_prod_category",
)

#--------------------------------------------------------------------------------------------------
# dim_fin_weekly_type
@asset(
    group_name="dim_user_input"
)
def extract_dim_fin_weekly_channel(
    download_Assumption_Input_mapping: bytes,
) -> Output[pa.Table]:
    df = pd.read_excel(download_Assumption_Input_mapping, sheet_name="weekly_channel")
    df.rename(
        columns={
            "country_code": "country_code",
            "start_date": "start_date",
            "end_date": "end_date",
            "channel": "channel",
            "product": "product",
            "mkt_cost": "mkt_cost",
            "commission": "commission",
            "telecom": "telecom",
            "logistics": "logistics",
            "salary": "salary",
            "gp": "gp",
            "ga": "ga",
            "ebitda": "ebitda"
        },
        inplace=True,
    )
    data = pa.Table.from_pandas(
        df,
        pa.schema(
            [
                ("country_code", "string"),
                ("start_date", "date32"),
                ("end_date", "date32"),
                ("channel", "string"),
                ("product", "float32"),
                ("mkt_cost", "float32"),
                ("commission", "float32"),
                ("telecom", "float32"),
                ("logistics", "float32"),
                ("salary", "float32"),
                ("gp", "float32"),
                ("ga", "float32"),
                ("ebitda", "float32")
            ]
        ),
    )
    return Output(value=data, metadata={"Count": MetadataValue.int(data.num_rows)})

extract_dim_fin_weekly_channel = add_blocking_checks_to_asset(
    extract_dim_fin_weekly_channel,
    checks=[
        CheckDupDateRange(
            from_date_col='"start_date"',
            to_date_col='"end_date"',
            partitions="country_code, channel",
        ),
    ],
)

load_dim_fin_weekly_channel = create_load_to_postgres_asset(
    asset_name="load_dim_fin_weekly_channel",
    source_assets=[extract_dim_fin_weekly_channel],
    target_table="dim_fin_weekly_channel",
)

#--------------------------------------------------------------------------------------------------

# schedule jobs
populate_dim_table_job = define_asset_job(
    name="populate_dim_table_job",
    selection=AssetSelection.groups("dim_user_input"),
    config={
        "execution": {
            "config": {
                "multiprocess": {
                    "max_concurrent": 10,
                },
            }
        }
    },
)
populate_dim_table_schedule = ScheduleDefinition(
    job=populate_dim_table_job,
    cron_schedule="0 23 * * *",
    execution_timezone="Asia/Bangkok",
)
