from datetime import datetime, timedelta
from dagster import asset,  define_asset_job, ScheduleDefinition, AssetSelection, get_dagster_logger, DagsterInstance
# from dagster import solid

import psutil

logger = get_dagster_logger()

# MAX_JOB_RUNTIME_MINUTES = 60
# CHECK_INTERVAL_MINUTES = 5


@asset(group_name="turn_off_dagster")
# @solid
def check_and_stop_jobs(context):
    current_time = datetime.now()
    running_jobs = context.instance.get_runs()
    # print(running_jobs)
    # Lặp qua từng job để kiểm tra và tắt những job chạy quá 1 phút
    for run in running_jobs:
        start_time_str = run.tags.get("dagster/pipeline_start_time")
        if start_time_str:
            start_time = datetime.fromisoformat(start_time_str)
            run_duration = current_time - start_time
            print("===============================start_time====================================")
            print(start_time)
            print("===============================duaration_time======================================")
            print(run_duration)
            print("=====================================================================")
            if run_duration > timedelta(minutes=1):
                context.instance.terminate_run(run.run_id)
            # context.log.info(f"Tắt job {run.run_id} vì đã chạy quá 1 phút.")

                


# schedule jobs
turn_off_schedule_job = define_asset_job(
    name="turn_off_schedule_job",
    selection=AssetSelection.assets(check_and_stop_jobs),
    config={
        "execution": {
            "config": {
                "multiprocess": {
                    "max_concurrent": 10,
                },
            }
        }
    },
)
turn_off_dagster_schedule = ScheduleDefinition(
    job=turn_off_schedule_job,
    cron_schedule="*/5 * * * *",
    execution_timezone="Asia/Bangkok",
)
