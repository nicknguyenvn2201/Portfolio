import pandas as pd
import numpy as np
import datetime
from dagster import (
    asset,
    AssetExecutionContext,
    MaterializeResult,
    Config,
    define_asset_job,
    AssetSelection,
    ScheduleDefinition,
    RetryPolicy,
)
from DagsFlow.resources.postgres import PostgresConnection
from DagsFlow.assets.utls.func import extract_from_dwh
import io


def _transform(data: pd.DataFrame, geo: str) -> pd.DataFrame:
    data["lead_date"] = pd.to_datetime(data["lead_date"])
    # po = payout[payout["geo"] == geo][["lead_id", "max_po", "payout"]].copy()
    # data_merge = pd.merge(data, po, how = "left")
    data_merge = data

    data_merge["pub"].fillna("None", inplace=True)
    data_merge["cam_lead"].fillna("None", inplace=True)  ## 14.07.2023
    data_agg = (
        data_merge.groupby(["lead_date", "network", "pub", "cam_lead", "product_name"])
        .agg(
            {
                "lead_id": pd.Series.nunique,
                "quantity": sum,
                "trash": sum,
                "approved": sum,
                "validated": sum,
                "total_approved_postback": sum,
                "total_pending_postback": sum,
                "amt_validated": sum,
                "delivered": sum,
                "amt_delivered": sum,
                "unfinish": sum,
                "amt_unfinish": sum,
                "payout": np.mean,
                "max_po": np.mean,
            }
        )
        .reset_index()
    )
    data_agg.rename(columns={"lead_id": "total_lead"}, inplace=True)

    # data_agg.sort_values(by=['lead_date'], ascending = True, inplace = True)
    roll_sum: pd.DataFrame = (
        data_agg.groupby(["network", "pub", "cam_lead", "product_name"])
        .rolling(29, on="lead_date", min_periods=0)["validated", "delivered"]
        .sum()
        .reset_index()
    )
    roll_sum.rename(
        columns={"validated": "validated_hist", "delivered": "delivered_hist"},
        inplace=True,
    )
    roll_sum[["validated_hist", "delivered_hist"]] = roll_sum.groupby(
        ["network", "pub", "cam_lead", "product_name"]
    )[["validated_hist", "delivered_hist"]].shift(15)

    final = pd.merge(
        data_agg,
        roll_sum,
        on=["network", "pub", "cam_lead", "product_name", "lead_date"],
    )

    # Filter L150D data
    ##final = final.loc[data_agg["lead_date"].between(last_150d, yesterday)]
    # final = final.loc[data_agg["lead_date"].between(last_150d, today)]
    final["pub"].replace("None", np.nan, inplace=True)
    final["cam_lead"].replace("None", np.nan, inplace=True)  ## 14.07.2023
    final["geo"] = geo
    # print('final day ne')
    # print(final)
    final["cpl_lead"] = final.apply(
        lambda row: row["total_lead"] - row["trash"]
        if "cpl" in row["product_name"]
        else np.nan,
        axis=1,
    )
    return final


@asset(group_name="pub_ads_roi", retry_policy=RetryPolicy(max_retries=3))
def pub_ads_roi_agg_my(oltp01_conn: PostgresConnection) -> pd.DataFrame:
    query = f"""
     with full_merge as (
        select l.lead_id, l.org_id,
        lead_type,
        case when prod_name is null or prod_name = '' then product1
          else prod_name
        end as product_name,
        --date_trunc('month',l.createdate) as lead_month,
        date_trunc('month', case when lead_type = 'A' then l.createdate else oso.createdate end) as lead_month,
        date(case when lead_type = 'A' then l.createdate else oso.createdate end) as lead_date,
        cf_lead.name as lead_status,
        date(oso.createdate) as so_date,
        cf_so.name as so_status,
        date(odn.createdate) as do_date,
        cf_do.name as do_status,
        --case when COALESCE(p.shortname, l.agc_code, 'LOYAL CUSTOMER') = 'AFS' then affiliate_id else COALESCE(p.shortname, l.agc_code, 'LOYAL CUSTOMER') end as network,
        coalesce((case when COALESCE(p.shortname, l.agc_code, 'LOYAL CUSTOMER') = 'AFS' then affiliate_id else COALESCE(p.shortname, l.agc_code, 'LOYAL CUSTOMER') end),'No network') as network,
        --case when COALESCE(p.shortname, l.agc_code, 'LOYAL CUSTOMER') = 'AFS' then subid1 else affiliate_id end as pub,
        case when subid1= '' then 'blank'
        	 when subid1 is null then 'No PubID' else
        	case when COALESCE(p.shortname, l.agc_code, 'LOYAL CUSTOMER') in ('AFS', 'OFP') then coalesce(subid1,'No PubID') 
        		else affiliate_id 
        		end 
        	end as pub,
        amount,
        qty.quantity,
        cam_lead, payout, max_po, l.postback_status
        from (
            select cl.org_id, lead_id, cl.geo,
              cl.createdate,
              prod_name,
                agc_id, agc_code, affiliate_id, subid1,
                lead_type,
                lead_status,
                case when lower(prod_name) like '%prosta%id' then 'Fresh HC'  -- 472
		            when lower(prod_name) like '%duramax%th' then 'Fresh ME' -- 567
		            else cam.name
	              end cam_lead,
                coalesce(agent_fc.fullname, agent.fullname) as fc_agent,
                agent.fullname as cl_agent, afs.payout, afs.max_po, cl.postback_status
            from cl_fresh cl
            left join ( select max_po, payout, transaction_id from ods_affscale_conversion where geo = 'MY' ) afs on cl.click_id = afs.transaction_id 
            left join (
                select *
                from or_user ou
                where user_type = 'agent' and org_id = 11) as agent_fc
            on cl.first_call_by = agent_fc.user_id and cl.org_id = agent_fc.org_id 
            left join (
                select *
                from or_user ou
                where user_type = 'agent' and org_id = 11) as agent
            on cl.assigned = agent.user_id and cl.org_id = agent.org_id
          left join cp_campaign cam on cam.cp_id = cl.cp_id  and cam.geo = cl.geo
          where( lower(cam.name) is null or lower(cam.name) not like '%research%' )
          and cl.name not ilike '%test%'
          and CASE
                    WHEN cl.lead_status = 4 OR cl.lead_status = 5 AND cl.assigned = 0 THEN 1
                    ELSE 0
                END <> 1
          and cl.org_id = 11 -- MY
            ) as l
        left join (
          select lead_id, so_id, createdate, status, cp_id, amount, ag_id, createby, geo, org_id
          from od_sale_order
          where org_id =11
          ) oso
        on oso.lead_id = l.lead_id and oso.geo = l.geo
        left join (select geo, so_id, sum(quantity) quantity 
        			from od_so_item 
        			where geo = 'MY' 
        			group by so_id, geo) qty 
		on oso.so_id = qty.so_id and oso.geo = qty.geo
        left join (
          select so_id, geo,
          do_id,
          tracking_code,
          createdate,
          status
          from od_do_new
          where geo = 'MY'
          ) odn
        on oso.so_id = odn.so_id  and oso.geo = l.geo
        left join (
          with temp_so as (
          SELECT oi_id, osi.geo,
          so_id,
          quantity,
          item_no,
          osi.prod_id,
          pp.name as product_name,
          row_number() over(partition by so_id order by item_no) as item_no_new
          FROM od_so_item osi 
          left join pd_product pp 
          on osi.prod_id = pp.prod_id and osi.geo = pp.geo
          where osi.geo = 'MY'
          )
          SELECT so_id, geo,
          max((case when item_no_new = 1 then product_name end)) as product1,
          SUM(quantity) no_quantity,
          COUNT(DISTINCT prod_id) as no_product 
          FROM temp_so
          group by so_id, geo
          order by so_id desc
          ) osi 
        on oso.so_id = osi.so_id and oso.geo = osi.geo
        left join (
            select *
            from cf_synonym cs
            where "type" = 'lead status' and geo = 'MY'
            ) as cf_lead
        on l.lead_status = cf_lead.value and l.geo = cf_lead.geo
        left join (
            select *
            from cf_synonym cs
            where "type" = 'sale order status' and geo = 'MY'
            ) as cf_so 
        on oso.status = cf_so.value and oso.geo = cf_so.geo 
        left join (
          select *
          from cf_synonym
          where type = 'delivery order status' and geo = 'MY'
          ) as cf_do
        on odn.status = cf_do.value and odn.geo = cf_do.geo
        left join (
            select *
            from or_user ou
            where user_type = 'agent' and org_id = 11) as agent
        on oso.ag_id = agent.user_id and oso.geo = agent.geo
        left join (
            select *
            from or_user ou
            where user_type = 'agent' and org_id = 11) as agent_create
        on oso.createby = agent_create.user_id and oso.geo = agent_create.geo
        left join bp_partner p on l.agc_id = p.pn_id and l.geo = p.geo
        left join cp_campaign cam on cam.cp_id = oso.cp_id and cam.geo = oso.geo
        --where date_trunc('month', case when lead_type = 'A' then l.createdate else oso.createdate end) >= date_trunc('month', current_date - interval '5 months')
        --and 
        where l.org_id = 11
        and lead_type = 'A'
        )
        --select lead_id, lead_date, lead_month, network, case when network = 'EW' or network = 'AT' or network = 'ADT' then 'No PubID' else pub end as pub,
        select lead_id, lead_date, lead_month, network, case when (network in('EW','AT','ADT','ABT','ARB','CSL','MKR','XXX','PFC','ORG','ORG2',
        		'PIB','MH','MP','IGO','VIC','ODS','DAT','VAL','MIR','NGN','WIL','PD','CTR','U_DOMA','ABG')) or (network in('U_RUS') and org_id = 10)
        		then 'No PubID' else pub end as pub,  payout, max_po,
        cam_lead, product_name, quantity,
        case when lead_status in ('trash','duplicated') then 1 else null end as trash,
        case when lead_status in ('approved') then 1 else null end as approved,
        case when lead_status in ('approved') and so_status in ('validated', 'delay') then 1 else null end as validated,
        case when lead_status in ('approved') and so_status in ('validated', 'delay')  and (postback_status = 'approved' or postback_status is null) then 1 else null end as total_approved_postback,
        case when lead_status in ('approved') and so_status in ('validated', 'delay')  and postback_status in ('pending_postback', 'pending_pb') then 1 else null end as total_pending_postback,
        case when lead_status in ('approved') and so_status in ('validated', 'delay') then amount else null end as amt_validated,
        case when lead_status in ('approved') and so_status in ('validated', 'delay') and do_status in ('refund', 'delivered') then 1 else null end as delivered,
        case when lead_status in ('approved') and so_status in ('validated', 'delay') and do_status in ('refund', 'delivered') then amount else null end as amt_delivered,
        case when lead_status in ('approved') and so_status in ('validated', 'delay') and (lower(do_status) not in ('refund', 'delivered', 'returned', 'cancel') or do_status is null) then 1 else null end as unfinish,
        case when lead_status in ('approved') and so_status in ('validated', 'delay') and (lower(do_status) not in ('refund', 'delivered', 'returned', 'cancel') or do_status is null) then amount else null end as amt_unfinish
        from full_merge
    """
    df: pd.DataFrame = extract_from_dwh(query, oltp01_conn)
    df = _transform(df, "MY")
    return df


@asset(group_name="pub_ads_roi", retry_policy=RetryPolicy(max_retries=3))
def pub_ads_roi_agg_vn(oltp01_conn: PostgresConnection) -> pd.DataFrame:
    query = f"""
        with full_merge as (
        select l.lead_id, l.geo,
        lead_type,
        case when prod_name is null or prod_name = '' then product1
          else prod_name
        end as product_name,
        --date_trunc('month',l.createdate) as lead_month,
        date_trunc('month', case when lead_type = 'A' then l.createdate else oso.createdate end) as lead_month,
        date(case when lead_type = 'A' then l.createdate else oso.createdate end) as lead_date,
        cf_lead.name as lead_status,
        date(oso.createdate) as so_date,
        cf_so.name as so_status,
        date(odn.createdate) as do_date,
        cf_do.name as do_status,
        --case when COALESCE(p.shortname, l.agc_code, 'LOYAL CUSTOMER') = 'AFS' then affiliate_id else COALESCE(p.shortname, l.agc_code, 'LOYAL CUSTOMER') end as network,
        coalesce((case when COALESCE(p.shortname, l.agc_code, 'LOYAL CUSTOMER') = 'AFS' then affiliate_id else COALESCE(p.shortname, l.agc_code, 'LOYAL CUSTOMER') end),'No network') as network,
        --case when COALESCE(p.shortname, l.agc_code, 'LOYAL CUSTOMER') = 'AFS' then subid1 else affiliate_id end as pub,
        case when subid1= '' then 'blank'
        	 when subid1 is null then 'No PubID' else
        	case when COALESCE(p.shortname, l.agc_code, 'LOYAL CUSTOMER') in ('AFS', 'OFP') then coalesce(subid1,'No PubID') 
        		else affiliate_id 
        		end 
        	end as pub,
        amount,
        qty.quantity,
        cam_lead, payout, max_po, l.postback_status
        from (
            select cl.org_id, lead_id, cl.geo,
              cl.createdate,
              prod_name,
                agc_id, agc_code, affiliate_id, subid1,
                lead_type,
                lead_status,
                case when lower(prod_name) like '%prosta%id' then 'Fresh HC'  -- 472
		            when lower(prod_name) like '%duramax%th' then 'Fresh ME' -- 567
		            else cam.name
	              end cam_lead, 
                coalesce(agent_fc.fullname, agent.fullname) as fc_agent,
                agent.fullname as cl_agent
                , afs.payout, afs.max_po, cl.postback_status
            from cl_fresh cl
            left join ( select max_po, payout, transaction_id from ods_affscale_conversion where geo = 'VN' ) afs on cl.click_id = afs.transaction_id 
            left join (
                select *
                from or_user ou
                where user_type = 'agent' and org_id = 4 ) as agent_fc
        on cl.first_call_by = agent_fc.user_id and cl.geo = agent_fc.geo
        left join (
            select *
            from or_user ou
            where user_type = 'agent' and org_id = 4 ) as agent
            on cl.assigned = agent.user_id and cl.geo = agent.geo 
          left join cp_campaign cam on cam.cp_id = cl.cp_id and cam.geo = cl.geo
          where( lower(cam.name) is null or lower(cam.name) not like '%research%' )
          and lower(cl.name) not like'%test%'
          and CASE
                    WHEN cl.lead_status = 4 OR cl.lead_status = 5 AND cl.assigned = 0 THEN 1
                    ELSE 0
                END <> 1
          and cl.org_id = 4 --VN
            ) as l
        left join (
          select lead_id, so_id, createdate, status, cp_id, amount, ag_id, createby, geo
          from od_sale_order
          where geo = 'VN'
          ) oso
        on oso.lead_id = l.lead_id and oso.geo = l.geo
        left join (select so_id, sum(quantity) quantity, geo from od_so_item where geo = 'VN' group by so_id, geo) qty
		on oso.so_id = qty.so_id and oso.geo = qty.geo
        --left join (select * from (
		--  select ma_don_hang,
        --    ma_don_goc,
        --    created_date,
        --    status_transport, tinh_thanh_pho,
        --    rank() over(partition by ma_don_hang order by created_date desc) as rn
        --    from log_data_main) ldm where rn = 1) odn
        left join (
          select so_id, geo,
          do_id,
          tracking_code,
          createdate,
          status
          from od_do_new
          where geo = 'VN'
          ) odn
        on oso.so_id = odn.so_id and oso.geo = odn.geo
        left join (
          with temp_so as (
          SELECT oi_id, osi.geo,
          so_id,
          quantity,
          item_no,
          osi.prod_id,
          pp.name as product_name,
          row_number() over(partition by so_id order by item_no) as item_no_new
          FROM od_so_item osi 
          left join pd_product pp 
          on osi.prod_id = pp.prod_id  and osi.geo = pp.geo
          where osi.geo = 'VN'
          )
          SELECT so_id, geo,
          max((case when item_no_new = 1 then product_name end)) as product1,
          SUM(quantity) no_quantity,
          COUNT(DISTINCT prod_id) as no_product 
          FROM temp_so
          group by so_id, geo
          order by so_id desc
          ) osi 
        on oso.so_id = osi.so_id and oso.geo = osi.geo
        left join (
            select *
            from cf_synonym cs
            where "type" = 'lead status' and geo = 'VN') as cf_lead
        on l.lead_status = cf_lead.value and l.geo = cf_lead.geo
        left join (
            select *
            from cf_synonym cs
            where "type" = 'sale order status'  and geo = 'VN') as cf_so
        on oso.status = cf_so.value and oso.geo = cf_so.geo
        left join (
          select *
          from cf_synonym
          where type = 'delivery order status' and geo = 'VN'
          ) as cf_do
        on odn.status = cf_do.value and odn.geo = cf_do.geo
        left join (
            select *
            from or_user ou
            where user_type = 'agent' and org_id = 4) as agent
        on oso.ag_id = agent.user_id and oso.geo = agent.geo
        left join (
            select *
            from or_user ou
            where user_type = 'agent' and org_id = 4) as agent_create
        on oso.createby = agent_create.user_id and oso.geo = agent_create.geo
        left join bp_partner p on l.agc_id = p.pn_id and l.geo = p.geo
        left join cp_campaign cam on cam.cp_id = oso.cp_id and cam.geo = oso.geo
        --where date_trunc('month', case when lead_type = 'A' then l.createdate else oso.createdate end) >= date_trunc('month', current_date - interval '5 months')
        --and 
        where l.org_id = 4
        and lead_type = 'A'
        )
        --select lead_id, lead_date, lead_month, network, case when network = 'EW' or network = 'AT' or network = 'ADT' then 'No PubID' else pub end as pub,
        select lead_id, lead_date, lead_month, network, case when network in('EW','AT','ADT','ABT','ARB','CSL','MKR','XXX','PFC','ORG','ORG2',
        		'PIB','MH','MP','IGO','VIC','ODS','DAT','VAL','MIR','NGN','WIL','PD','CTR','U_DOMA','ABG')  
        		then 'No PubID' else pub end as pub,
        cam_lead, product_name, quantity,  payout, max_po,
        case when lead_status in ('trash','duplicated') then 1 else null end as trash,
        case when lead_status in ('approved') then 1 else null end as approved,
        case when lead_status in ('approved') and lower(so_status) in ('validated', 'delay') then 1 else null end as validated,
        case when lead_status in ('approved') and so_status in ('validated', 'delay')  and (postback_status = 'approved' or postback_status is null) then 1 else null end as total_approved_postback,
        case when lead_status in ('approved') and so_status in ('validated', 'delay')  and postback_status in ('pending_postback', 'pending_pb') then 1 else null end as total_pending_postback,
        case when lead_status in ('approved') and lower(so_status) in ('validated', 'delay') then amount else null end as amt_validated,
        case when lead_status in ('approved') and lower(so_status) in ('validated', 'delay') and lower(do_status) in ('refund', 'delivered') then 1 else null end as delivered,
        case when lead_status in ('approved') and lower(so_status) in ('validated', 'delay') and lower(do_status) in ('refund', 'delivered') then amount else null end as amt_delivered,
        case when lead_status in ('approved') and lower(so_status) in ('validated', 'delay') and (lower(do_status) not in ('refund', 'delivered', 'reject', 'cancelled') or do_status is null) then 1 else null end as unfinish,
        case when lead_status in ('approved') and lower(so_status) in ('validated', 'delay') and (lower(do_status) not in ('refund', 'delivered', 'reject', 'cancelled') or do_status is null) then amount else null end as amt_unfinish
        from full_merge
    """
    df: pd.DataFrame = extract_from_dwh(query, oltp01_conn)
    df = _transform(df, "VN")
    return df


@asset(group_name="pub_ads_roi", retry_policy=RetryPolicy(max_retries=3))
def pub_ads_roi_agg_ph(oltp01_conn: PostgresConnection) -> pd.DataFrame:
    query = f"""
with full_merge as (
        select l.lead_id, l.org_id, l.geo,
        lead_type,
        case when prod_name is null or prod_name = '' then product1
          else prod_name
        end as product_name,
        --date_trunc('month',l.createdate) as lead_month,
        date_trunc('month', case when lead_type = 'A' then l.createdate else oso.createdate end) as lead_month,
        date(case when lead_type = 'A' then l.createdate else oso.createdate end) as lead_date,
        cf_lead.name as lead_status,
        date(oso.createdate) as so_date,
        cf_so.name as so_status,
        date(odn.createdate) as do_date,
        cf_do.name as do_status,
        --case when COALESCE(p.shortname, l.agc_code, 'LOYAL CUSTOMER') = 'AFS' then affiliate_id else COALESCE(p.shortname, l.agc_code, 'LOYAL CUSTOMER') end as network,
        coalesce((case when COALESCE(p.shortname, l.agc_code, 'LOYAL CUSTOMER') = 'AFS' then affiliate_id else COALESCE(p.shortname, l.agc_code, 'LOYAL CUSTOMER') end),'No network') as network,
        --case when COALESCE(p.shortname, l.agc_code, 'LOYAL CUSTOMER') = 'AFS' then subid1 else affiliate_id end as pub,
        case when subid1= '' then 'blank'
        	 when subid1 is null then 'No PubID' else
        	case when COALESCE(p.shortname, l.agc_code, 'LOYAL CUSTOMER') in ('AFS', 'OFP') then coalesce(subid1,'No PubID') 
        		else affiliate_id 
        		end 
        	end as pub,
        amount,
        qty.quantity, payout, max_po, l.postback_status,
        cam_lead
        from (
            select cl.org_id, cl.lead_id, cl.geo,
              cl.createdate,
              prod_name,
                agc_id, agc_code, affiliate_id, subid1,
                lead_type,
                lead_status,
                case when lower(prod_name) like '%prosta%id' then 'Fresh HC'  -- 472
		            when lower(prod_name) like '%duramax%th' then 'Fresh ME' -- 567
		            else cam.name
	              end cam_lead,
                coalesce(agent_fc.fullname, agent.fullname) as fc_agent,
                agent.fullname as cl_agent , afs.payout, afs.max_po, cl.postback_status
            from cl_fresh cl
            left join ( select max_po, payout, transaction_id from ods_affscale_conversion where geo = 'PH' ) afs on cl.click_id = afs.transaction_id 
            left join (
                select *
                from or_user ou
                where user_type = 'agent') as agent_fc
            on cl.first_call_by = agent_fc.user_id and cl.geo = agent_fc.geo
            left join (
                select *
                from or_user ou
                where user_type = 'agent') as agent
            on cl.assigned = agent.user_id and cl.geo = agent.geo
          left join cp_campaign cam on cam.cp_id = cl.cp_id and cam.geo = cl.geo
          where( lower(cam.name) is null or lower(cam.name) not like '%research%' )
          and lower(cl.name) not like'%test%'
          and CASE
                    WHEN cl.lead_status = 4 OR cl.lead_status = 5 AND cl.assigned = 0 THEN 1
                    ELSE 0
                END <> 1
          and cl.org_id = 14 -- PH
            ) as l
        left join (
          select geo, lead_id, so_id, createdate, status, cp_id, amount, ag_id, createby
          from od_sale_order
          ) oso
        on oso.lead_id = l.lead_id and oso.geo = l.geo
        left join (select geo, so_id, sum(quantity) quantity from od_so_item group by so_id, geo) qty
		on oso.so_id = qty.so_id and oso.geo = qty.geo
        left join (
          select so_id, geo,
          do_id,
          tracking_code,
          createdate,
          status
          from od_do_new) odn
        on oso.so_id = odn.so_id and oso.geo = odn.geo
        left join (
          with temp_so as (
          SELECT oi_id, osi.geo,
          so_id,
          quantity,
          item_no,
          osi.prod_id,
          pp.name as product_name,
          row_number() over(partition by so_id order by item_no) as item_no_new
          FROM od_so_item osi 
          left join pd_product pp 
          on osi.prod_id = pp.prod_id and osi.geo = pp.geo
          )
          SELECT so_id, geo,
          max((case when item_no_new = 1 then product_name end)) as product1,
          SUM(quantity) no_quantity,
          COUNT(DISTINCT prod_id) as no_product 
          FROM temp_so
          group by so_id, geo
          order by so_id desc
          ) osi 
        on oso.so_id = osi.so_id and oso.geo = osi.geo
        left join (
            select *
            from cf_synonym cs
            where "type" = 'lead status') as cf_lead
        on l.lead_status = cf_lead.value and l.geo = cf_lead.geo
        left join (
            select *
            from cf_synonym cs
            where "type" = 'sale order status') as cf_so
        on oso.status = cf_so.value and oso.geo = cf_so.geo
        left join (
          select *
          from cf_synonym
          where type = 'delivery order status'
          ) as cf_do
        on odn.status = cf_do.value and odn.geo = cf_do.geo
        left join (
            select *
            from or_user ou
            where user_type = 'agent') as agent
        on oso.ag_id = agent.user_id and oso.geo = agent.geo
        left join (
            select *
            from or_user ou
            where user_type = 'agent') as agent_create
        on oso.createby = agent_create.user_id and oso.geo = agent_create.geo
        left join bp_partner p on l.agc_id = p.pn_id and l.geo = p.geo
        left join cp_campaign cam on cam.cp_id = oso.cp_id and cam.geo = oso.geo
        --where date_trunc('month', case when lead_type = 'A' then l.createdate else oso.createdate end) >= date_trunc('month', current_date - interval '5 months')
        --and 
        where l.org_id = 14 -- PH
        and lead_type = 'A'
        ) 
        select lead_id, lead_date, lead_month, network, case when (network in('EW','AT','ADT','ABT','ARB','CSL','MKR','XXX','PFC','ORG','ORG2',
        		'PIB','MH','MP','IGO','VIC','ODS','DAT','VAL','MIR','NGN','WIL','PD','CTR','U_DOMA','ABG')) 
        		then 'No PubID' else pub end as pub,
        cam_lead, product_name, quantity, payout, max_po,
        case when lead_status in ('trash','duplicated') then 1 else null end as trash,
        case when lead_status in ('approved') then 1 else null end as approved,
        case when lead_status in ('approved') and so_status in ('validated', 'delay') then 1 else null end as validated,
        case when lead_status in ('approved') and so_status in ('validated', 'delay')  and (postback_status = 'approved' or postback_status is null) then 1 else null end as total_approved_postback,
        case when lead_status in ('approved') and so_status in ('validated', 'delay')  and postback_status in ('pending_postback', 'pending_pb') then 1 else null end as total_pending_postback,
        case when lead_status in ('approved') and so_status in ('validated', 'delay') then amount else null end as amt_validated,
        case when lead_status in ('approved') and so_status in ('validated', 'delay') and do_status in ('refund', 'delivered') then 1 else null end as delivered,
        case when lead_status in ('approved') and so_status in ('validated', 'delay') and do_status in ('refund', 'delivered') then amount else null end as amt_delivered,
        case when lead_status in ('approved') and so_status in ('validated', 'delay') and (lower(do_status) not in ('refund', 'delivered', 'returned', 'cancel') or do_status is null) then 1 else null end as unfinish,
        case when lead_status in ('approved') and so_status in ('validated', 'delay') and (lower(do_status) not in ('refund', 'delivered', 'returned', 'cancel') or do_status is null) then amount else null end as amt_unfinish
        from full_merge 
        """
    df: pd.DataFrame = extract_from_dwh(query, oltp01_conn)
    df = _transform(df, "PH")
    return df


@asset(group_name="pub_ads_roi", retry_policy=RetryPolicy(max_retries=3))
def pub_ads_roi_agg_id(oltp01_conn: PostgresConnection) -> pd.DataFrame:
    query = f"""
    with full_merge as (
        select l.lead_id, l.org_id,
        lead_type,
        case when prod_name is null or prod_name = '' then product1
          else prod_name
        end as product_name,
        --date_trunc('month',l.createdate) as lead_month,
        date_trunc('month', case when lead_type = 'A' then l.createdate else oso.createdate end) as lead_month,
        date(case when lead_type = 'A' then l.createdate else oso.createdate end) as lead_date,
        cf_lead.name as lead_status,
        date(oso.createdate) as so_date,
        cf_so.name as so_status,
        date(odn.createdate) as do_date,
        cf_do.name as do_status,
        --case when COALESCE(p.shortname, l.agc_code, 'LOYAL CUSTOMER') = 'AFS' then affiliate_id else COALESCE(p.shortname, l.agc_code, 'LOYAL CUSTOMER') end as network,
        coalesce((case when COALESCE(p.shortname, l.agc_code, 'LOYAL CUSTOMER') = 'AFS' then affiliate_id else COALESCE(p.shortname, l.agc_code, 'LOYAL CUSTOMER') end),'No network') as network,
        --case when COALESCE(p.shortname, l.agc_code, 'LOYAL CUSTOMER') = 'AFS' then subid1 else affiliate_id end as pub,
        case when subid1= '' then 'blank'
        	 when subid1 is null then 'No PubID' else
        	case when COALESCE(p.shortname, l.agc_code, 'LOYAL CUSTOMER') in ('AFS', 'OFP') then coalesce(subid1,'No PubID') 
        		else affiliate_id 
        		end 
        	end as pub,
        amount,
        qty.quantity,
        cam_lead, payout, max_po
        , l.postback_status
        from (
            select cl.org_id, lead_id, cl.geo,
              cl.createdate,
              prod_name,
                agc_id, agc_code, affiliate_id, subid1,
                lead_type,
                lead_status,
                case when lower(prod_name) like '%prosta%id' then 'Fresh HC'  -- 472
		            when lower(prod_name) like '%duramax%th' then 'Fresh ME' -- 567
		            else cam.name
	              end cam_lead,
                coalesce(agent_fc.fullname, agent.fullname) as fc_agent,
                agent.fullname as cl_agent
                , afs.payout, afs.max_po , cl.postback_status
            from cl_fresh cl
            left join ( select max_po, payout, transaction_id from ods_affscale_conversion where geo = 'ID'  ) afs on cl.click_id = afs.transaction_id 
            left join (
                select *
                from or_user ou
                where user_type = 'agent' and org_id in (8,9) ) as agent_fc
            on cl.first_call_by = agent_fc.user_id and cl.org_id = agent_fc.org_id 
            left join (
                select *
                from or_user ou
                where user_type = 'agent' and org_id in (8,9) ) as agent
            on cl.assigned = agent.user_id and cl.org_id = agent.org_id
          left join cp_campaign cam on cam.cp_id = cl.cp_id  and cam.geo = cl.geo
          where( lower(cam.name) is null or lower(cam.name) not like '%research%' )
          and lower(cl.name) not like'%test%'
          and CASE
                    WHEN cl.lead_status = 4 OR cl.lead_status = 5 AND cl.assigned = 0 THEN 1
                    ELSE 0
                END <> 1
          and cl.org_id in (8,9)  -- ID , ID2
            ) as l
        left join (
          select lead_id, so_id, createdate, status, cp_id, amount, ag_id, createby, geo, org_id
          from od_sale_order
          where org_id in (8,9) 
          ) oso
        on oso.lead_id = l.lead_id and oso.geo = l.geo
        left join (select geo, so_id, sum(quantity) quantity 
        			from od_so_item 
        			where geo in ('ID', 'ID2') 
        			group by so_id, geo) qty 
		on oso.so_id = qty.so_id and oso.geo = qty.geo
        left join (
          select so_id, geo,
          do_id,
          tracking_code,
          createdate,
          status
          from od_do_new
          where geo in ('ID', 'ID2') 
          ) odn
        on oso.so_id = odn.so_id  and oso.geo = l.geo
        left join (
          with temp_so as (
          SELECT oi_id, osi.geo,
          so_id,
          quantity,
          item_no,
          osi.prod_id,
          pp.name as product_name,
          row_number() over(partition by so_id order by item_no) as item_no_new
          FROM od_so_item osi 
          left join pd_product pp 
          on osi.prod_id = pp.prod_id and osi.geo = pp.geo
          where osi.geo in ('ID', 'ID2') 
          )
          SELECT so_id, geo,
          max((case when item_no_new = 1 then product_name end)) as product1,
          SUM(quantity) no_quantity,
          COUNT(DISTINCT prod_id) as no_product 
          FROM temp_so
          group by so_id, geo
          order by so_id desc
          ) osi 
        on oso.so_id = osi.so_id and oso.geo = osi.geo
        left join (
            select *
            from cf_synonym cs
            where "type" = 'lead status' and geo in ('ID', 'ID2') 
            ) as cf_lead
        on l.lead_status = cf_lead.value and l.geo = cf_lead.geo
        left join (
            select *
            from cf_synonym cs
            where "type" = 'sale order status' and geo in ('ID', 'ID2') 
            ) as cf_so 
        on oso.status = cf_so.value and oso.geo = cf_so.geo 
        left join (
          select *
          from cf_synonym
          where type = 'delivery order status' and geo in ('ID', 'ID2') 
          ) as cf_do
        on odn.status = cf_do.value and odn.geo = cf_do.geo
        left join (
            select *
            from or_user ou
            where user_type = 'agent' and org_id  in (8,9)  ) as agent
        on oso.ag_id = agent.user_id and oso.geo = agent.geo
        left join (
            select *
            from or_user ou
            where user_type = 'agent' and org_id in (8,9) ) as agent_create
        on oso.createby = agent_create.user_id and oso.geo = agent_create.geo
        left join bp_partner p on l.agc_id = p.pn_id and l.geo = p.geo
        left join cp_campaign cam on cam.cp_id = oso.cp_id and cam.geo = oso.geo
        --where date_trunc('month', case when lead_type = 'A' then l.createdate else oso.createdate end) >= date_trunc('month', current_date - interval '5 months')
        --and 
        where l.org_id in (8,9) 
        and lead_type = 'A'
        )
        --select lead_id, lead_date, lead_month, network, case when network = 'EW' or network = 'AT' or network = 'ADT' then 'No PubID' else pub end as pub,
        select lead_id, lead_date, lead_month, network, case when (network in('EW','AT','ADT','ABT','ARB','CSL','MKR','XXX','PFC','ORG','ORG2',
        		'PIB','MH','MP','IGO','VIC','ODS','DAT','VAL','MIR','NGN','WIL','PD','CTR','U_DOMA','ABG')) or (network in('U_RUS') and org_id = 10)
        		then 'No PubID' else pub end as pub,
        cam_lead, product_name, quantity,  payout,  max_po,
        case when lead_status in ('trash','duplicated') then 1 else null end as trash,
        case when lead_status in ('approved') then 1 else null end as approved,
        case when lead_status in ('approved') and so_status in ('validated', 'delay') then 1 else null end as validated,
        case when lead_status in ('approved') and so_status in ('validated', 'delay')  and (postback_status = 'approved' or postback_status is null) then 1 else null end as total_approved_postback,
        case when lead_status in ('approved') and so_status in ('validated', 'delay')  and postback_status in ('pending_postback', 'pending_pb') then 1 else null end as total_pending_postback,
        case when lead_status in ('approved') and so_status in ('validated', 'delay') then amount else null end as amt_validated,
        case when lead_status in ('approved') and so_status in ('validated', 'delay') and do_status in ('refund', 'delivered') then 1 else null end as delivered,
        case when lead_status in ('approved') and so_status in ('validated', 'delay') and do_status in ('refund', 'delivered') then amount else null end as amt_delivered,
        case when lead_status in ('approved') and so_status in ('validated', 'delay') and (lower(do_status) not in ('refund', 'delivered', 'returned', 'cancel') or do_status is null) then 1 else null end as unfinish,
        case when lead_status in ('approved') and so_status in ('validated', 'delay') and (lower(do_status) not in ('refund', 'delivered', 'returned', 'cancel') or do_status is null) then amount else null end as amt_unfinish
        from full_merge 
    """
    df: pd.DataFrame = extract_from_dwh(query, oltp01_conn)
    df = _transform(df, "ID")
    return df


@asset(group_name="pub_ads_roi", retry_policy=RetryPolicy(max_retries=3))
def pub_ads_roi_agg_vn2(oltp01_conn: PostgresConnection) -> pd.DataFrame:
    query = f"""
              with full_merge as (
        select l.lead_id,
        lead_type,
        case when prod_name is null or prod_name = '' then product1
          else prod_name
        end as product_name,
        --date_trunc('month',l.createdate) as lead_month,
        date_trunc('month', case when lead_type = 'A' then l.createdate else oso.createdate end) as lead_month,
        date(case when lead_type = 'A' then l.createdate else oso.createdate end) as lead_date,
        cf_lead.name as lead_status,
        date(oso.createdate) as so_date,
        cf_so.name as so_status,
        date(odn.createdate) as do_date,
        cf_do.name as do_status,
        --case when COALESCE(p.shortname, l.agc_code, 'LOYAL CUSTOMER') = 'AFS' then affiliate_id else COALESCE(p.shortname, l.agc_code, 'LOYAL CUSTOMER') end as network,
        coalesce((case when COALESCE(p.shortname, l.agc_code, 'LOYAL CUSTOMER') = 'AFS' then affiliate_id else COALESCE(p.shortname, l.agc_code, 'LOYAL CUSTOMER') end),'No network') as network,
        --case when COALESCE(p.shortname, l.agc_code, 'LOYAL CUSTOMER') = 'AFS' then subid1 else affiliate_id end as pub,
        case when subid1= '' then 'blank'
        	 when subid1 is null then 'No PubID' else
        	case when COALESCE(p.shortname, l.agc_code, 'LOYAL CUSTOMER') in ('AFS', 'OFP') then coalesce(subid1,'No PubID') 
        		else affiliate_id 
        		end 
        	end as pub,
        amount,
        qty.quantity, payout, max_po, l.postback_status,
        cam_lead
        from (
            select cl.org_id, lead_id, cl.geo,
              cl.createdate,
              prod_name,
                agc_id, agc_code, affiliate_id, subid1,
                lead_type,
                lead_status,
                case when lower(prod_name) like '%prosta%id' then 'Fresh HC'  -- 472
		            when lower(prod_name) like '%duramax%th' then 'Fresh ME' -- 567
		            else cam.name
	              end cam_lead,
                coalesce(agent_fc.fullname, agent.fullname) as fc_agent,
                agent.fullname as cl_agent, afs.payout, afs.max_po, cl.postback_status
            from cl_fresh cl
            left join ( select max_po, payout, transaction_id from ods_affscale_conversion where geo = 'VN' ) afs on cl.click_id = afs.transaction_id 
            left join (
                select *
                from or_user ou
                where user_type = 'agent') as agent_fc
        on cl.first_call_by = agent_fc.user_id and cl.geo = agent_fc.geo
        left join (
            select *
            from or_user ou
            where user_type = 'agent') as agent
            on cl.assigned = agent.user_id  and cl.geo = agent.geo
          left join cp_campaign cam on cam.cp_id = cl.cp_id and cam.geo = cl.geo
          where( lower(cam.name) is null or lower(cam.name) not like '%research%' )
          and lower(cl.name) not like'%test%'
          and CASE
                    WHEN cl.lead_status = 4 OR cl.lead_status = 5 AND cl.assigned = 0 THEN 1
                    ELSE 0
                END <> 1
			and cl.org_id = 5 --VN2
            ) as l
        left join (
          select geo, lead_id, so_id, createdate, status, cp_id, amount, ag_id, createby
          from od_sale_order
          ) oso
        on oso.lead_id = l.lead_id and oso.geo = l.geo
        left join (select geo, so_id, sum(quantity) quantity from od_so_item group by so_id, geo) qty
		on oso.so_id = qty.so_id and oso.geo = qty.geo
        left join (
          select so_id, geo,
          do_id,
          tracking_code,
          createdate,
          status
          from od_do_new
          where geo = 'VN2'
          ) odn
        on oso.so_id = odn.so_id and oso.geo = odn.geo
        left join (
          with temp_so as (
          SELECT oi_id, osi.geo,
          so_id,
          quantity,
          item_no,
          osi.prod_id,
          pp.name as product_name,
          row_number() over(partition by so_id order by item_no) as item_no_new
          FROM od_so_item osi 
          left join pd_product pp 
          on osi.prod_id = pp.prod_id and osi.geo = pp.geo
          where osi.geo = 'VN2'
          )
          SELECT so_id, geo,
          max((case when item_no_new = 1 then product_name end)) as product1,
          SUM(quantity) no_quantity,
          COUNT(DISTINCT prod_id) as no_product 
          FROM temp_so
          group by so_id, geo
          order by so_id desc
          ) osi 
        on oso.so_id = osi.so_id and oso.geo = osi.geo
        left join (
            select *
            from cf_synonym cs
            where "type" = 'lead status') as cf_lead 
        on l.lead_status = cf_lead.value and l.geo = cf_lead.geo
        left join (
            select *
            from cf_synonym cs
            where "type" = 'sale order status') as cf_so
        on oso.status = cf_so.value and oso.geo = cf_so.geo
        left join (
          select *
          from cf_synonym
          where type = 'delivery order status' and geo = 'VN2'
          ) as cf_do
        on odn.status = cf_do.value and odn.geo = cf_do.geo
        left join (
            select *
            from or_user ou
            where user_type = 'agent') as agent 
        on oso.ag_id = agent.user_id and oso.geo = agent.geo
        left join (
            select *
            from or_user ou
            where user_type = 'agent') as agent_create
        on oso.createby = agent_create.user_id and oso.geo = agent_create.geo
        left join bp_partner p on l.agc_id = p.pn_id and l.geo = p.geo
        left join cp_campaign cam on cam.cp_id = oso.cp_id and cam.geo = oso.geo
        --where date_trunc('month', case when lead_type = 'A' then l.createdate else oso.createdate end) >= date_trunc('month', current_date - interval '5 months')
        --and 
        where l.org_id = 5 -- VN2
        and lead_type = 'A'
        )
        --select lead_id, lead_date, lead_month, network, case when network = 'EW' or network = 'AT' or network = 'ADT' then 'No PubID' else pub end as pub,
        select lead_id, lead_date, lead_month, network, case when network in('EW','AT','ADT','ABT','ARB','CSL','MKR','XXX','PFC','ORG','ORG2',
        		'PIB','MH','MP','IGO','VIC','ODS','DAT','VAL','MIR','NGN','WIL','PD','CTR','U_DOMA','ABG')   
        		then 'No PubID' else pub end as pub, 
        cam_lead, product_name, quantity,  payout,  max_po,
        case when lead_status in ('trash','duplicated') then 1 else null end as trash,
        case when lead_status in ('approved') then 1 else null end as approved,
        case when lead_status in ('approved') and lower(so_status) in ('validated', 'delay') then 1 else null end as validated,
        case when lead_status in ('approved') and so_status in ('validated', 'delay')  and (postback_status = 'approved' or postback_status is null) then 1 else null end as total_approved_postback,
        case when lead_status in ('approved') and so_status in ('validated', 'delay')  and postback_status in ('pending_postback', 'pending_pb') then 1 else null end as total_pending_postback,
        case when lead_status in ('approved') and lower(so_status) in ('validated', 'delay') then amount else null end as amt_validated,
        case when lead_status in ('approved') and lower(so_status) in ('validated', 'delay') and lower(do_status) in ('refund', 'delivered') then 1 else null end as delivered,
        case when lead_status in ('approved') and lower(so_status) in ('validated', 'delay') and lower(do_status) in ('refund', 'delivered') then amount else null end as amt_delivered,
        case when lead_status in ('approved') and lower(so_status) in ('validated', 'delay') and (lower(do_status) not in ('refund', 'delivered', 'reject', 'cancelled') or do_status is null) then 1 else null end as unfinish,
        case when lead_status in ('approved') and lower(so_status) in ('validated', 'delay') and (lower(do_status) not in ('refund', 'delivered', 'reject', 'cancelled') or do_status is null) then amount else null end as amt_unfinish
        from full_merge
    """
    df: pd.DataFrame = extract_from_dwh(query, oltp01_conn)
    df = _transform(df, "VN2")
    return df


@asset(group_name="pub_ads_roi", retry_policy=RetryPolicy(max_retries=3))
def pub_ads_roi_agg_vn4(oltp01_conn: PostgresConnection) -> pd.DataFrame:
    query = f"""
              with full_merge as (
        select l.lead_id,
        lead_type,
        case when prod_name is null or prod_name = '' then product1
          else prod_name
        end as product_name,
        --date_trunc('month',l.createdate) as lead_month,
        date_trunc('month', case when lead_type = 'A' then l.createdate else oso.createdate end) as lead_month,
        date(case when lead_type = 'A' then l.createdate else oso.createdate end) as lead_date,
        cf_lead.name as lead_status,
        date(oso.createdate) as so_date,
        cf_so.name as so_status,
        date(odn.createdate) as do_date,
        cf_do.name as do_status,
        --case when COALESCE(p.shortname, l.agc_code, 'LOYAL CUSTOMER') = 'AFS' then affiliate_id else COALESCE(p.shortname, l.agc_code, 'LOYAL CUSTOMER') end as network,
        coalesce((case when COALESCE(p.shortname, l.agc_code, 'LOYAL CUSTOMER') = 'AFS' then affiliate_id else COALESCE(p.shortname, l.agc_code, 'LOYAL CUSTOMER') end),'No network') as network,
        --case when COALESCE(p.shortname, l.agc_code, 'LOYAL CUSTOMER') = 'AFS' then subid1 else affiliate_id end as pub,
        case when subid1= '' then 'blank'
        	 when subid1 is null then 'No PubID' else
        	case when COALESCE(p.shortname, l.agc_code, 'LOYAL CUSTOMER') in ('AFS', 'OFP') then coalesce(subid1,'No PubID') 
        		else affiliate_id 
        		end 
        	end as pub,
        amount,
        qty.quantity, payout, max_po, l.postback_status,
        cam_lead
        from (
            select cl.org_id, lead_id, cl.geo,
              cl.createdate,
              prod_name,
                agc_id, agc_code, affiliate_id, subid1,
                lead_type,
                lead_status,
                case when lower(prod_name) like '%prosta%id' then 'Fresh HC'  -- 472
		            when lower(prod_name) like '%duramax%th' then 'Fresh ME' -- 567
		            else cam.name
	              end cam_lead,
                coalesce(agent_fc.fullname, agent.fullname) as fc_agent,
                agent.fullname as cl_agent, afs.payout, afs.max_po, cl.postback_status
            from cl_fresh cl
            left join ( select max_po, payout, transaction_id from ods_affscale_conversion where geo = 'VN' ) afs on cl.click_id = afs.transaction_id 
            left join (
                select *
                from or_user ou
                where user_type = 'agent') as agent_fc
        on cl.first_call_by = agent_fc.user_id and cl.geo = agent_fc.geo
        left join (
            select *
            from or_user ou
            where user_type = 'agent') as agent
            on cl.assigned = agent.user_id  and cl.geo = agent.geo
          left join cp_campaign cam on cam.cp_id = cl.cp_id and cam.geo = cl.geo
          where( lower(cam.name) is null or lower(cam.name) not like '%research%' )
          and lower(cl.name) not like'%test%'
          and CASE
                    WHEN cl.lead_status = 4 OR cl.lead_status = 5 AND cl.assigned = 0 THEN 1
                    ELSE 0
                END <> 1
			and cl.org_id = 15 --VN4
            ) as l
        left join (
          select geo, lead_id, so_id, createdate, status, cp_id, amount, ag_id, createby
          from od_sale_order
          ) oso
        on oso.lead_id = l.lead_id and oso.geo = l.geo
        left join (select geo, so_id, sum(quantity) quantity from od_so_item group by so_id, geo) qty
		on oso.so_id = qty.so_id and oso.geo = qty.geo
        left join (
          select so_id, geo,
          do_id,
          tracking_code,
          createdate,
          status
          from od_do_new
          where geo = 'VN4'
          ) odn
        on oso.so_id = odn.so_id and oso.geo = odn.geo
        left join (
          with temp_so as (
          SELECT oi_id, osi.geo,
          so_id,
          quantity,
          item_no,
          osi.prod_id,
          pp.name as product_name,
          row_number() over(partition by so_id order by item_no) as item_no_new
          FROM od_so_item osi 
          left join pd_product pp 
          on osi.prod_id = pp.prod_id and osi.geo = pp.geo
          where osi.geo = 'VN4'
          )
          SELECT so_id, geo,
          max((case when item_no_new = 1 then product_name end)) as product1,
          SUM(quantity) no_quantity,
          COUNT(DISTINCT prod_id) as no_product 
          FROM temp_so
          group by so_id, geo
          order by so_id desc
          ) osi 
        on oso.so_id = osi.so_id and oso.geo = osi.geo
        left join (
            select *
            from cf_synonym cs
            where "type" = 'lead status') as cf_lead 
        on l.lead_status = cf_lead.value and l.geo = cf_lead.geo
        left join (
            select *
            from cf_synonym cs
            where "type" = 'sale order status') as cf_so
        on oso.status = cf_so.value and oso.geo = cf_so.geo
        left join (
          select *
          from cf_synonym
          where type = 'delivery order status' and geo = 'VN4'
          ) as cf_do
        on odn.status = cf_do.value and odn.geo = cf_do.geo
        left join (
            select *
            from or_user ou
            where user_type = 'agent'  and org_id = 15) as agent 
        on oso.ag_id = agent.user_id and oso.geo = agent.geo
        left join (
            select *
            from or_user ou
            where user_type = 'agent'  and org_id = 15) as agent_create
        on oso.createby = agent_create.user_id and oso.geo = agent_create.geo
        left join bp_partner p on l.agc_id = p.pn_id and l.geo = p.geo
        left join cp_campaign cam on cam.cp_id = oso.cp_id and cam.geo = oso.geo
        --where date_trunc('month', case when lead_type = 'A' then l.createdate else oso.createdate end) >= date_trunc('month', current_date - interval '5 months')
        --and 
        where l.org_id = 15 -- VN4
        and lead_type = 'A'
        )
        --select lead_id, lead_date, lead_month, network, case when network = 'EW' or network = 'AT' or network = 'ADT' then 'No PubID' else pub end as pub,
        select lead_id, lead_date, lead_month, network, case when network in('EW','AT','ADT','ABT','ARB','CSL','MKR','XXX','PFC','ORG','ORG2',
        		'PIB','MH','MP','IGO','VIC','ODS','DAT','VAL','MIR','NGN','WIL','PD','CTR','U_DOMA','ABG')   
        		then 'No PubID' else pub end as pub, 
        cam_lead, product_name, quantity,  payout,  max_po,
        case when lead_status in ('trash','duplicated') then 1 else null end as trash,
        case when lead_status in ('approved') then 1 else null end as approved,
        case when lead_status in ('approved') and lower(so_status) in ('validated', 'delay') then 1 else null end as validated,
        case when lead_status in ('approved') and so_status in ('validated', 'delay')  and (postback_status = 'approved' or postback_status is null) then 1 else null end as total_approved_postback,
        case when lead_status in ('approved') and so_status in ('validated', 'delay')  and postback_status in ('pending_postback', 'pending_pb') then 1 else null end as total_pending_postback,
        case when lead_status in ('approved') and lower(so_status) in ('validated', 'delay') then amount else null end as amt_validated,
        case when lead_status in ('approved') and lower(so_status) in ('validated', 'delay') and lower(do_status) in ('refund', 'delivered') then 1 else null end as delivered,
        case when lead_status in ('approved') and lower(so_status) in ('validated', 'delay') and lower(do_status) in ('refund', 'delivered') then amount else null end as amt_delivered,
        case when lead_status in ('approved') and lower(so_status) in ('validated', 'delay') and (lower(do_status) not in ('refund', 'delivered', 'reject', 'cancelled') or do_status is null) then 1 else null end as unfinish,
        case when lead_status in ('approved') and lower(so_status) in ('validated', 'delay') and (lower(do_status) not in ('refund', 'delivered', 'reject', 'cancelled') or do_status is null) then amount else null end as amt_unfinish
        from full_merge
    """
    df: pd.DataFrame = extract_from_dwh(query, oltp01_conn)
    df = _transform(df, "VN4")
    return df


@asset(group_name="pub_ads_roi", retry_policy=RetryPolicy(max_retries=3))
def pub_ads_roi_agg_th2(oltp01_conn: PostgresConnection) -> pd.DataFrame:
    query = f"""
        with full_merge as (
        select l.lead_id, l.org_id, l.geo,
        lead_type,
        case when prod_name is null or prod_name = '' then product1
          else prod_name
        end as product_name,
        --date_trunc('month',l.createdate) as lead_month,
        date_trunc('month', case when lead_type = 'A' then l.createdate else oso.createdate end) as lead_month,
        date(case when lead_type = 'A' then l.createdate else oso.createdate end) as lead_date,
        cf_lead.name as lead_status,
        date(oso.createdate) as so_date,
        cf_so.name as so_status,
        date(odn.createdate) as do_date,
        cf_do.name as do_status,
        --case when COALESCE(p.shortname, l.agc_code, 'LOYAL CUSTOMER') = 'AFS' then affiliate_id else COALESCE(p.shortname, l.agc_code, 'LOYAL CUSTOMER') end as network,
        coalesce((case when COALESCE(p.shortname, l.agc_code, 'LOYAL CUSTOMER') = 'AFS' then affiliate_id else COALESCE(p.shortname, l.agc_code, 'LOYAL CUSTOMER') end),'No network') as network,
        --case when COALESCE(p.shortname, l.agc_code, 'LOYAL CUSTOMER') = 'AFS' then subid1 else affiliate_id end as pub,
        case when subid1= '' then 'blank'
        	 when subid1 is null then 'No PubID' else
        	case when COALESCE(p.shortname, l.agc_code, 'LOYAL CUSTOMER') in ('AFS', 'OFP') then coalesce(subid1,'No PubID') 
        		else affiliate_id 
        		end 
        	end as pub,
        amount,
        qty.quantity, payout, max_po, l.postback_status,
        cam_lead
        from (
            select cl.org_id, cl.lead_id, cl.geo,
              cl.createdate,
              prod_name,
                agc_id, agc_code, affiliate_id, subid1,
                lead_type,
                lead_status,
                case when lower(prod_name) like '%prosta%id' then 'Fresh HC'  -- 472
		            when lower(prod_name) like '%duramax%th' then 'Fresh ME' -- 567
		            else cam.name
	            end cam_lead,
                coalesce(agent_fc.fullname, agent.fullname) as fc_agent,
                agent.fullname as cl_agent, afs.payout, afs.max_po, cl.postback_status
            from cl_fresh cl
            left join ( select max_po, payout, transaction_id from ods_affscale_conversion where geo = 'TH' ) afs on cl.click_id = afs.transaction_id 
            left join (
                select *
                from or_user ou
                where user_type = 'agent') as agent_fc
            on cl.first_call_by = agent_fc.user_id and cl.geo = agent_fc.geo
            left join (
                select *
                from or_user ou
                where user_type = 'agent') as agent
            on cl.assigned = agent.user_id and cl.geo = agent.geo
          left join cp_campaign cam on cam.cp_id = cl.cp_id and cam.geo = cl.geo
          where( lower(cam.name) is null or lower(cam.name) not like '%research%' )
          and lower(cl.name) not like'%test%'
          and CASE
                    WHEN cl.lead_status = 4 OR cl.lead_status = 5 AND cl.assigned = 0 THEN 1
                    ELSE 0
                END <> 1
          and cl.org_id = 12 --TH2
            ) as l
        left join (
          select geo, lead_id, so_id, createdate, status, cp_id, amount, ag_id, createby
          from od_sale_order
          ) oso
        on oso.lead_id = l.lead_id and oso.geo = l.geo
        left join (select geo, so_id, sum(quantity) quantity from od_so_item group by so_id, geo) qty
		on oso.so_id = qty.so_id and oso.geo = qty.geo
        left join (
          select so_id, geo,
          do_id,
          tracking_code,
          createdate,
          status
          from od_do_new) odn
        on oso.so_id = odn.so_id and oso.geo = odn.geo
        left join (
          with temp_so as (
          SELECT oi_id, osi.geo,
          so_id,
          quantity,
          item_no,
          osi.prod_id,
          pp.name as product_name,
          row_number() over(partition by so_id order by item_no) as item_no_new
          FROM od_so_item osi 
          left join pd_product pp 
          on osi.prod_id = pp.prod_id and osi.geo = pp.geo
          )
          SELECT so_id, geo,
          max((case when item_no_new = 1 then product_name end)) as product1,
          SUM(quantity) no_quantity,
          COUNT(DISTINCT prod_id) as no_product 
          FROM temp_so
          group by so_id, geo
          order by so_id desc
          ) osi 
        on oso.so_id = osi.so_id and oso.geo = osi.geo
        left join (
            select *
            from cf_synonym cs
            where "type" = 'lead status') as cf_lead
        on l.lead_status = cf_lead.value and l.geo = cf_lead.geo
        left join (
            select *
            from cf_synonym cs
            where "type" = 'sale order status') as cf_so
        on oso.status = cf_so.value and oso.geo = cf_so.geo
        left join (
          select *
          from cf_synonym
          where type = 'delivery order status'
          ) as cf_do
        on odn.status = cf_do.value and odn.geo = cf_do.geo
        left join (
            select *
            from or_user ou
            where user_type = 'agent') as agent
        on oso.ag_id = agent.user_id and oso.geo = agent.geo
        left join (
            select *
            from or_user ou
            where user_type = 'agent') as agent_create
        on oso.createby = agent_create.user_id and oso.geo = agent_create.geo
        left join bp_partner p on l.agc_id = p.pn_id and l.geo = p.geo
        left join cp_campaign cam on cam.cp_id = oso.cp_id and cam.geo = oso.geo
        --where date_trunc('month', case when lead_type = 'A' then l.createdate else oso.createdate end) >= date_trunc('month', current_date - interval '5 months')
        --and 
        where l.org_id = 12 -- 12
        and lead_type = 'A'
        )
        --select lead_id, lead_date, lead_month, network, case when network = 'EW' or network = 'AT' or network = 'ADT' then 'No PubID' else pub end as pub,
        select lead_id, lead_date, lead_month, network, case when (network in('EW','AT','ADT','ABT','ARB','CSL','MKR','XXX','PFC','ORG','ORG2',
        		'PIB','MH','MP','IGO','VIC','ODS','DAT','VAL','MIR','NGN','WIL','PD','CTR','U_DOMA','ABG')) or (network in('U_RUS') and org_id = 12) -- 12
        		then 'No PubID' else pub end as pub,
        cam_lead, product_name, quantity, payout,  max_po,
        case when lead_status in ('trash','duplicated') then 1 else null end as trash,
        case when lead_status in ('approved') then 1 else null end as approved,
        case when lead_status in ('approved') and so_status in ('validated', 'delay') then 1 else null end as validated,
        case when lead_status in ('approved') and so_status in ('validated', 'delay')  and (postback_status = 'approved' or postback_status is null) then 1 else null end as total_approved_postback,
        case when lead_status in ('approved') and so_status in ('validated', 'delay')  and postback_status in ('pending_postback', 'pending_pb') then 1 else null end as total_pending_postback,
        case when lead_status in ('approved') and so_status in ('validated', 'delay') then amount else null end as amt_validated,
        case when lead_status in ('approved') and so_status in ('validated', 'delay') and do_status in ('refund', 'delivered') then 1 else null end as delivered,
        case when lead_status in ('approved') and so_status in ('validated', 'delay') and do_status in ('refund', 'delivered') then amount else null end as amt_delivered,
        case when lead_status in ('approved') and so_status in ('validated', 'delay') and (lower(do_status) not in ('refund', 'delivered', 'returned', 'cancel') or do_status is null) then 1 else null end as unfinish,
        case when lead_status in ('approved') and so_status in ('validated', 'delay') and (lower(do_status) not in ('refund', 'delivered', 'returned', 'cancel') or do_status is null) then amount else null end as amt_unfinish
        from full_merge
    """
    df: pd.DataFrame = extract_from_dwh(query, oltp01_conn)
    df = _transform(df, "TH")
    return df


@asset(group_name="pub_ads_roi", retry_policy=RetryPolicy(max_retries=3))
def pub_ads_roi_agg_th(oltp01_conn: PostgresConnection) -> pd.DataFrame:
    query = f"""
    with full_merge as (
        select l.lead_id, l.org_id, l.geo,
        lead_type,
        case when prod_name is null or prod_name = '' then product1
          else prod_name
        end as product_name,
        --date_trunc('month',l.createdate) as lead_month,
        date_trunc('month', case when lead_type = 'A' then l.createdate else oso.createdate end) as lead_month,
        date(case when lead_type = 'A' then l.createdate else oso.createdate end) as lead_date,
        cf_lead.name as lead_status,
        date(oso.createdate) as so_date,
        cf_so.name as so_status,
        date(odn.createdate) as do_date,
        cf_do.name as do_status,
        --case when COALESCE(p.shortname, l.agc_code, 'LOYAL CUSTOMER') = 'AFS' then affiliate_id else COALESCE(p.shortname, l.agc_code, 'LOYAL CUSTOMER') end as network,
        coalesce((case when COALESCE(p.shortname, l.agc_code, 'LOYAL CUSTOMER') = 'AFS' then affiliate_id else COALESCE(p.shortname, l.agc_code, 'LOYAL CUSTOMER') end),'No network') as network,
        --case when COALESCE(p.shortname, l.agc_code, 'LOYAL CUSTOMER') = 'AFS' then subid1 else affiliate_id end as pub,
        case when subid1= '' then 'blank'
        	 when subid1 is null then 'No PubID' else
        	case when COALESCE(p.shortname, l.agc_code, 'LOYAL CUSTOMER') in ('AFS', 'OFP') then coalesce(subid1,'No PubID') 
        		else affiliate_id 
        		end 
        	end as pub,
        amount,
        qty.quantity,payout, max_po, l.postback_status,
        cam_lead
        from (
            select cl.org_id, cl.lead_id, cl.geo,
              cl.createdate,
              prod_name,
                agc_id, agc_code, affiliate_id, subid1,
                lead_type,
                lead_status,
                case when lower(prod_name) like '%prosta%id' then 'Fresh HC'  -- 472
		            when lower(prod_name) like '%duramax%th' then 'Fresh ME' -- 567
		            else cam.name
	              end cam_lead,
                coalesce(agent_fc.fullname, agent.fullname) as fc_agent,
                agent.fullname as cl_agent , afs.payout, afs.max_po, cl.postback_status
            from cl_fresh cl
            left join ( select max_po, payout, transaction_id from ods_affscale_conversion where geo = 'TH' ) afs on cl.click_id = afs.transaction_id 
            left join (
                select *
                from or_user ou
                where user_type = 'agent' and org_id = 10) as agent_fc
            on cl.first_call_by = agent_fc.user_id and cl.geo = agent_fc.geo
            left join (
                select *
                from or_user ou
                where user_type = 'agent' and org_id = 10) as agent
            on cl.assigned = agent.user_id and cl.geo = agent.geo
          left join cp_campaign cam on cam.cp_id = cl.cp_id and cam.geo = cl.geo
          where( lower(cam.name) is null or lower(cam.name) not like '%research%' )
          and lower(cl.name) not like'%test%'
          and CASE
                    WHEN cl.lead_status = 4 OR cl.lead_status = 5 AND cl.assigned = 0 THEN 1
                    ELSE 0
                END <> 1
          and cl.org_id = 10 --TH
            ) as l
        left join (
          select geo, lead_id, so_id, createdate, status, cp_id, amount, ag_id, createby, org_id
          from od_sale_order
          where org_id = 10
          ) oso
        on oso.lead_id = l.lead_id and oso.geo = l.geo
        left join (select geo, so_id, sum(quantity) quantity from od_so_item where geo = 'TH' group by so_id, geo) qty
		on oso.so_id = qty.so_id and oso.geo = qty.geo
        left join (
          select so_id, geo,
          do_id,
          tracking_code,
          createdate,
          status
          from od_do_new
          where geo = 'TH'
          ) odn
        on oso.so_id = odn.so_id and oso.geo = odn.geo
        left join (
          with temp_so as (
          SELECT oi_id, osi.geo,
          so_id,
          quantity,
          item_no,
          osi.prod_id,
          pp.name as product_name,
          row_number() over(partition by so_id order by item_no) as item_no_new
          FROM od_so_item osi 
          left join pd_product pp 
          on osi.prod_id = pp.prod_id and osi.geo = pp.geo
          where osi.geo = 'TH'
          )
          SELECT so_id, geo,
          max((case when item_no_new = 1 then product_name end)) as product1,
          SUM(quantity) no_quantity,
          COUNT(DISTINCT prod_id) as no_product 
          FROM temp_so
          group by so_id, geo
          order by so_id desc
          ) osi 
        on oso.so_id = osi.so_id and oso.geo = osi.geo
        left join (
            select *
            from cf_synonym cs
            where "type" = 'lead status' and geo = 'TH') as cf_lead
        on l.lead_status = cf_lead.value and l.geo = cf_lead.geo
        left join (
            select *
            from cf_synonym cs
            where "type" = 'sale order status' and geo = 'TH') as cf_so
        on oso.status = cf_so.value and oso.geo = cf_so.geo
        left join (
          select *
          from cf_synonym
          where type = 'delivery order status' and geo = 'TH'
          ) as cf_do
        on odn.status = cf_do.value and odn.geo = cf_do.geo
        left join (
            select *
            from or_user ou
            where user_type = 'agent' and geo = 'TH'
            ) as agent
        on oso.ag_id = agent.user_id and oso.geo = agent.geo
        left join (
            select *
            from or_user ou
            where user_type = 'agent' and geo = 'TH'
            ) as agent_create
        on oso.createby = agent_create.user_id and oso.geo = agent_create.geo
        left join bp_partner p on l.agc_id = p.pn_id and l.geo = p.geo
        left join cp_campaign cam on cam.cp_id = oso.cp_id and cam.geo = oso.geo
        --where date_trunc('month', case when lead_type = 'A' then l.createdate else oso.createdate end) >= date_trunc('month', current_date - interval '5 months')
        --and 
        where l.org_id = 10 -- TH
        and lead_type = 'A'
        )
        --select lead_id, lead_date, lead_month, network, case when network = 'EW' or network = 'AT' or network = 'ADT' then 'No PubID' else pub end as pub,
        select lead_id, lead_date, lead_month, network, case when (network in('EW','AT','ADT','ABT','ARB','CSL','MKR','XXX','PFC','ORG','ORG2',
        		'PIB','MH','MP','IGO','VIC','ODS','DAT','VAL','MIR','NGN','WIL','PD','CTR','U_DOMA','ABG')) or (network in('U_RUS') and org_id = 12) -- 12
        		then 'No PubID' else pub end as pub,
        cam_lead, product_name, quantity, payout, max_po,
        case when lead_status in ('trash','duplicated') then 1 else null end as trash,
        case when lead_status in ('approved') then 1 else null end as approved,
        case when lead_status in ('approved') and so_status in ('validated', 'delay') then 1 else null end as validated,
        case when lead_status in ('approved') and so_status in ('validated', 'delay')  and (postback_status = 'approved' or postback_status is null) then 1 else null end as total_approved_postback,
        case when lead_status in ('approved') and so_status in ('validated', 'delay')  and postback_status in ('pending_postback', 'pending_pb') then 1 else null end as total_pending_postback,
        case when lead_status in ('approved') and so_status in ('validated', 'delay') then amount else null end as amt_validated,
        case when lead_status in ('approved') and so_status in ('validated', 'delay') and do_status in ('refund', 'delivered') then 1 else null end as delivered,
        case when lead_status in ('approved') and so_status in ('validated', 'delay') and do_status in ('refund', 'delivered') then amount else null end as amt_delivered,
        case when lead_status in ('approved') and so_status in ('validated', 'delay') and (lower(do_status) not in ('refund', 'delivered', 'returned', 'cancel') or do_status is null) then 1 else null end as unfinish,
        case when lead_status in ('approved') and so_status in ('validated', 'delay') and (lower(do_status) not in ('refund', 'delivered', 'returned', 'cancel') or do_status is null) then amount else null end as amt_unfinish
        from full_merge
    """
    df: pd.DataFrame = extract_from_dwh(query, oltp01_conn)
    df = _transform(df, "TH2")
    return df


@asset(group_name="pub_ads_roi")
def pub_ads_roi_agg_all(
    pub_ads_roi_agg_vn: pd.DataFrame,
    pub_ads_roi_agg_my: pd.DataFrame,
    pub_ads_roi_agg_ph: pd.DataFrame,
    pub_ads_roi_agg_id: pd.DataFrame,
    pub_ads_roi_agg_vn2: pd.DataFrame,
    pub_ads_roi_agg_vn4: pd.DataFrame,
    pub_ads_roi_agg_th: pd.DataFrame,
    pub_ads_roi_agg_th2: pd.DataFrame,
) -> pd.DataFrame:
    full_agg = pd.concat(
        [
            pub_ads_roi_agg_vn,
            pub_ads_roi_agg_my,
            pub_ads_roi_agg_ph,
            pub_ads_roi_agg_id,
            pub_ads_roi_agg_vn2,
            pub_ads_roi_agg_vn4,
            pub_ads_roi_agg_th,
            pub_ads_roi_agg_th2,
        ]
    )
    full_agg[
        [
            "quantity",
            "trash",
            "cpl_lead",
            "approved",
            "validated",
            "total_approved_postback",
            "total_pending_postback",
            "delivered",
            "unfinish",
            "validated_hist",
            "delivered_hist",
        ]
    ] = full_agg[
        [
            "quantity",
            "trash",
            "cpl_lead",
            "approved",
            "validated",
            "total_approved_postback",
            "total_pending_postback",
            "delivered",
            "unfinish",
            "validated_hist",
            "delivered_hist",
        ]
    ].fillna(
        0
    )
    full_agg = full_agg.astype(
        {
            "quantity": int,
            "trash": int,
            "cpl_lead": int,
            "approved": int,
            "validated": int,
            "total_approved_postback": int,
            "total_pending_postback": int,
            "unfinish": int,
            "delivered": int,
            "validated_hist": int,
            "delivered_hist": int,
        }
    )
    full_agg["last_update"] = datetime.datetime.now().strftime("%Y-%m-%d, %H:%M")

    # # create index column
    # full_agg.insert(0,'index',np.arange(len(full_agg)))

    # convert NaN values into None (Null when imported to Postgre)
    # full_agg = full_agg.where(pd.notnull(full_agg), None)
    full_agg = full_agg.fillna(np.nan).replace([np.nan], [None])

    return full_agg[
        [
            "lead_date",
            "network",
            "pub",
            "cam_lead",
            "product_name",
            "total_lead",
            "quantity",
            "trash",
            "approved",
            "validated",
            "amt_validated",
            "delivered",
            "amt_delivered",
            "unfinish",
            "amt_unfinish",
            "payout",
            "max_po",
            "delivered_hist",
            "validated_hist",
            "geo",
            "last_update",
            "cpl_lead",
            "total_approved_postback",
            "total_pending_postback",
        ]
    ]


class CopyConfig(Config):
    table_name: str = "ads_roi_global"


@asset(group_name="pub_ads_roi")
def load_pub_ads_roi_to_postgres(
    pub_ads_roi_agg_all: pd.DataFrame,
    oltp01_conn: PostgresConnection,
    config: CopyConfig,
) -> MaterializeResult:
    df = pub_ads_roi_agg_all
    buffer = io.BytesIO()
    df.to_csv(buffer, index=False, encoding="utf-8")
    buffer.seek(0)
    with oltp01_conn.get_connection() as connection:
        with connection.cursor() as cursor:
            table_name = config.table_name
            delete_query = f"delete from {table_name}"
            cursor.execute(delete_query)
            with cursor.copy(
                f"""copy "{table_name}" from stdin with (format csv, header)"""
            ) as copy:
                copy.write(buffer.read())
    pass


update_pub_ads_roi_job = define_asset_job(
    name="update_pub_ads_roi_job",
    selection=AssetSelection.assets(
        pub_ads_roi_agg_vn,
        pub_ads_roi_agg_my,
        pub_ads_roi_agg_ph,
        pub_ads_roi_agg_id,
        pub_ads_roi_agg_vn2,
        pub_ads_roi_agg_vn4,
        pub_ads_roi_agg_th,
        pub_ads_roi_agg_th2,
        pub_ads_roi_agg_all,
        load_pub_ads_roi_to_postgres,
    ),
    config={
        "execution": {
            "config": {
                "multiprocess": {
                    "max_concurrent": 1,
                },
            }
        }
    },
)

update_pub_ads_roi_schedule = ScheduleDefinition(
    job=update_pub_ads_roi_job,
    cron_schedule=["30 6,10,16 * * *", "0 9 * * *", "45 7 * * * "],
    execution_timezone="Asia/Bangkok",
)
