from datetime import datetime
import psycopg2 as pg
import os    
import time                                              
from dagster import (
    asset,
    define_asset_job,
    ScheduleDefinition,
)
TIMEZONE = os.getenv("DAGSTER_TIMEZONE")

@asset(group_name="realtime_auto_bot")
def refresh_realtime_bd_master():
    # chat_id = Neyu_test_bot
    print("Start refreshing...")
    # bot.send_message(chat_id, text = 'Start REFRESHING realtime_resell_master...')
    print("Establishing connection to DWH...")
    conn = pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG"))
    cur = conn.cursor()
    cur.execute("SET statement_timeout = 0")
    conn.commit()
    print("REFRESH MATERIALIZED VIEW realtime_bd_master_temp") 
    cur.execute("refresh materialized view CONCURRENTLY realtime_bd_master_temp with data")
    conn.commit()
    print("Finish REFRESHING realtime_bd_master_temp")
    cur.close()
    conn.close()
    print("-Finish refreshing realtime_bd_master_temp")



refresh_realtime_bd_master_job = define_asset_job(
    "refresh_realtime_bd_master_job",
    selection=[
        refresh_realtime_bd_master
    ],
)

refresh_realtime_bd_master_schedule = ScheduleDefinition(
    job=refresh_realtime_bd_master_job,
    cron_schedule="*/2 * * * *",
    execution_timezone=TIMEZONE,
    tags={"dagster/priority": "3"},
)


