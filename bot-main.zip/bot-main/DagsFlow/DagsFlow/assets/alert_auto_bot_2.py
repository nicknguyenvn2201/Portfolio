import numpy as np
import pandas as pd
from datetime import datetime
import psycopg2 as pg
import psycopg2.extras
import os                                                         
import requests
import datetime
from dagster import (
    asset,
    define_asset_job,
    ScheduleDefinition,
)


TIMEZONE = os.getenv("DAGSTER_TIMEZONE")



def count_resell_forecast_view():
    q = f"""
        select count(*) from resell_forecast_view
            """
    conn = pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG"))
    cur = conn.cursor()
    data = pd.read_sql_query(q,conn)
    conn.commit()
    cur.close()
    conn.close()

    return data # data_length

@asset(group_name="auto_bot_2")
def refresh_resell_forecast_view():
    print("Establishing connection to DWH...")
    conn = pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG"))
    cur = conn.cursor()
    cur.execute("SET statement_timeout = 0")
    conn.commit()

    print("REFRESHING resell_forecast_view_temp") 
    cur.execute("REFRESH MATERIALIZED VIEW resell_forecast_view_temp")
    conn.commit()

    print("Finish REFRESHING resell_forecast_view_temp")
    cur.close()
    conn.close()



def count_v_sale_master():
    q = f"""
        select count(*) from v_sale_master
            """
    conn = pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG"))
    cur = conn.cursor()
    data = pd.read_sql_query(q,conn)
    conn.commit()
    cur.close()
    conn.close()

    return data # data_length

@asset(group_name="auto_bot_2")
def refresh_v_sale_master():
        print("Start refreshing...")
        print("Establishing connection to DWH...")
        conn = pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG"))
        cur = conn.cursor()
        cur.execute("SET statement_timeout = 0")
        conn.commit()

        print("REFRESHING v_sale_master") 
        cur.execute("REFRESH MATERIALIZED VIEW v_sale_master")
        conn.commit()

        print("Finish REFRESHING v_sale_master")
        cur.close()
        conn.close()




def count_cs_vn_view():
    q = f"""
        select count(*) from cs_vn_view
            """
    conn = pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG"))
    cur = conn.cursor()
    data = pd.read_sql_query(q,conn)
    conn.commit()
    cur.close()
    conn.close()

    return data # data_length

@asset(group_name="auto_bot_2")
def refresh_cs_vn_view():
    print("Start refreshing...")
    print("Establishing connection to DWH...")
    conn = pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG"))
    cur = conn.cursor()
    cur.execute("SET statement_timeout = 0")
    conn.commit()

    print("REFRESHING cs_vn_view_temp") 
    cur.execute("REFRESH MATERIALIZED VIEW cs_vn_view_temp")
    conn.commit()

    print("Finish REFRESHING cs_vn_view_temp")
    cur.close()
    conn.close()



#---------------------------------------------------------------------------------------------------------------------------
# VN Ops export data
@asset(group_name="auto_bot_2")
def fresh_indicators():
    q = f"""
--Fresh geo VN
with a as (
select 
agname, product_name as product, sourcename, subid_fnl, date_used::date as "Date"
,sum(leads) as Leads
,case when sum(leads) = 0 then null else sum(approve)/sum(leads) end as "AR%"
,case when sum(leads) = 0 then null else sum(total_do)/sum(leads) end as "AR_QA%"
,case when sum(leads) = 0 then null else sum(trash)/sum(leads) end as "Trash%"
,sum(delivered::float) as Delivered 
,sum(total_do) as "Total orders"
,case when sum(validated) = 0 then null else sum(delivered::float)/sum(validated) end as "DR%"
,case when sum(total_do) = 0 then null else sum(total_intransit)/sum(total_do) end as "intransit%" 
,case when sum(total_do) = 0 then null else sum(cancelled)/sum(total_do) end as "cancel%"
,case when sum(total_do) = 0 then null else sum(rejected::float)/sum(total_do) end as "return%"
,case when sum(total_do) = 0 then null else sum(other_deli)/sum(total_do) end as "Other_deli%" 
,case when sum(validated) = 0 then null else sum(validated_amount)/sum(validated) end as "AOV_val"
,case when sum(delivered::float) = 0 then null else sum(delivered_amount)/sum(delivered::float) end as "AOV_deli"
,case when sum(delivered_qty) = 0 then null else sum(delivered_amount)/sum(delivered_qty) end as "Price"  
,case when sum(validated_qty) = 0 then null else sum(validated_amount)/sum(validated_qty) end as "Price_val"
,sum(delivered_amount) as "Amount delivered" 
,sum(validated_amount) as "Amount validated"
from dareport.cmd_dim_finance 
where "Geo" = 'VN' and leadtype = 'A' and date_used::date >= '2022-07-01' and date_used::date <= current_date 
group by date_used::date, agname, product_name, sourcename, subid_fnl 
)
select 
agname, product, sourcename, subid_fnl, "Date", Leads, "AR%", "AR_QA%", "Trash%", Delivered, "Total orders",
"DR%", "intransit%", "cancel%", "return%", "Other_deli%", "AOV_val", "AOV_deli"
,case when "Price" = 0 then null else "AOV_deli"/"Price" end as "Upsell_deli"
,case when "Price_val" = 0 then null else "AOV_val"/"Price_val" end as "Upsell"
,"Amount delivered", "Amount validated"
from a
    """
    conn = pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG"))
    cur = conn.cursor()
    data = pd.read_sql_query(q,conn)
    conn.commit()
    cur.close()
    conn.close()
    return data



@asset(group_name="auto_bot_2")
def resell_indicators():
    q = f"""
--Resell geo VN
with a as (
select
agname, product_name as product, sourcename, date_used::date as "Date"
,sum(delivered::float) as Delivered 
,sum(total_intransit) as Delivering
,sum(total_do) as "Total orders"
,case when sum(validated) = 0 then null else sum(delivered::float)/sum(validated) end as "DR%"
,case when sum(total_do) = 0 then null else sum(total_intransit)/sum(total_do) end as "intransit%"
,case when sum(total_do) = 0 then null else sum(cancelled::float)/sum(total_do) end as "cancel%"
,case when sum(total_do) = 0 then null else sum(rejected::float)/sum(total_do) end as "return%"
,case when sum(total_do) = 0 then null else sum(other_deli)/sum(total_do) end as "Other_deli%"
,case when sum(validated) = 0 then null else sum(validated_amount)/sum(validated) end as "AOV_val"
,case when sum(delivered::float) = 0 then null else sum(delivered_amount)/sum(delivered::float) end as "AOV_deli"
,case when sum(delivered_qty) = 0 then null else sum(delivered_amount)/sum(delivered_qty) end as "Price"
,case when sum(validated_qty) = 0 then null else sum(validated_amount)/sum(validated_qty) end as "Price_val"
,sum(delivered_amount) as "Amount delivered"
,sum(validated_amount) as "Amount validated"
from dareport.cmd_dim_finance 
where "Geo" = 'VN' and leadtype = 'M' and date_used::date >= '2022-07-01' and date_used::date <= current_date 
group by date_used::date, agname, product_name, sourcename
)
select agname, product, sourcename, "Date", Delivered, Delivering, "Total orders", "DR%", "intransit%", "cancel%", "return%",
"Other_deli%", "AOV_val", "AOV_deli"
,case when "Price" = 0 then null else "AOV_deli"/"Price" end as "Upsell_deli"
,case when "Price_val" = 0 then null else "AOV_val"/"Price_val" end as "Upsell"
,"Price", "Price_val", "Amount delivered", "Amount validated"
from a
    """
    try: 
        conn = pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG"))
        cur = conn.cursor()
        data = pd.read_sql_query(q,conn)
        conn.commit()
        cur.close()
        conn.close()
        return data
    except ZeroDivisionError: 
        return 0

# -------------------------------------------------------------------------------------------------------------------------------------------------
# Finance - update data forecast - %intransit to delivered
@asset(group_name="auto_bot_2")
def load_data_forecast():
    q = """
        with vn_fresh as (
		select cf.geo,
		cf.createdate::date date_used,
		cf.lead_id,
		cfs.name lead_status,
		oso.so_id,
		cfs2.name order_status,
		ldm.ma_don_goc do_code,
		lower(status_transport) delivery_status
		from (select geo,lead_type,createdate, lead_status, lead_id from cl_fresh where geo = 'VN'
		and createdate >= current_date - 25
		and lead_type = 'A'
		) cf
		left join (select lead_id, so_id, status 
		from 
		(
		select geo,lead_id, so_id, status,
		sum(case when status in (43, 357) then 1 else null end) over (partition by lead_id) validated_rn,
		row_number() over (partition by lead_id order by createdate desc) rn,
		case when row_number() over (partition by lead_id order by createdate desc) = 1 
		and sum(case when status in (43, 357) then 1 else null end) over (partition by lead_id) > 0 
		and status not in (43, 357)
		then 2 
		when row_number() over (partition by lead_id order by createdate desc) <> 1 
		and status in (43, 357) then 1
		else row_number() over (partition by lead_id order by createdate desc) end final_rn
		from od_sale_order oso 
		where status <> 46
		and geo = 'VN'
		) a
		where final_rn = 1
		) oso on cf.lead_id = oso.lead_id
		left join (select * from cf_synonym where type = 'lead status' and geo = 'VN') cfs on cf.lead_status = cfs.value 
		left join (
		select created_date, ma_don_hang, status_transport,ma_don_goc
		from (select created_date::date, ma_don_hang, status_transport, ma_don_goc,
		row_number() over (partition by ma_don_hang order by created_date desc) rn
		from log_data_main where status_transport <> 'Unassigned') a
		where rn = 1
		) ldm on oso.so_id = ldm.ma_don_hang::int
		left join (select * from cf_synonym where type = 'sale order status' and geo = 'VN') cfs2 on oso.status = cfs2.value 
), indo_fresh as 
(
		select cf.geo,
		cf.createdate::date date_used,
		cf.lead_id,
		cfs.name lead_status,
		oso.so_id,
		cfs2.name order_status,
		odn.do_code do_code,
		cfs3.name delivery_status
		from (select geo,lead_type,createdate, lead_status, lead_id from cl_fresh where geo = 'ID'
		and createdate >= current_date - 45
		and lead_type = 'A'
		) cf
		left join (select lead_id, so_id, status 
		from 
		(select geo,lead_id, so_id, status,
		sum(case when status in (43, 357) then 1 else null end) over (partition by lead_id) validated_rn,
		row_number() over (partition by lead_id order by createdate desc) rn,
		case when row_number() over (partition by lead_id order by createdate desc) = 1 
		and sum(case when status in (43, 357) then 1 else null end) over (partition by lead_id) > 0 
		and status not in (43, 357)
		then 2 
		when row_number() over (partition by lead_id order by createdate desc) <> 1 
		and status in (43, 357) then 1
		else row_number() over (partition by lead_id order by createdate desc) end final_rn
		from od_sale_order oso 
		where status <> 46
		and geo = 'ID') a
		where final_rn = 1
		) oso on cf.lead_id = oso.lead_id
		left join (select * from cf_synonym where type = 'lead status' and geo = 'ID') cfs on cf.lead_status = cfs.value 
		left join (
		select so_id, status,do_code
		from (select createdate::date, so_id, status,do_code,
		row_number() over (partition by so_id order by createdate desc) rn
		from od_do_new
		where geo = 'ID') a
		where rn = 1
		) odn on oso.so_id = odn.so_id
		left join (select * from cf_synonym where type = 'sale order status' and geo = 'ID') cfs2 on oso.status = cfs2.value 
		left join (select * from cf_synonym where type = 'delivery order status' and geo = 'ID') cfs3 on odn.status = cfs3.value
), th_fresh as 
(
		select 'TH' as geo,
		cf.createdate::date date_used,
		cf.lead_id,
		cfs.name lead_status,
		oso.so_id,
		cfs2.name order_status,
		odn.do_code do_code,
		cfs3.name delivery_status
		from (select geo,lead_type,createdate, lead_status, lead_id from cl_fresh where geo = 'TH2'
		and createdate >= current_date - 20
		and lead_type = 'A'
		) cf
		left join (select lead_id, so_id, status 
		from 
		(select geo,lead_id, so_id, status,
		sum(case when status in (43, 357) then 1 else null end) over (partition by lead_id) validated_rn,
		row_number() over (partition by lead_id order by createdate desc) rn,
		case when row_number() over (partition by lead_id order by createdate desc) = 1 
		and sum(case when status in (43, 357) then 1 else null end) over (partition by lead_id) > 0 
		and status not in (43, 357)
		then 2 
		when row_number() over (partition by lead_id order by createdate desc) <> 1 
		and status in (43, 357) then 1
		else row_number() over (partition by lead_id order by createdate desc) end final_rn
		from od_sale_order oso 
		where status <> 46
		and geo = 'TH2') a
		where final_rn = 1
		) oso on cf.lead_id = oso.lead_id
		left join (select * from cf_synonym where type = 'lead status' and geo = 'TH2') cfs on cf.lead_status = cfs.value 
		left join (
		select so_id, status,do_code
		from (select createdate::date, so_id, status,do_code,
		row_number() over (partition by so_id order by createdate desc) rn
		from od_do_new
		where geo = 'TH2') a
		where rn = 1
		) odn on oso.so_id = odn.so_id
		left join (select * from cf_synonym where type = 'sale order status' and geo = 'TH2') cfs2 on oso.status = cfs2.value 
		left join (select * from cf_synonym where type = 'delivery order status' and geo = 'TH2') cfs3 on odn.status = cfs3.value
), my_fresh as (
		select cf.geo,
		cf.createdate::date date_used,
		cf.lead_id,
		cfs.name lead_status,
		oso.so_id,
		cfs2.name order_status,
		odn.do_code do_code,
		cfs3.name delivery_status
		from (select geo,lead_type,createdate, lead_status, lead_id from cl_fresh where geo = 'MY'
		and createdate >= current_date - 20
		and lead_type = 'A'
		) cf
		left join (select lead_id, so_id, status 
		from 
		(select geo,lead_id, so_id, status,
		sum(case when status in (43, 357) then 1 else null end) over (partition by lead_id) validated_rn,
		row_number() over (partition by lead_id order by createdate desc) rn,
		case when row_number() over (partition by lead_id order by createdate desc) = 1 
		and sum(case when status in (43, 357) then 1 else null end) over (partition by lead_id) > 0 
		and status not in (43, 357)
		then 2 
		when row_number() over (partition by lead_id order by createdate desc) <> 1 
		and status in (43, 357) then 1
		else row_number() over (partition by lead_id order by createdate desc) end final_rn
		from od_sale_order oso 
		where status <> 46 and lead_id = 41525
		and geo = 'MY') a
		where final_rn = 1
		) oso on cf.lead_id = oso.lead_id
		left join (select * from cf_synonym where type = 'lead status' and geo = 'MY') cfs on cf.lead_status = cfs.value 
		left join (
		select so_id, status,do_code
		from (select createdate::date, so_id, status,do_code,
		row_number() over (partition by so_id order by createdate desc) rn
		from od_do_new
		where geo = 'MY') a
		where rn = 1
		) odn on oso.so_id = odn.so_id
		left join (select * from cf_synonym where type = 'sale order status' and geo = 'MY') cfs2 on oso.status = cfs2.value 
		left join (select * from cf_synonym where type = 'delivery order status' and geo = 'MY') cfs3 on odn.status = cfs3.value
), vn_resell as 
(
		select cf.geo,
		oso.createdate::date date_used,
		oso.lead_id,
		cfs.name lead_status,
		oso.so_id,
		cfs2.name order_status,
		ldm.ma_don_goc do_code,
		lower(status_transport) delivery_status
		from (select geo,lead_type,createdate, lead_status, lead_id from cl_fresh where geo = 'VN'
		and lead_type = 'M'
		) cf
		join (select lead_id, so_id, status, createdate
		from 
		(select geo,lead_id, so_id, status, createdate::date,
		sum(case when status in (43, 357) then 1 else null end) over (partition by lead_id) validated_rn,
		row_number() over (partition by lead_id order by createdate desc) rn,
		case when row_number() over (partition by lead_id order by createdate desc) = 1 
		and sum(case when status in (43, 357) then 1 else null end) over (partition by lead_id) > 0 
		and status not in (43, 357)
		then 2 
		when row_number() over (partition by lead_id order by createdate desc) <> 1 
		and status in (43, 357) then 1
		else row_number() over (partition by lead_id order by createdate desc) end final_rn
		from od_sale_order oso 
		where status <> 46
		and geo = 'VN'
		and createdate >= current_date - 20
		) a
		where final_rn = 1
		) oso on cf.lead_id = oso.lead_id
		left join (select * from cf_synonym where type = 'lead status' and geo = 'VN') cfs on cf.lead_status = cfs.value 
		left join (
		select created_date, ma_don_hang, status_transport,ma_don_goc
		from (select created_date::date, ma_don_hang, status_transport, ma_don_goc,
		row_number() over (partition by ma_don_hang order by created_date desc) rn
		from log_data_main where status_transport <> 'Unassigned') a
		where rn = 1
		) ldm on oso.so_id = ldm.ma_don_hang::int
		left join (select * from cf_synonym where type = 'sale order status' and geo = 'VN') cfs2 on oso.status = cfs2.value 
), indo_resell as 
(
		select cf.geo,
		oso.createdate::date date_used,
		oso.lead_id,
		cfs.name lead_status,
		oso.so_id,
		cfs2.name order_status,
		odn.do_code do_code,
		cfs3.name delivery_status
		from (select geo,lead_type,createdate, lead_status, lead_id from cl_fresh where geo = 'ID'
		and lead_type = 'M'
		) cf
		join (select lead_id, so_id, status, createdate::date
		from 
		(select geo,lead_id, so_id, status, createdate::date,
		sum(case when status in (43, 357) then 1 else null end) over (partition by lead_id) validated_rn,
		row_number() over (partition by lead_id order by createdate desc) rn,
		case when row_number() over (partition by lead_id order by createdate desc) = 1 
		and sum(case when status in (43, 357) then 1 else null end) over (partition by lead_id) > 0 
		and status not in (43, 357)
		then 2 
		when row_number() over (partition by lead_id order by createdate desc) <> 1 
		and status in (43, 357) then 1
		else row_number() over (partition by lead_id order by createdate desc) end final_rn
		from od_sale_order oso 
		where status <> 46
		and geo = 'ID'
		and createdate >= current_date - 53
		) a
		where final_rn = 1
		) oso on cf.lead_id = oso.lead_id
		left join (select * from cf_synonym where type = 'lead status' and geo = 'ID') cfs on cf.lead_status = cfs.value 
		left join (
		select so_id, status,do_code
		from (select createdate::date, so_id, status,do_code,
		row_number() over (partition by so_id order by createdate desc) rn
		from od_do_new
		where geo = 'ID') a
		where rn = 1
		) odn on oso.so_id = odn.so_id
		left join (select * from cf_synonym where type = 'sale order status' and geo = 'ID') cfs2 on oso.status = cfs2.value 
		left join (select * from cf_synonym where type = 'delivery order status' and geo = 'ID') cfs3 on odn.status = cfs3.value
), th_resell as 
(
		select cf.geo,
		oso.createdate::date date_used,
		oso.lead_id,
		cfs.name lead_status,
		oso.so_id,
		cfs2.name order_status,
		odn.do_code do_code,
		cfs3.name delivery_status
		from (select geo,lead_type,createdate, lead_status, lead_id from cl_fresh where geo = 'TH'
		and lead_type = 'M'
		) cf
		join (select lead_id, so_id, status, createdate::date
		from 
		(select geo,lead_id, so_id, status, createdate::date,
		sum(case when status in (43, 357) then 1 else null end) over (partition by lead_id) validated_rn,
		row_number() over (partition by lead_id order by createdate desc) rn,
		case when row_number() over (partition by lead_id order by createdate desc) = 1 
		and sum(case when status in (43, 357) then 1 else null end) over (partition by lead_id) > 0 
		and status not in (43, 357)
		then 2 
		when row_number() over (partition by lead_id order by createdate desc) <> 1 
		and status in (43, 357) then 1
		else row_number() over (partition by lead_id order by createdate desc) end final_rn
		from od_sale_order oso 
		where status <> 46
		and geo = 'TH'
		and createdate >= current_date - 15
		) a
		where final_rn = 1
		) oso on cf.lead_id = oso.lead_id
		left join (select * from cf_synonym where type = 'lead status' and geo = 'TH') cfs on cf.lead_status = cfs.value 
		left join (
		select so_id, status,do_code
		from (select createdate::date, so_id, status,do_code,
		row_number() over (partition by so_id order by createdate desc) rn
		from od_do_new
		where geo = 'TH') a
		where rn = 1
		) odn on oso.so_id = odn.so_id
		left join (select * from cf_synonym where type = 'sale order status' and geo = 'TH') cfs2 on oso.status = cfs2.value 
		left join (select * from cf_synonym where type = 'delivery order status' and geo = 'TH') cfs3 on odn.status = cfs3.value
), my_resell as
(
		select cf.geo,
		oso.createdate::date date_used,
		oso.lead_id,
		cfs.name lead_status,
		oso.so_id,
		cfs2.name order_status,
		odn.do_code do_code,
		cfs3.name delivery_status
		from (select geo,lead_type,createdate, lead_status, lead_id from cl_fresh where geo = 'MY'
		and lead_type = 'M'
		) cf
		join (select lead_id, so_id, status, createdate::date
		from 
		(select geo,lead_id, so_id, status, createdate::date,
		sum(case when status in (43, 357) then 1 else null end) over (partition by lead_id) validated_rn,
		row_number() over (partition by lead_id order by createdate desc) rn,
		case when row_number() over (partition by lead_id order by createdate desc) = 1 
		and sum(case when status in (43, 357) then 1 else null end) over (partition by lead_id) > 0 
		and status not in (43, 357)
		then 2 
		when row_number() over (partition by lead_id order by createdate desc) <> 1 
		and status in (43, 357) then 1
		else row_number() over (partition by lead_id order by createdate desc) end final_rn
		from od_sale_order oso 
		where status <> 46
		and geo = 'MY'
		and createdate >= current_date - 15
		) a
		where final_rn = 1
		) oso on cf.lead_id = oso.lead_id
		left join (select * from cf_synonym where type = 'lead status' and geo = 'MY') cfs on cf.lead_status = cfs.value 
		left join (
		select so_id, status,do_code
		from (select createdate::date, so_id, status,do_code,
		row_number() over (partition by so_id order by createdate desc) rn
		from od_do_new
		where geo = 'MY') a
		where rn = 1
		) odn on oso.so_id = odn.so_id
		left join (select * from cf_synonym where type = 'sale order status' and geo = 'MY') cfs2 on oso.status = cfs2.value 
		left join (select * from cf_synonym where type = 'delivery order status' and geo = 'MY') cfs3 on odn.status = cfs3.value
		),
		union_cte as 
		(
		select *
		from vn_fresh
		union
		select *
		from indo_fresh
		union
		select *
		from th_fresh
		union
		select *
		from my_fresh
		union
		select *
		from vn_resell
		union
		select *
		from indo_resell
		union
		select *
		from th_resell
		union
		select *
		from my_resell
		)
		select * from union_cte 
        """
    conn = pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG"))
    cur = conn.cursor()
    df = pd.read_sql_query(q,conn)
    conn.commit()
    cur.close()
    conn.close()
        
    df['date_used'] = pd.to_datetime(df['date_used'], format='%Y-%m-%d')

    df['updated_at'] = pd.to_datetime(datetime.now().strftime("%Y-%m-%d"))

    df['aging'] = df['updated_at'] - df['date_used']

    df['aging'] = df['aging'].apply(lambda x: x.days)
    df = df.fillna(np.nan).replace({np.nan: None})

    return df

@asset(group_name="auto_bot_2", deps=["load_data_forecast"])
def insert_data_forecast():
    print("Start loading...")
    df = load_data_forecast()
    print("-Establishing connection to DWH...")
    conn = pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG"))
    cur = conn.cursor()
    cur.execute("SET statement_timeout = 0")
    conn.commit()
    cur.execute("delete from fin_fc_data where updated_at = current_date::date or (current_date::date - updated_at::date) > 50")
    conn.commit()
    print('-Finish deleting from fin_fc_data DWH')
    columns = ",".join(df)
    values = "VALUES({})".format(",".join(["%s" for _ in df]))
    insert_stmt = "INSERT INTO {} ({}) {}".format('fin_fc_data',columns,values)
    cur = conn.cursor()
    psycopg2.extras.execute_batch(cur, insert_stmt, df.values)
    conn.commit()
    cur.close()
    conn.close()




@asset(group_name="auto_bot_2")
def load_data_forecast_2():
    q = """
        with vn_fresh as (
		select cf.geo,
		cf.createdate::date date_used,
		cf.lead_id,
		cfs.name lead_status,
		oso.so_id,
		cfs2.name order_status,
		ldm.ma_don_goc do_code,
		lower(status_transport) delivery_status
		from (select geo,lead_type,createdate, lead_status, lead_id from cl_fresh where geo = 'VN'
		and createdate >= current_date - 50
		and lead_type = 'A'
		) cf
		left join (select lead_id, so_id, status 
		from 
		(select geo,lead_id, so_id, status,
		sum(case when status in (43, 357) then 1 else null end) over (partition by lead_id) validated_rn,
		row_number() over (partition by lead_id order by createdate desc) rn,
		case when row_number() over (partition by lead_id order by createdate desc) = 1 
		and sum(case when status in (43, 357) then 1 else null end) over (partition by lead_id) > 0 
		and status not in (43, 357)
		then 2 
		when row_number() over (partition by lead_id order by createdate desc) <> 1 
		and status in (43, 357) then 1
		else row_number() over (partition by lead_id order by createdate desc) end final_rn
		from od_sale_order oso 
		where status <> 46
		and geo = 'VN') a
		where final_rn = 1
		) oso on cf.lead_id = oso.lead_id
		left join (select * from cf_synonym where type = 'lead status' and geo = 'VN') cfs on cf.lead_status = cfs.value 
		left join (
		select created_date, ma_don_hang, status_transport,ma_don_goc
		from (select created_date::date, ma_don_hang, status_transport, ma_don_goc,
		row_number() over (partition by ma_don_hang order by created_date desc) rn
		from log_data_main where status_transport <> 'Unassigned') a
		where rn = 1
		) ldm on oso.so_id = ldm.ma_don_hang::int
		left join (select * from cf_synonym where type = 'sale order status' and geo = 'VN') cfs2 on oso.status = cfs2.value 
), indo_fresh as 
(
		select cf.geo,
		cf.createdate::date date_used,
		cf.lead_id,
		cfs.name lead_status,
		oso.so_id,
		cfs2.name order_status,
		odn.do_code do_code,
		cfs3.name delivery_status
		from (select geo,lead_type,createdate, lead_status, lead_id from cl_fresh where geo = 'ID'
		and createdate >= current_date - 90
		and lead_type = 'A'
		) cf
		left join (select lead_id, so_id, status 
		from 
		(select geo,lead_id, so_id, status,
		sum(case when status in (43, 357) then 1 else null end) over (partition by lead_id) validated_rn,
		row_number() over (partition by lead_id order by createdate desc) rn,
		case when row_number() over (partition by lead_id order by createdate desc) = 1 
		and sum(case when status in (43, 357) then 1 else null end) over (partition by lead_id) > 0 
		and status not in (43, 357)
		then 2 
		when row_number() over (partition by lead_id order by createdate desc) <> 1 
		and status in (43, 357) then 1
		else row_number() over (partition by lead_id order by createdate desc) end final_rn
		from od_sale_order oso 
		where status <> 46
		and geo = 'ID') a
		where final_rn = 1
		) oso on cf.lead_id = oso.lead_id
		left join (select * from cf_synonym where type = 'lead status' and geo = 'ID') cfs on cf.lead_status = cfs.value 
		left join (
		select so_id, status,do_code
		from (select createdate::date, so_id, status,do_code,
		row_number() over (partition by so_id order by createdate desc) rn
		from od_do_new
		where geo = 'ID') a
		where rn = 1
		) odn on oso.so_id = odn.so_id
		left join (select * from cf_synonym where type = 'sale order status' and geo = 'ID') cfs2 on oso.status = cfs2.value 
		left join (select * from cf_synonym where type = 'delivery order status' and geo = 'ID') cfs3 on odn.status = cfs3.value
), th_fresh as 
(
		select 'TH' as geo,
		cf.createdate::date date_used,
		cf.lead_id,
		cfs.name lead_status,
		oso.so_id,
		cfs2.name order_status,
		odn.do_code do_code,
		cfs3.name delivery_status
		from (select geo,lead_type,createdate, lead_status, lead_id from cl_fresh where geo = 'TH2'
		and createdate >= current_date - 40
		and lead_type = 'A'
		) cf
		left join (select lead_id, so_id, status 
		from 
		(select geo,lead_id, so_id, status,
		sum(case when status in (43, 357) then 1 else null end) over (partition by lead_id) validated_rn,
		row_number() over (partition by lead_id order by createdate desc) rn,
		case when row_number() over (partition by lead_id order by createdate desc) = 1 
		and sum(case when status in (43, 357) then 1 else null end) over (partition by lead_id) > 0 
		and status not in (43, 357)
		then 2 
		when row_number() over (partition by lead_id order by createdate desc) <> 1 
		and status in (43, 357) then 1
		else row_number() over (partition by lead_id order by createdate desc) end final_rn
		from od_sale_order oso 
		where status <> 46
		and geo = 'TH2') a
		where final_rn = 1
		) oso on cf.lead_id = oso.lead_id
		left join (select * from cf_synonym where type = 'lead status' and geo = 'TH2') cfs on cf.lead_status = cfs.value 
		left join (
		select so_id, status,do_code
		from (select createdate::date, so_id, status,do_code,
		row_number() over (partition by so_id order by createdate desc) rn
		from od_do_new
		where geo = 'TH2') a
		where rn = 1
		) odn on oso.so_id = odn.so_id
		left join (select * from cf_synonym where type = 'sale order status' and geo = 'TH2') cfs2 on oso.status = cfs2.value 
		left join (select * from cf_synonym where type = 'delivery order status' and geo = 'TH2') cfs3 on odn.status = cfs3.value
), my_fresh as (
		select cf.geo,
		cf.createdate::date date_used,
		cf.lead_id,
		cfs.name lead_status,
		oso.so_id,
		cfs2.name order_status,
		odn.do_code do_code,
		cfs3.name delivery_status
		from (select geo,lead_type,createdate, lead_status, lead_id from cl_fresh where geo = 'MY'
		and createdate >= current_date - 40
		and lead_type = 'A'
		) cf
		left join (select lead_id, so_id, status 
		from 
		(select geo,lead_id, so_id, status,
		sum(case when status in (43, 357) then 1 else null end) over (partition by lead_id) validated_rn,
		row_number() over (partition by lead_id order by createdate desc) rn,
		case when row_number() over (partition by lead_id order by createdate desc) = 1 
		and sum(case when status in (43, 357) then 1 else null end) over (partition by lead_id) > 0 
		and status not in (43, 357)
		then 2 
		when row_number() over (partition by lead_id order by createdate desc) <> 1 
		and status in (43, 357) then 1
		else row_number() over (partition by lead_id order by createdate desc) end final_rn
		from od_sale_order oso 
		where status <> 46
		and geo = 'MY') a
		where final_rn = 1
		) oso on cf.lead_id = oso.lead_id
		left join (select * from cf_synonym where type = 'lead status' and geo = 'MY') cfs on cf.lead_status = cfs.value 
		left join (
		select so_id, status,do_code
		from (select createdate::date, so_id, status,do_code,
		row_number() over (partition by so_id order by createdate desc) rn
		from od_do_new
		where geo = 'MY') a
		where rn = 1
		) odn on oso.so_id = odn.so_id
		left join (select * from cf_synonym where type = 'sale order status' and geo = 'MY') cfs2 on oso.status = cfs2.value 
		left join (select * from cf_synonym where type = 'delivery order status' and geo = 'MY') cfs3 on odn.status = cfs3.value
), vn_resell as 
(
		select cf.geo,
		oso.createdate::date date_used,
		oso.lead_id,
		cfs.name lead_status,
		oso.so_id,
		cfs2.name order_status,
		ldm.ma_don_goc do_code,
		lower(status_transport) delivery_status
		from (select geo,lead_type,createdate, lead_status, lead_id from cl_fresh where geo = 'VN'
		and lead_type = 'M'
		) cf
		join (select lead_id, so_id, status, createdate
		from 
		(select geo,lead_id, so_id, status, createdate::date,
		sum(case when status in (43, 357) then 1 else null end) over (partition by lead_id) validated_rn,
		row_number() over (partition by lead_id order by createdate desc) rn,
		case when row_number() over (partition by lead_id order by createdate desc) = 1 
		and sum(case when status in (43, 357) then 1 else null end) over (partition by lead_id) > 0 
		and status not in (43, 357)
		then 2 
		when row_number() over (partition by lead_id order by createdate desc) <> 1 
		and status in (43, 357) then 1
		else row_number() over (partition by lead_id order by createdate desc) end final_rn
		from od_sale_order oso 
		where status <> 46
		and geo = 'VN'
		and createdate >= current_date - 40
		) a
		where final_rn = 1
		) oso on cf.lead_id = oso.lead_id
		left join (select * from cf_synonym where type = 'lead status' and geo = 'VN') cfs on cf.lead_status = cfs.value 
		left join (
		select created_date, ma_don_hang, status_transport,ma_don_goc
		from (select created_date::date, ma_don_hang, status_transport, ma_don_goc,
		row_number() over (partition by ma_don_hang order by created_date desc) rn
		from log_data_main where status_transport <> 'Unassigned') a
		where rn = 1
		) ldm on oso.so_id = ldm.ma_don_hang::int
		left join (select * from cf_synonym where type = 'sale order status' and geo = 'VN') cfs2 on oso.status = cfs2.value 
), indo_resell as 
(
		select cf.geo,
		oso.createdate::date date_used,
		oso.lead_id,
		cfs.name lead_status,
		oso.so_id,
		cfs2.name order_status,
		odn.do_code do_code,
		cfs3.name delivery_status
		from (select geo,lead_type,createdate, lead_status, lead_id from cl_fresh where geo = 'ID'
		and lead_type = 'M'
		) cf
		join (select lead_id, so_id, status, createdate::date
		from 
		(select geo,lead_id, so_id, status, createdate::date,
		sum(case when status in (43, 357) then 1 else null end) over (partition by lead_id) validated_rn,
		row_number() over (partition by lead_id order by createdate desc) rn,
		case when row_number() over (partition by lead_id order by createdate desc) = 1 
		and sum(case when status in (43, 357) then 1 else null end) over (partition by lead_id) > 0 
		and status not in (43, 357)
		then 2 
		when row_number() over (partition by lead_id order by createdate desc) <> 1 
		and status in (43, 357) then 1
		else row_number() over (partition by lead_id order by createdate desc) end final_rn
		from od_sale_order oso 
		where status <> 46
		and geo = 'ID'
		and createdate >= current_date - 106
		) a
		where final_rn = 1
		) oso on cf.lead_id = oso.lead_id
		left join (select * from cf_synonym where type = 'lead status' and geo = 'ID') cfs on cf.lead_status = cfs.value 
		left join (
		select so_id, status,do_code
		from (select createdate::date, so_id, status,do_code,
		row_number() over (partition by so_id order by createdate desc) rn
		from od_do_new
		where geo = 'ID') a
		where rn = 1
		) odn on oso.so_id = odn.so_id
		left join (select * from cf_synonym where type = 'sale order status' and geo = 'ID') cfs2 on oso.status = cfs2.value 
		left join (select * from cf_synonym where type = 'delivery order status' and geo = 'ID') cfs3 on odn.status = cfs3.value
), th_resell as 
(
		select cf.geo,
		oso.createdate::date date_used,
		oso.lead_id,
		cfs.name lead_status,
		oso.so_id,
		cfs2.name order_status,
		odn.do_code do_code,
		cfs3.name delivery_status
		from (select geo,lead_type,createdate, lead_status, lead_id from cl_fresh where geo = 'TH'
		and lead_type = 'M'
		) cf
		join (select lead_id, so_id, status, createdate::date
		from 
		(select geo,lead_id, so_id, status, createdate::date,
		sum(case when status in (43, 357) then 1 else null end) over (partition by lead_id) validated_rn,
		row_number() over (partition by lead_id order by createdate desc) rn,
		case when row_number() over (partition by lead_id order by createdate desc) = 1 
		and sum(case when status in (43, 357) then 1 else null end) over (partition by lead_id) > 0 
		and status not in (43, 357)
		then 2 
		when row_number() over (partition by lead_id order by createdate desc) <> 1 
		and status in (43, 357) then 1
		else row_number() over (partition by lead_id order by createdate desc) end final_rn
		from od_sale_order oso 
		where status <> 46
		and geo = 'TH'
		and createdate >= current_date - 30
		) a
		where final_rn = 1
		) oso on cf.lead_id = oso.lead_id
		left join (select * from cf_synonym where type = 'lead status' and geo = 'TH') cfs on cf.lead_status = cfs.value 
		left join (
		select so_id, status,do_code
		from (select createdate::date, so_id, status,do_code,
		row_number() over (partition by so_id order by createdate desc) rn
		from od_do_new
		where geo = 'TH') a
		where rn = 1
		) odn on oso.so_id = odn.so_id
		left join (select * from cf_synonym where type = 'sale order status' and geo = 'TH') cfs2 on oso.status = cfs2.value 
		left join (select * from cf_synonym where type = 'delivery order status' and geo = 'TH') cfs3 on odn.status = cfs3.value
), my_resell as
(
		select cf.geo,
		oso.createdate::date date_used,
		oso.lead_id,
		cfs.name lead_status,
		oso.so_id,
		cfs2.name order_status,
		odn.do_code do_code,
		cfs3.name delivery_status
		from (select geo,lead_type,createdate, lead_status, lead_id from cl_fresh where geo = 'MY'
		and lead_type = 'M'
		) cf
		join (select lead_id, so_id, status, createdate::date
		from 
		(select geo,lead_id, so_id, status, createdate::date,
		sum(case when status in (43, 357) then 1 else null end) over (partition by lead_id) validated_rn,
		row_number() over (partition by lead_id order by createdate desc) rn,
		case when row_number() over (partition by lead_id order by createdate desc) = 1 
		and sum(case when status in (43, 357) then 1 else null end) over (partition by lead_id) > 0 
		and status not in (43, 357)
		then 2 
		when row_number() over (partition by lead_id order by createdate desc) <> 1 
		and status in (43, 357) then 1
		else row_number() over (partition by lead_id order by createdate desc) end final_rn
		from od_sale_order oso 
		where status <> 46
		and geo = 'MY'
		and createdate >= current_date - 30
		) a
		where final_rn = 1
		) oso on cf.lead_id = oso.lead_id
		left join (select * from cf_synonym where type = 'lead status' and geo = 'MY') cfs on cf.lead_status = cfs.value 
		left join (
		select so_id, status,do_code
		from (select createdate::date, so_id, status,do_code,
		row_number() over (partition by so_id order by createdate desc) rn
		from od_do_new
		where geo = 'MY') a
		where rn = 1
		) odn on oso.so_id = odn.so_id
		left join (select * from cf_synonym where type = 'sale order status' and geo = 'MY') cfs2 on oso.status = cfs2.value 
		left join (select * from cf_synonym where type = 'delivery order status' and geo = 'MY') cfs3 on odn.status = cfs3.value
		),
		union_cte as 
		(
		select *
		from vn_fresh
		union
		select *
		from indo_fresh
		union
		select *
		from th_fresh
		union
		select *
		from my_fresh
		union
		select *
		from vn_resell
		union
		select *
		from indo_resell
		union
		select *
		from th_resell
		union
		select *
		from my_resell
		)
		select * from union_cte
        """
    conn = pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG"))
    cur = conn.cursor()
    df = pd.read_sql_query(q,conn)
    conn.commit()
    cur.close()
    conn.close()
        
    df['date_used'] = pd.to_datetime(df['date_used'], format='%Y-%m-%d')

    df['updated_at'] = pd.to_datetime(datetime.now().strftime("%Y-%m-%d"))

    df['aging'] = df['updated_at'] - df['date_used']

    df['aging'] = df['aging'].apply(lambda x: x.days)
    df = df.fillna(np.nan).replace({np.nan: None})

    return df

@asset(group_name="auto_bot_2")
def insert_data_forecast_2():
    print("Start loading...")
    df = load_data_forecast_2()
    print("-Establishing connection to DWH...")
    conn = pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG"))
    cur = conn.cursor()
    cur.execute("SET statement_timeout = 0")
    conn.commit()
    cur.execute("delete from fin_fc_data_2 where updated_at = current_date::date or (current_date::date - updated_at::date) > 50")
    conn.commit()
    print('-Finish deleting from fin_fc_data_2 DWH')

    # create (col1,col2,...)
    columns = ",".join(df)

    # create VALUES('%s', '%s",...) one '%s' per column
    values = "VALUES({})".format(",".join(["%s" for _ in df]))

    #create INSERT INTO table (columns) VALUES('%s',...)
    insert_stmt = "INSERT INTO {} ({}) {}".format('fin_fc_data_2',columns,values)
    cur = conn.cursor()
    psycopg2.extras.execute_batch(cur, insert_stmt, df.values)
    conn.commit()
    cur.close()
    conn.close()

    print("-Finish updating fin_fc_data_2 DWH")



#--------------------------------------------------------------------------------------------------------------------------------------

def count_bd_master():
    q = f"""
        select count(*) 
        from bd_master
            """
    conn = pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG"))
    cur = conn.cursor()
    data = pd.read_sql_query(q,conn)
    conn.commit()
    cur.close()
    conn.close()

    return data # data_length

# refresh bd_master view
@asset(group_name="auto_bot_2")
def refresh_bd_master():
    print("Start refreshing...")
    print("Establishing connection to DWH...")
    conn = pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG"))
    cur = conn.cursor()
    cur.execute("SET statement_timeout = 0")
    conn.commit()
    print("REFRESH MATERIALIZED VIEW CONCURRENTLY bd_master WITH DATA") 
    cur.execute("REFRESH MATERIALIZED VIEW CONCURRENTLY bd_master WITH DATA")
    conn.commit()
    print("Finish REFRESHING bd_master")
    cur.close()
    conn.close()
    print("-Finish refreshing bd_master")





#--------------------------------------------------------------------------------------------------------------------------------------

def count_traffic_bd_master():
    q = f"""
        select count(*) 
        from traffic_bd_master
            """
    conn = pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG"))
    cur = conn.cursor()
    data = pd.read_sql_query(q,conn)
    conn.commit()
    cur.close()
    conn.close()

    return data # data_length

# refresh traffic_bd_master view
@asset(group_name="auto_bot_2")
def refresh_traffic_bd_master():
    print("Start refreshing...")
    print("Establishing connection to DWH...")
    conn = pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG"))
    cur = conn.cursor()
    cur.execute("SET statement_timeout = 0")
    conn.commit()

    print("REFRESH MATERIALIZED VIEW traffic_bd_master_temp") 
    cur.execute("REFRESH MATERIALIZED VIEW traffic_bd_master_temp")
    conn.commit()
    print("Finish REFRESHING traffic_bd_master_temp")

    cur.close()
    conn.close()

    print("-Finish refreshing traffic_bd_master_temp")



#------------------------------------------------------------------------------------------------------------------------------------------
# DR forecast
@asset(group_name="auto_bot_2")
def load_data_dr_forecast():
    q = f"""
 -- Auto_Bot_2
-- cdm_dim_dr_forecast_by_date
with cte_raw as (
select roi.lead_date::date as createdate 
	,extract('week' from lead_date + interval '1 day')as lead_week
	,extract('month' from lead_date)as lead_month
	,extract('week' from current_date + interval '1 day')as current_week
	,(date_trunc('week',lead_date + interval '1 day')- interval '1 day')::date as week_start
	,(date_trunc('week',current_date + interval '1 day')- interval '1 day')::date as week_start_current
	,case 
		when roi.geo = 'TH2' then 'TH' 
		when roi.geo = 'VN2' then 'VN' 
		when roi.geo = 'ID2' then 'ID'
		else roi.geo end 
	as geo
	--,dim_pc.category
	,roi.cam_lead category
	,roi.network 
	,roi.product_name 
	,roi.pub 
	,total_lead 
	,roi.approved 
	,payout
	,max_po 
	,validated 
	,delivered 
	,amt_validated 
from ads_roi_global roi
),
data as (
select *
	,case when (cte_raw.geo ='VN' and week_start >=week_start_current - 14) then 1 else 
		 case when (cte_raw.geo in ('ID', 'ID2') and week_start >=week_start_current - 21 and week_start > '2023-01-01') then 1 else 		 
			 case when (cte_raw.geo ='TH' and week_start >=week_start_current - 7) then 1 else
			 	case when (cte_raw.geo ='MY' and week_start >=week_start_current - 14) then 1 else 
			 		case when (cte_raw.geo ='TH2' and week_start >=week_start_current - 7) then 1 else
			 			case when (cte_raw.geo ='VN2' and week_start >=week_start_current - 14) then 1 else 
                        	case when (cte_raw.geo ='PH' and week_start >=week_start_current - 7) then 1  -- -- 22.06.2023
                            else 0
                            end
			 			end
			 		end
			 	end
			 end 
		end
	end as InRangeForeCast
from cte_raw
),
--data_need_forecast as (
--	select data.*
--	from data
--	where InRangeForeCast= 1 
--)
--,
--data_need_forecast2 as (
--	select data.*
--	from data
--	where InRangeForeCast= 2 -- 09.01.2023 -- = 2
--),
data_forecast1 as (
	select data.*
	from data
	where InRangeForeCast= 0 and ((data.geo = 'VN' and createdate<= week_start_current-15 and createdate>=week_start_current-35)
								or (data.geo in ('ID', 'ID2') and createdate<= week_start_current-22 and createdate>=week_start_current-42)
								--or (data.geo = 'TH' and createdate<= week_start_current-8 and createdate>=week_start_current-28)
								or (data.geo = 'TH' and data.category = 'Fresh Hair' and createdate<= '2022-08-31' and createdate>='2022-08-01')
								or (data.geo = 'TH' and data.category <> 'Fresh Hair' and createdate<= week_start_current-22 and createdate>=week_start_current-42)
                                or (data.geo = 'PH' and createdate<= week_start_current-22 and createdate>=week_start_current-42) -- -- 22.06.2023
								or (data.geo = 'MY' and createdate<= week_start_current-15 and createdate>=week_start_current-35))				
),
data_forecast2 as (
	select data.*
	from data
	where InRangeForeCast= 0 and data.geo = 'ID' and createdate<= '2022-12-10' and createdate>='2022-11-20'				---- 09.01.2023		
),
data_forecast3 as (
	select data.*
	from data
	where InRangeForeCast= 0 and data.geo = 'TH' and createdate<= '2022-12-24' and createdate>='2022-12-04'	--- W49.50.51				---- 09.01.2023
),
full_data_forecast1 as (
select data_forecast.geo
	,data_forecast.category
	,data_forecast.product_name
	,data_forecast.network
	,data_forecast.pub
	,sum(validated) as validated
	,sum(delivered) as delivered
	,case when sum(validated) =0 then 0 else sum(delivered)/sum(validated)::float end as dr_forecast
from data_forecast1 data_forecast
group by data_forecast.geo
	,data_forecast.category
	,data_forecast.product_name
	,data_forecast.network
	,data_forecast.pub
),
full_data_forecast2 as (
select data_forecast.geo
	,data_forecast.category
	,data_forecast.product_name
	,data_forecast.network
	,data_forecast.pub
	,sum(validated) as validated
	,sum(delivered) as delivered
	,case when sum(validated) =0 then 0 else sum(delivered)/sum(validated)::float end as dr_forecast
from data_forecast2 data_forecast
group by data_forecast.geo
	,data_forecast.category
	,data_forecast.product_name
	,data_forecast.network
	,data_forecast.pub
), 
full_data_forecast3 as (
select data_forecast.geo
	,data_forecast.category
	,data_forecast.product_name
	,data_forecast.network
	,data_forecast.pub
	,sum(validated) as validated
	,sum(delivered) as delivered
	,case when sum(validated) =0 then 0 else sum(delivered)/sum(validated)::float end as dr_forecast
from data_forecast3 data_forecast
group by data_forecast.geo
	,data_forecast.category
	,data_forecast.product_name
	,data_forecast.network
	,data_forecast.pub
),
full_data_forecast as ( 
select coalesce(a.geo, b.geo, c.geo) geo
		,coalesce(a.category , b.category, c.category) category
		,coalesce(a.product_name , b.product_name, c.product_name) product_name
		,coalesce(a.network , b.network ,c.network) network
		,coalesce(a.pub , b.pub, c.pub) pub
		,a.validated as validated,a.delivered as delivered, a.dr_forecast as dr_forecast
		,b.validated as validated2,b.delivered as delivered2, b.dr_forecast as dr_forecast2
		,c.validated as validated3,c.delivered as delivered3, c.dr_forecast as dr_forecast3
from full_data_forecast1 a
full outer join full_data_forecast2 b
on a.geo = b.geo and a.category = b.category and a.product_name = b.product_name and a.network = b.network and a.pub = b.pub
full outer join full_data_forecast3 c
on a.geo = c.geo and a.category = c.category and a.product_name = c.product_name and a.network = c.network and a.pub = c.pub
--where coalesce(a.geo, b.geo) in ('TH', 'TH2')
),
full_data_forecast_by_network as(
select geo
	,category
	,product_name
	,network
	,sum(validated) as validated_by_network
	,sum(validated2) as validated_by_network2
	,sum(validated3) as validated_by_network3
	,sum(delivered) as delivered_by_network
	,sum(delivered2) as delivered_by_network2
	,sum(delivered3) as delivered_by_network3
	,case when sum(validated) =0 then 0 else sum(delivered)/sum(validated)::float end as dr_forecast_by_network
	,case when sum(validated2) =0 then 0 else sum(delivered2)/sum(validated2)::float end as dr_forecast_by_network2
	,case when sum(validated3) =0 then 0 else sum(delivered3)/sum(validated3)::float end as dr_forecast_by_network3
from full_data_forecast
group by geo
	,category
	,product_name
	,network
),
full_data_forecast_by_offer as(
select geo
	,category
	,product_name	
	,sum(validated) as validated_by_offer
	,sum(delivered) as delivered_by_offer
	,case when sum(validated) =0 then 0 else sum(delivered)/sum(validated)::float end as dr_forecast_by_offer
	,sum(validated2) as validated_by_offer2
	,sum(delivered2) as delivered_by_offer2
	,case when sum(validated2) =0 then 0 else sum(delivered2)/sum(validated2)::float end as dr_forecast_by_offer2
	,sum(validated3) as validated_by_offer3
	,sum(delivered3) as delivered_by_offer3
	,case when sum(validated3) =0 then 0 else sum(delivered3)/sum(validated3)::float end as dr_forecast_by_offer3
from full_data_forecast
group by geo
	,category
	,product_name
),
full_data_forecast_by_cat as(
select geo
	,category	
	,sum(validated) as validated_by_cat
	,sum(delivered) as delivered_by_cat
	,case when sum(validated) =0 then 0 else sum(delivered)/sum(validated)::float end as dr_forecast_by_cat
	,sum(validated2) as validated_by_cat2
	,sum(delivered2) as delivered_by_cat2
	,case when sum(validated2) =0 then 0 else sum(delivered2)/sum(validated2)::float end as dr_forecast_by_cat2
	,sum(validated3) as validated_by_cat3
	,sum(delivered3) as delivered_by_cat3
	,case when sum(validated3) =0 then 0 else sum(delivered3)/sum(validated3)::float end as dr_forecast_by_cat3
from full_data_forecast
group by geo
	,category
)
select raw.geo
	,raw.category
	,raw.product_name
	,raw.network
	,case when raw.pub is null then 'No PubID' 
		  when raw.pub = '' then 'blank' else raw.pub end as pub
	,a.validated
	,a.delivered
	,a.dr_forecast
	,b.validated_by_network	
	,b.delivered_by_network 
	,b.dr_forecast_by_network
	,c.validated_by_offer 
	,c.delivered_by_offer 
	,c.dr_forecast_by_offer	
	,d.validated_by_cat
	,d.delivered_by_cat
	,d.dr_forecast_by_cat 
	,case when raw.product_name = 'bonivita-my' then dr_forecast_by_cat else
		case when a.validated >30 then a.dr_forecast else 
			case when b.validated_by_network >30 then b.dr_forecast_by_network else
				case when c.validated_by_offer >30 then c.dr_forecast_by_offer else dr_forecast_by_cat
					end
				end
			end
		end as dr_forecast_final
	,a.validated2
	,a.delivered2
	,a.dr_forecast2
	,b.validated_by_network2
	,b.delivered_by_network2 
	,b.dr_forecast_by_network2
	,c.validated_by_offer2 
	,c.delivered_by_offer2 
	,c.dr_forecast_by_offer2	
	,d.validated_by_cat2
	,d.delivered_by_cat2
	,d.dr_forecast_by_cat2 
	,
		case when a.validated2 >30 then a.dr_forecast2 else 
			case when b.validated_by_network2 >30 then b.dr_forecast_by_network2 else
				case when c.validated_by_offer2 >30 then c.dr_forecast_by_offer2 else dr_forecast_by_cat2
					end
				end
			end
		as dr_forecast_final2
	,a.validated3
	,a.delivered3
	,a.dr_forecast3
	,b.validated_by_network3
	,b.delivered_by_network3 
	,b.dr_forecast_by_network3
	,c.validated_by_offer3 
	,c.delivered_by_offer3 
	,c.dr_forecast_by_offer3	
	,d.validated_by_cat3
	,d.delivered_by_cat3
	,d.dr_forecast_by_cat3 
	,
		case when a.validated3 >30 then a.dr_forecast3 else 
			case when b.validated_by_network3 >30 then b.dr_forecast_by_network3 else
				case when c.validated_by_offer3 >30 then c.dr_forecast_by_offer3 else dr_forecast_by_cat3
					end
				end
			end
		as dr_forecast_final3
from (select distinct geo, category, network, product_name, pub 
		from cte_raw) raw
left join full_data_forecast a on raw.geo = a.geo
				and raw.category=a.category and raw.product_name = a.product_name and raw.network = a.network and raw.pub = a.pub
left join full_data_forecast_by_network b on raw.geo = b.geo 
				and raw.category=b.category and raw.product_name = b.product_name and raw.network = b.network
left join full_data_forecast_by_offer c on raw.geo = c.geo 
				and raw.category=c.category and raw.product_name = c.product_name 
left join full_data_forecast_by_cat d on raw.geo = d.geo 
				and raw.category=d.category
    """
    conn = pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG"))
    cur = conn.cursor()
    data = pd.read_sql_query(q,conn)
    conn.commit()
    cur.close()
    conn.close()
    data = data.fillna(np.nan).replace([np.nan], [None])
    return data

@asset(group_name="auto_bot_2")
def load_data_dr_fc_resell():
    q = f"""
	with cte_raw as (
        select cf.geo,
        --case when cf.geo<> 'TH' then agc_code else cf.cp_id::text end rs_source,
        cf.cp_id::text as rs_source,
        oso.createdate::date
        ,extract('week' from oso.createdate + interval '1 day')as lead_week
        ,extract('month' from oso.createdate)as lead_month
        ,extract('week' from current_date + interval '1 day')as current_week
        ,(date_trunc('week',oso.createdate + interval '1 day')- interval '1 day')::date as week_start
        ,(date_trunc('week',current_date + interval '1 day')- interval '1 day')::date as week_start_current,
        sum(case when oso.status in (43,357)then 1 else 0 end) validated,
        sum(case when odn.status = 59 then 1 else 0 end) delivered
        from (select geo,lead_id,agc_code, cp_id from cl_fresh where lead_type = 'M') cf
        join od_sale_order oso on cf.lead_id = oso.lead_id and cf.geo = oso.geo 
        left join od_do_new odn on oso.so_id = odn.so_id and oso.geo = odn.geo
        group by 1,2,3,4,5,6,7,8
        ),
        data as (
        select *
            ,case when (cte_raw.geo ='VN' and createdate>= current_date - 15) then 1 else 
                case when (cte_raw.geo ='ID' and createdate>= current_date - 28) then 1 else 
                    case when (cte_raw.geo ='TH' and createdate>= current_date - 17) then 1 else 0
                    end 
                end
            end as InRangeForeCast
        from cte_raw
        ),
        data_need_forecast as (
            select data.*
            from data
            where InRangeForeCast= 1
        ),
        data_forecast as (
            select data.*
            from data
            where InRangeForeCast= 0 and ((data.geo = 'VN' and createdate< current_date - 15 and createdate>= current_date - 36)
                                        or (data.geo = 'ID' and createdate< current_date - 28 and createdate>= current_date -49)
                                        or (data.geo = 'TH' and createdate< current_date - 17 and createdate>= current_date -38))				
        ),
        full_data_forecast as (
        select data_forecast.geo
            ,data_forecast.rs_source
            ,sum(validated) as validated
            ,sum(delivered) as delivered
            ,case when sum(validated) =0 then 0 else sum(delivered)/sum(validated)::float end as dr_forecast
        from data_forecast
        group by 1,2
        ),
        full_data_forecast_by_geo as(
        select geo
            ,sum(validated) as validated_by_geo
            ,sum(delivered) as delivered_by_geo
            ,case when sum(validated) =0 then 0 else sum(delivered)/sum(validated)::float end as dr_forecast_by_geo
        from full_data_forecast
        group by 1
        )
        select raw.geo
            ,raw.rs_source
            ,a.validated
            ,a.delivered
            ,a.dr_forecast
            ,b.validated_by_geo
            ,b.delivered_by_geo
            ,b.dr_forecast_by_geo
            ,case when a.validated >30 then a.dr_forecast else 
                case when b.validated_by_geo >30 then b.dr_forecast_by_geo 
                end
            end as dr_forecast_final
        from (select distinct geo, rs_source from cte_raw) raw
        left join full_data_forecast a on raw.geo = a.geo
                        and raw.rs_source=a.rs_source
        left join full_data_forecast_by_geo b on raw.geo = b.geo 
            """
    conn = pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG"))
    cur = conn.cursor()
    data = pd.read_sql_query(q,conn)
    conn.commit()
    cur.close()
    conn.close()
    data = data.fillna(np.nan).replace([np.nan], [None])
    return data	

@asset(group_name="auto_bot_2", deps=["load_data_dr_forecast"])
def insert_cdm_dim_dr_forecast_by_date():
    from datetime import datetime
    print("Start inserting...")
    dfx = load_data_dr_forecast()
    dfx["last_update"] = datetime.now().strftime("%Y-%m-%d, %H:%M")
    df = dfx[['geo', 'category','product_name', 'network', 'pub', 'validated', 'delivered', 'dr_forecast', 'validated_by_network', 'delivered_by_network', 'dr_forecast_by_network', 'validated_by_offer', 'delivered_by_offer', 'dr_forecast_by_offer','validated_by_cat','delivered_by_cat','dr_forecast_by_cat','dr_forecast_final',	'last_update',   'validated2','delivered2','dr_forecast2','validated_by_network2', 'delivered_by_network2', 'dr_forecast_by_network2','validated_by_offer2','delivered_by_offer2','dr_forecast_by_offer2','validated_by_cat2','delivered_by_cat2','dr_forecast_by_cat2','dr_forecast_final2', 'validated3','delivered3','dr_forecast3','validated_by_network3', 'delivered_by_network3', 'dr_forecast_by_network3','validated_by_offer3','delivered_by_offer3','dr_forecast_by_offer3','validated_by_cat3','delivered_by_cat3','dr_forecast_by_cat3','dr_forecast_final3' ]]
    # insert_data(df.loc[:1],"cdm_dim_dr_forecast_by_date")
    print("establishing connection to DWH...")
    conn = pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG"))
    cur = conn.cursor()
    cur.execute("SET statement_timeout = 0")
    conn.commit()
    print("deleting data in cdm_dim_dr_forecast_by_date...")
    cur.execute("delete from cdm_dim_dr_forecast_by_date")
    conn.commit()

    tup = list(df.itertuples(index=False))
    print("inserting with {} rows into cdm_dim_dr_forecast_by_date...".format(len(df)))
    args_str = b','.join(cur.mogrify("(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)", x) 
                            for x in tup)
    cur.execute("INSERT INTO cdm_dim_dr_forecast_by_date VALUES " + args_str.decode("utf-8"))
    conn.commit()
    cur.close()
    conn.close()
    print("Done")

    print("-Finish inserting to cdm_dim_dr_forecast_by_date")


@asset(group_name="auto_bot_2", deps=["load_data_dr_fc_resell"])
def insert_cdm_dim_dr_fc_resell():
    print("Start inserting...")
    df = load_data_dr_fc_resell()
    print("-Establishing connection to DWH...")
    conn = pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG"))

    cur = conn.cursor()
    cur.execute("SET statement_timeout = 0")
    conn.commit()

    cur.execute("truncate table cdm_dim_dr_fc_resell_temp")
    conn.commit()
    print('-Finish deleting from cdm_dim_dr_fc_resell_temp')

    df_columns = list(df)
    columns = str(df_columns).replace("'",'"').replace('[','').replace(']','')
    values = "VALUES({})".format(",".join(["%s" for _ in df_columns])) 
    insert_stmt = "INSERT INTO {} ({}) {}".format('cdm_dim_dr_fc_resell_temp',columns,values)

    #create INSERT INTO table (columns) VALUES('%s',...)
    cur = conn.cursor()
    psycopg2.extras.execute_batch(cur, insert_stmt, df.values)
    conn.commit()
    cur.close()
    conn.close()

    print("-Finish updating cdm_dim_dr_fc_resell_temp")



#intransit to delivered
##Fresh
def count_intransit_to_delivered_fresh():
    q = f"""
        select count(*) from intransit_to_delivered_fresh
            """
    conn = pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG"))
    cur = conn.cursor()
    data = pd.read_sql_query(q,conn)
    conn.commit()
    cur.close()
    conn.close()

    return data # data_length


#intransit to delivered
##Fresh # Function: Load data
@asset(group_name="auto_bot_2")
def load_intransit_to_delivered_fresh():
    q = f"""
            WITH cte_raw AS (
                SELECT fd.geo,
                    fd.date_used,
                    fd.lead_id,
                    fd.lead_status,
                    fd.so_id,
                    fd.order_status,
                    fd.do_code,
                    fd.delivery_status,
                    fd.updated_at,
                    fd.aging,
                    d.lead_type,
                    d.cp_id,
                    d.campaign,
                        CASE
                            WHEN lower(fd.delivery_status) = ANY (ARRAY['cancel'::text, 'cancelled'::text, 'reject'::text, 'returning'::text, 'returned'::text]) THEN 'reject'::text
                            WHEN lower(fd.delivery_status) = 'delivered'::text THEN 'delivered'::text
                            WHEN lower(fd.order_status) in ('validated','delay') and fd.delivery_status IS NULL THEN 'intransit'::text
                            WHEN lower(fd.delivery_status) IS NULL THEN NULL::text
                            ELSE 'intransit'::text
                        END AS status_fn
                FROM ( SELECT fin_fc_data_2.geo,
                            fin_fc_data_2.date_used,
                            fin_fc_data_2.lead_id,
                            fin_fc_data_2.lead_status,
                            fin_fc_data_2.so_id,
                            fin_fc_data_2.order_status,
                            fin_fc_data_2.do_code,
                            fin_fc_data_2.delivery_status,
                            fin_fc_data_2.updated_at,
                            fin_fc_data_2.aging
                            --current_date::date - fin_fc_data_2.date_used::date as aging
                        FROM fin_fc_data_2) fd
                    LEFT JOIN ( SELECT d_1.geo,
                            d_1.lead_type,
                            d_1.lead_id,
                            d_1.cp_id,
                            cp.name AS campaign
                        FROM cl_fresh d_1
                            LEFT JOIN ( SELECT cp_campaign.geo,
                                    cp_campaign.cp_id,
                                    cp_campaign.org_id,
                                    cp_campaign.name,
                                    cp_campaign.owner,
                                    cp_campaign.status,
                                    cp_campaign.startdate,
                                    cp_campaign.stopdate,
                                    cp_campaign.createby,
                                    cp_campaign.createdate,
                                    cp_campaign.modifyby,
                                    cp_campaign.modifydate,
                                    cp_campaign.cp_cat,
                                    cp_campaign.cp_subcat,
                                    cp_campaign.tag_value_id
                                FROM cp_campaign) cp ON d_1.geo::text = cp.geo::text AND d_1.cp_id = cp.cp_id) d ON fd.geo = d.geo::text AND fd.lead_id = d.lead_id
                WHERE lower(fd.lead_status) = 'approved'::text AND (lower(fd.order_status) = ANY (ARRAY['validated'::text, 'delay'::text])) AND fd.date_used >= current_date - 35 AND d.lead_type::text = 'A'::text AND fd.aging <=
                        CASE
                            WHEN fd.geo = 'VN'::text THEN 20
                            WHEN fd.geo = 'ID'::text THEN 28
                            WHEN fd.geo = 'TH'::text THEN 15
                            WHEN fd.geo = 'MY'::text THEN 15
                            ELSE NULL::integer
                        END
                )
                , aging_max AS (
                SELECT raw.geo,
                    raw.campaign,
                    max(raw.aging) AS max_aging,
                    case when count(DISTINCT
                        CASE
                            WHEN raw.geo = 'VN'::text AND raw.aging = 20 OR raw.geo = 'ID'::text AND raw.aging = 28 OR raw.geo = 'TH'::text AND raw.aging = 15 OR raw.geo = 'MY'::text AND raw.aging = 15 THEN raw.lead_id
                            ELSE NULL::bigint
                        END)::double precision = 0::double precision then 0
                        else
                    count(DISTINCT
                        CASE
                            WHEN raw.status_fn = 'delivered'::text AND (raw.geo = 'VN'::text AND raw.aging = 20 OR raw.geo = 'ID'::text AND raw.aging = 28 OR raw.geo = 'TH'::text AND raw.aging = 15 OR raw.geo = 'MY'::text AND raw.aging = 15) THEN raw.lead_id
                            ELSE NULL::bigint
                        END)::double precision /
                        count(DISTINCT
                        CASE
                            WHEN raw.geo = 'VN'::text AND raw.aging = 20 OR raw.geo = 'ID'::text AND raw.aging = 28 OR raw.geo = 'TH'::text AND raw.aging = 15 OR raw.geo = 'MY'::text AND raw.aging = 15 THEN raw.lead_id
                            ELSE NULL::bigint
                        END)::double precision end AS dr_aging_max
                FROM cte_raw raw
                GROUP BY raw.geo, raw.campaign
                )
                , group_raw AS (
                SELECT raw.geo,
                    raw.campaign,
                    raw.aging,
                    case when count(DISTINCT raw.lead_id) <> 0 then
                    count(DISTINCT
                        CASE
                            WHEN raw.status_fn = 'delivered'::text THEN raw.lead_id
                            ELSE NULL::bigint
                        END)::double precision / count(DISTINCT raw.lead_id)
                        else 0 end AS dr_percentage,
                    case when count(DISTINCT raw.lead_id) <> 0 then   
                    count(DISTINCT
                        CASE
                            WHEN raw.status_fn = 'intransit'::text THEN raw.lead_id
                            ELSE NULL::bigint
                        END)::double precision / count(DISTINCT raw.lead_id) 
                        else 0 end AS intransit_percentage,
                    am.max_aging,
                    am.dr_aging_max
                FROM cte_raw raw
                    LEFT JOIN aging_max am ON raw.geo = am.geo AND raw.campaign::text = am.campaign::text
                GROUP BY raw.geo, raw.campaign, raw.aging, am.max_aging, am.dr_aging_max
                )
        SELECT group_raw.geo,
            group_raw.campaign,
            group_raw.aging,
            group_raw.dr_percentage,
            group_raw.intransit_percentage,
            group_raw.max_aging,
            group_raw.dr_aging_max,
            group_raw.dr_aging_max - group_raw.dr_percentage AS dr_adding
            ,
                CASE
                    WHEN group_raw.intransit_percentage = 0 THEN 0
                    ELSE
                    CASE
                        WHEN ((group_raw.dr_aging_max - group_raw.dr_percentage) / group_raw.intransit_percentage) < 0::double precision THEN 0::double precision
                        WHEN ((group_raw.dr_aging_max - group_raw.dr_percentage) / group_raw.intransit_percentage) > 1::double precision THEN 1::double precision
                        ELSE (group_raw.dr_aging_max - group_raw.dr_percentage) / group_raw.intransit_percentage
                    END
                END AS ins_to_del
        FROM group_raw
            """
    conn = pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG"))
    cur = conn.cursor()
    data = pd.read_sql_query(q,conn)
    conn.commit()
    cur.close()
    conn.close()
    return data


#intransit to delivered
##Fresh # Function: Insert data
@asset(group_name="auto_bot_2", deps=["count_intransit_to_delivered_fresh", "load_intransit_to_delivered_fresh"])
def insert_intransit_to_delivered_fresh():
    print("Establishing connection to DWH...")
    conn = pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG"))
    cur = conn.cursor()
    cur.execute("SET statement_timeout = 0")
    conn.commit()

    print("START TRUNCATING table intransit_to_delivered_fresh") 

    #Truncate
    cur.execute("truncate table intransit_to_delivered_fresh")
    conn.commit()
    print("-Finish truncating table intransit_to_delivered_fresh...")

    # Insert data
    data = load_intransit_to_delivered_fresh()
    output_path = r'E:\OneDrive - NEYU.CO\Finance Cost Input\Agg_data'
    output_file = 'intransit_to_delivered_fresh.csv'
    data.to_csv(os.path.join(output_path,output_file))
    print("DATA IS EXPORTED TO {}\n file's name is {} \n".format(output_path, output_file),datetime.now())

    df_columns = list(data)
    # create (col1,col2,...)
    # columns = ",".join(df_columns)
    columns = str(df_columns).replace("'",'"').replace('[','').replace(']','')


    # create VALUES('%s', '%s",...) one '%s' per column
    values = "VALUES({})".format(",".join(["%s" for _ in df_columns])) 

    #create INSERT INTO table (columns) VALUES('%s',...) 
    insert_stmt = "INSERT INTO {} ({}) {}".format('intransit_to_delivered_fresh',columns,values)

    #create INSERT INTO table (columns) VALUES('%s',...)
    cur = conn.cursor()
    psycopg2.extras.execute_batch(cur, insert_stmt, data.values)
    conn.commit()
    cur.close()
    conn.close()
    print("-Finish inserting intransit_to_delivered_fresh")

    cur.close()
    conn.close()
    print("-Finish inserting intransit_to_delivered_fresh")


  

##Resell
def count_intransit_to_delivered_resell():
    q = f"""
        select count(*) from intransit_to_delivered_resell
            """
    conn = pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG"))
    cur = conn.cursor()
    data = pd.read_sql_query(q,conn)
    conn.commit()
    cur.close()
    conn.close()

    return data # data_length

##Resell # Function: Load data
@asset(group_name="auto_bot_2")
def load_intransit_to_delivered_resell():
    q = f"""
		WITH cte_raw AS (
				SELECT fd.geo,
					fd.date_used,
					fd.lead_id,
					fd.lead_status,
					fd.so_id,
					fd.order_status,
					fd.do_code,
					fd.delivery_status,
					fd.updated_at,
					fd.aging,
					d.lead_type,
					d.cp_id,
					d.campaign,
						CASE
							WHEN lower(fd.delivery_status) = ANY (ARRAY['cancel'::text, 'cancelled'::text, 'reject'::text, 'returning'::text, 'returned'::text]) THEN 'reject'::text
							WHEN lower(fd.delivery_status) = 'delivered'::text THEN 'delivered'::text
							WHEN lower(fd.order_status) in ('validated','delay') and fd.delivery_status IS NULL THEN 'intransit'::text
							WHEN lower(fd.delivery_status) IS NULL THEN NULL::text
							ELSE 'intransit'::text
						END AS status_fn
				FROM ( SELECT fin_fc_data_2.geo,
                    fin_fc_data_2.date_used,
                    fin_fc_data_2.lead_id,
                    fin_fc_data_2.lead_status,
                    fin_fc_data_2.so_id,
                    fin_fc_data_2.order_status,
                    fin_fc_data_2.do_code,
                    fin_fc_data_2.delivery_status,
                    fin_fc_data_2.updated_at,
                    fin_fc_data_2.aging
                    --current_date::date - fin_fc_data_2.date_used::date as aging
                   FROM fin_fc_data_2) fd
					LEFT JOIN ( SELECT d_1.geo,
							d_1.lead_type,
							d_1.lead_id,
							d_1.cp_id,
							cp.name AS campaign
						FROM cl_fresh d_1
							LEFT JOIN ( SELECT cp_campaign.geo,
									cp_campaign.cp_id,
									cp_campaign.org_id,
									cp_campaign.name,
									cp_campaign.owner,
									cp_campaign.status,
									cp_campaign.startdate,
									cp_campaign.stopdate,
									cp_campaign.createby,
									cp_campaign.createdate,
									cp_campaign.modifyby,
									cp_campaign.modifydate,
									cp_campaign.cp_cat,
									cp_campaign.cp_subcat,
									cp_campaign.tag_value_id
								FROM cp_campaign) cp ON d_1.geo::text = cp.geo::text AND d_1.cp_id = cp.cp_id) d ON fd.geo = d.geo::text AND fd.lead_id = d.lead_id
				WHERE lower(fd.lead_status) = 'approved'::text AND (lower(fd.order_status) = ANY (ARRAY['validated'::text, 'delay'::text])) AND fd.date_used >= current_date - 35 AND d.lead_type::text = 'M'::text AND fd.aging <=
						CASE
							WHEN fd.geo = 'VN'::text THEN 15
							WHEN fd.geo = 'ID'::text THEN 28
							WHEN fd.geo = 'TH'::text THEN 17
							WHEN fd.geo = 'MY'::text THEN 15
							ELSE NULL::integer
						END
				), aging_max AS (
				SELECT raw.geo,
					max(raw.aging) AS max_aging,
					case when count(DISTINCT
						CASE
							WHEN raw.geo = 'VN'::text AND raw.aging = 15 OR raw.geo = 'ID'::text AND raw.aging = 28 OR raw.geo = 'TH'::text AND raw.aging = 17 OR raw.geo = 'MY'::text AND raw.aging = 15 THEN raw.lead_id
							ELSE NULL::bigint
						END) = 0 then 0
					else 
					count(DISTINCT
						CASE
							WHEN raw.status_fn = 'delivered'::text AND (raw.geo = 'VN'::text AND raw.aging = 15 OR raw.geo = 'ID'::text AND raw.aging = 28 OR raw.geo = 'TH'::text AND raw.aging = 17 OR raw.geo = 'MY'::text AND raw.aging = 15) THEN raw.lead_id
							ELSE NULL::bigint
						END)::double precision / count(DISTINCT
						CASE
							WHEN raw.geo = 'VN'::text AND raw.aging = 15 OR raw.geo = 'ID'::text AND raw.aging = 28 OR raw.geo = 'TH'::text AND raw.aging = 17 OR raw.geo = 'MY'::text AND raw.aging = 15 THEN raw.lead_id
							ELSE NULL::bigint
						END)::double precision end AS dr_aging_max
				FROM cte_raw raw
				GROUP BY raw.geo
				), group_raw AS (
				SELECT raw.geo,
					raw.aging,
					count(DISTINCT
						CASE
							WHEN raw.status_fn = 'delivered'::text THEN raw.lead_id
							ELSE NULL::bigint
						END)::double precision / count(DISTINCT raw.lead_id)::double precision AS dr_percentage,
					count(DISTINCT
						CASE
							WHEN raw.status_fn = 'intransit'::text THEN raw.lead_id
							ELSE NULL::bigint
						END)::double precision / count(DISTINCT raw.lead_id)::double precision AS intransit_percentage,
					am.max_aging,
					am.dr_aging_max
				FROM cte_raw raw
					LEFT JOIN aging_max am ON raw.geo = am.geo
				GROUP BY raw.geo, raw.aging, am.max_aging, am.dr_aging_max
				)
		SELECT group_raw.geo,
			group_raw.aging,
			group_raw.dr_percentage,
			group_raw.intransit_percentage,
			group_raw.max_aging,
			group_raw.dr_aging_max,
			group_raw.dr_aging_max - group_raw.dr_percentage AS dr_adding,
				CASE
					WHEN group_raw.intransit_percentage = 0::double precision THEN 0::double precision
					ELSE
					CASE
						WHEN ((group_raw.dr_aging_max - group_raw.dr_percentage) / group_raw.intransit_percentage) < 0::double precision THEN 0::double precision
						WHEN ((group_raw.dr_aging_max - group_raw.dr_percentage) / group_raw.intransit_percentage) > 1::double precision THEN 1::double precision
						ELSE (group_raw.dr_aging_max - group_raw.dr_percentage) / group_raw.intransit_percentage
					END
				END AS ins_to_del
		FROM group_raw
	"""
    conn = pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG"))
    cur = conn.cursor()
    data = pd.read_sql_query(q,conn)
    conn.commit()
    cur.close()
    conn.close()
    return data

##Resell # Function: Insert data
@asset(group_name="auto_bot_2", deps=["load_intransit_to_delivered_resell"])
def insert_intransit_to_delivered_resell():
    print("Establishing connection to DWH...")
    conn = pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG"))
    cur = conn.cursor()
    cur.execute("SET statement_timeout = 0")
    conn.commit()

    print("START TRUNCATING table intransit_to_delivered_resell") 

    #Truncate
    cur.execute("truncate table intransit_to_delivered_resell")
    conn.commit()
    print("-Finish truncating table intransit_to_delivered_resell...")


    # Insert data
    data = load_intransit_to_delivered_resell()
    output_path = r'E:\OneDrive - NEYU.CO\Finance Cost Input\Agg_data'
    output_file = 'intransit_to_delivered_resell.csv'
    data.to_csv(os.path.join(output_path,output_file))
    print("DATA IS EXPORTED TO {}\n file's name is {} \n".format(output_path, output_file),datetime.now())

    df_columns = list(data)
    # create (col1,col2,...)
    # columns = ",".join(df_columns)
    columns = str(df_columns).replace("'",'"').replace('[','').replace(']','')


    # create VALUES('%s', '%s",...) one '%s' per column
    values = "VALUES({})".format(",".join(["%s" for _ in df_columns])) 

    #create INSERT INTO table (columns) VALUES('%s',...) 
    insert_stmt = "INSERT INTO {} ({}) {}".format('intransit_to_delivered_resell',columns,values)

    #create INSERT INTO table (columns) VALUES('%s',...)
    cur = conn.cursor()
    psycopg2.extras.execute_batch(cur, insert_stmt, data.values)
    conn.commit()
    cur.close()
    conn.close()
    print("-Finish inserting intransit_to_delivered_resell")




    cur.close()
    conn.close()

    print("-Finish inserting intransit_to_delivered_resell")


#--------------------------------------------------------------------------------------------------------------------------------------------
#Refresh finance daily report view

def count_finance_view():
    q = f"""
        select count(*) from finance_daily_view
            """
    conn = pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG"))
    cur = conn.cursor()
    data = pd.read_sql_query(q,conn)
    conn.commit()
    cur.close()
    conn.close()

    return data # data_length

@asset(group_name="auto_bot_2")
def refresh_finance_view():
    print("Start refreshing...")


    print("Establishing connection to DWH...")
    conn = pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG"))
    cur = conn.cursor()
    cur.execute("SET statement_timeout = 0")
    conn.commit()

    print("Refreshing finance_daily_view") 
    cur.execute("REFRESH MATERIALIZED VIEW finance_daily_view")
    conn.commit()

    print("Finish refreshing finance_daily_view")
    cur.close()
    conn.close()






#------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
### Realtime CS Tracking
def count_realtime_cs():
    q = f"""
        select count(*) from realtime_cs_tracking
            """
    conn = pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG"))
    cur = conn.cursor()
    data = pd.read_sql_query(q,conn)
    conn.commit()
    cur.close()
    conn.close()

    return data # data_length

@asset(group_name="auto_bot_2")
def refresh_realtime_cs():
    print("Start refreshing...")
    # bot.send_message(chat_id, text = 'Start refreshing realtime_cs_tracking...')

    print("Establishing connection to DWH...")
    conn = pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG"))
    cur = conn.cursor()
    cur.execute("SET statement_timeout = 0")
    conn.commit()

    print("Refreshing realtime_cs_tracking") 
    cur.execute("REFRESH MATERIALIZED VIEW realtime_cs_tracking")
    conn.commit()

    print("Finish refreshing realtime_cs_tracking")
    cur.close()
    conn.close()


 

#-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
## Refresh dim group product
@asset(group_name="auto_bot_2")
def refresh_dim_group_product():
    print("Start refreshing...")


    print("Establishing connection to DWH...")
    conn = pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG"))
    cur = conn.cursor()
    cur.execute("SET statement_timeout = 0")
    conn.commit()

    print("Refreshing dim_group_product_temp") 
    cur.execute("REFRESH MATERIALIZED VIEW dim_group_product_temp")
    conn.commit()

    print("Finish refreshing dim_group_product_temp")
    cur.close()
    conn.close()






# --------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# Log data
def get_raw_data():
    q = """
with prod_skill as (
with temp_so as (
SELECT so_id, geo,
SUM(coalesce(quantity,0)) no_quantity,
COUNT(DISTINCT prod_id) as no_product 
FROM od_so_item osi where geo in ('VN', 'VN2', 'VN3','VN4')
group by so_id, geo
),
group_so as (
select *,
case when no_product > 1 then 'Cross_sell'
	when no_quantity > 12 then 'Upsell > 12'
	when no_quantity > 5 and no_quantity <= 12 then 'Upsell 6-12'
	when no_quantity > 1 and no_quantity <= 5 then 'Upsell 2-5'
	else 'Normal'
end as prod_skill
from temp_so
)
select *
from group_so),
log AS (
select odn.geo geo,
	odn.org_id orgId,
	odn.so_id saleorder,
	odn.customer_id leadid,
	cl.lead_type leadtype, 
	cl.total_call,
	cl.address dia_chi,
	cl.ghi_chu_khach_hang,
	odn.do_code, -- deliverycode,
	odn.tracking_code trackingcode,
	odn.do_id,
	case when COALESCE(j.shortname, cl.agc_code) = 'AFS' then affiliate_id else COALESCE(j.shortname, cl.agc_code) end as sourcename,
--	case when COALESCE(j.shortname, cl.agc_code) = 'AFS' then subid1 else affiliate_id end as pub,
	h.user_name username,
--	cl.cp_name,
	cl.address,
	odn.customer_name,
--	lead_product,
--	COALESCE(odn.package_name,'None') productcrosssell,
--	a.customer_address,
--	ns."name" location_status, 
	n.code zipcode_db,
--	t.name neighborhood,
	n.name wards,
	m.name district,
	l.name province,
--	reg.region_name AS region,
	b.shortname ffmname,
	warehouse_name,
	e.shortname carrier,
	p.name status,
	o.name sostatus,
	d.name statustransport,
	CASE
		WHEN d.name IN ('delivered', 'refund') THEN 'Delivered'
		WHEN d.name IN ('returned','returning') THEN 'Reject'
		WHEN d.name IN ('intransit', 'packed', 'ready to pick') THEN 'Intransit' -- 31.01.23
		when d.name in ('delivering', 'delivery fail', 'picked up') then 'Delivering' -- 31.01.23
		WHEN d.name IN ('cancel') THEN 'Cancelled'
		WHEN d.name IN ('new', 'pending', 'picking') THEN 'New'
		WHEN d.name = 'Unassigned' then 'Unassigned'  -- 31.01.23
		ELSE 'Undefined'  -- 31.01.23
	END AS adjusted_status_transport,
--	CASE
--		WHEN d.name IN ('delivered', 'refund') THEN 'Success'
--		WHEN d.name IN ('returning','returned', 'cancel') THEN 'Fail'
--		WHEN d.name IN ('new', 'picking', 'pending') THEN 'New order'
--		ELSE 'In transit'
--	END AS zone_status,
	odn.createdate as createdate_dt,
	date(odn.createdate) AS created_date,
        odn.closetime,
        odn.firstdelivertime,
	date_part('week', odn.createdate) AS week_of_year,
	to_char(odn.createdate, 'YYYY-MM') AS month_of_year,
	odn.updatedate AS do_updatedate,
	CASE
		oso.payment_method WHEN 1 THEN 'COD'
		WHEN 2 THEN 'Bank tranfer'
	END AS paymentmethod ,
	coalesce(oso.amount, 0) as amount,
	round(EXTRACT(epoch FROM (odn.createdate - oso.createdate))::numeric/86400,1) AS qa_time
	, q.product1, q.qty1, q.price1, q.product2, q.qty2, q.price2, q.product3, q.qty3, q.price3, q.product4, q.qty4, q.price4
	, odn.FFM_id
	, q.so_id
--	product1,
--	a.ffm_code,
--	EXTRACT(epoch FROM (firstdelivertime - a.createdate))/3600 AS lead_time
FROM
	(
	select * 
	from od_do_new
	WHERE
--	createdate >= date_trunc('month',current_date - interval '4 months')
	--and org_id = 11
--	and
	geo in ('VN', 'VN2', 'VN3','VN4')
--	and tracking_code in ( 'ULT2023013000604539', 'ULT2023050100661349', 'GAXMPAU8', 'GAXMPA39', 'SNP225201136') 
	) odn
LEFT JOIN od_sale_order oso ON
	odn.so_id = oso.so_id and odn.geo = oso.geo
LEFT JOIN (
	SELECT cl.geo, cl.org_id, lead_id, prod_name, pp.name lead_product, total_call,lead_status, lead_type, agc_id, agc_code,
	assigned,cl.address, province, district, subdistrict, postal_code, affiliate_id, subid1, cc.name cp_name, comment as ghi_chu_khach_hang
	FROM cl_fresh cl
	LEFT JOIN pd_product pp ON
	pp.prod_id = cl.prod_id and pp.geo = cl.geo
	LEFT JOIN cp_campaign cc ON
	cc.cp_id = cl.cp_id and cc.geo = cl.geo
	WHERE cl.modifydate >= date_trunc('month',current_date - interval '4 months') 
	and cl.cp_id not in (504,505) -- Remove Orders From System Repository/ResearchMarket
	--and cl.org_id = 11
	) cl ON
	cl.lead_id = odn.customer_id and cl.geo = odn.geo
LEFT JOIN (
	SELECT
		so_id, a.geo,
		max((CASE WHEN item_no = 1 THEN b.name END)) AS product1,
		coalesce(max((CASE WHEN item_no = 1 THEN quantity END)), 0) AS qty1,
		coalesce(max((CASE WHEN item_no = 1 THEN a.price END)), 0) AS price1,
		max((CASE WHEN item_no = 2 THEN b.name END)) AS product2,
		coalesce(max((CASE WHEN item_no = 2 THEN quantity END)), 0) AS qty2,
		coalesce(max((CASE WHEN item_no = 2 THEN a.price END)), 0) AS price2,
		max((CASE WHEN item_no = 3 THEN b.name END)) AS product3,
		coalesce(max((CASE WHEN item_no = 3 THEN quantity END)), 0) AS qty3,
		coalesce(max((CASE WHEN item_no = 3 THEN a.price END)), 0) AS price3,
		max((CASE WHEN item_no = 4 THEN b.name END)) AS product4,
		coalesce(max((CASE WHEN item_no = 4 THEN quantity END)), 0) AS qty4,
		coalesce(max((CASE WHEN item_no = 4 THEN a.price END)), 0) AS price4
	FROM
		od_so_item a 
	JOIN pd_product b ON
		a.prod_id = b.prod_id and a.geo = b.geo
	WHERE a.geo in ('VN', 'VN2', 'VN3','VN4')
	GROUP BY
		so_id, a.geo
	ORDER BY
		so_id desc
		) q ON
	q.so_id = oso.so_id and q.geo = oso.geo
-- Join partner
LEFT JOIN bp_partner b ON
	odn.FFM_id = b.pn_id and odn.geo = b.geo
LEFT JOIN bp_warehouse c ON
	odn.warehouse_id = c.warehouse_id and odn.geo = c.geo
LEFT JOIN bp_partner e ON
	e.pn_id = odn.carrier_id and e.geo = odn.geo 
LEFT JOIN or_user h ON
	cl.assigned = h.user_id and cl.geo = h.geo
LEFT JOIN bp_partner j ON
	j.pn_id = cl.agc_id and j.geo = cl.geo
-- Join region
LEFT JOIN lc_province l ON
	l.prv_id::TEXT = cl.province and l.geo = cl.geo
LEFT JOIN lc_region AS reg ON
	l.region_id = reg.region_id and l.geo = reg.geo
LEFT JOIN lc_district m ON
	m.dt_id::TEXT = cl.district and m.geo = cl.geo
LEFT JOIN lc_subdistrict n ON
	n.sdt_id::TEXT = cl.subdistrict and n.geo = cl.geo
--left join lc_neighborhood t on 
--	t.id = cl.neighborhood::integer
left join lc_postal_code u on 
	u.id::text = cl.postal_code and u.geo = cl.geo
-- Join status
LEFT JOIN (
	SELECT *
	FROM cf_synonym
	WHERE
		TYPE = 'delivery order status' and geo in ('VN', 'VN2', 'VN3','VN4'))d ON
	odn.status = d.value and odn.geo = d.geo
LEFT JOIN (
	SELECT *
	FROM cf_synonym
	WHERE
		TYPE = 'sale order status' and geo in ('VN', 'VN2', 'VN3','VN4'))o ON
	oso.status = o.value and oso.geo = o.geo
LEFT JOIN (
	SELECT *
	FROM cf_synonym
	WHERE
		TYPE = 'lead status' and geo in ('VN', 'VN2', 'VN3','VN4'))p ON
	cl.lead_status = p.value and cl.geo = p.geo
)
---------------------- Main query
SELECT
	log.created_date,
	log.so_id ma_don_hang,
	log.do_code ma_don_goc,
	log.customer_name ten_nguoi_nhan,
	null as so_dien_thoai_khach_hang,
	log.sourcename source,
	log.username assgin,
	log.dia_chi,
	log.wards phuong_xa,
	log.district quan_huyen,
	log.province tinh_thanh_pho,
	log.carrier,
	log.ghi_chu_khach_hang ,
	log.status,
	log.sostatus sub_status,
	log.adjusted_status_transport status_transport,
	log.do_updatedate updated_date,
	log.total_call,
	log.paymentmethod payment_method,
	log.amount so_tien_thu_cod,
	log.product1 products_name_1,
	log.qty1 products_qty_1,
	log.price1 products_price_1,
	log.product2 products_name_2,
	log.qty2 products_qty_2,
	log.price2 products_price_2,
	log.product3 products_name_3,
	log.qty3 products_qty_3,
	log.price3 products_price_3,
	log.product4 products_name_4,
	log.qty4 products_qty_4,
	log.price4 products_price_4,
	log.trackingcode tracking_code,
	log.ffmname warehouse,
	log.geo
--	no_product,
--	no_quantity,
--	p.prod_skill,
--	CASE
--		WHEN log.username LIKE 'a%' THEN 'Fresh'
--		WHEN log.username LIKE 'r%' THEN 'CIT'
--		ELSE 'Others'
--	END AS team,
--	CASE
--		when leadtype = 'M' and lower(sourcename) like 'cr%' then 'CROSS SELL'
--		when leadtype = 'M' and lower(sourcename) like 'de%' then 'DELIVERED'
--		when leadtype = 'M' and lower(sourcename) like 're%' then 'RETURNED'
--		when leadtype = 'M' and lower(sourcename) is null then 'LOYAL CUSTOMER'
--		when leadtype = 'M' then 'Resell_Others'
--		ELSE sourcename 
--	END AS final_source
FROM
	log
--LEFT JOIN prod_skill p ON
--	log.saleorder = p.so_id and log.geo = p.geo
--left join dim_group_product gp 
--	on gp.prod_name = log.product1
    """
    try:
        conn = pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG"))
        cur = conn.cursor()
        data = pd.read_sql_query(q,conn)
        conn.commit()
        cur.close()
        conn.close()
    except:
        data = pd.DataFrame()
    return data 


def get_region():
    q = """
    select "Tỉnh, Thành Phố" , "Regional" , "Areas"
    from dim_region_logvn 
    """
    try:
        conn = pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG"))
        cur = conn.cursor()
        data = pd.read_sql_query(q,conn)
        conn.commit()
        cur.close()
        conn.close()
    except:
        data = pd.DataFrame()
    return data 

@asset(group_name="auto_bot_2")
def transform_log_data():
    raw_df = get_raw_data()
    region = get_region()
    df = pd.DataFrame()
    # df_ffm = pd.DataFrame(columns = ['product', 'beginning_inventory', 'import', 'export', 'ending_inventory', 'warehouse', 'period', 'days', 'DSI'])
    df = raw_df[['created_date', 'ma_don_hang', 'ma_don_goc',
        'ten_nguoi_nhan', 'so_dien_thoai_khach_hang', 'source', 'assgin',
        'dia_chi', 'phuong_xa', 'quan_huyen', 'tinh_thanh_pho', 'carrier',
        'ghi_chu_khach_hang', 'status', 'sub_status', 'status_transport','updated_date', 
            'total_call', 'payment_method',
        'so_tien_thu_cod', 'products_name_1', 'products_qty_1',
        'products_price_1', 'products_name_2', 'products_qty_2',
        'products_price_2', 'products_name_3', 'products_qty_3',
        'products_price_3', 'products_name_4', 'products_qty_4', "products_price_4",
        'tracking_code', 'warehouse', 'geo'
        ]]
    # ko lay cot so dien thoai trong df o phia tren
    # drop rows that cause errors
    df = df.dropna(subset=['created_date'])
    df['created_date'] = df['created_date'].apply(lambda x: str(x)[0:10])
    #df['Updated_date'] = df['Updated_date'].apply(lambda x: str(x)[0:10])
    for i in range(len(df)):
        try:
            #print(df['Created_date'].iat[i])
            df['created_date'].iat[i] = pd.to_datetime(datetime.strptime(df['created_date'].iat[i], '%d-%m-%Y').strftime('%Y-%m-%d'), format='%Y-%m-%d')
        except:
            #print('error')
            #print(df['Created_date'].iat[i])
            df['created_date'].iat[i] = pd.to_datetime(df['created_date'].iat[i])

    for i in range(len(df)):
        try:
            if math.isnan(df['so_tien_thu_cod'].iat[i]):
                df['so_tien_thu_cod'].iat[i] = 0
            else:
                df['so_tien_thu_cod'].iat[i]+1
        except:
            df['so_tien_thu_cod'].iat[i] = 0
        try:
            if math.isnan(df['products_price_1'].iat[i]):
                df['products_price_1'].iat[i] = 0
            else:
                df['products_price_1'].iat[i]+1
        except:
            df['products_price_1'].iat[i] = 0
        
        try:
            if math.isnan(df['products_price_2'].iat[i]):
                df['products_price_2'].iat[i] = 0
            else:
                df['products_price_2'].iat[i]+1
        except:
            df['products_price_2'].iat[i] = 0
        try:
            if math.isnan(df['products_price_3'].iat[i]):
                df['products_price_3'].iat[i] = 0
            else:
                df['products_price_3'].iat[i]+1
        except:
            df['products_price_3'].iat[i] = 0
        try:
            if math.isnan(df['products_price_4'].iat[i]):
                df['products_price_4'].iat[i] = 0
            else:
                df['products_price_4'].iat[i]+1
        except:
            df['products_price_4'].iat[i] = 0
        try:
            if math.isnan(df['products_qty_1'].iat[i]):
                df['products_qty_1'].iat[i] = 0
            else:
                df['products_qty_1'].iat[i]+1
        except:
            df['products_qty_1'].iat[i] = 0
        try:
            if math.isnan(df['products_qty_2'].iat[i]):
                df['products_qty_2'].iat[i] = 0
            else:
                df['products_qty_2'].iat[i]+1
        except:
            df['products_qty_2'].iat[i] = 0
        try:
            if math.isnan(df['products_qty_3'].iat[i]):
                df['products_qty_3'].iat[i] = 0
            else:
                df['products_qty_3'].iat[i]+1
        except:
            df['products_qty_3'].iat[i] = 0
        try:
            if math.isnan(df['products_qty_4'].iat[i]):
                df['products_qty_4'].iat[i] = 0
            else:
                df['products_qty_4'].iat[i]+1
        except:
            df['products_qty_4'].iat[i] = 0

    df['total_qty'] = df['products_qty_1'] + df['products_qty_2'] + df['products_qty_3'] + df['products_qty_4']
    df['total_value'] = (df['products_price_1']*df['products_qty_1'])+(df['products_price_2']*df['products_qty_2'])+(df['products_price_3']*df['products_qty_3'])+(df['products_price_4']*df['products_qty_4'])
    df['delivered'] = df.apply(lambda row: 1 if str(row['status_transport']).lower() == 'delivered' else 0, axis=1)
    df['reject'] = df.apply(lambda row: 1 if str(row['status_transport']).lower() == 'reject' else 0, axis=1)
    df['cancelled'] = df.apply(lambda row: 1 if str(row['status_transport']).lower() == 'cancelled' else 0, axis=1)
    df['unassigned'] = df.apply(lambda row: 1 if str(row['status_transport']).lower() == 'unassigned' else 0, axis=1)
    df['delivered_amount'] = df.apply(lambda row: row['total_value'] if row['delivered'] == 1 else 0, axis=1)
    df['reject_amount'] = df.apply(lambda row: row['total_value'] if row['reject'] == 1 else 0, axis=1)
    df['cancelled_amount'] = df.apply(lambda row: row['total_value'] if row['cancelled'] == 1 else 0, axis=1)
    df['unassigned_amount'] = df.apply(lambda row: row['total_value'] if row['unassigned'] == 1 else 0, axis=1)
    # add new columns
    df['tinh_thanh_pho'] = df['tinh_thanh_pho'].apply(lambda x: 'Đắk Nông' if x == 'Đăk Nông' else 'Đắk Lắk' if x == 'Đăk Lăk' else x)
    df['area'] = df.apply(lambda row: 'North' if row['tinh_thanh_pho'] in list(region[region['Areas'] == 'North']['Tỉnh, Thành Phố'])
                            else 'South' if row['tinh_thanh_pho'] in list(region[region['Areas'] == 'South']['Tỉnh, Thành Phố'])
                            else 'Central' if row['tinh_thanh_pho'] in list(region[region['Areas'] == 'Central']['Tỉnh, Thành Phố'])
                            else 'Need update' , axis=1)
    df['region'] = df.apply(lambda row: 'North - Hà Nội' if row['tinh_thanh_pho'] in list(region[region['Regional'] == 'North - Hà Nội']['Tỉnh, Thành Phố'])
                            else 'Central - Bắc Trung Bộ' if row['tinh_thanh_pho'] in list(region[region['Regional'] == 'Central - Bắc Trung Bộ']['Tỉnh, Thành Phố'])
                            else 'North - Đồng bằng sông Hồng' if row['tinh_thanh_pho'] in list(region[region['Regional'] == 'North - Đồng bằng sông Hồng']['Tỉnh, Thành Phố'])
                            else 'South - Tây Nam Bộ' if row['tinh_thanh_pho'] in list(region[region['Regional'] == 'South - Tây Nam Bộ']['Tỉnh, Thành Phố'])
                            else 'South - Hồ Chí Minh' if row['tinh_thanh_pho'] in list(region[region['Regional'] == 'South - Hồ Chí Minh']['Tỉnh, Thành Phố'])
                            else 'South - Tây Nguyên' if row['tinh_thanh_pho'] in list(region[region['Regional'] == 'South - Tây Nguyên']['Tỉnh, Thành Phố'])
                            else 'North - Hải Phòng' if row['tinh_thanh_pho'] in list(region[region['Regional'] == 'North - Hải Phòng']['Tỉnh, Thành Phố'])
                            else 'South - Đông Nam Bộ' if row['tinh_thanh_pho'] in list(region[region['Regional'] == 'South - Đông Nam Bộ']['Tỉnh, Thành Phố'])
                            else 'North - Trung du và miền núi phía Bắc' if row['tinh_thanh_pho'] in list(region[region['Regional'] == 'North - Trung du và miền núi phía Bắc']['Tỉnh, Thành Phố'])
                            else 'Central - Nam Trung Bộ' if row['tinh_thanh_pho'] in list(region[region['Regional'] == 'Central - Nam Trung Bộ']['Tỉnh, Thành Phố'])
                            else 'South - Cần Thơ' if row['tinh_thanh_pho'] in list(region[region['Regional'] == 'South - Cần Thơ']['Tỉnh, Thành Phố'])
                            else 'Central - Đà Nẵng' if row['tinh_thanh_pho'] in list(region[region['Regional'] == 'Central - Đà Nẵng']['Tỉnh, Thành Phố'])
                            else 'Need update', axis=1)
    df['type'] = 'Daily'
    df.drop_duplicates(subset=['ma_don_goc', 'status_transport'],inplace=True)
    print('before kho')
    print(len(df))

    df_final = df.where(pd.notnull(df), None)
    df_final = df.fillna(np.nan).replace({np.nan: None})
    print('Final dataframe: ', len(df), '\n Null value: ', df.isnull().sum())
    data = df_final 

    return data

@asset(group_name="auto_bot_2", deps=["transform_log_data"])
def update_log_data_vn():

    df_final = transform_log_data()

    
    print("-Establishing connection to DWH...")

    conn = pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG"))
    cur = conn.cursor()
    cur.execute("SET statement_timeout = 0")
    conn.commit()

    cur.execute("delete from log_data_vn_temp")
    conn.commit()
    print('-Finish deleting from log_data_vn_temp DWH') 


    df_columns = list(df_final)
    ## create (col1,col2,...)
    columns = ",".join(df_columns)

    ## create VALUES('%s', '%s",...) one '%s' per column
    values = "VALUES({})".format(",".join(["%s" for _ in df_columns])) 

    ## create INSERT INTO table (columns) VALUES('%s',...)
    insert_stmt = "INSERT INTO {} ({}) {}".format('log_data_vn_temp',columns,values)
    ## create INSERT INTO table (columns) VALUES('%s',...)
    cur = conn.cursor()
    psycopg2.extras.execute_batch(cur, insert_stmt, df_final.values)
    conn.commit()
    cur.close()
    conn.close()

    print("-Finish updating log_data_vn_temp DWH")


    return



## --------------------------
## MB Balance realtime 
def insert_into_table(table_name, data_df):
    print("Start refreshing...")

    if len(data_df) == 0:
        print("Input table has no data. Skip processing...")
        return

    print("Establishing connection to DWH...")

    conn = pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG"))
    cur = conn.cursor()
    cur.execute("SET statement_timeout = 0")
    conn.commit()

    command_execute = "truncate table {}".format(table_name)
    cur.execute(command_execute)
    conn.commit()
    print("-Finish truncating from {} DWH".format(table_name))

    # find available column names in datawarehouse
    with conn.cursor() as cur:
        cur.execute(f"select * from {table_name} where false")
        dwh_col_names = [col.name for col in cur.description if col.name != "index"]

    data_df = data_df.loc[:, dwh_col_names]
    columns = ",".join(data_df)
    values = "VALUES({})".format(",".join(["%s" for _ in data_df]))
    insert_stmt = "INSERT INTO {} ({}) {}".format(table_name, columns, values)
    cur = conn.cursor()
    psycopg2.extras.execute_batch(cur, insert_stmt, data_df.values)
    conn.commit()
    cur.close()
    conn.close()

    print("-Finish updating {} DWH".format(table_name))
    


@asset(group_name="auto_bot_2")
def mb_adnet_media_buyer_func():
    q = f"""
    with cte_raw as (
        select distinct regexp_replace(ts_name, '[-(].*', '') AS adnet
            , SPLIT_PART(group_name,'_',1) media_buyer
        from mb_data md )
    select * , adnet || '_' || media_buyer as mapping_key
    from cte_raw
        """
    conn = pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG"))
    cur = conn.cursor()
    data = pd.read_sql_query(q,conn)
    conn.commit()
    cur.close()
    conn.close()
    return data



## 10.12.2023
def get_dim_bd_team_level_input(geo = 'team'):
    q = f"""
        select * from dim_bd_team_level_input
            """
    conn = pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG"))
    cur = conn.cursor()
    data = pd.read_sql_query(q,conn)
    conn.commit()
    cur.close()
    conn.close()
    return data


# Dictionary to store managers and their subordinates
def transform_dim_bd_team_level_input():
    managers_dict = {}
    existing_df = get_dim_bd_team_level_input()
    for index, row in existing_df.iterrows():
        head = row["head_level"]
        manager_2 = row["bd_level_2"]
        manager_3 = row["bd_level_3"]
        bd_level_1 = row["bd_level_1"]

        if manager_2 not in managers_dict:
            managers_dict[manager_2] = []
        managers_dict[manager_2].append(bd_level_1)

        if manager_3 not in managers_dict:
            managers_dict[manager_3] = []
        managers_dict[manager_3].append(bd_level_1)

        if head not in managers_dict:
            managers_dict[head] = []
        managers_dict[head].append(bd_level_1)

        if bd_level_1 not in managers_dict:
            managers_dict[bd_level_1] = []
        managers_dict[bd_level_1].append(bd_level_1)

    return managers_dict



# Function to generate manager-subordinates relationships DataFrame
def generate_manager_subordinates(manager):
    managers_dict = transform_dim_bd_team_level_input()
    subordinates = managers_dict.get(manager, []) 
    data = [{'manager': manager, 'subordinates': subordinate} for subordinate in subordinates]
    return pd.DataFrame(data)

# Generate the Manager-Subordinates DataFrame
def load_manager_subordinates():
    managers_dict = transform_dim_bd_team_level_input()
    result_df = pd.concat([generate_manager_subordinates(manager) for manager in managers_dict.keys()], ignore_index=True)
    result_df = result_df.drop_duplicates()

    return result_df

@asset(group_name="auto_bot_2")
def insert_data_dim_bd_team_level_input_rls(): 
    try:
        print("Start loading...")
        df = load_manager_subordinates()  
        
        print("-Establishing connection to DWH...")
        conn = pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG"))

        cur = conn.cursor()
        cur.execute("SET statement_timeout = 0")
        conn.commit()

        cur.execute("delete from dim_bd_team_level_input_rls")
        conn.commit()
        print('-Finish deleting from dim_bd_team_level_input_rls DWH')

        # create (col1,col2,...)
        columns = ",".join(df)

        # create VALUES('%s', '%s",...) one '%s' per column
        values = "VALUES({})".format(",".join(["%s" for _ in df]))

        #create INSERT INTO table (columns) VALUES('%s',...)
        insert_stmt = "INSERT INTO {} ({}) {}".format('dim_bd_team_level_input_rls',columns,values)
        cur = conn.cursor()
        psycopg2.extras.execute_batch(cur, insert_stmt, df.values)
        conn.commit()
        cur.close()
        conn.close()


        
    except Exception as e:
        print(f"The bot is facing with error: {e}")

    return  
    




# schedule
#--------------------------------------------------------------------------------------------
# schedule refresh_cs_vn_view
# schedule.every().day.at("08:40").do(refresh_cs_vn_view)
# schedule.every().day.at("11:40").do(refresh_cs_vn_view)
# schedule.every().day.at("15:40").do(refresh_cs_vn_view)
# schedule.every().day.at("19:44").do(refresh_cs_vn_view) 
refresh_cs_vn_view_job = define_asset_job(
    "refresh_cs_vn_view_job",
    selection=[
        refresh_cs_vn_view,
    ],
)

refresh_cs_vn_view_schedule = ScheduleDefinition(
    job=refresh_cs_vn_view_job,
    cron_schedule="40 8,11,15,19 * * *",
    execution_timezone=TIMEZONE,
)

#-----------------------------------------------------------------------------------------
# schedule refresh_traffic_bd_master
# schedule.every().day.at("07:55").do(refresh_traffic_bd_master)
refresh_traffic_bd_master_job = define_asset_job(
    "auto_bot_refresh_traffic_bd_master_job",
    selection=[
        refresh_traffic_bd_master,
    ],
)

refresh_traffic_bd_master_schedule = ScheduleDefinition(
    job=refresh_traffic_bd_master_job,
    cron_schedule="55 7 * * *",
    execution_timezone=TIMEZONE,
)



#-----------------------------------------------------------------------------------------
# schedule refresh_resell_forecast_view
# schedule.every().day.at("02:30").do(refresh_resell_forecast_view)
refresh_resell_forecast_view_job = define_asset_job(
    "auto_bot_refresh_resell_forecast_view_job",
    selection=[
        refresh_resell_forecast_view,
    ],
)

refresh_resell_forecast_view_schedule = ScheduleDefinition(
    job=refresh_resell_forecast_view_job,
    cron_schedule="30 2 * * *",
    execution_timezone=TIMEZONE,
)



#-----------------------------------------------------------------------------------------
# schedule update_log_data_vn
# schedule.every().day.at("07:10").do(update_log_data_vn)
update_log_data_vn_job = define_asset_job(
    "auto_bot_update_log_data_vn_job",
    selection=[
        update_log_data_vn,
    ],
)

update_log_data_vn_schedule = ScheduleDefinition(
    job=update_log_data_vn_job,
    cron_schedule="10 7 * * *",
    execution_timezone=TIMEZONE,
)
#-----------------------------------------------------------------------------------------
# schedule update_log_data_vn
# schedule.every().day.at("11:40").do(update_log_data_vn)
update_log_data_vn_job_01 = define_asset_job(
    "auto_bot_update_log_data_vn_job_01",
    selection=[
        update_log_data_vn,
    ],
)

update_log_data_vn_schedule_01 = ScheduleDefinition(
    job=update_log_data_vn_job_01,
    cron_schedule="40 11 * * *",
    execution_timezone=TIMEZONE,
)
#-----------------------------------------------------------------------------------------
# schedule update_log_data_vn
# schedule.every().day.at("17:18").do(update_log_data_vn)
update_log_data_vn_job_02 = define_asset_job(
    "auto_bot_update_log_data_vn_job_02",
    selection=[
        update_log_data_vn,
    ],
)

update_log_data_vn_schedule_02 = ScheduleDefinition(
    job=update_log_data_vn_job_02,
    cron_schedule="18 17 * * *",
    execution_timezone=TIMEZONE,
)



#-----------------------------------------------------------------------------------------
# schedule insert_cdm_dim_dr_fc_resell
# schedule.every().day.at("07:00").do(insert_cdm_dim_dr_fc_resell)
insert_cdm_dim_dr_fc_resell_job = define_asset_job(
    "auto_bot_insert_cdm_dim_dr_fc_resell_job",
    selection=[
        insert_cdm_dim_dr_fc_resell,
    ],
)

insert_cdm_dim_dr_fc_resell_schedule = ScheduleDefinition(
    job=insert_cdm_dim_dr_fc_resell_job,
    cron_schedule="0 7 * * *",
    execution_timezone=TIMEZONE,
)
#-----------------------------------------------------------------------------------------
# schedule insert_cdm_dim_dr_fc_resell
# schedule.every().day.at("11:36").do(insert_cdm_dim_dr_fc_resell)
insert_cdm_dim_dr_fc_resell_job_01 = define_asset_job(
    "auto_bot_insert_cdm_dim_dr_fc_resell_job_01",
    selection=[
        insert_cdm_dim_dr_fc_resell,
    ],
)

insert_cdm_dim_dr_fc_resell_schedule_01 = ScheduleDefinition(
    job=insert_cdm_dim_dr_fc_resell_job_01,
    cron_schedule="36 11 * * *",
    execution_timezone=TIMEZONE,
)
#-----------------------------------------------------------------------------------------
# schedule insert_cdm_dim_dr_fc_resell
# schedule.every().day.at("17:14").do(insert_cdm_dim_dr_fc_resell)
insert_cdm_dim_dr_fc_resell_job_02 = define_asset_job(
    "auto_bot_insert_cdm_dim_dr_fc_resell_job_02",
    selection=[
        insert_cdm_dim_dr_fc_resell,
    ],
)

insert_cdm_dim_dr_fc_resell_schedule_02 = ScheduleDefinition(
    job=insert_cdm_dim_dr_fc_resell_job_02,
    cron_schedule="14 17 * * *",
    execution_timezone=TIMEZONE,
)
#-----------------------------------------------------------------------------------------
# schedule insert_cdm_dim_dr_fc_resell
# schedule.every().day.at("23:30").do(insert_cdm_dim_dr_fc_resell)
insert_cdm_dim_dr_fc_resell_job_03 = define_asset_job(
    "auto_bot_insert_cdm_dim_dr_fc_resell_job_03",
    selection=[
        insert_cdm_dim_dr_fc_resell,
    ],
)

insert_cdm_dim_dr_fc_resell_schedule_03 = ScheduleDefinition(
    job=insert_cdm_dim_dr_fc_resell_job_03,
    cron_schedule="30 23 * * *",
    execution_timezone=TIMEZONE,
)



#-----------------------------------------------------------------------------------------
# schedule refresh_dim_group_product
# schedule.every().day.at("05:00").do(refresh_dim_group_product)
refresh_dim_group_product_job = define_asset_job(
    "auto_bot_refresh_dim_group_product_job",
    selection=[
        refresh_dim_group_product,
    ],
)

refresh_dim_group_product_schedule = ScheduleDefinition(
    job=refresh_dim_group_product_job,
    cron_schedule="0 5 * * *",
    execution_timezone=TIMEZONE,
)


#-----------------------------------------------------------------------------------------
# schedule update_bm_balance
# schedule.every().day.at("05:30").do(insert_data_dim_bd_team_level_input_rls)
insert_data_dim_bd_team_level_input_rls_job = define_asset_job(
    "insert_data_dim_bd_team_level_input_rls_job",
    selection=[
        insert_data_dim_bd_team_level_input_rls,
    ],
)

insert_data_dim_bd_team_level_input_rls_schedule = ScheduleDefinition(
    job=insert_data_dim_bd_team_level_input_rls_job,
    cron_schedule="30 5 * * *",
    execution_timezone=TIMEZONE,
)
