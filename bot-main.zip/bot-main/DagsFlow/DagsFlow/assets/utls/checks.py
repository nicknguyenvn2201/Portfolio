from typing import Optional, Protocol
from dagster import (
    AssetsDefinition,
    AssetCheckResult,
    AssetCheckSeverity,
    asset_check,
    MetadataValue,
)
from DagsFlow.assets.utls.sql import SqlStore
from dagster._core.definitions.asset_checks import (
    AssetChecksDefinition,
)
import pyarrow as pa
import pandas as pd
import hashlib
import duckdb


def find_duplicate_date_range(
    df: pd.DataFrame, from_date_col: str, to_date_col: str, partitions: str
) -> pd.DataFrame:
    templates = SqlStore()
    sql_query = templates.get("find_duplicated_date_range").render(
        model="df",
        from_date_col=from_date_col,
        to_date_col=to_date_col,
        partitions=partitions,
    )
    dup_df = duckdb.query(sql_query).df()
    return dup_df


def find_duplicate_dim(df: pd.DataFrame, partitions: str) -> pd.DataFrame:
    templates = SqlStore()
    sql_query = templates.get("find_duplicated_dim").render(
        model="df",
        partitions=partitions,
    )
    dup_df = duckdb.query(sql_query).df()
    return dup_df


class AssetCheckFactory(Protocol):
    def __init__(self) -> None:
        pass

    def create(self, asset: AssetsDefinition) -> AssetChecksDefinition:
        pass


class CheckDupDateRange:
    def __init__(self, from_date_col: str, to_date_col: str, partitions: str):
        self.from_date_col = from_date_col
        self.to_date_col = to_date_col
        self.partitions = partitions

    def create(self, asset: AssetsDefinition) -> AssetChecksDefinition:
        description = f"""Use SQL to check for overlap dates and keys. Keys to check: {self.partitions}"""
        check_name = asset.op.name + "_check_dup_date_range"

        @asset_check(
            name=check_name,
            asset=asset,
            description=description,
        )
        def _check(data) -> AssetCheckResult:
            duplicates = find_duplicate_date_range(
                data,
                from_date_col=self.from_date_col,
                to_date_col=self.to_date_col,
                partitions=self.partitions,
            )
            return AssetCheckResult(
                check_name=check_name,
                passed=duplicates.empty,
                metadata={
                    "Duplicates": MetadataValue.md(duplicates.to_markdown(index=False))
                },
                severity=AssetCheckSeverity.ERROR,
            )

        return _check


class CheckDupDim:
    def __init__(self, partitions: str):
        self.partitions = partitions

    def create(self, asset: AssetsDefinition) -> AssetChecksDefinition:
        description = f"""Use SQL to check for overlap in key dimensions. Keys to check: {self.partitions}"""
        check_name = asset.op.name + "_check_duplicate_dim"

        @asset_check(
            name=check_name,
            asset=asset,
            description=description,
        )
        def _check(data) -> AssetCheckResult:
            duplicates = find_duplicate_dim(
                data,
                partitions=self.partitions,
            )
            return AssetCheckResult(
                check_name=check_name,
                passed=duplicates.empty,
                metadata={
                    "Duplicates": MetadataValue.md(duplicates.to_markdown(index=False))
                },
                severity=AssetCheckSeverity.ERROR,
            )

        return _check


class CheckNullColumn:
    def __init__(self, columns: Optional[list[str]] = None):
        self.columns = columns

    def create(self, asset: AssetsDefinition) -> AssetChecksDefinition:
        description = f"""Check if any column contains null values. If None is provided at initialization, check on all columns"""
        check_name = asset.op.name + "_check_column_not_null"

        @asset_check(
            name=check_name,
            asset=asset,
            description=description,
        )
        def _check(data: pa.Table) -> AssetCheckResult:
            data: pd.DataFrame = data.to_pandas()
            if not self.columns:
                empty_df = data[data.isnull().any(axis=1)]
            else:
                empty_df = data[data[self.columns].isnull().any(axis=1)]
            return AssetCheckResult(
                check_name=check_name,
                passed=empty_df.empty,
                metadata={
                    "Null Values": MetadataValue.md(empty_df.to_markdown(index=False))
                },
                severity=AssetCheckSeverity.ERROR,
            )

        return _check
