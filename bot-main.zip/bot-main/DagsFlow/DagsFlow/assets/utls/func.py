from DagsFlow.assets.utls.sql import SqlStore
import pandas as pd
import psycopg as pg
import os
import io
import pyarrow as pa
import pyarrow.csv as pcsv
from typing import Union, Sequence, Optional, Literal
from dagster import get_dagster_logger, MetadataValue, Output, AssetIn, asset
from dagster import AssetsDefinition, AssetExecutionContext
from dagster._core.definitions.asset_checks import (
    AssetChecksDefinition,
    build_asset_with_blocking_check,
)
from DagsFlow.assets.utls.checks import AssetCheckFactory
import connectorx
from dateutil import tz
from DagsFlow.resources.msgraph import MSSiteClient
from DagsFlow.resources.postgres import PostgresConnection
import hashlib

logger = get_dagster_logger()


def extract_from_dwh(
    query: str,
    dwh_conn: PostgresConnection,
    **connectorx_kwargs,
):
    uri_conn = dwh_conn.as_uri_string()
    return connectorx.read_sql(uri_conn, query, **connectorx_kwargs)


def convert_utc_ts_to_local_tz(
    timestamp: pd.Timestamp, local_tz: str = "Asia/Ho_Chi_Minh"
) -> pd.Timestamp:
    local_tz = tz.gettz(local_tz)
    return timestamp.replace(tzinfo=tz.UTC).tz_convert(tz=local_tz)


def get_table_columns(cur: pg.Cursor, table_name: str) -> list[str]:
    return [
        col.name
        for col in cur.execute(f"select * from {table_name} where false").description
    ]


def get_table_indexes(cur: pg.Cursor, table_name: str) -> list[str]:
    return cur.execute(
        f"select indexname, indexdef from pg_indexes where tablename = '{table_name}'"
    ).fetchall()

def get_table_indexes_base_layer(cur: pg.Cursor, schema_name: str, table_name: str) -> list[str]:
    return cur.execute(
        f"select indexname, indexdef from pg_indexes where tablename = '{schema_name}.{table_name}'"
    ).fetchall()


def check_duplicate_date_range_postgres(
    cursor: pg.Cursor, model: str, from_date_col: str, to_date_col: str, partitions: str
) -> None:
    templates = SqlStore()
    sql_query = templates.get("find_duplicated_date_range_postgres").render(
        model=model,
        from_date_col=from_date_col,
        to_date_col=to_date_col,
        partitions=partitions,
    )
    dup_df = pd.DataFrame(cursor.execute(sql_query).fetchall())
    logger.error(dup_df)
    if not dup_df.empty:
        logger.error("Duplicated date range in:\n%s", str(dup_df))
        logger.error(f"Compiled SQL:\n{sql_query}")
        raise ValueError("Found duplicated date range")


def _map_arrow_to_pg_type(arrow_type) -> str:
    type_conversion = {
        "string": "text",
        "date32[day]": "date",
        "int32": "int8",
        "int16": "int8",
        "float32": "real",
        "double": "double precision",
        "time32[s]": "timestamp",
    }
    if str(arrow_type) in type_conversion:
        return type_conversion[arrow_type]
    return arrow_type


def check_if_table_exists(cursor: pg.Cursor, table_name: str) -> bool:
    cursor.execute(f"SELECT to_regclass('{table_name}')")
    return cursor.fetchone() != (None,)

def check_if_table_exist_base_layer(cursor: pg.Cursor, schema_name: str, table_name: str) -> bool:
    cursor.execute(f"SELECT to_regclass('{schema_name}.{table_name}')")
    return cursor.fetchone() != (None,)


def _reset_table(cursor: pg.Cursor, data: pa.Table, table_name: str):
    column_schema = list(
        zip(data.schema.names, map(_map_arrow_to_pg_type, data.schema.types))
    )
    cursor.execute(f"SELECT to_regclass('{table_name}')")
    if cursor.fetchone() == (None,):
        logger.info("Table not found. Creating a new one from schema ...")
        templates = SqlStore()
        sql_create = templates.get("create_table_from_arrow").render(
            table_name=table_name, column_schema=column_schema
        )
        cursor.execute(sql_create)
    else:
        logger.info("Table found. Truncating old data ...")
        cursor.execute(f"TRUNCATE TABLE {table_name}")


def pg_reset_then_insert(connection: pg.Connection, data: pa.Table, table_name: str):
    with connection.cursor() as cursor:
        _reset_table(cursor, data, table_name)
        for batch in data.to_reader(max_chunksize=10000):
            buffer = io.BytesIO()
            pcsv.write_csv(batch, buffer, pcsv.WriteOptions(include_header=True))
            buffer.seek(0)
            with cursor.copy(f"COPY {table_name} FROM STDIN WITH CSV HEADER") as copy:
                copy.write(buffer.read())
    connection.commit()


def create_raw_metadata(row_count: int, last_modified_date: Union[str, None]) -> dict:
    meta_dict = {
        "Count": MetadataValue.int(row_count),
        "Last Modified Date": MetadataValue.text(last_modified_date),
    }

    return meta_dict


def add_blocking_checks_to_asset(
    asset: AssetsDefinition,
    checks: Optional[list[AssetCheckFactory]] = None,
) -> AssetsDefinition:
    return build_asset_with_blocking_check(
        asset, checks=[check.create(asset) for check in checks]
    )


def create_download_from_sharepoint_asset(
    asset_name: str, path_to_file: str, link: str, file_id: str = None
) -> AssetsDefinition:
    description = f"""Name: {path_to_file}

Link: {link}
"""

    @asset(name=asset_name, description=description, group_name="dim_user_input")
    def _asset(
        dataneyu_client: MSSiteClient,
    ) -> Output[bytes]:
        metadata, content = dataneyu_client.download_item_by_path(path_to_file)
        last_modified_time = metadata["lastModifiedDateTime"]
        last_modified_user = metadata["lastModifiedBy"]["user"]
        return Output(
            value=content,
            metadata={
                "Last Modified At": MetadataValue.text(last_modified_time),
                "Last Modified By": MetadataValue.text(
                    last_modified_user["displayName"]
                    + " ("
                    + last_modified_user["email"]
                    + ")"
                ),
            },
        )

    return _asset


def create_download_from_sharepoint_ass_input(
    asset_name: str, path_to_file: str, link: str, file_id: str = None
) -> AssetsDefinition:
    description = f"""Name: {path_to_file}

Link: {link}
"""

    @asset(name=asset_name, description=description, group_name="dim_user_input")
    def _asset(
        dataneyu_client: MSSiteClient,
    ) -> Output[bytes]:
        metadata, content = dataneyu_client.download_item_by_path(path_to_file)
        return Output(
            value=content,
        )

    return _asset


def create_load_to_postgres_asset(
    asset_name: str,
    source_assets: list[AssetsDefinition],
    target_table: str,
    group_name: str = "dim_user_input",
):
    @asset(
        name=asset_name,
        compute_kind="postgres",
        group_name=group_name,
        ins={
            source.key.to_user_string(): AssetIn(source.key) for source in source_assets
        },
    )
    def _asset(
        context: AssetExecutionContext,
        oltp01_conn: PostgresConnection,
        **sources: pa.Table,
    ) -> None:
        combined_souce = pa.concat_tables(sources.values())
        with oltp01_conn.get_connection() as connection:
            pg_reset_then_insert(
                connection,
                combined_souce,
                target_table,
            )
            with connection.cursor() as cursor:
                row_count = cursor.execute(
                    f"select count(*) from {target_table}"
                ).fetchone()[0]
                context.add_output_metadata({"Row Count": MetadataValue.int(row_count)})

    return _asset


def get_hash_name(name_to_hash: str, num_char: int) -> str:
    return hashlib.sha256(name_to_hash).hexdigest()[:num_char]

def create_load_to_postgres_asset_db_master(
    asset_name: str,
    source_assets: list[AssetsDefinition],
    target_table: str,
    group_name: str = "dim_user_db_master",
):
    @asset(
        name=asset_name,
        compute_kind="postgres",
        group_name=group_name,
        ins={
            source.key.to_user_string(): AssetIn(source.key) for source in source_assets
        },
    )
    def _asset(
        context: AssetExecutionContext,
        oltp03_conn: PostgresConnection,
        **sources: pa.Table,
    ) -> None:
        combined_souce = pa.concat_tables(sources.values())
        with oltp03_conn.get_connection() as connection:
            pg_reset_then_insert(
                connection,
                combined_souce,
                target_table,
            )
            with connection.cursor() as cursor:
                row_count = cursor.execute(
                    f"select count(*) from {target_table}"
                ).fetchone()[0]
                logger.error('rown_count----------------------------', row_count)
                context.add_output_metadata({"Row Count": MetadataValue.int(row_count)})
    return _asset


def create_download_from_sharepoint_asset_base_layer(
    asset_name: str, path_to_file: str, link: str, file_id: str = None
) -> AssetsDefinition:
    description = f"""Name: {path_to_file}

Link: {link}
"""

    @asset(name=asset_name, description=description, group_name="dim_user_db_master")
    def _asset(
        dataneyu_client: MSSiteClient,
    ) -> Output[bytes]:
        metadata, content = dataneyu_client.download_item_by_path(path_to_file)
        last_modified_time = metadata["lastModifiedDateTime"]
        last_modified_user = metadata["lastModifiedBy"]["user"]
        return Output(
            value=content,
            metadata={
                "Last Modified At": MetadataValue.text(last_modified_time),
                "Last Modified By": MetadataValue.text(
                    last_modified_user["displayName"]
                    + " ("
                    + last_modified_user["email"]
                    + ")"
                ),
            },
        )

    return _asset


