from pathlib import Path
from jinja2 import Template
from typing import Optional


class SqlStore:
    def __init__(self, path: Optional[Path] = None) -> None:
        if not path:
            self._base_path = Path(__file__).parent / "sql"
        else:
            self._base_path = path

    def get(self, template: str) -> Template:
        with open(
            self._base_path / (template + ".sql"), "r", encoding="utf-8"
        ) as template_file:
            return Template(template_file.read())
