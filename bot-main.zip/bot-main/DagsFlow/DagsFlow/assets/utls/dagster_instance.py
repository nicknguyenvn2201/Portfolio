"""
Special module to interact with Dagster Metadata. Implementation specific
"""
from dagster import (
    DagsterInstance,
    RunsFilter,
    asset,
    DagsterEventType,
    EventRecordsFilter,
)
from DagsFlow.resources.msgraph import MSSiteClient
from datetime import datetime, timedelta
from dagster._core.storage.event_log import (
    AssetKeyTable,
    DynamicPartitionsTable,
    SqlEventLogStorage,
    SqlEventLogStorageMetadata,
    SqlEventLogStorageTable,
)
from dagster._core.storage.runs import SqlRunStorage
from sqlalchemy import or_
import pyarrow as pa
import pandas as pd


def archive_event_logs(before: datetime, preverve_events: list):
    """
    Extract all events `before` into an pyarrow table
    Preserve events specified in params. Delete the rest.
    """
    instance = DagsterInstance.get()
    event_storage: SqlEventLogStorage = instance.event_log_storage
    with event_storage.index_connection() as conn:
        conn.execute(
            SqlEventLogStorageTable.delete().where(
                or_(
                    SqlEventLogStorageTable.c.dagster_event_type.not_in(
                        preverve_events
                    ),
                    SqlEventLogStorageTable.c.dagster_event_type == None,
                )
            )
        )


if __name__ == "__main__":
    from dagster import build_init_resource_context, EnvVar
    from DagsFlow.resources import msgraph
    import io

    with DagsterInstance.get() as instance:
        resources_context = build_init_resource_context(
            instance=instance,
            resources={
                "ms_client": msgraph.MSSiteClient(
                    tenant_id=EnvVar("AZURE_TENANT_ID"),
                    client_id=EnvVar("AZURE_CLIENT_ID"),
                    client_secret=EnvVar("AZURE_CLIENT_SECRET"),
                    site_id="1b783fae-9880-4600-b18e-7e5f04e77c6d",
                )
            },
        )
        event_storage: SqlEventLogStorage = instance.event_log_storage
        run_storage: SqlRunStorage = instance.run_storage
        with event_storage.index_connection() as conn:
            with conn.begin() as trans:
                try:
                    data = pd.read_sql(
                        SqlEventLogStorageTable.select(), conn, dtype_backend="pyarrow"
                    )
                    buffer = io.BytesIO()
                    data.to_parquet(buffer)
                    ms_client: msgraph.MSSiteClient = (
                        resources_context.resources.ms_client
                    )
                    ms_client.upload_item(buffer, "test/dagster_logs")
                    conn.execute(
                        SqlEventLogStorageTable.delete().where(
                            or_(
                                SqlEventLogStorageTable.c.dagster_event_type.not_in(
                                    [
                                        "ASSET_MATERIALIZATION",
                                        "ASSET_CHECK_EVALUATION",
                                    ]
                                ),
                                SqlEventLogStorageTable.c.dagster_event_type == None,
                            )
                        )
                    )
                    raise
                except Exception:
                    trans.rollback()
pass
