with
    blocking_queries as (
        select distinct unnest(pg_blocking_pids(pid)) as pid
        from pg_stat_activity
        where cardinality(pg_blocking_pids(pid)) >= 0
    )
select blocking_queries.pid, query_start, backend_start, state, query
from pg_stat_activity all_queries
inner join blocking_queries on blocking_queries.pid = all_queries.pid
where extract(hour from now() - query_start) > 1
