-- dareport.cmd_dim_finance definition

-- Drop table

-- DROP TABLE dareport.cmd_dim_finance;

CREATE TABLE dareport.cmd_dim_finance (
	"index" int8 NULL,
	date_used date NULL,
	sourcename text NULL,
	sourcename_fnl text NULL,
	agname text NULL,
	wholesale_name text NULL,
	leadtype text NULL,
	product_name text NULL,
	affiliateid text NULL,
	cpname text NULL,
	subid_fnl text NULL,
	subid text NULL,
	province text NULL,
	district text NULL,
	carrier text NULL,
	paymentmethod text NULL,
	warehouse text NULL,
	leads int8 NULL,
	approve int8 NULL,
	"validate" int8 NULL,
	trash int8 NULL,
	callback int8 NULL,
	uncall int8 NULL,
	delivered_amount float8 NULL,
	delivered_qty float8 NULL,
	delivered float8 NULL,
	validated_amount float8 NULL,
	validated_qty float8 NULL,
	validated float8 NULL,
	rejected float8 NULL,
	cancelled float8 NULL,
	other_deli int8 NULL,
	total_do int8 NULL,
	total_intransit int8 NULL,
	total_amount float8 NULL,
	quantity float8 NULL,
	leadstatus text NULL,
	status_transport text NULL,
	adjusted_status_transport text NULL,
	team text NULL,
	"Geo" text NULL,
	max_po float8 NULL,
	payout float8 NULL,
	total_approved_postback int8 NULL,
	total_pending_postback int8 NULL,
	cpl_lead int8 NULL
);
CREATE INDEX "cmd_dim_finance_Geo_date_used_idx" ON dareport.cmd_dim_finance USING btree ("Geo", date_used);
CREATE INDEX cmd_dim_finance_date_used_idx ON dareport.cmd_dim_finance USING btree (date_used);
CREATE INDEX ix_cmd_dim_finance_index ON dareport.cmd_dim_finance USING btree (index);
