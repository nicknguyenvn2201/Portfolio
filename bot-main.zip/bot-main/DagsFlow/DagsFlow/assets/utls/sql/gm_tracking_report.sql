-- dareport.gm_tracking_report source

CREATE OR REPLACE VIEW dareport.gm_tracking_report
AS WITH raw_data AS (
         SELECT a.lead_date AS createdate,
            date_part('week'::text, a.lead_date + '1 day'::interval) AS lead_week,
            date_part('month'::text, a.lead_date) AS lead_month,
            date_part('year'::text, a.lead_date) AS lead_year,
            a.geo,
            a.org_id,
            a.country_code,
            a.etp_code,
            a.so_status,
            a.do_status,
            a.carrier,
            a.sale_campaign,
            a.fin_campaign,
            a.network,
            a.offer,
            a.pub,
            a.province,
            a.district,
            a.subdistrict,
            a.assigned,
            a.lead_type,
            a.agname,
            a.offer_type,
            a.leads AS total_lead,
            a.uncall_leads,
            a.trash_leads,
            a.approved_postback,
            a.approved_payout,
            a.approved_max_po,
            a.ar_target_mrp,
            a.validated,
            a.amt_validated,
            a.delivered,
            a.amt_delivered,
            a.finalized_do,
            a.lead_wait_time,
            a.total_items,
            a.gift_items,
            a.actual_call,
            a.week_used_start,
            a.week_used_start_current,
            a.exchange,
            a.inrangeforecast,
            a.tax_rate,
            a.amt_validated_usd,
            a.amt_delivered_usd,
            a.dr_final,
            a.payment_method,
            a.uncall_actual_call,
            a.lead_wait_time_working_hours,
                CASE
                    WHEN lower(a.so_status::text) = 'validated'::text THEN a.total_items
                    ELSE NULL::numeric
                END AS validated_qty,
                CASE
                    WHEN a.lead_type::text = 'A'::text THEN 'Fresh'::text
                    ELSE 'Resell'::text
                END AS leadtypename,
                CASE
                    WHEN a.so_status IS NULL THEN NULL::text
                    WHEN lower(a.do_status::text) = ANY (ARRAY['cancel'::text, 'cancelled'::text, 'reject'::text, 'returning'::text, 'returned'::text]) THEN 'reject'::text
                    WHEN lower(a.do_status::text) = 'delivered'::text THEN 'delivered'::text
                    WHEN a.so_status::text <> ALL (ARRAY['validated'::text, 'delay'::text]) THEN NULL::text
                    ELSE 'intransit'::text
                END AS status_fn,
            CURRENT_DATE -
                CASE
                    WHEN a.lead_type::text = 'A'::text THEN a.lead_date
                    ELSE a.lead_date
                END - 1 AS aging,
                CASE
                    WHEN a.lead_date < '2024-06-01'::date AND a.geo::text = 'VNID'::text THEN 16
                    WHEN a.geo::text ^@ 'VN'::text THEN 4
                    WHEN a.geo::text ^@ 'ID'::text THEN 9
                    WHEN a.geo::text ^@ 'MY'::text THEN 11
                    WHEN a.geo::text ^@ 'PH'::text THEN 14
                    WHEN a.geo::text ^@ 'TH'::text THEN 10
                    ELSE a.org_id
                END AS geo_id,
                CASE
                    WHEN a.ar_target_mrp IS NULL THEN NULL::bigint
                    ELSE a.leads
                END AS total_lead_mrp,
                CASE
                    WHEN a.validated > 0 THEN a.finalized_do / a.validated
                    ELSE 0::bigint
                END AS do_done
           FROM data_master_agg a
          WHERE a.lead_type::text = 'A'::text AND a.lead_date >= '2024-01-01'::date
        ), cte_lead_traffics AS (
         SELECT lead_traffics.affiliate_id AS network,
            lead_traffics.traffic,
            lead_traffics.applied_from_date::date AS started_date,
            lead_traffics.applied_to_date::date AS ending_date
           FROM lead_traffics
          WHERE lead_traffics.applied_from_date::date <= lead_traffics.applied_to_date::date
        ), cte_lead_mrps AS (
         SELECT lead_mrps.affiliate_id AS network,
            lead_mrps.org_id,
            lead_mrps.offer_id AS product_name,
                CASE
                    WHEN lower(lead_mrps.sub_id) = '*'::text THEN ''::text
                    WHEN lower(lead_mrps.sub_id) = ''::text THEN 'blank'::text
                    ELSE lead_mrps.sub_id
                END AS sub_id,
            lead_mrps.lead_mrp,
            lead_mrps.applied_from_date::date AS started_date,
            lead_mrps.applied_to_date::date AS ending_date,
                CASE
                    WHEN lower(lead_mrps.sub_id) = '*'::text THEN concat(lead_mrps.affiliate_id, '_', lead_mrps.offer_id)
                    WHEN lower(lead_mrps.sub_id) = ''::text THEN concat(lead_mrps.affiliate_id, '_', 'blank', '_', lead_mrps.offer_id)
                    ELSE concat(lead_mrps.affiliate_id, '_', lead_mrps.sub_id, '_', lead_mrps.offer_id)
                END AS target_key
           FROM lead_mrps
        ), bd_draft AS (
         SELECT cte_raw.createdate,
            cte_raw.lead_week,
            cte_raw.lead_month,
            cte_raw.lead_year,
            cte_raw.geo,
            cte_raw.org_id,
            cte_raw.country_code,
            cte_raw.etp_code,
            cte_raw.so_status,
            cte_raw.do_status,
            cte_raw.carrier,
            cte_raw.sale_campaign,
            cte_raw.fin_campaign,
            cte_raw.network,
            cte_raw.offer,
            cte_raw.pub,
            cte_raw.province,
            cte_raw.district,
            cte_raw.subdistrict,
            cte_raw.assigned,
            cte_raw.lead_type,
            cte_raw.agname,
            cte_raw.offer_type,
            cte_raw.total_lead,
            cte_raw.uncall_leads,
            cte_raw.trash_leads,
            cte_raw.approved_postback,
            cte_raw.approved_payout,
            cte_raw.approved_max_po,
            cte_raw.ar_target_mrp,
            cte_raw.validated,
            cte_raw.amt_validated,
            cte_raw.delivered,
            cte_raw.amt_delivered,
            cte_raw.finalized_do,
            cte_raw.lead_wait_time,
            cte_raw.total_items,
            cte_raw.gift_items,
            cte_raw.actual_call,
            cte_raw.week_used_start,
            cte_raw.week_used_start_current,
            cte_raw.exchange,
            cte_raw.inrangeforecast,
            cte_raw.tax_rate,
            cte_raw.amt_validated_usd,
            cte_raw.amt_delivered_usd,
            cte_raw.dr_final,
            cte_raw.payment_method,
            cte_raw.uncall_actual_call,
            cte_raw.lead_wait_time_working_hours,
            cte_raw.validated_qty,
            cte_raw.leadtypename,
            cte_raw.status_fn,
            cte_raw.aging,
            cte_raw.geo_id,
            cte_raw.total_lead_mrp,
            cte_raw.do_done,
                CASE
                    WHEN cte_raw.do_done::numeric >= 0.9 THEN cte_raw.delivered::double precision
                    ELSE cte_raw.validated::double precision * cte_raw.dr_final
                END AS delivered_final,
                CASE
                    WHEN cddlt.bd_manager IS NULL THEN 'Others'::text
                    ELSE cddlt.bd_manager
                END AS manager,
                CASE
                    WHEN cte_raw.leadtypename = 'Resell'::text THEN
                    CASE
                        WHEN lower(cte_raw.status_fn) = 'delivered'::text THEN 1::double precision
                        WHEN lower(cte_raw.status_fn) = 'intransit'::text THEN itdr.ins_to_del
                        WHEN lower(cte_raw.status_fn) IS NULL AND (lower(cte_raw.so_status::text) = ANY (ARRAY['validated'::text, 'delay'::text])) THEN itdr.ins_to_del
                        WHEN lower(cte_raw.status_fn) IS NULL THEN NULL::double precision
                        ELSE 0::double precision
                    END
                    WHEN cte_raw.leadtypename = 'Fresh'::text THEN
                    CASE
                        WHEN lower(cte_raw.status_fn) = 'delivered'::text THEN 1::double precision
                        WHEN lower(cte_raw.status_fn) = 'intransit'::text THEN itdf.ins_to_del
                        WHEN lower(cte_raw.status_fn) IS NULL AND (lower(cte_raw.so_status::text) = ANY (ARRAY['validated'::text, 'delay'::text])) THEN itdf.ins_to_del
                        WHEN lower(cte_raw.status_fn) IS NULL THEN NULL::double precision
                        ELSE 0::double precision
                    END
                    ELSE NULL::double precision
                END AS dr,
                CASE
                    WHEN tf.traffic = ''::text OR tf.traffic IS NULL THEN 'No Traffic'::text
                    ELSE tf.traffic
                END AS traffic_source,
            lm.lead_mrp,
            lm_2.lead_mrp AS pub_lead_mrp,
            gm.tele_rate,
            gm.commission_rate,
            gm.bd_comm_rate,
            uc.unit_cost,
            lc.ffm_fee,
            lc.lm_fee,
            lc.return_rate,
            lc.cod_rate,
            lc.portion
           FROM raw_data cte_raw
             LEFT JOIN dim_bd_daily_lead_target cddlt ON lower(cddlt.network) = lower(cte_raw.network::text) AND cddlt.week_num_target::double precision = cte_raw.lead_week AND cddlt.target_year::double precision =
                CASE
                    WHEN cte_raw.lead_week = 1::double precision AND (date_part('day'::text, cte_raw.createdate) = ANY (ARRAY[29::double precision, 30::double precision, 31::double precision])) THEN cte_raw.lead_year + 1::double precision
                    ELSE cte_raw.lead_year
                END
             LEFT JOIN ins_to_del_resell itdr ON cte_raw.geo::text = itdr.geo AND cte_raw.aging = itdr.aging AND cte_raw.sale_campaign::text = itdr.campaign AND cte_raw.offer::text = itdr.product
             LEFT JOIN ins_to_del_fresh itdf ON cte_raw.geo::text = itdf.geo AND cte_raw.aging = itdf.aging AND cte_raw.sale_campaign::text = itdf.campaign AND cte_raw.offer::text = itdf.product AND cte_raw.network::text = itdf.pub
             LEFT JOIN cte_lead_traffics tf ON cte_raw.network::text = tf.network AND cte_raw.createdate >= tf.started_date AND cte_raw.createdate <= tf.ending_date
             LEFT JOIN cte_lead_mrps lm ON lm.org_id = cte_raw.geo_id AND
                CASE
                    WHEN cte_raw.pub::text = ''::text THEN concat(cte_raw.network, '_', 'blank', '_', cte_raw.offer)
                    ELSE concat(cte_raw.network, '_', cte_raw.pub, '_', cte_raw.offer)
                END = lm.target_key AND cte_raw.createdate >= lm.started_date AND cte_raw.createdate <= lm.ending_date
             LEFT JOIN cte_lead_mrps lm_2 ON lm_2.org_id = cte_raw.geo_id AND concat(cte_raw.network, '_', cte_raw.offer) = lm_2.target_key AND cte_raw.createdate >= lm_2.started_date AND cte_raw.createdate <= lm_2.ending_date
             LEFT JOIN dim_bd_gm_input gm ON gm.geo = cte_raw.country_code::text AND cte_raw.createdate >= gm.started_date::date AND cte_raw.createdate <= gm.ending_date::date
             LEFT JOIN dim_bd_unit_cost uc ON btrim(lower(uc.offer)) = lower(cte_raw.offer::text) AND uc.geo = cte_raw.country_code::text AND cte_raw.createdate >= uc.started_date::date AND cte_raw.createdate <= uc.ending_date::date
             LEFT JOIN dim_bd_log_cost lc ON lc.geo = cte_raw.country_code::text AND cte_raw.createdate >= lc.started_date::date AND cte_raw.createdate <= lc.ending_date::date
        ), cte_drfc_aging AS (
         SELECT fd.geo,
            fd.createdate,
            fd.network AS source,
            fd.offer AS offer_product,
            fd.sale_campaign AS sale_camp,
            sum(fd.validated) AS validated,
            sum(fd.dr) AS delivered_fc_aging,
                CASE
                    WHEN sum(fd.dr) = 0::double precision OR sum(fd.validated) = 0::numeric THEN 0::double precision
                    ELSE sum(fd.dr) / sum(fd.validated)::double precision
                END AS dr_forecast_aging
           FROM bd_draft fd
          WHERE fd.leadtypename = 'Fresh'::text AND fd.aging <=
                CASE
                    WHEN fd.geo::text = 'VN'::text THEN 22
                    WHEN fd.geo::text = 'ID'::text THEN 28
                    WHEN fd.geo::text = 'TH'::text THEN 17
                    WHEN fd.geo::text = 'PH'::text THEN 17
                    WHEN fd.geo::text = 'MY'::text THEN 15
                    ELSE NULL::integer
                END
          GROUP BY fd.createdate, fd.network, fd.offer, fd.sale_campaign, fd.geo
        ), cte_bd_master AS (
         SELECT bm_1.createdate,
            bm_1.lead_week,
            bm_1.lead_month,
            bm_1.lead_year,
            bm_1.geo,
            bm_1.org_id,
            bm_1.country_code,
            bm_1.etp_code,
            bm_1.so_status,
            bm_1.do_status,
            bm_1.carrier,
            bm_1.sale_campaign,
            bm_1.fin_campaign,
            bm_1.network,
            bm_1.offer,
            bm_1.pub,
            bm_1.province,
            bm_1.district,
            bm_1.subdistrict,
            bm_1.assigned,
            bm_1.lead_type,
            bm_1.agname,
            bm_1.offer_type,
            bm_1.total_lead,
            bm_1.uncall_leads,
            bm_1.trash_leads,
            bm_1.approved_postback,
            bm_1.approved_payout,
            bm_1.approved_max_po,
            bm_1.ar_target_mrp,
            bm_1.validated,
            bm_1.amt_validated,
            bm_1.delivered,
            bm_1.amt_delivered,
            bm_1.finalized_do,
            bm_1.lead_wait_time,
            bm_1.total_items,
            bm_1.gift_items,
            bm_1.actual_call,
            bm_1.week_used_start,
            bm_1.week_used_start_current,
            bm_1.exchange,
            bm_1.inrangeforecast,
            bm_1.tax_rate,
            bm_1.amt_validated_usd,
            bm_1.amt_delivered_usd,
            bm_1.dr_final,
            bm_1.payment_method,
            bm_1.uncall_actual_call,
            bm_1.lead_wait_time_working_hours,
            bm_1.validated_qty,
            bm_1.leadtypename,
            bm_1.status_fn,
            bm_1.aging,
            bm_1.geo_id,
            bm_1.total_lead_mrp,
            bm_1.do_done,
            bm_1.delivered_final,
            bm_1.manager,
            bm_1.dr,
            bm_1.traffic_source,
            bm_1.lead_mrp,
            bm_1.pub_lead_mrp,
            bm_1.tele_rate,
            bm_1.commission_rate,
            bm_1.bd_comm_rate,
            bm_1.unit_cost,
            bm_1.ffm_fee,
            bm_1.lm_fee,
            bm_1.return_rate,
            bm_1.cod_rate,
            bm_1.portion,
            drfca.delivered_fc_aging,
            drfca.dr_forecast_aging
           FROM bd_draft bm_1
             LEFT JOIN cte_drfc_aging drfca ON bm_1.country_code::text = drfca.geo::text AND bm_1.createdate = drfca.createdate AND bm_1.sale_campaign::text = drfca.sale_camp::text AND bm_1.offer::text = drfca.offer_product::text AND bm_1.network::text = drfca.source::text
          WHERE bm_1.lead_type::text = 'A'::text AND bm_1.manager IS NULL OR (bm_1.manager <> ALL (ARRAY['Nastya'::text, 'Anton'::text, 'Aleks'::text]))
        )
 SELECT bm.createdate,
    bm.lead_week,
    bm.lead_month,
    bm.lead_year,
    bm.geo,
    bm.org_id,
    bm.country_code,
    bm.etp_code,
    bm.so_status,
    bm.do_status,
    bm.carrier,
    bm.sale_campaign,
    bm.fin_campaign,
    bm.network,
    bm.offer,
    bm.pub,
    bm.province,
    bm.district,
    bm.subdistrict,
    bm.assigned,
    bm.lead_type,
    bm.agname,
    bm.offer_type,
    bm.total_lead,
    bm.uncall_leads,
    bm.trash_leads,
    bm.approved_postback,
    bm.approved_payout,
    bm.approved_max_po,
    bm.ar_target_mrp,
    bm.validated,
    bm.amt_validated,
    bm.delivered,
    bm.amt_delivered,
    bm.finalized_do,
    bm.lead_wait_time,
    bm.total_items,
    bm.gift_items,
    bm.actual_call,
    bm.week_used_start,
    bm.week_used_start_current,
    bm.exchange,
    bm.inrangeforecast,
    bm.tax_rate,
    bm.amt_validated_usd,
    bm.amt_delivered_usd,
    bm.dr_final,
    bm.payment_method,
    bm.uncall_actual_call,
    bm.lead_wait_time_working_hours,
    bm.validated_qty,
    bm.leadtypename,
    bm.status_fn,
    bm.aging,
    bm.geo_id,
    bm.total_lead_mrp,
    bm.do_done,
    bm.delivered_final,
    bm.manager,
    bm.dr,
    bm.traffic_source,
    bm.lead_mrp,
    bm.pub_lead_mrp,
    bm.tele_rate,
    bm.commission_rate,
    bm.bd_comm_rate,
    bm.unit_cost,
    bm.ffm_fee,
    bm.lm_fee,
    bm.return_rate,
    bm.cod_rate,
    bm.portion,
    bm.delivered_fc_aging,
    bm.dr_forecast_aging,
    dct.spl_mrp,
    dct.ar_target,
    dfudt."Type",
    dfudt."%Lead cost MRP" AS deal_lead_cost_mrp
   FROM cte_bd_master bm
     LEFT JOIN dim_cpl_target dct ON dct.pub = bm.network::text AND dct.offer = bm.offer::text AND bm.createdate >= dct.from_date AND bm.createdate <= dct.to_date
     LEFT JOIN dim_follow_up_deal_target dfudt ON bm.offer::text = dfudt."Offer" AND bm.network::text = dfudt."Pub" AND bm.createdate >= dfudt."Start date" AND bm.createdate <= dfudt."end date" AND bm.etp_code::text = dfudt."Geo";
