with
    dup_check as (
        select {{ partitions }}, count(*)
        from {{ model }} model
        group by {{ partitions }}
        having count(*) > 1
    )
select *
from dup_check
