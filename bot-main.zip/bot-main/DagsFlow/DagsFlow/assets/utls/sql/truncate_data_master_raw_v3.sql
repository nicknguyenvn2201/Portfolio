DELETE FROM dareport.data_master_raw_test_v3 
WHERE (lead_id, geo) IN (
    SELECT lead_id,
    geo
   FROM dareport.data_master_raw_temp)
