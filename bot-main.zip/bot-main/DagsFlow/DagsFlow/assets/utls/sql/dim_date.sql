CREATE TABLE dim_date (
    date DATE PRIMARY KEY,                     -- Ngày
    year_month_day TEXT,					   -- Ngày tháng năm
    day_num TEXT,                              -- Ngày trong tháng, format 2 chữ số
    day_of_week INT,                           -- Ngày trong tuần (1-7, Chủ nhật là 1)
    long_day_name TEXT,                        -- Tên ngày trong tuần (Sunday, Monday, ...)
    short_day_name TEXT,                       -- Tên ngày trong tuần viết tắt (Sun, Mon, ...)
    is_weekday BOOLEAN,                        -- TRUE nếu là ngày làm việc (Thứ 2 - Thứ 6)
    sow DATE,                                  -- Start of Week (Chủ nhật đầu tuần)
    eow DATE,                                  -- End of Week (Thứ 7 cuối tuần)
    week_num TEXT,                             -- Tuần tính từ Chủ nhật (week bắt đầu từ Chủ nhật)
    year_week TEXT,                            -- Concatenate year and week number (e.g., 2024-W01)
    som DATE,                                  -- Start of Month (Ngày đầu tháng)
    eom DATE,                                  -- End of Month (Ngày cuối tháng)
    month_num TEXT,                            -- Tháng trong năm, format 2 chữ số
    long_month_name TEXT,                      -- Tên tháng đầy đủ (January, February, ...)
    short_month_name TEXT,                     -- Tên tháng ngắn (Jan, Feb, ...)
    year_month TEXT,                           -- Năm - tháng, format yyyy-mm
    quarter_num INT,                           -- Quý trong năm (1-4)
    quarter_name TEXT,                         -- Tên quý (Q1, Q2, Q3, Q4)
    year_quarter TEXT,                         -- Năm - Quý, format yyyy-Qx
    year_num INT                               -- Năm trong kiểu số nguyên
);

--TRUNCATE TABLE dim_date;

INSERT INTO dareport.dim_date (
    date,
    year_month_day,
    day_num,
    day_of_week,
    long_day_name,
    short_day_name,
    is_weekday,
    sow,
    eow,
    week_num,
    year_week,
    som,
    eom,
    month_num,
    long_month_name,
    short_month_name,
    year_month,
    quarter_num,
    quarter_name,
    year_quarter,
    year_num
)

SELECT 
    d::DATE AS date,
    TO_CHAR(d, 'YYYY-MM-DD')::TEXT AS year_month_day,
    
    -- day_num: Ngày trong tháng, format 2 chữ số
    LPAD(EXTRACT(DAY FROM d)::TEXT, 2, '0') AS day_num,
    
    -- day_of_week: Ngày trong tuần, Chủ nhật là 1, Thứ 2 là 2, ..., Thứ 7 là 7
    EXTRACT(DOW FROM d)::INTEGER + 1 AS day_of_week, 
    
    -- long_day_name: Tên ngày trong tuần
    UPPER(TO_CHAR(d, 'Day'))::TEXT AS long_day_name,
    
    -- short_day_name: Tên ngày trong tuần viết tắt
    UPPER(TO_CHAR(d, 'Dy'))::TEXT AS short_day_name,
    
    -- is_weekday: TRUE nếu là ngày làm việc (Thứ 2 - Thứ 6), FALSE nếu là cuối tuần
    CASE WHEN EXTRACT(DOW FROM d) BETWEEN 1 AND 5 THEN TRUE ELSE FALSE END AS is_weekday,
    
    -- sow: Start of Week, Chủ nhật đầu tuần
    d - (EXTRACT(DOW FROM d)::INTEGER * INTERVAL '1 day') AS sow, 
    
    -- eow: End of Week, Thứ 7 cuối tuần
    d + ((6 - EXTRACT(DOW FROM d)::INTEGER) * INTERVAL '1 day') AS eow,
    
    -- week_num: Tuần tính từ Chủ nhật (tuần bắt đầu từ Chủ nhật)
    -- Logic: Nếu tuần đó có chứa ngày 1/1, thì tuần đó sẽ là tuần 01
    CASE
        WHEN EXTRACT(DAY FROM d) = 1 AND EXTRACT(MONTH FROM d) = 1 THEN LPAD(1::TEXT, 2, '0') -- Nếu ngày là 1/1 thì tuần là 01
        WHEN EXTRACT(DAY FROM (d - INTERVAL '1 day')) = 1 AND EXTRACT(MONTH FROM (d - INTERVAL '1 day')) = 1 THEN LPAD(1::TEXT, 2, '0') -- Nếu ngày 1/1 có trong tuần, tuần cũng là 01
        ELSE LPAD(EXTRACT(WEEK FROM (d + INTERVAL '1 day'))::TEXT, 2, '0') -- Các tuần còn lại tính bình thường
    END AS week_num,  -- Tuần bắt đầu từ Chủ nhật
    
    -- year_week: Concatenate year from eow and week_num, ví dụ 2024-W01
    CONCAT(EXTRACT(YEAR FROM (d + ((6 - EXTRACT(DOW FROM d)::INTEGER) * INTERVAL '1 day'))), 
           '-W', 
           LPAD(EXTRACT(WEEK FROM (d + INTERVAL '1 day'))::TEXT, 2, '0'))::TEXT AS year_week,

    -- som: Start of Month
    DATE_TRUNC('MONTH', d) AS som,
    
    -- eom: End of Month
    (DATE_TRUNC('MONTH', d) + INTERVAL '1 MONTH' - INTERVAL '1 day')::DATE AS eom,
    
    -- month_num: Tháng trong năm, format 2 chữ số
    LPAD(EXTRACT(MONTH FROM d)::TEXT, 2, '0') AS month_num,
    
    -- long_month_name: Tên tháng đầy đủ (January, February, ...)
    UPPER(TO_CHAR(d, 'Month'))::TEXT AS long_month_name,
    
    -- short_month_name: Tên tháng ngắn (Jan, Feb, ...)
    UPPER(LEFT(TO_CHAR(d, 'Mon'), 3))::TEXT AS short_month_name,
    
    -- year_month: Năm - tháng, format yyyy-mm
    TO_CHAR(d, 'YYYY-MM')::TEXT AS year_month,
    
    -- quarter_num: Quý trong năm
    EXTRACT(QUARTER FROM d)::INTEGER AS quarter_num,
    
    -- quarter_name: Tên quý (Q1, Q2, Q3, Q4)
    CONCAT('Q', EXTRACT(QUARTER FROM d))::TEXT AS quarter_name,
    
    -- year_quarter: Năm - Quý, format yyyy-Qx
    CONCAT(EXTRACT(YEAR FROM d), '-Q', EXTRACT(QUARTER FROM d))::TEXT AS year_quarter,
    
    -- year_num: Năm trong kiểu số nguyên
    EXTRACT(YEAR FROM d)::INTEGER AS year_num
FROM 
    GENERATE_SERIES(
        '2019-01-01'::DATE, 
        '2026-12-31'::DATE, 
        '1 day'::INTERVAL
    ) d;
