insert into dareport.data_master_raw_backup (
  	lead_id,
	so_id,
	do_id,
	tracking_code,
	geo,
	org_id,
	country_code,
	etp_code,
	lead_date,
	so_date,
	do_date,
	lead_modify_date,
	so_modify_date,
	do_modify_date,
	"name",
	phone,
	sale_campaign,
	offer,
	network,
	pub,
	conversion_status,
	payout,
	max_po,
	so_amount,
	lead_status,
	first_call_status,
	so_status,
	postback_status,
	do_status,
	province,
	district,
	subdistrict,
	total_call,
	actual_call,
	lead_type,
	first_call_time,
	total_items,
	gift_items,
	assigned,
	creation_date,
	packed_time,
    shortname,
    agc_code,
    carrier,
    first_call_click,
    payment_method,
    firstdelivertime,
    warehouse_name,
    region,
    pre_cutoff,
    time_cutoff,
    closetime,
     delivery_packages_name,
     product_1
) (SELECT cf.lead_id,
    oso.so_id,
    odn.do_id,
    odn.tracking_code,
    cf.geo,
    cf.org_id,
        CASE
            WHEN cf.geo::text ^@ 'VN'::text THEN 'VN'::character varying
            WHEN cf.geo::text ^@ 'ID'::text THEN 'ID'::character varying
            WHEN cf.geo::text ^@ 'MY'::text THEN 'MY'::character varying
            WHEN cf.geo::text ^@ 'PH'::text THEN 'PH'::character varying
            WHEN cf.geo::text ^@ 'TH'::text THEN 'TH'::character varying
            ELSE cf.geo
        END AS country_code,
        CASE
            WHEN cf.geo::text = 'VNID'::text THEN 'VNID'::character varying
            WHEN cf.geo::text ^@ 'VN'::text THEN 'VN'::character varying
            WHEN cf.geo::text ^@ 'ID'::text THEN 'ID'::character varying
            WHEN cf.geo::text ^@ 'MY'::text THEN 'MY'::character varying
            WHEN cf.geo::text ^@ 'PH'::text THEN 'PH'::character varying
            WHEN cf.geo::text ^@ 'TH'::text THEN 'TH'::character varying
            ELSE cf.geo
        END AS etp_code,
    cf.createdate AS lead_date,
    oso.createdate AS so_date,
    odn.createdate AS do_date,
    cf.modifydate AS lead_modify_date,
    oso.modifydate AS so_modify_date,
    odn.updatedate AS do_modify_date,
    cf.name,
    cf.phone,
    cc.name AS sale_campaign,
    case when lead_type = 'A' then cf.prod_name else osi.product_1 end AS offer,
    cf.affiliate_id AS network,
    cf.subid1 AS pub,
    fanc.conversion_status,
    fanc.payout,
    fanc.revenue AS max_po,
    oso.amount AS so_amount,
    cf_lead.name AS lead_status,
    cf_lead_first.name AS first_call_status,
    cf_so.name AS so_status,
    cf.postback_status,
    cf_do.name AS do_status,
    case when cf.geo ^@ 'TH' then lp.shortname else lp.name end AS province,
    case when cf.geo ^@ 'TH' then ld.shortname else ld.name end AS district,
    case when cf.geo ^@ 'TH' then ls.shortname else ls.name end AS subdistrict,
    cf.total_call,
    cf.actual_call,
    cf.lead_type,
    cf.first_call_time,
    osi.total_items,
    osi.gift_items,
    cf.assigned,
    oso.creation_date,
    odn.packed_time,
    p.shortname,
    agc_code,
    odn.carrier,
    first_call_click,
    payment_method,
    firstdelivertime,
    warehouse_name,
    region_shortname region,
    coalesce(slc.pre_cutoff,slc2.pre_cutoff) pre_cutoff,
     svc.time_cutoff,
     closetime,
     delivery_packages_name,
     osi.product_1 product_1
   FROM ( SELECT cl_fresh.geo,
            cl_fresh.lead_id,
            cl_fresh.org_id,
            cl_fresh.cp_id,
            cl_fresh.lead_status,
            cl_fresh.createdate,
            cl_fresh.modifydate,
            cl_fresh.name,
            cl_fresh.phone,
            agc_id,
            agc_code,
            cl_fresh.affiliate_id,
            cl_fresh.prod_name,
            cl_fresh.first_call_status,
            cl_fresh.first_call_time,
            cl_fresh.lead_type,
            cl_fresh.subid1,
            cl_fresh.postback_status,
            cl_fresh.total_call,
            cl_fresh.actual_call,
            cl_fresh.click_id,
            cl_fresh.province,
            cl_fresh.district,
            cl_fresh.subdistrict,
            cl_fresh.assigned,
            first_call_click,
            case when lead_type = 'M' and affiliate_id is not null and cp_id in (521,4) then 1 else 0 end filters
           FROM cl_fresh
          WHERE cl_fresh.modifydate >= current_date - 365) cf
     LEFT JOIN ( SELECT od_sale_order.so_id,
            od_sale_order.lead_id,
            od_sale_order.geo,
            od_sale_order.amount,
            od_sale_order.status,
            od_sale_order.createdate,
            od_sale_order.modifydate,
            od_sale_order.creation_date,
            payment_method
           FROM od_sale_order
          WHERE od_sale_order.status <> 46 AND od_sale_order.modifydate >= current_date - 365) oso ON cf.lead_id::text = oso.lead_id::text AND cf.geo::text = oso.geo::text
     LEFT JOIN ( SELECT od_so_item.geo,
            od_so_item.so_id,
            max(
                CASE
                    WHEN od_so_item.item_no = 1 THEN pp.name
                    ELSE NULL::character varying
                END::text) AS product_1,
            sum(od_so_item.quantity) AS total_items,
            sum(
                CASE
                    WHEN od_so_item.price = 0 THEN od_so_item.quantity
                    ELSE 0
                END) AS gift_items
           FROM od_so_item od_so_item
           LEFT JOIN pd_product pp ON od_so_item.prod_id = pp.prod_id AND od_so_item.geo::text = pp.geo::text
          GROUP BY od_so_item.geo, od_so_item.so_id) osi ON oso.so_id::text = osi.so_id::text AND osi.geo::text = oso.geo::text
     LEFT JOIN ( SELECT odn.do_id,
            odn.do_code,
            odn.tracking_code,
            odn.so_id,
            odn.geo,
            bp.shortname carrier,
            odn.createdate,
            odn.updatedate,
            odn.status,
            odn.packed_time,
            odn.firstdelivertime,
            odn.closetime,
            warehouse_shortname warehouse_name,
            dp.name delivery_packages_name
           FROM od_do_new odn 
           left join bp_partner bp on bp.pn_id::text = odn.carrier_id::text and bp.geo::text = odn.geo::text  
           left join bp_warehouse bw on odn.geo = bw.geo and odn.warehouse_id = bw.warehouse_id
           LEFT JOIN delivery_packages dp ON  odn.delivery_package_code = dp.code and odn.geo = dp.geo
          WHERE odn.updatedate >= current_date - 365) odn ON oso.so_id::text = odn.so_id::text AND odn.geo::text = oso.geo::text
     LEFT JOIN ( SELECT cf_synonym.geo,
            cf_synonym.synonym_id,
            cf_synonym.type,
            cf_synonym.name,
            cf_synonym.value,
            cf_synonym.dscr,
            cf_synonym.type_id,
            cf_synonym.localized_name
           FROM cf_synonym
          WHERE cf_synonym.type::text = 'lead status'::text) cf_lead ON cf_lead.geo::text = cf.geo::text AND cf.lead_status::text = cf_lead.value::text
     LEFT JOIN ( SELECT cf_synonym.geo,
            cf_synonym.synonym_id,
            cf_synonym.type,
            cf_synonym.name,
            cf_synonym.value,
            cf_synonym.dscr,
            cf_synonym.type_id,
            cf_synonym.localized_name
           FROM cf_synonym
          WHERE cf_synonym.type::text = 'lead status'::text) cf_lead_first ON cf_lead_first.geo::text = cf.geo::text AND cf.lead_status::text = cf_lead_first.value::text
     LEFT JOIN ( SELECT cf_synonym.geo,
            cf_synonym.synonym_id,
            cf_synonym.type,
            cf_synonym.name,
            cf_synonym.value,
            cf_synonym.dscr,
            cf_synonym.type_id,
            cf_synonym.localized_name
           FROM cf_synonym
          WHERE cf_synonym.type::text = 'sale order status'::text) cf_so ON cf_so.geo::text = oso.geo::text AND oso.status::text = cf_so.value::text
     LEFT JOIN ( SELECT cf_synonym.geo,
            cf_synonym.synonym_id,
            cf_synonym.type,
            cf_synonym.name,
            cf_synonym.value,
            cf_synonym.dscr,
            cf_synonym.type_id,
            cf_synonym.localized_name
           FROM cf_synonym
          WHERE cf_synonym.type::text = 'delivery order status'::text) cf_do ON cf_do.geo::text = odn.geo::text AND odn.status::text = cf_do.value::text
     LEFT JOIN cp_campaign cc ON cc.geo::text = cf.geo::text AND cc.cp_id::text = cf.cp_id::text
     LEFT JOIN fct_affscale_network_conversion fanc ON cf.click_id::text = fanc.transaction_id
     LEFT JOIN lc_province lp ON cf.province = lp.prv_id::text AND cf.geo::text = lp.geo::text
     LEFT JOIN lc_district ld ON cf.district = ld.dt_id::text AND cf.geo::text = ld.geo::text
     LEFT JOIN lc_subdistrict ls ON cf.subdistrict = ls.sdt_id::text AND cf.geo::text = ls.geo::text
     LEFT JOIN bp_partner p ON cf.agc_id = p.pn_id AND p.geo::text = cf.geo::text
     left join lc_region lr on lp.geo = lr.geo and lp.region_id = lr.region_id
     left join public.sla_location_conf slc on
  p.pn_id = slc.fulfillment_id and p.geo = slc.geo
    left join public.sla_location_conf slc2 on
  p.pn_id = slc2.last_mile_id and p.geo = slc2.geo
    LEFT JOIN public.sla_vendor_conf svc ON 
  p.pn_id = svc.partner_id AND p.geo::text = svc.geo::text
     where cf.filters = 0
)
