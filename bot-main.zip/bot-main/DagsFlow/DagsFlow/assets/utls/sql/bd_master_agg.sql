-- dareport.bd_master_agg source

CREATE OR REPLACE VIEW dareport.bd_master_agg
AS WITH final AS (
         SELECT date_part('day'::text, now() - roi_1.lead_date::timestamp with time zone) - 1::double precision AS aging,
            roi_1.lead_date,
            date_part('week'::text, roi_1.lead_date + '1 day'::interval) AS lead_week,
            date_part('month'::text, roi_1.lead_date) AS lead_month,
            date_part('year'::text, roi_1.lead_date) AS lead_year,
            roi_1.network,
            roi_1.pub,
            roi_1.sale_campaign,
            roi_1.offer AS product_name,
            roi_1.leads AS total_lead,
            roi_1.trash_leads AS trash,
            roi_1.validated,
            roi_1.amt_validated,
            roi_1.delivered,
            roi_1.amt_delivered,
            roi_1.geo,
            roi_1.country_code,
            roi_1.etp_code,
            roi_1.lead_type,
            roi_1.finalized_do,
                CASE
                    WHEN lower(roi_1.offer::text) ~~ '%cpl%'::text THEN roi_1.leads - roi_1.trash_leads
                    ELSE NULL::bigint
                END AS cpl_lead,
            roi_1.approved_postback AS total_approved_postback,
            roi_1.exchange,
            roi_1.inrangeforecast,
            roi_1.dr_final,
                CASE
                    WHEN roi_1.validated > 0 THEN roi_1.finalized_do / roi_1.validated
                    ELSE 0::bigint
                END AS do_done,
            roi_1.approved_payout,
            roi_1.approved_max_po,
                CASE
                    WHEN roi_1.offer::text ~~ '%rosta%X%'::text THEN 'prostaniX -'::text::character varying
                    ELSE roi_1.offer
                END AS product_fn,
            roi_1.ar_target_mrp,
                CASE
                    WHEN roi_1.lead_date >= '2024-06-01'::date AND roi_1.geo::text = 'VNID'::text THEN 4
                    WHEN roi_1.lead_date < '2024-06-01'::date AND roi_1.geo::text = 'VNID'::text THEN 16
                    WHEN roi_1.geo::text ^@ 'VN'::text THEN 4
                    WHEN roi_1.geo::text ^@ 'ID'::text THEN 9
                    WHEN roi_1.geo::text ^@ 'MY'::text THEN 11
                    WHEN roi_1.geo::text ^@ 'PH'::text THEN 14
                    WHEN roi_1.geo::text ^@ 'TH'::text THEN 10
                    ELSE 0
                END AS geo_id,
            gm.tax_rate,
            gm.tele_rate,
            gm.commission_rate,
            gm.bd_comm_rate,
            uc.unit_cost,
            lc.ffm_fee,
            lc.lm_fee,
            lc.return_rate,
            lc.cod_rate,
            lc.portion,
            mbp.spl_plan,
            mbp.lead_cost_budget,
            mbp.mkt_budget,
            mbd.spl_plan AS spl_plan_def,
            mbd.lead_cost_budget AS lead_cost_budget_def,
            mbd.mkt_budget AS mkt_budget_def,
                CASE
                    WHEN va.affiliate_id IS NOT NULL THEN 1
                    ELSE 0
                END AS vip_pub,
            df."AR Forecast",
            df."AOV Forecast",
            df."DR_Forecast",
            df."SPL Forecast",
            df."%Lead cost FC",
            df."%GM1 FC",
            df."%GM2 FC",
            dt."Lead MRP" AS deal_lead_mrp,
            dt."AR_MRP" AS deal_armrp,
            dt."AOV_MRP" AS deal_aov_mrp,
            dt."SPL target" AS deal_spl_target,
            dt."DR_MRP" AS deal_dr_mrp,
            dt."%Lead cost MRP" AS deal_lead_cost_mrp,
            dt."%GM1 MRP" AS deal_gm1_mrp,
            dt."%GM2 MRP" AS deal_gm2_mrp,
                CASE
                    WHEN btrim(dt."Type") ^@ 'CPL'::text THEN 'CPL'::text
                    ELSE 'CPA'::text
                END AS deal_type,
            sfpsc.cost_usd,
            dfblc.logistics_cost_per_validated_order_usd,
            dmbtc.lead_target AS camp_lead_target,
            dmbtc.spl_target AS camp_spl_target,
            dmbtc.percentage_lead_cost_target AS camp_percentage_lead_cost_target,
            dmbtg.lead_target AS geo_lead_target,
            dmbtg.spl_target AS geo_spl_target,
            dmbtg.percentage_lead_cost_target AS geo_percentage_lead_cost_target,
            dmbto.lead_target AS offer_lead_target,
            dmbto.spl_target AS offer_spl_target,
            dmbto.percentage_lead_cost_target AS offer_percentage_lead_cost_target,
            dct.spl_mrp,
            cm.fresh AS "COM cost",
            lm.order_local_cur AS "LM cost",
            ffm.order_local_cur AS "FFM cost",
            cod.cod AS "COD cost",
            bd.agent_cost_2 AS "standard agent cost",
            bd.agent_cost_3 AS "% agent cost trash",
            tel."TEL cost",
            rtn."RTN cost",
            COALESCE(dim_mkt_1.mkt_expense_target, dim_mkt.mkt_expense_target, dim_mkt_2.mkt_expense_target) AS mkt_expense_target
           FROM data_master_agg roi_1
             LEFT JOIN dim_bd_gm_input gm ON roi_1.etp_code::text = gm.geo AND roi_1.lead_date >= gm.started_date::date AND roi_1.lead_date <= gm.ending_date::date
             LEFT JOIN dim_bd_unit_cost uc ON lower(roi_1.offer::text) = btrim(lower(uc.offer)) AND roi_1.country_code::text = uc.geo AND roi_1.lead_date >= uc.started_date::date AND roi_1.lead_date <= uc.ending_date::date
             LEFT JOIN dim_bd_log_cost lc ON roi_1.country_code::text = lc.geo AND roi_1.lead_date >= lc.started_date::date AND roi_1.lead_date <= lc.ending_date::date
             LEFT JOIN mkt_budget_plan mbp ON roi_1.sale_campaign::text = mbp.sales_camp AND roi_1.network::text = mbp.network AND roi_1.offer::text = mbp.product_name AND roi_1.lead_date >= mbp.from_date::date AND roi_1.lead_date <= mbp.to_date::date
             LEFT JOIN mkt_budget_default mbd ON roi_1.country_code::text = mbd.geo AND roi_1.sale_campaign::text = mbd.sales_camp AND roi_1.lead_date >= mbd.from_date::date AND roi_1.lead_date <= mbd.to_date::date
             LEFT JOIN vip_affiliates va ON roi_1.network::text = va.affiliate_id AND roi_1.offer::text = va.offer_id AND roi_1.lead_date >= va.applied_from_date::date AND roi_1.lead_date <= va.applied_to_date::date
             LEFT JOIN dim_follow_up_deal_target dt ON roi_1.etp_code::text = dt."Geo" AND dt."Pub" = roi_1.network::text AND lower(dt."Offer") = lower(roi_1.offer::text) AND roi_1.lead_date >= dt."Start date" AND roi_1.lead_date <= dt."end date"
             LEFT JOIN dim_follow_up_deal_forecast df ON df."Pub" = roi_1.network::text AND lower(df."Offer") = lower(roi_1.offer::text) AND roi_1.lead_date >= df."Start date" AND roi_1.lead_date <= df."end date"
             LEFT JOIN stg_fin__pretty_salary_cost sfpsc ON sfpsc.salary_cost_type = 'ibs'::text AND roi_1.network::text = sfpsc.network::text AND roi_1.offer::text = sfpsc.offer::text AND roi_1.lead_date = sfpsc.lead_date AND roi_1.sale_campaign::text = sfpsc.sale_campaign::text
             LEFT JOIN dim_finance_bd_logistics_cost dfblc ON roi_1.country_code::text = dfblc.country_code AND roi_1.lead_date >= dfblc.start_date AND roi_1.lead_date <= dfblc.end_date
             LEFT JOIN dim_mkt_budget_target_camp dmbtc ON roi_1.sale_campaign::text = dmbtc.camp AND roi_1.country_code::text = dmbtc.geo AND roi_1.lead_date >= dmbtc.from_date AND roi_1.lead_date <= dmbtc.to_date
             LEFT JOIN dim_mkt_budget_target_geo dmbtg ON roi_1.country_code::text = dmbtg.geo AND roi_1.lead_date >= dmbtg.from_date AND roi_1.lead_date <= dmbtg.to_date
             LEFT JOIN dim_mkt_budget_target_offer dmbto ON roi_1.offer::text = dmbto.offer AND roi_1.lead_date >= dmbto.from_date AND roi_1.lead_date <= dmbto.to_date
             LEFT JOIN dim_cpl_target dct ON dct.pub = roi_1.network::text AND dct.offer = roi_1.offer::text AND roi_1.lead_date >= dct.from_date AND roi_1.lead_date <= dct.to_date
             LEFT JOIN dim_commision_cost cm ON roi_1.etp_code::text = cm.geo AND roi_1.lead_date >= cm.started_date::date AND roi_1.lead_date <= cm.ending_date::date
             LEFT JOIN dim_lm_cost lm ON roi_1.etp_code::text = lm.geo AND roi_1.lead_date >= lm.started_date::date AND roi_1.lead_date <= lm.ending_date::date
             LEFT JOIN dim_ffm_cost ffm ON roi_1.etp_code::text = ffm.geo AND roi_1.lead_date >= ffm.started_date::date AND roi_1.lead_date <= ffm.ending_date::date
             LEFT JOIN dim_log_cod cod ON roi_1.etp_code::text = cod.geo AND roi_1.lead_date >= cod.started_date::date AND roi_1.lead_date <= cod.ending_date::date
             LEFT JOIN dim_bd_agent_cost bd ON roi_1.country_code::text = bd.geo AND roi_1.lead_date >= bd.started_date::date AND roi_1.lead_date <= bd.ending_date::date AND roi_1.sale_campaign::text = bd.sale_campaign
             LEFT JOIN ( SELECT dim_tel_cost.geo,
                    dim_tel_cost.started_date,
                    dim_tel_cost.ending_date,
                    avg(dim_tel_cost.lead_local_cur::double precision) AS "TEL cost"
                   FROM dim_tel_cost
                  GROUP BY dim_tel_cost.geo, dim_tel_cost.started_date, dim_tel_cost.ending_date) tel ON roi_1.etp_code::text = tel.geo AND roi_1.lead_date >= tel.started_date::date AND roi_1.lead_date <= tel.ending_date::date
             LEFT JOIN ( SELECT dim_log_rtn.geo,
                    dim_log_rtn.started_date,
                    dim_log_rtn.ending_date,
                    avg(dim_log_rtn.rtn::double precision) AS "RTN cost"
                   FROM dim_log_rtn
                  GROUP BY dim_log_rtn.geo, dim_log_rtn.started_date, dim_log_rtn.ending_date) rtn ON roi_1.etp_code::text = rtn.geo AND roi_1.lead_date >= rtn.started_date::date AND roi_1.lead_date <= rtn.ending_date::date
             LEFT JOIN ( SELECT dim_mkt_exp_target.geo,
                    dim_mkt_exp_target.product_name,
                    dim_mkt_exp_target.category,
                    dim_mkt_exp_target.network,
                    dim_mkt_exp_target."Pub",
                    dim_mkt_exp_target.mkt_expense_target,
                    dim_mkt_exp_target.week_num_target,
                    dim_mkt_exp_target.started_date,
                    dim_mkt_exp_target.ending_date,
                    dim_mkt_exp_target."Rank",
                    dim_mkt_exp_target.last_update,
                        CASE
                            WHEN dim_mkt_exp_target.network IS NOT NULL AND dim_mkt_exp_target."Pub" IS NOT NULL THEN concat(dim_mkt_exp_target.product_name, '_', dim_mkt_exp_target.network, '_', dim_mkt_exp_target."Pub")
                            ELSE 'no_key'::text
                        END AS key_1,
                        CASE
                            WHEN dim_mkt_exp_target.network IS NULL AND dim_mkt_exp_target."Pub" IS NULL AND dim_mkt_exp_target.product_name IS NOT NULL THEN dim_mkt_exp_target.product_name
                            ELSE 'no_key'::text
                        END AS key_2,
                        CASE
                            WHEN dim_mkt_exp_target.network IS NULL AND dim_mkt_exp_target."Pub" IS NULL AND dim_mkt_exp_target.product_name IS NULL THEN dim_mkt_exp_target.geo
                            ELSE 'no_key'::text
                        END AS key_3
                   FROM dim_mkt_exp_target) dim_mkt ON lower(roi_1.offer::text) = lower(dim_mkt.key_2) AND roi_1.lead_date >= dim_mkt.started_date::date AND roi_1.lead_date <= dim_mkt.ending_date::date
             LEFT JOIN ( SELECT dim_mkt_exp_target.geo,
                    dim_mkt_exp_target.product_name,
                    dim_mkt_exp_target.category,
                    dim_mkt_exp_target.network,
                    dim_mkt_exp_target."Pub",
                    dim_mkt_exp_target.mkt_expense_target,
                    dim_mkt_exp_target.week_num_target,
                    dim_mkt_exp_target.started_date,
                    dim_mkt_exp_target.ending_date,
                    dim_mkt_exp_target."Rank",
                    dim_mkt_exp_target.last_update,
                        CASE
                            WHEN dim_mkt_exp_target.network IS NOT NULL AND dim_mkt_exp_target."Pub" IS NOT NULL THEN concat(dim_mkt_exp_target.product_name, '_', dim_mkt_exp_target.network, '_', dim_mkt_exp_target."Pub")
                            ELSE 'no_key'::text
                        END AS key_1,
                        CASE
                            WHEN dim_mkt_exp_target.network IS NULL AND dim_mkt_exp_target."Pub" IS NULL AND dim_mkt_exp_target.product_name IS NOT NULL THEN dim_mkt_exp_target.product_name
                            ELSE 'no_key'::text
                        END AS key_2,
                        CASE
                            WHEN dim_mkt_exp_target.network IS NULL AND dim_mkt_exp_target."Pub" IS NULL AND dim_mkt_exp_target.product_name IS NULL THEN dim_mkt_exp_target.geo
                            ELSE 'no_key'::text
                        END AS key_3
                   FROM dim_mkt_exp_target) dim_mkt_1 ON lower(concat(roi_1.offer, '_', roi_1.network, '_', roi_1.pub)) = lower(dim_mkt_1.key_1) AND roi_1.lead_date >= dim_mkt_1.started_date::date AND roi_1.lead_date <= dim_mkt_1.ending_date::date
             LEFT JOIN ( SELECT dim_mkt_exp_target.geo,
                    dim_mkt_exp_target.product_name,
                    dim_mkt_exp_target.category,
                    dim_mkt_exp_target.network,
                    dim_mkt_exp_target."Pub",
                    dim_mkt_exp_target.mkt_expense_target,
                    dim_mkt_exp_target.week_num_target,
                    dim_mkt_exp_target.started_date,
                    dim_mkt_exp_target.ending_date,
                    dim_mkt_exp_target."Rank",
                    dim_mkt_exp_target.last_update,
                        CASE
                            WHEN dim_mkt_exp_target.network IS NOT NULL AND dim_mkt_exp_target."Pub" IS NOT NULL THEN concat(dim_mkt_exp_target.product_name, '_', dim_mkt_exp_target.network, '_', dim_mkt_exp_target."Pub")
                            ELSE 'no_key'::text
                        END AS key_1,
                        CASE
                            WHEN dim_mkt_exp_target.network IS NULL AND dim_mkt_exp_target."Pub" IS NULL AND dim_mkt_exp_target.product_name IS NOT NULL THEN dim_mkt_exp_target.product_name
                            ELSE 'no_key'::text
                        END AS key_2,
                        CASE
                            WHEN dim_mkt_exp_target.network IS NULL AND dim_mkt_exp_target."Pub" IS NULL AND dim_mkt_exp_target.product_name IS NULL THEN dim_mkt_exp_target.geo
                            ELSE 'no_key'::text
                        END AS key_3
                   FROM dim_mkt_exp_target) dim_mkt_2 ON
                CASE
                    WHEN roi_1.geo::text ^@ 'TH'::text THEN 'TH'::character varying
                    WHEN roi_1.geo::text ^@ 'VN'::text THEN 'VN'::character varying
                    WHEN roi_1.geo::text ^@ 'ID'::text THEN 'ID'::character varying
                    ELSE roi_1.geo
                END::text = dim_mkt_2.key_3 AND roi_1.lead_date >= dim_mkt_2.started_date::date AND roi_1.lead_date <= dim_mkt_2.ending_date::date
        )
 SELECT roi.aging,
    roi.lead_date,
    roi.lead_week,
    roi.lead_month,
    roi.lead_year,
    roi.network,
    roi.pub,
    roi.product_name,
    roi.total_lead,
    roi.trash,
    roi.validated,
    roi.amt_validated,
    roi.delivered,
    roi.finalized_do,
    roi.amt_delivered,
    roi.approved_payout,
    roi.approved_max_po,
    roi.sale_campaign,
    roi.cpl_lead,
    roi.ar_target_mrp,
    roi.total_approved_postback,
    roi.country_code,
    roi.product_fn,
    roi.inrangeforecast,
    roi.exchange,
    roi.dr_final,
    roi.do_done,
    roi.lead_type,
    roi.geo_id,
    roi.tax_rate,
    roi.tele_rate,
    roi.commission_rate,
    roi.bd_comm_rate,
    roi.unit_cost,
    roi.ffm_fee,
    roi.lm_fee,
    roi.return_rate,
    roi.cod_rate,
    roi.portion,
    roi.spl_plan,
    roi.lead_cost_budget,
    roi.mkt_budget,
    roi.spl_plan_def,
    roi.lead_cost_budget_def,
    roi.mkt_budget_def,
    roi.vip_pub,
    roi."AR Forecast",
    roi."AOV Forecast",
    roi."DR_Forecast",
    roi."SPL Forecast",
    roi."%Lead cost FC",
    roi."%GM1 FC",
    roi."%GM2 FC",
    roi.deal_lead_mrp,
    roi.deal_armrp,
    roi.deal_aov_mrp,
    roi.deal_spl_target,
    roi.deal_dr_mrp,
    roi.deal_lead_cost_mrp,
    roi.deal_gm1_mrp,
    roi.deal_gm2_mrp,
    roi.deal_type,
    roi.cost_usd,
    roi.logistics_cost_per_validated_order_usd,
    roi.camp_lead_target,
    roi.camp_spl_target,
    roi.camp_percentage_lead_cost_target,
    roi.geo_lead_target,
    roi.geo_spl_target,
    roi.geo_percentage_lead_cost_target,
    roi.offer_lead_target,
    roi.offer_spl_target,
    roi.offer_percentage_lead_cost_target,
    roi.spl_mrp,
    roi."COM cost",
    roi."LM cost",
    roi."FFM cost",
    roi."COD cost",
    roi."standard agent cost",
    roi."% agent cost trash",
    roi."TEL cost",
    roi."RTN cost",
    roi.mkt_expense_target,
        CASE
            WHEN roi.do_done::numeric > 0.9 THEN roi.delivered::double precision
            ELSE roi.validated::double precision * roi.dr_final
        END AS delivered_final,
    dlcrp."Lead Target",
    dlcrp."Validated target",
    dlcrp."DR target",
    dlcrp."AOV target",
    dlcrp."Revenue target",
    dlcrp."Lead cost Plan",
    dfgt.lead_cost_target AS geo_lead_cost_target,
    dfgt.ar_qa_plan AS geo_ar_qa_plan,
    dfgt.dr_mrp AS geo_dr_mrp,
    dfgt.aov_mrp AS geo_aov_mrp,
    dfct.lead_cost_target AS camp_lead_cost_target,
    dfct.ar_qa_plan AS camp_ar_qa_plan,
    dfct.dr_mrp AS camp_dr_mrp,
    dfct.aov_mrp AS camp_aov_mrp,
    dfot.lead_cost_target AS offer_lead_cost_target,
    dfot.ar_qa_plan AS offer_ar_qa_plan,
    dfot.dr_mrp AS offer_dr_mrp,
    dfot.aov_mrp AS offer_aov_mrp
   FROM final roi
     LEFT JOIN dim_lead_cost_rev_plan dlcrp ON dlcrp."Pub" = roi.network::text AND dlcrp."Offer" = roi.product_name::text AND dlcrp."Month"::double precision = roi.lead_month AND dlcrp."Year"::double precision = roi.lead_year
     LEFT JOIN dim_finance_geo_target dfgt ON roi.lead_year = dfgt.year_::double precision AND roi.country_code::text = dfgt.country_code AND dfgt.month_::double precision = roi.lead_month
     LEFT JOIN dim_finance_camp_target dfct ON roi.lead_year = dfct.year_::double precision AND roi.country_code::text = dfct.country_code AND dfct.month_::double precision = roi.lead_month AND dfct.sales_camp = roi.sale_campaign::text
     LEFT JOIN dim_finance_offer_target dfot ON roi.lead_year = dfot.year_::double precision AND dfot.month_::double precision = roi.lead_month AND dfot.offer = roi.product_name::text;
