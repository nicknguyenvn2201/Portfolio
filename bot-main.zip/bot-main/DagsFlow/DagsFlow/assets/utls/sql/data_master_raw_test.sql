WITH new_data AS (SELECT cf.lead_id,
    oso.so_id,
    odn.do_id,
    odn.tracking_code,
    cf.geo,
    cf.org_id,
        CASE
            WHEN cf.geo::text ^@ 'VN'::text THEN 'VN'::character varying
            WHEN cf.geo::text ^@ 'ID'::text THEN 'ID'::character varying
            WHEN cf.geo::text ^@ 'MY'::text THEN 'MY'::character varying
            WHEN cf.geo::text ^@ 'PH'::text THEN 'PH'::character varying
            WHEN cf.geo::text ^@ 'TH'::text THEN 'TH'::character varying
            ELSE cf.geo
        END AS country_code,
        CASE
            WHEN cf.geo::text = 'VNID'::text THEN 'VNID'::character varying
            WHEN cf.geo::text ^@ 'VN'::text THEN 'VN'::character varying
            WHEN cf.geo::text ^@ 'ID'::text THEN 'ID'::character varying
            WHEN cf.geo::text ^@ 'MY'::text THEN 'MY'::character varying
            WHEN cf.geo::text ^@ 'PH'::text THEN 'PH'::character varying
            WHEN cf.geo::text ^@ 'TH'::text THEN 'TH'::character varying
            ELSE cf.geo
        END AS etp_code,
    cf.createdate AS lead_date,
    oso.createdate AS so_date,
    odn.createdate AS do_date,
    cf.modifydate AS lead_modify_date,
    oso.modifydate AS so_modify_date,
    odn.updatedate AS do_modify_date,
    cf.name,
    cf.phone,
    cc.name AS sale_campaign,
    case when lead_type = 'A' then cf.prod_name else osi.product_1 end AS offer,
    cf.affiliate_id AS network,
    cf.subid1 AS pub,
    fanc.conversion_status,
    fanc.payout,
    fanc.revenue AS max_po,
    oso.amount AS so_amount,
    cf_lead.name AS lead_status,
    cf_lead_first.name AS first_call_status,
    cf_so.name AS so_status,
    cf.postback_status,
    cf_do.name AS do_status,
    case when cf.geo ^@ 'TH' then lp.shortname else lp.name end AS province,
    case when cf.geo ^@ 'TH' then ld.shortname else ld.name end AS district,
    case when cf.geo ^@ 'TH' then ls.shortname else ls.name end AS subdistrict,
    cf.total_call,
    cf.actual_call,
    cf.lead_type,
    cf.first_call_time,
    osi.total_items,
    osi.gift_items,
    cf.assigned,
    oso.creation_date,
    odn.packed_time,
    p.shortname,
    agc_code,
    odn.carrier,
    first_call_click,
    payment_method,
    firstdelivertime,
    warehouse_name,
    region_shortname region,
    slc.pre_cutoff,
    svc.time_cutoff,
     closetime,
     delivery_packages_name,
     osi.product_1 product_1,
     CONCAT(cf.lead_id, cf.geo, oso.so_id, odn.do_id) AS unique_key
   FROM ( SELECT cl_fresh.geo,
            cl_fresh.lead_id,
            cl_fresh.org_id,
            cl_fresh.cp_id,
            cl_fresh.lead_status,
            cl_fresh.createdate,
            cl_fresh.modifydate,
            cl_fresh.name,
            cl_fresh.phone,
            agc_id,
            agc_code,
            cl_fresh.affiliate_id,
            cl_fresh.prod_name,
            cl_fresh.first_call_status,
            cl_fresh.first_call_time,
            cl_fresh.lead_type,
            cl_fresh.subid1,
            cl_fresh.postback_status,
            cl_fresh.total_call,
            cl_fresh.actual_call,
            cl_fresh.click_id,
            cl_fresh.province,
            cl_fresh.district,
            cl_fresh.subdistrict,
            cl_fresh.assigned,
            first_call_click,
            case when lead_type = 'M' and affiliate_id is not null and cp_id in (521,4) then 1 else 0 end filters
           FROM cl_fresh_temp cl_fresh) cf
     LEFT JOIN ( SELECT od_sale_order.so_id,
            od_sale_order.lead_id,
            od_sale_order.geo,
            od_sale_order.amount,
            od_sale_order.status,
            od_sale_order.createdate,
            od_sale_order.modifydate,
            od_sale_order.creation_date,
            payment_method
           FROM od_sale_order_temp od_sale_order
          WHERE od_sale_order.status <> 46 ) oso ON cf.lead_id::text = oso.lead_id::text AND cf.geo::text = oso.geo::text
     LEFT JOIN ( SELECT od_so_item.geo,
            od_so_item.so_id,
            max(
                CASE
                    WHEN od_so_item.item_no = 1 THEN pp.name
                    ELSE NULL::character varying
                END::text) AS product_1,
            sum(od_so_item.quantity) AS total_items,
            sum(
                CASE
                    WHEN od_so_item.price = 0 THEN od_so_item.quantity
                    ELSE 0
                END) AS gift_items
           FROM od_so_item od_so_item
           LEFT JOIN pd_product pp ON od_so_item.prod_id = pp.prod_id AND od_so_item.geo::text = pp.geo::text
          GROUP BY od_so_item.geo, od_so_item.so_id) osi ON oso.so_id::text = osi.so_id::text AND osi.geo::text = oso.geo::text
     LEFT JOIN ( SELECT odn.do_id,
            odn.do_code,
            odn.tracking_code,
            odn.so_id,
            odn.geo,
            bp.shortname carrier,
            odn.createdate,
            odn.updatedate,
            odn.status,
            odn.packed_time,
            odn.firstdelivertime,
            odn.closetime,
            warehouse_shortname warehouse_name,
            dp.name delivery_packages_name,
            odn.warehouse_id,
            odn.ffm_id,
            odn.carrier_id
           FROM od_do_new_temp odn 
           left join bp_partner bp on bp.pn_id::text = odn.carrier_id::text and bp.geo::text = odn.geo::text  
           left join bp_warehouse bw on odn.geo = bw.geo and odn.warehouse_id = bw.warehouse_id
           LEFT JOIN delivery_packages dp ON  odn.delivery_package_code = dp.code and odn.geo = dp.geo
          WHERE odn.updatedate >= current_date - 365) odn ON oso.so_id::text = odn.so_id::text AND odn.geo::text = oso.geo::text
     LEFT JOIN ( SELECT cf_synonym.geo,
            cf_synonym.synonym_id,
            cf_synonym.type,
            cf_synonym.name,
            cf_synonym.value,
            cf_synonym.dscr,
            cf_synonym.type_id,
            cf_synonym.localized_name
           FROM cf_synonym
          WHERE cf_synonym.type::text = 'lead status'::text) cf_lead ON cf_lead.geo::text = cf.geo::text AND cf.lead_status::text = cf_lead.value::text
     LEFT JOIN ( SELECT cf_synonym.geo,
            cf_synonym.synonym_id,
            cf_synonym.type,
            cf_synonym.name,
            cf_synonym.value,
            cf_synonym.dscr,
            cf_synonym.type_id,
            cf_synonym.localized_name
           FROM cf_synonym
          WHERE cf_synonym.type::text = 'lead status'::text) cf_lead_first ON cf_lead_first.geo::text = cf.geo::text AND cf.lead_status::text = cf_lead_first.value::text
     LEFT JOIN ( SELECT cf_synonym.geo,
            cf_synonym.synonym_id,
            cf_synonym.type,
            cf_synonym.name,
            cf_synonym.value,
            cf_synonym.dscr,
            cf_synonym.type_id,
            cf_synonym.localized_name
           FROM cf_synonym
          WHERE cf_synonym.type::text = 'sale order status'::text) cf_so ON cf_so.geo::text = oso.geo::text AND oso.status::text = cf_so.value::text
     LEFT JOIN ( SELECT cf_synonym.geo,
            cf_synonym.synonym_id,
            cf_synonym.type,
            cf_synonym.name,
            cf_synonym.value,
            cf_synonym.dscr,
            cf_synonym.type_id,
            cf_synonym.localized_name
           FROM cf_synonym
          WHERE cf_synonym.type::text = 'delivery order status'::text) cf_do ON cf_do.geo::text = odn.geo::text AND odn.status::text = cf_do.value::text
     LEFT JOIN cp_campaign cc ON cc.geo::text = cf.geo::text AND cc.cp_id::text = cf.cp_id::text
     LEFT JOIN fct_affscale_network_conversion fanc ON cf.click_id::text = fanc.transaction_id
     LEFT JOIN lc_province lp ON cf.province = lp.prv_id::text AND cf.geo::text = lp.geo::text
     LEFT JOIN lc_district ld ON cf.district = ld.dt_id::text AND cf.geo::text = ld.geo::text
     LEFT JOIN lc_subdistrict ls ON cf.subdistrict = ls.sdt_id::text AND cf.geo::text = ls.geo::text
     LEFT JOIN bp_partner p ON cf.agc_id = p.pn_id AND p.geo::text = cf.geo::text
     LEFT JOIN lc_region lr on lp.geo = lr.geo and lp.region_id = lr.region_id
     LEFT JOIN (select geo, warehouse_id, last_mile_id, province_id , district_id , ward_id ,avg(pre_cutoff) pre_cutoff, 
                       avg(post_cutoff) post_cutoff
                  from public.sla_location_conf 
                  group by 1,2,3,4,5,6) slc on odn.warehouse_id::text = slc.warehouse_id::text and odn.geo = slc.geo 
                                                                                               and slc.province_id::text = cf.province
                                                                                               and slc.district_id::text = cf.district::text
                                                                                               and slc.ward_id::text = cf.subdistrict::text
                                                                                               and slc.last_mile_id::text = odn.carrier_id::text
    LEFT JOIN public.sla_vendor_conf svc ON odn.ffm_id::text = svc.partner_id::text AND odn.geo::text = svc.geo::text
     where cf.filters = 0
)
INSERT INTO dareport.data_master_raw_test_v2 (lead_id,
	so_id,
	do_id,
	tracking_code,
	geo,
	org_id,
	country_code,
	etp_code,
	lead_date,
	so_date,
	do_date,
	lead_modify_date,
	so_modify_date,
	do_modify_date,
	"name",
	phone,
	sale_campaign,
	offer,
	network,
	pub,
	conversion_status,
	payout,
	max_po,
	so_amount,
	lead_status,
	first_call_status,
	so_status,
	postback_status,
	do_status,
	province,
	district,
	subdistrict,
	total_call,
	actual_call,
	lead_type,
	first_call_time,
	total_items,
	gift_items,
	assigned,
	creation_date,
	packed_time,
    shortname,
    agc_code,
    carrier,
    first_call_click,
	payment_method,
    firstdelivertime,
    warehouse_name,
    region,
    pre_cutoff,
    time_cutoff,
    closetime,
     delivery_packages_name,
     product_1,
     unique_key
)
select distinct * from new_data
ON CONFLICT (unique_key) DO UPDATE
SET tracking_code = EXCLUDED.tracking_code ,
	org_id = EXCLUDED.org_id ,
	country_code = EXCLUDED.country_code ,
	etp_code = EXCLUDED.etp_code ,
	lead_id = EXCLUDED.lead_id ,
	geo = EXCLUDED.geo ,
	so_id = EXCLUDED.so_id ,
	do_id = EXCLUDED.do_id ,
	lead_date = EXCLUDED.lead_date ,
	so_date = EXCLUDED.so_date ,
	do_date = EXCLUDED.do_date ,
	lead_modify_date = EXCLUDED.lead_modify_date ,
	so_modify_date = EXCLUDED.so_modify_date ,
	do_modify_date = EXCLUDED.do_modify_date ,
	"name" = EXCLUDED."name" ,
	phone = EXCLUDED.phone ,
	sale_campaign = EXCLUDED.sale_campaign ,
	offer = EXCLUDED.offer ,
	network = EXCLUDED.network ,
	pub = EXCLUDED.pub ,
	conversion_status = EXCLUDED.conversion_status ,
	payout = EXCLUDED.payout ,
	max_po = EXCLUDED.max_po ,
	so_amount = EXCLUDED.so_amount ,
	lead_status = EXCLUDED.lead_status ,
	first_call_status = EXCLUDED.first_call_status ,
	so_status = EXCLUDED.so_status ,
	postback_status = EXCLUDED.postback_status ,
	do_status = EXCLUDED.do_status ,
	province = EXCLUDED.province ,
	district = EXCLUDED.district ,
	subdistrict = EXCLUDED.subdistrict ,
	total_call = EXCLUDED.total_call ,
	actual_call = EXCLUDED.actual_call ,
	lead_type = EXCLUDED.lead_type ,
	first_call_time = EXCLUDED.first_call_time ,
	total_items = EXCLUDED.total_items ,
	gift_items = EXCLUDED.gift_items ,
	assigned = EXCLUDED.assigned ,
	creation_date = EXCLUDED.creation_date ,
	packed_time = EXCLUDED.packed_time ,
    shortname = EXCLUDED.shortname ,
    agc_code = EXCLUDED.agc_code ,
    carrier = EXCLUDED.carrier ,
    first_call_click = EXCLUDED.first_call_click,
	payment_method = EXCLUDED.payment_method,
    firstdelivertime = EXCLUDED.firstdelivertime,
    warehouse_name = EXCLUDED.warehouse_name,
    region = EXCLUDED.region,
    pre_cutoff = EXCLUDED.pre_cutoff,
    time_cutoff = EXCLUDED.time_cutoff,
    closetime = EXCLUDED.closetime,
     delivery_packages_name = EXCLUDED.delivery_packages_name,
     product_1 = EXCLUDED.product_1;
