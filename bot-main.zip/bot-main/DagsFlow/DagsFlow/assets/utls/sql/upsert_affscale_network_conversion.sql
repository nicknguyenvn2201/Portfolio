insert
	into
	{{ target_table }}
select
	*
from
	{{ temp_table_name }}
on
	conflict ({{ primary_col }}) do update
set
	{% for col in non_primary_cols %}
	"{{ col }}" = excluded."{{ col }}"{% if not loop.last %}, {% endif %}
	{% endfor %}
