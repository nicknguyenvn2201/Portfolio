select
    coalesce(c.current_stage, b.stage) current_stage,
    coalesce(
        c.start_of_current_stage,
        case
            when sum(cost) over (partition by id) > 0
            then
                min(date_start) filter (where cost > 0) over (
                    partition by id order by date_start
                )
            else min(date_start) over (partition by id order by date_start)
        end
    ) current_stage_start,
    coalesce(c.status, b.status) current_status,
    coalesce(c.category, b.camp_category) current_category,
    coalesce(c.budget, b.budget) current_budget,
    case when c.current_stage is null then 1 else 0 end new_camp,
    case
        when sum(cost) over (partition by id) > 0
        then
            min(date_start) filter (where cost > 0) over (
                partition by id order by date_start
            )
        else min(date_start) over (partition by id order by date_start)
    end
    camp_start,
    max(create_date) over (partition by id) start_,
    a.id,
    a.date_start,
    a.date_end,
    a.mb_week,
    a.leads,
    a.cost,
    a.profit,
    b.camp_category,
    b.budget,
    b.stage,
    b.status
from mb_data_daily a
left join dim_mb_camp_category b on a.id = b.camp_id
left join dim_mb_initial_stage c on a.id = c.cp_id
