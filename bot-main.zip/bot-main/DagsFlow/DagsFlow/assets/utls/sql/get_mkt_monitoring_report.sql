with
    rename_columns as (
        select
            added_timestamp as "Lead Createdate",
            payout as "Payout",
            revenue as "Revenue",
            profit as "Profit",
            changed_timestamp as "Date Modified",
            "affiliate.id" as "Affiliate ID",
            "affiliate.value" as "Affiliate",
            aff_click_id as "Affiliate Click ID",
            conversion_status as "Conversion Status",
            currency as "Currency",
            "paid_to_affiliate.value" as "Paid to Affiliate",
            transaction_id as "Transaction ID",
            sub_id1 as "Affiliate Sub ID 1",
            sub_id2 as "Affiliate Sub ID 2",
            sub_id3 as "Affiliate Sub ID 3",
            sub_id4 as "Affiliate Sub ID 4",
            sub_id5 as "Affiliate Sub ID 5",
            "affiliate_invoice.value" as "Affiliate Invoice",
            "offer.id" as "Offer ID",
            advertiser_user_id as "Advertiser User ID",
            "offer.value" as "Offer"
        from fct_affscale_network_conversion
    ),
    reorder_columns as (
        select
            "Lead Createdate",
            "Date Modified",
            "Conversion Status",
            "Affiliate ID",
            "Affiliate",
            "Offer ID",
            "Offer",
            "Revenue",
            "Payout",
            "Profit",
            "Currency",
            "Paid to Affiliate",
            "Affiliate Invoice",
            "Transaction ID",
            "Affiliate Click ID",
            "Affiliate Sub ID 1",
            "Affiliate Sub ID 2",
            "Affiliate Sub ID 3",
            "Affiliate Sub ID 4",
            "Affiliate Sub ID 5",
            "Advertiser User ID"
        from rename_columns
    )
select *
from reorder_columns
where "Lead Createdate" >= '2023-01-01'
