DELETE FROM dareport.data_master_raw_id
WHERE (lead_id, geo) IN (
    SELECT cf.lead_id,
    cf.geo
   FROM ( SELECT cl_fresh.geo,
            cl_fresh.lead_id,
                CASE
                    WHEN cl_fresh.lead_type::text = 'M'::text AND cl_fresh.affiliate_id IS NOT NULL AND (cl_fresh.cp_id = ANY (ARRAY[521, 4])) THEN 1
                    ELSE 0
                END AS filters
           FROM cl_fresh_temp cl_fresh) cf
           where cf.filters = 0 
           and cf.geo ^@ 'ID')