--TRUNCATE dareport.data_master_agg

insert into dareport.data_master_agg_fresh_only_testing (
  	geo ,
	org_id ,
	country_code ,
	etp_code ,
	so_status ,
	do_status ,
	carrier ,
	lead_date ,
	so_date ,
	do_date ,
	date_used ,
	sale_campaign ,
	fin_campaign ,
	network ,
	offer ,
	pub ,
	province ,
	district ,
	subdistrict ,
	assigned ,
	lead_type ,
	agname ,
	offer_type ,
	leads ,
	uncall_leads ,
	trash_leads ,
	approved_postback ,
	approved_payout ,
	approved_max_po ,
	ar_target_mrp ,
	validated ,
	amt_validated ,
	delivered ,
	amt_delivered ,
	finalized_do ,
	lead_wait_time ,
	total_items ,
	gift_items ,
	actual_call ,
	week_used_start ,
	week_used_start_current ,
	exchange ,
	inrangeforecast ,
	week_used ,
	month_used ,
	year_used ,
	week_year_used ,
	month_year_used ,
	tax_rate ,
	amt_validated_usd ,
	amt_delivered_usd ,
	dr_final,
    payment_method,
    uncall_actual_call,
    lead_wait_time_working_hours,
    firstdelivertime,
    warehouse_name,
    region,
    pre_cutoff,
    time_cutoff,
    lead_mrp,
    pub_lead_mrp,
    contactable_leads,
        creation_date,
        so_modify_date,
        do_modify_date,
        packed_time,
        closetime,
     delivery_packages_name,
     product_1,
     team_name,
     do_hour,
     packed_hour,
     productcrosssell,
     FFMname
)(
WITH cte_ar_mrps AS (SELECT ar_mrps.affiliate_id AS network,
    ar_mrps.org_id,
    ar_mrps.offer_id AS product_name,
        CASE
            WHEN lower(ar_mrps.sub_id) = '*'::text THEN ''::text
            WHEN lower(ar_mrps.sub_id) = ''::text THEN 'blank'::text
            ELSE ar_mrps.sub_id
        END AS sub_id,
    ar_mrps.ar_mrp,
    ar_mrps.applied_from_date::date AS started_date,
    ar_mrps.applied_to_date::date AS ending_date,
        CASE
            WHEN lower(ar_mrps.sub_id) = '*'::text THEN concat(ar_mrps.affiliate_id, '_', ar_mrps.offer_id)
            WHEN lower(ar_mrps.sub_id) = ''::text THEN concat(ar_mrps.affiliate_id, '_', 'blank', '_', ar_mrps.offer_id)
            ELSE concat(ar_mrps.affiliate_id, '_', ar_mrps.sub_id, '_', ar_mrps.offer_id)
        END AS target_key
   FROM ar_mrps
), 
cte_lead_mrps AS (
         SELECT lead_mrps.affiliate_id AS network,
            lead_mrps.org_id,
            lead_mrps.offer_id AS product_name,
                CASE
                    WHEN lower(lead_mrps.sub_id) = '*'::text THEN ''::text::character varying::text
                    WHEN lower(lead_mrps.sub_id) = ''::text THEN 'blank'::text::character varying::text
                    ELSE lead_mrps.sub_id
                END AS sub_id,
            lead_mrps.lead_mrp,
            lead_mrps.applied_from_date::date AS started_date,
            lead_mrps.applied_to_date::date AS ending_date,
                CASE
                    WHEN lower(lead_mrps.sub_id) = '*'::text THEN concat(lead_mrps.affiliate_id, '_', lead_mrps.offer_id)
                    WHEN lower(lead_mrps.sub_id) = ''::text THEN concat(lead_mrps.affiliate_id, '_', 'blank', '_', lead_mrps.offer_id)
                    ELSE concat(lead_mrps.affiliate_id, '_', lead_mrps.sub_id, '_', lead_mrps.offer_id)
                END AS target_key
           FROM lead_mrps
        ),
main_cte AS (
 SELECT dmr.geo,
    dmr.org_id,
    dmr.country_code,
    dmr.etp_code,
    dmr.so_status,
    dmr.do_status,
    dmr.carrier,
    dmr.lead_date::date lead_date,
    dmr.so_date,
    dmr.do_date,
        CASE
            WHEN dmr.lead_type::text = 'A'::text THEN dmr.lead_date::date
            ELSE dmr.so_date
        END AS date_used,
    dmr.sale_campaign,
        CASE
            WHEN COALESCE(dmr.shortname, dmr.agc_code)::text = ANY (ARRAY['AFS'::character varying::text, 'OFP'::character varying::text]) THEN dmr.network
            ELSE COALESCE(dmr.shortname, dmr.agc_code, null)
        END AS network,
    dmr.offer,
        CASE
            WHEN (dmr.network::text = ANY (ARRAY['EW'::character varying::text, 'AT'::character varying::text, 'ADT'::character varying::text, 'ABT'::character varying::text, 'ARB'::character varying::text, 'CSL'::character varying::text, 'MKR'::character varying::text, 'XXX'::character varying::text, 'PFC'::character varying::text, 'ORG'::character varying::text, 'ORG2'::character varying::text, 'PIB'::character varying::text, 'MH'::character varying::text, 'MP'::character varying::text, 'IGO'::character varying::text, 'VIC'::character varying::text, 'ODS'::character varying::text, 'DAT'::character varying::text, 'VAL'::character varying::text, 'MIR'::character varying::text, 'NGN'::character varying::text, 'WIL'::character varying::text, 'PD'::character varying::text, 'CTR'::character varying::text, 'U_DOMA'::character varying::text, 'ABG'::character varying::text])) OR dmr.network::text = 'U_RUS'::text AND dmr.geo::text = 'TH'::text OR dmr.pub IS NULL THEN 'No PubID'::character varying
            WHEN dmr.pub::text = ''::text THEN 'blank'::character varying
            ELSE dmr.pub
        END AS pub,
    dmr.province,
    dmr.district,
    dmr.subdistrict,
    dmr.assigned,
    dmr.lead_type,
    payment_method,
    firstdelivertime,
						warehouse_name,
						region,
						pre_cutoff,
						time_cutoff,
    ou.user_name AS agname,
        CASE
            WHEN dmr.lead_type::text = 'A'::text AND dmr.offer::text ~~* '%cpl%'::text THEN 'cpl'::text
            WHEN dmr.lead_type::text = 'A'::text AND dmr.offer::text !~~* '%cpl%'::text THEN 'cpa'::text
            ELSE 'undefined'::text
        END AS offer_type,
    count(DISTINCT dmr.lead_id) AS leads,
    count(DISTINCT
        CASE
            WHEN dmr.lead_status::text = ANY (ARRAY['closed'::character varying::text, 'unreachable'::character varying::text, 'busy'::character varying::text, 'noanswer'::character varying::text]) THEN dmr.lead_id
            ELSE NULL::bigint
        END) AS uncall_leads,
    count(DISTINCT
        CASE
            WHEN dmr.lead_status::text = 'trash'::text THEN dmr.lead_id
            ELSE NULL::bigint
        END) AS trash_leads,
    count(distinct 
        CASE
            WHEN dmr.lead_type::text = 'A'::text AND dmr.postback_status::text = 'approved'::text THEN dmr.lead_id 
            ELSE null
        END) AS approved_postback,
    sum(
        CASE
            WHEN dmr.lead_type::text = 'A'::text AND dmr.postback_status::text = 'approved'::text THEN dmr.payout
            ELSE 0::double precision
        END) AS approved_payout,
    sum(
        CASE
            WHEN dmr.lead_type::text = 'A'::text AND dmr.postback_status::text = 'approved'::text THEN dmr.max_po
            ELSE 0::double precision
        END) AS approved_max_po,
    count(distinct 
        CASE
            WHEN dmr.so_status::text = ANY (ARRAY['validated'::character varying::text, 'delay'::character varying::text]) THEN dmr.lead_id 
            ELSE null 
        END) AS validated,
    sum(
        CASE
            WHEN dmr.so_status::text = ANY (ARRAY['validated'::character varying::text, 'delay'::character varying::text]) THEN dmr.so_amount
            ELSE 0::numeric
        END) AS amt_validated,
    count(distinct 
        CASE
            WHEN dmr.do_status::text = 'delivered'::text THEN dmr.lead_id 
            ELSE null 
        END) AS delivered,
    sum(
        CASE
            WHEN dmr.do_status::text = 'delivered'::text THEN dmr.so_amount
            ELSE 0::numeric
        END) AS amt_delivered,
    count(distinct 
        CASE
            WHEN dmr.do_status::text = ANY (ARRAY['delivered'::character varying::text, 'returned'::character varying::text, 'returning'::character varying::text, 'cancel'::character varying::text]) THEN dmr.lead_id 
            ELSE null 
        END) AS finalized_do,
    sum(dmr.total_items) AS total_items,
    sum(dmr.gift_items) AS gift_items,
    sum(dmr.actual_call) AS actual_call,
    avg(
        CASE
            WHEN dmr.hour_type_ = 'Working Hours'::text THEN date_part('day'::text, dmr.first_call_click - dmr.lead_date) * 24::double precision * 60::double precision + date_part('hour'::text, dmr.first_call_click - dmr.lead_date) * 60::double precision + date_part('minute'::text, dmr.first_call_click - dmr.lead_date) + date_part('second'::text, dmr.first_call_click - dmr.lead_date) / 60::double precision
            WHEN dmr.hour_type_ = 'Non-Working Hours'::text THEN date_part('day'::text, dmr.first_call_click - dmr.start_working_time) * 24::double precision * 60::double precision + date_part('hour'::text, dmr.first_call_click - dmr.start_working_time) * 60::double precision + date_part('minute'::text, dmr.first_call_click - dmr.start_working_time) + date_part('second'::text, dmr.first_call_click - dmr.start_working_time) / 60::double precision
            ELSE NULL::double precision
        END) AS lead_wait_time,
        sum(CASE
            WHEN dmr.lead_status::text = ANY (ARRAY['closed'::character varying::text, 'unreachable'::character varying::text, 'busy'::character varying::text, 'noanswer'::character varying::text]) THEN actual_call else 0 end) AS uncall_actual_call,
            avg(
        CASE
            WHEN dmr.hour_type_ = 'Working Hours'::text THEN date_part('day'::text, dmr.first_call_click - dmr.lead_date) * 24::double precision * 60::double precision + date_part('hour'::text, dmr.first_call_click - dmr.lead_date) * 60::double precision + date_part('minute'::text, dmr.first_call_click - dmr.lead_date) + date_part('second'::text, dmr.first_call_click - dmr.lead_date) / 60::double precision
            ELSE NULL::double precision
        END) AS lead_wait_time_working_hours,
        count(DISTINCT
        CASE
            WHEN dmr.lead_status::text = ANY (ARRAY['approved'::character varying::text, 'rejected'::character varying::text, 'callback not prospect'::character varying::text, 'callback consulting'::character varying::text, 'callback potential'::character varying::text]) THEN dmr.lead_id
            ELSE NULL::bigint
        END) AS contactable_leads,
        creation_date,
        so_modify_date,
        do_modify_date,
        packed_time,
        closetime,
     delivery_packages_name,
     product_1,
     do_hour,
     ot.name team_name,
     packed_hour,
     productcrosssell,
     FFMname
   FROM ( SELECT dmr_1.lead_id,
            dmr_1.so_id,
            dmr_1.do_id,
            dmr_1.tracking_code,
            dmr_1.geo,
            dmr_1.org_id,
            dmr_1.country_code,
            dmr_1.etp_code,
            dmr_1.lead_date,
            dmr_1.so_date,
            dmr_1.do_date,
            dmr_1.lead_modify_date,
            dmr_1.so_modify_date,
            dmr_1.do_modify_date,
            dmr_1.name,
            dmr_1.phone,
            dmr_1.sale_campaign,
            dmr_1.offer,
            dmr_1.network,
            dmr_1.pub,
            dmr_1.conversion_status,
            dmr_1.payout,
            dmr_1.max_po,
            dmr_1.so_amount,
            dmr_1.lead_status,
            dmr_1.first_call_status,
            dmr_1.so_status,
            dmr_1.postback_status,
            dmr_1.do_status,
            dmr_1.province,
            dmr_1.district,
            dmr_1.subdistrict,
            dmr_1.total_call,
            dmr_1.actual_call,
            dmr_1.lead_type,
            dmr_1.first_call_time,
            dmr_1.total_items,
            dmr_1.gift_items,
            dmr_1.assigned,
            dmr_1.creation_date::date creation_date,
            dmr_1.packed_time,
            dmr_1.shortname,
            dmr_1.agc_code,
            dmr_1.carrier,
            dmr_1.first_call_click,
            payment_method,
            dmr_1.hour_type_,
                CASE
                    WHEN dmr_1.hour_type_ = 'Non-Working Hours'::text AND (dmr_1.country_code::text = 'TH'::text OR dmr_1.country_code::text = 'MY'::text OR dmr_1.country_code::text = 'VN'::text) THEN date_trunc('day'::text, dmr_1.lead_date + '05:00:00'::interval) + '08:00:00'::interval
                    WHEN dmr_1.hour_type_ = 'Non-Working Hours'::text AND (dmr_1.country_code::text = 'ID'::text OR dmr_1.country_code::text = 'PH'::text) THEN date_trunc('day'::text, dmr_1.lead_date + '05:00:00'::interval) + '07:00:00'::interval
                    ELSE dmr_1.lead_date
                END AS start_working_time,
                firstdelivertime,
						warehouse_name,
						region,
						pre_cutoff,
						time_cutoff,
						closetime,
     delivery_packages_name,
     product_1,
     do_hour,
     packed_hour,
     productcrosssell,
     FFMname
           FROM ( SELECT data_master_raw.lead_id,
                    data_master_raw.so_id,
                    data_master_raw.do_id,
                    data_master_raw.tracking_code,
                    data_master_raw.geo,
                    data_master_raw.org_id,
                    data_master_raw.country_code,
                    data_master_raw.etp_code,
                    data_master_raw.lead_date,
                    data_master_raw.so_date::date so_date,
                    data_master_raw.do_date::date do_date,
                    data_master_raw.lead_modify_date::date lead_modify_date,
                    data_master_raw.so_modify_date::date so_modify_date,
                    data_master_raw.do_modify_date::date do_modify_date,
                    data_master_raw.name,
                    data_master_raw.phone,
                    data_master_raw.sale_campaign,
                    data_master_raw.offer,
                    data_master_raw.network,
                    data_master_raw.pub,
                    data_master_raw.conversion_status,
                    data_master_raw.payout,
                    data_master_raw.max_po,
                    data_master_raw.so_amount,
                    data_master_raw.lead_status,
                    data_master_raw.first_call_status,
                    data_master_raw.so_status,
                    data_master_raw.postback_status,
                    data_master_raw.do_status,
                    data_master_raw.province,
                    data_master_raw.district,
                    data_master_raw.subdistrict,
                    data_master_raw.total_call,
                    data_master_raw.actual_call,
                    data_master_raw.lead_type,
                    data_master_raw.first_call_time,
                    data_master_raw.total_items,
                    data_master_raw.gift_items,
                    data_master_raw.assigned,
                    data_master_raw.creation_date,
                    data_master_raw.packed_time::date packed_time,
                    data_master_raw.shortname,
                    data_master_raw.agc_code,
                    data_master_raw.carrier,
                    data_master_raw.first_call_click,
                    cfs.name payment_method,
                        CASE
                            WHEN data_master_raw.country_code::text = 'TH'::text AND date_part('hour'::text, data_master_raw.lead_date) >= 8::double precision AND date_part('hour'::text, data_master_raw.lead_date) <= 19::double precision THEN 'Working Hours'::text
                            WHEN data_master_raw.country_code::text = 'ID'::text AND date_part('hour'::text, data_master_raw.lead_date) >= 7::double precision AND date_part('hour'::text, data_master_raw.lead_date) <= 21::double precision THEN 'Working Hours'::text
                            WHEN data_master_raw.country_code::text = 'MY'::text AND date_part('hour'::text, data_master_raw.lead_date) >= 8::double precision AND date_part('hour'::text, data_master_raw.lead_date) <= 19::double precision THEN 'Working Hours'::text
                            WHEN data_master_raw.country_code::text = 'VN'::text AND date_part('hour'::text, data_master_raw.lead_date) >= 8::double precision AND date_part('hour'::text, data_master_raw.lead_date) <= 21::double precision THEN 'Working Hours'::text
                            WHEN data_master_raw.country_code::text = 'PH'::text AND date_part('hour'::text, data_master_raw.lead_date) >= 7::double precision AND date_part('hour'::text, data_master_raw.lead_date) <= 20::double precision THEN 'Working Hours'::text
                            ELSE 'Non-Working Hours'::text
                        END AS hour_type_,
                        firstdelivertime,
						warehouse_name,
						region,
						pre_cutoff,
						time_cutoff,
                        closetime::date closetime,
     delivery_packages_name,
     product_1,
     extract(hour from data_master_raw.do_date) do_hour,
     extract(hour from data_master_raw.packed_time) packed_hour,
     productcrosssell,
     FFMname
                   FROM data_master_raw data_master_raw
                   left join cf_synonym cfs on data_master_raw.geo = cfs.geo and data_master_raw.payment_method = cfs.value and cfs."type" = 'payment mothod'
                   where lead_type = 'A'
                   ) dmr_1) dmr
     LEFT JOIN or_user ou ON dmr.geo::text = ou.geo::text AND dmr.assigned = ou.user_id AND ou.user_type::text = 'agent'::text
left join or_team_member tm ON 
 ou.user_id = tm.user_id AND ou.geo::text = tm.geo::text
left join or_team ot on 
    ot.id = tm.team_id AND ot.geo::text = tm.geo::text
  WHERE (dmr.lead_modify_date >= (CURRENT_DATE - 365) OR dmr.so_modify_date >= (CURRENT_DATE - 365) OR dmr.do_modify_date >= (CURRENT_DATE - 365)) AND dmr.name::text !~~ '%test%'::text AND
        CASE
            WHEN dmr.lead_status::text = 'duplicated'::text OR dmr.lead_status::text = 'trash'::text AND dmr.assigned = 0 THEN 1
            ELSE 0
        END = 0
  GROUP BY dmr.geo, dmr.org_id, dmr.country_code, dmr.etp_code, dmr.so_status, dmr.do_status, dmr.carrier, (dmr.lead_date::date), (dmr.so_date::date), (dmr.do_date::date), (
        CASE
            WHEN dmr.lead_type::text = 'A'::text THEN dmr.lead_date::date
            ELSE dmr.so_date::date
        END), dmr.sale_campaign, CASE
            WHEN COALESCE(dmr.shortname, dmr.agc_code)::text = ANY (ARRAY['AFS'::character varying::text, 'OFP'::character varying::text]) THEN dmr.network
            ELSE COALESCE(dmr.shortname, dmr.agc_code, null)
        END, dmr.offer, (
        CASE
            WHEN (dmr.network::text = ANY (ARRAY['EW'::character varying::text, 'AT'::character varying::text, 'ADT'::character varying::text, 'ABT'::character varying::text, 'ARB'::character varying::text, 'CSL'::character varying::text, 'MKR'::character varying::text, 'XXX'::character varying::text, 'PFC'::character varying::text, 'ORG'::character varying::text, 'ORG2'::character varying::text, 'PIB'::character varying::text, 'MH'::character varying::text, 'MP'::character varying::text, 'IGO'::character varying::text, 'VIC'::character varying::text, 'ODS'::character varying::text, 'DAT'::character varying::text, 'VAL'::character varying::text, 'MIR'::character varying::text, 'NGN'::character varying::text, 'WIL'::character varying::text, 'PD'::character varying::text, 'CTR'::character varying::text, 'U_DOMA'::character varying::text, 'ABG'::character varying::text])) OR dmr.network::text = 'U_RUS'::text AND dmr.geo::text = 'TH'::text OR dmr.pub IS NULL THEN 'No PubID'::character varying
            WHEN dmr.pub::text = ''::text THEN 'blank'::character varying
            ELSE dmr.pub
        END), dmr.province, dmr.district, dmr.subdistrict, dmr.assigned, dmr.lead_type, payment_method,firstdelivertime,
						warehouse_name,
						region,
						pre_cutoff,
						time_cutoff,ou.user_name,creation_date,
        so_modify_date,
        do_modify_date,
        packed_time,
        closetime,
     delivery_packages_name,
     product_1,
     do_hour,
     ot.name,
     packed_hour,
     productcrosssell,
     FFMname
), final_cte AS (
 SELECT mc.geo,
        CASE
            WHEN mc.date_used = '2023-12-31'::date THEN 1::double precision
            ELSE date_part('week'::text, mc.date_used + '1 day'::interval)
        END AS week_used,
        CASE
            WHEN mc.date_used = '2023-12-31'::date THEN 1::double precision
            ELSE date_part('month'::text, mc.date_used)
        END AS month_used,
        CASE
            WHEN mc.date_used = '2023-12-31'::date THEN 2024::double precision
            ELSE date_part('year'::text, mc.date_used)
        END AS year_used,
        CASE
            WHEN mc.lead_date < '2024-06-01'::date AND mc.geo::text = 'VNID'::text THEN 16
            WHEN mc.country_code::text = 'VN'::text THEN 4
            WHEN mc.country_code::text = 'ID'::text THEN 9
            WHEN mc.country_code::text = 'MY'::text THEN 11
            WHEN mc.country_code::text = 'PH'::text THEN 14
            WHEN mc.country_code::text = 'TH'::text THEN 10
            ELSE mc.org_id
        END AS geo_id,
    mc.org_id,
    mc.country_code,
    mc.etp_code,
    mc.so_status,
    mc.do_status,
    mc.carrier,
    mc.lead_date,
    mc.so_date,
    mc.do_date,
    mc.date_used,
    mc.sale_campaign,
    mc.network,
    mc.offer,
    mc.pub,
    mc.province,
    mc.district,
    mc.subdistrict,
    mc.assigned,
    mc.lead_type,
    payment_method,
    firstdelivertime,
						warehouse_name,
						region,
						pre_cutoff,
						time_cutoff,
    mc.agname,
    mc.offer_type,
    mc.leads,
    mc.uncall_leads,
    mc.trash_leads,
    mc.approved_postback,
    mc.approved_payout,
    mc.approved_max_po,
    mc.validated,
    mc.amt_validated,
    mc.delivered,
    mc.amt_delivered,
    mc.finalized_do,
    mc.lead_wait_time,
    uncall_actual_call,
    lead_wait_time_working_hours,
    mc.total_items,
    mc.gift_items,
    mc.actual_call,
    mc.week_used_start,
    mc.week_used_start_current,
    rate.exchange,
        CASE
            WHEN mc.country_code::text = 'VN'::text AND mc.week_used_start >= (mc.week_used_start_current - 14) THEN 1
            WHEN mc.country_code::text = 'ID'::text AND mc.week_used_start >= (mc.week_used_start_current - 21) THEN 1
            WHEN mc.country_code::text = 'TH'::text AND mc.week_used_start >= (mc.week_used_start_current - 7) THEN 1
            WHEN mc.country_code::text = 'PH'::text AND mc.week_used_start >= (mc.week_used_start_current - 7) THEN 1
            WHEN mc.country_code::text = 'MY'::text AND mc.week_used_start >= (mc.week_used_start_current - 14) THEN 1
            ELSE 0
        END AS inrangeforecast,
        contactable_leads,
        creation_date,
        so_modify_date,
        do_modify_date,
        packed_time,
        closetime,
     delivery_packages_name,
     product_1,
     do_hour,
     team_name,
     packed_hour,
     productcrosssell,
     FFMname
   FROM ( SELECT main_cte.geo,
            main_cte.org_id,
            main_cte.country_code,
            main_cte.etp_code,
            main_cte.so_status,
            main_cte.do_status,
            main_cte.carrier,
            main_cte.lead_date,
            main_cte.so_date,
            main_cte.do_date,
            main_cte.date_used,
            main_cte.sale_campaign,
            main_cte.network,
            main_cte.offer,
            main_cte.pub,
            main_cte.province,
            main_cte.district,
            main_cte.subdistrict,
            main_cte.assigned,
            main_cte.lead_type,
            payment_method,
            firstdelivertime,
						warehouse_name,
						region,
						pre_cutoff,
						time_cutoff,
            main_cte.agname,
            main_cte.offer_type,
            main_cte.leads,
            main_cte.uncall_leads,
            main_cte.trash_leads,
            main_cte.approved_postback,
            main_cte.approved_payout,
            main_cte.approved_max_po,
            main_cte.validated,
            main_cte.amt_validated,
            main_cte.delivered,
            main_cte.amt_delivered,
            main_cte.finalized_do,
            main_cte.lead_wait_time,
            uncall_actual_call,
    lead_wait_time_working_hours,
    contactable_leads,
        creation_date,
        so_modify_date,
        do_modify_date,
        packed_time,
        closetime,
     delivery_packages_name,
     product_1,
     do_hour,
     team_name,
     packed_hour,
     productcrosssell,
     FFMname,
            main_cte.total_items,
            main_cte.gift_items,
            main_cte.actual_call,
            (date_trunc('week'::text, main_cte.lead_date + '1 day'::interval) - '1 day'::interval)::date AS week_used_start,
            (date_trunc('week'::text, CURRENT_DATE + '1 day'::interval) - '1 day'::interval)::date AS week_used_start_current
                   FROM main_cte) mc
             LEFT JOIN dim_exchange_rate rate ON rate.geo = mc.country_code::text AND mc.date_used >= rate.started_date::date AND mc.date_used <= rate.ending_date::date
        )
 SELECT fc.geo,
    fc.org_id,
    fc.country_code,
    fc.etp_code,
    fc.so_status,
    fc.do_status,
    fc.carrier,
    fc.lead_date,
    fc.so_date,
    fc.do_date,
    fc.date_used,
    fc.sale_campaign,
        CASE
            WHEN fc.sale_campaign::text ~~* '%hc%'::text THEN 'HC'::text
    WHEN fc.sale_campaign::text ~~* '%me%'::text THEN 'ME'::text
    WHEN fc.sale_campaign::text ~~* '%sl%'::text OR fc.sale_campaign::text ~~* '%bt%'::text OR fc.sale_campaign::text ~~* '%slim%'::text OR fc.sale_campaign::text ~~* '%beau%'::text THEN 'SL&BT'::text
    WHEN fc.sale_campaign::text ~~* '%fit%'::text THEN 'FIT'::text
    ELSE 'Others'::text
    END AS fin_campaign,
fc.network,
fc.offer,
fc.pub,
fc.province,
fc.district,
fc.subdistrict,
fc.assigned,
fc.lead_type,
lower(fc.agname) agname,
fc.offer_type,
fc.leads,
fc.uncall_leads,
fc.trash_leads,
fc.approved_postback,
fc.approved_payout,
fc.approved_max_po,
COALESCE(am.ar_mrp, am_2.ar_mrp) AS ar_target_mrp,
fc.validated,
fc.amt_validated,
fc.delivered,
fc.amt_delivered,
fc.finalized_do,
fc.lead_wait_time,
fc.total_items,
fc.gift_items,
fc.actual_call,
fc.week_used_start,
fc.week_used_start_current,
fc.exchange,
fc.inrangeforecast,
fc.week_used,
fc.month_used,
fc.year_used,
    CASE
        WHEN fc.week_used < 10::double precision THEN (fc.year_used::text || '0'::text) || fc.week_used::text
    ELSE fc.year_used::text || fc.week_used::text
END AS week_year_used,
CASE
    WHEN fc.month_used < 10::double precision THEN (fc.year_used::text || '0'::text) || fc.month_used::text
            ELSE fc.year_used::text || fc.month_used::text
        END AS month_year_used,
    gm.tax_rate,
    COALESCE(fc.amt_validated, NULL::numeric)::double precision / fc.exchange AS amt_validated_usd,
    COALESCE(fc.amt_delivered, NULL::numeric)::double precision / fc.exchange AS amt_delivered_usd,
        CASE
            WHEN fc.validated = 0 THEN 0::double precision
            WHEN fc.validated > 0 and fc.inrangeforecast = 1 THEN coalesce(ddfm.dr_forecast,cddfbd.dr_forecast_final)
            WHEN fc.validated > 0 and fc.inrangeforecast = 0 THEN fc.delivered::double precision / fc.validated::double precision
            ELSE NULL::double precision
        END AS dr_final,
        payment_method,
        uncall_actual_call,
    lead_wait_time_working_hours,
    firstdelivertime,
						warehouse_name,
						region,
						pre_cutoff,
						time_cutoff,
    lm.lead_mrp,
    lm_2.lead_mrp AS pub_lead_mrp,
    contactable_leads,
        creation_date,
        so_modify_date,
        do_modify_date,
        packed_time,
        closetime,
     delivery_packages_name,
     product_1,
     team_name,
     do_hour,
     packed_hour,
     productcrosssell,
     FFMname
   FROM final_cte fc
     LEFT JOIN cdm_dim_dr_forecast_by_date cddfbd ON fc.country_code::text = cddfbd.geo AND fc.sale_campaign::text = cddfbd.category AND fc.offer::text = cddfbd.product_name AND fc.network::text = cddfbd.network AND fc.pub::text = cddfbd.pub
     LEFT JOIN dim_dr_manual_forecast ddfm ON fc.etp_code::text = ddfm.country_code AND fc.network::text = ddfm.network AND fc.offer::text = ddfm.offer AND fc.date_used >= ddfm."from" AND fc.date_used <= ddfm."to"
 LEFT JOIN dim_bd_gm_input gm ON gm.geo = fc.country_code::text AND fc.date_used >= gm.started_date::date AND fc.date_used <= gm.ending_date::date
 LEFT JOIN cte_ar_mrps am ON am.org_id = fc.geo_id AND
    CASE
        WHEN fc.pub::text = ''::text THEN concat(fc.network, '_', 'blank', '_', fc.offer)
    ELSE concat(fc.network, '_', fc.pub, '_', fc.offer)
    END = am.target_key AND fc.lead_date >= am.started_date AND fc.lead_date <= am.ending_date
 LEFT JOIN cte_ar_mrps am_2 ON am_2.org_id = fc.geo_id AND concat(fc.network, '_', fc.offer) = am_2.target_key AND fc.lead_date >= am_2.started_date AND fc.lead_date <= am_2.ending_date
 LEFT JOIN cte_lead_mrps lm ON lm.org_id = fc.geo_id AND
                CASE
                    WHEN fc.pub::text = ''::text THEN concat(fc.network, '_', 'blank', '_', fc.offer)
                    ELSE concat(fc.network, '_', fc.pub, '_', fc.offer)
                END = lm.target_key AND fc.lead_date >= lm.started_date AND fc.lead_date <= lm.ending_date
 LEFT JOIN cte_lead_mrps lm_2 ON lm_2.org_id = fc.geo_id AND concat(fc.network, '_', fc.offer) = lm_2.target_key AND fc.lead_date >= lm_2.started_date AND fc.lead_date <= lm_2.ending_date
) 
