insert into dareport.fact_cdr (
	geo,
	user_id,
	lead_id,
	call_note,
	starttime,
	stoptime,
	createtime,
	duration
)(
select geo,
		user_id,
		lead_id,
		call_note,
		starttime,
		stoptime,
		createtime,
		duration
from public.cdr 
where createtime >= CURRENT_DATE - 1
)
