WITH new_data AS (SELECT cf.lead_id,
    oso.so_id,
    odn.do_id,
    odn.tracking_code,
    cf.geo,
    cf.org_id,
        CASE
            WHEN cf.geo::text ^@ 'VN'::text THEN 'VN'::character varying
            WHEN cf.geo::text ^@ 'ID'::text THEN 'ID'::character varying
            WHEN cf.geo::text ^@ 'MY'::text THEN 'MY'::character varying
            WHEN cf.geo::text ^@ 'PH'::text THEN 'PH'::character varying
            WHEN cf.geo::text ^@ 'TH'::text THEN 'TH'::character varying
            WHEN cf.geo::text ^@ 'IN'::text THEN 'IN'::character varying
            ELSE cf.geo
        END AS country_code,
        CASE
            WHEN cf.geo::text = 'VNID'::text THEN 'VNID'::character varying
            WHEN cf.geo::text ^@ 'VN'::text THEN 'VN'::character varying
            WHEN cf.geo::text ^@ 'ID'::text THEN 'ID'::character varying
            WHEN cf.geo::text ^@ 'MY'::text THEN 'MY'::character varying
            WHEN cf.geo::text ^@ 'PH'::text THEN 'PH'::character varying
            WHEN cf.geo::text ^@ 'TH'::text THEN 'TH'::character varying
            WHEN cf.geo::text ^@ 'IN'::text THEN 'IN'::character varying
            ELSE cf.geo
        END AS etp_code,
    cf.createdate AS lead_date,
    oso.createdate AS so_date,
    odn.createdate AS do_date,
    cf.modifydate AS lead_modify_date,
    oso.modifydate AS so_modify_date,
    odn.updatedate AS do_modify_date,
    cf.name,
    cf.phone,
    cc.name AS sale_campaign,
        CASE
            WHEN cf.lead_type::text = 'A'::text THEN cf.prod_name::text
            ELSE osi.product_1
        END AS offer,
    cf.affiliate_id AS network,
    cf.subid1 AS pub,
    fanc.conversion_status,
    fanc.payout,
    fanc.revenue AS max_po,
    oso.amount AS so_amount,
    cf_lead.name AS lead_status,
    cf_lead_first.name AS first_call_status,
    cf_so.name AS so_status,
    cf.postback_status,
    cf_do.name AS do_status,
        CASE
            WHEN cf.geo::text ^@ 'TH'::text THEN lp.shortname
            ELSE lp.name
        END AS province,
        CASE
            WHEN cf.geo::text ^@ 'TH'::text THEN ld.shortname
            ELSE ld.name
        END AS district,
        CASE
            WHEN cf.geo::text ^@ 'TH'::text THEN ls.shortname
            ELSE ls.name
        END AS subdistrict,
    cf.total_call,
    cf.actual_call,
    cf.lead_type,
    cf.first_call_time,
    osi.total_items,
    osi.gift_items,
    cf.assigned,
    oso.creation_date,
    odn.packed_time,
    p.shortname,
    cf.agc_code,
    odn.carrier,
    cf.first_call_click,
    oso.payment_method,
    odn.firstdelivertime,
    odn.warehouse_name,
    lr.region_shortname AS region,
    slc.pre_cutoff,
    svc.time_cutoff,
    odn.closetime,
    odn.delivery_packages_name,
    osi.product_1,
    odn.productcrosssell,
    odn.ffmname,
    cf.fresh_lead_id,
    cf.reference_lead_id,
    cf.fresh_org_id,
    rc.rescue_id,
    rc.job_first_assign,
    rc.updater_name,
    rc.job_date,
    rc.status_name,
    rc.substatus_name,
    rc.reason,
    rc.sub_reason,
    rc.cs_user_name,
    ou.fullname qa_name,
    slc.post_cutoff
   FROM ( SELECT cl_fresh.geo,
            cl_fresh.lead_id,
            cl_fresh.org_id,
            cl_fresh.cp_id,
            cl_fresh.lead_status,
            cl_fresh.createdate,
            cl_fresh.modifydate,
            cl_fresh.name,
            cl_fresh.phone,
            cl_fresh.agc_id,
            cl_fresh.agc_code,
            cl_fresh.affiliate_id,
            cl_fresh.prod_name,
            cl_fresh.first_call_status,
            cl_fresh.first_call_time,
            cl_fresh.lead_type,
            cl_fresh.subid1,
            cl_fresh.postback_status,
            cl_fresh.total_call,
            cl_fresh.actual_call,
            cl_fresh.click_id,
            cl_fresh.province,
            cl_fresh.district,
            cl_fresh.subdistrict,
            cl_fresh.assigned,
            cl_fresh.first_call_click,
            cl_fresh.fresh_lead_id,
            cl_fresh.reference_lead_id,
            cl_fresh.fresh_org_id,
                CASE
                    WHEN cl_fresh.lead_type::text = 'M'::text AND cl_fresh.affiliate_id IS NOT NULL AND (cl_fresh.cp_id = ANY (ARRAY[521, 4])) THEN 1
                    ELSE 0
                END AS filters
           FROM cl_fresh_temp_test cl_fresh) cf
     FULL JOIN ( SELECT od_sale_order.so_id,
            od_sale_order.lead_id,
            od_sale_order.geo,
            od_sale_order.amount,
            od_sale_order.status,
            od_sale_order.createdate,
            od_sale_order.modifydate,
            od_sale_order.creation_date,
            od_sale_order.payment_method,
            validate_by
           FROM od_sale_order_temp_test od_sale_order
          WHERE od_sale_order.status <> 46) oso ON cf.lead_id::text = oso.lead_id::text AND cf.geo::text = oso.geo::text
     LEFT JOIN ( SELECT od_so_item.geo,
            od_so_item.so_id,
            max(
                CASE
                    WHEN od_so_item.item_no = 1 THEN pp.name
                    ELSE NULL::character varying
                END::text) AS product_1,
            sum(od_so_item.quantity) AS total_items,
            sum(
                CASE
                    WHEN od_so_item.price = 0 THEN od_so_item.quantity
                    ELSE 0
                END) AS gift_items
           FROM od_so_item od_so_item
             LEFT JOIN pd_product pp ON od_so_item.prod_id = pp.prod_id AND od_so_item.geo::text = pp.geo::text
          GROUP BY od_so_item.geo, od_so_item.so_id) osi ON oso.so_id::text = osi.so_id::text AND osi.geo::text = oso.geo::text
     FULL JOIN ( SELECT odn_1.do_id,
            odn_1.do_code,
            odn_1.tracking_code,
            odn_1.so_id,
            odn_1.geo,
            bp.shortname AS carrier,
            odn_1.createdate,
            odn_1.updatedate,
            odn_1.status,
            odn_1.packed_time,
            odn_1.firstdelivertime,
            odn_1.closetime,
            bw.warehouse_shortname AS warehouse_name,
            dp.name AS delivery_packages_name,
            odn_1.warehouse_id,
            odn_1.ffm_id,
            odn_1.carrier_id,
            odn_1.package_name AS productcrosssell,
            b.shortname AS ffmname
           FROM od_do_new_temp_test odn_1
             LEFT JOIN bp_partner bp ON bp.pn_id::text = odn_1.carrier_id::text AND bp.geo::text = odn_1.geo::text
             LEFT JOIN bp_warehouse bw ON odn_1.geo::text = bw.geo::text AND odn_1.warehouse_id = bw.warehouse_id
             LEFT JOIN delivery_packages dp ON odn_1.delivery_package_code = dp.code AND odn_1.geo::text = dp.geo::text
             LEFT JOIN bp_partner b ON odn_1.ffm_id = b.pn_id AND odn_1.geo::text = b.geo::text
          WHERE odn_1.updatedate >= (CURRENT_DATE - 365)) odn ON oso.so_id::text = odn.so_id::text AND odn.geo::text = oso.geo::text
     LEFT JOIN ( SELECT cf_synonym.geo,
            cf_synonym.synonym_id,
            cf_synonym.type,
            cf_synonym.name,
            cf_synonym.value,
            cf_synonym.dscr,
            cf_synonym.type_id,
            cf_synonym.localized_name
           FROM cf_synonym
          WHERE cf_synonym.type::text = 'lead status'::text) cf_lead ON cf_lead.geo::text = cf.geo::text AND cf.lead_status::text = cf_lead.value::text
     LEFT JOIN ( SELECT cf_synonym.geo,
            cf_synonym.synonym_id,
            cf_synonym.type,
            cf_synonym.name,
            cf_synonym.value,
            cf_synonym.dscr,
            cf_synonym.type_id,
            cf_synonym.localized_name
           FROM cf_synonym
          WHERE cf_synonym.type::text = 'lead status'::text) cf_lead_first ON cf_lead_first.geo::text = cf.geo::text AND cf.lead_status::text = cf_lead_first.value::text
     LEFT JOIN ( SELECT cf_synonym.geo,
            cf_synonym.synonym_id,
            cf_synonym.type,
            cf_synonym.name,
            cf_synonym.value,
            cf_synonym.dscr,
            cf_synonym.type_id,
            cf_synonym.localized_name
           FROM cf_synonym
          WHERE cf_synonym.type::text = 'sale order status'::text) cf_so ON cf_so.geo::text = oso.geo::text AND oso.status::text = cf_so.value::text
     LEFT JOIN ( SELECT cf_synonym.geo,
            cf_synonym.synonym_id,
            cf_synonym.type,
            cf_synonym.name,
            cf_synonym.value,
            cf_synonym.dscr,
            cf_synonym.type_id,
            cf_synonym.localized_name
           FROM cf_synonym
          WHERE cf_synonym.type::text = 'delivery order status'::text) cf_do ON cf_do.geo::text = odn.geo::text AND odn.status::text = cf_do.value::text
     LEFT JOIN cp_campaign cc ON cc.geo::text = cf.geo::text AND cc.cp_id::text = cf.cp_id::text
     LEFT JOIN fct_affscale_network_conversion fanc ON cf.click_id::text = fanc.transaction_id
     LEFT JOIN lc_province lp ON cf.province = lp.prv_id::text AND cf.geo::text = lp.geo::text
     LEFT JOIN lc_district ld ON cf.district = ld.dt_id::text AND cf.geo::text = ld.geo::text
     LEFT JOIN lc_subdistrict ls ON cf.subdistrict = ls.sdt_id::text AND cf.geo::text = ls.geo::text
     LEFT JOIN bp_partner p ON cf.agc_id = p.pn_id AND p.geo::text = cf.geo::text
     LEFT JOIN lc_region lr ON lp.geo::text = lr.geo::text AND lp.region_id = lr.region_id
     LEFT JOIN ( SELECT sla_location_conf.geo,
            sla_location_conf.warehouse_id,
            sla_location_conf.last_mile_id,
            sla_location_conf.province_id,
            sla_location_conf.district_id,
            sla_location_conf.ward_id,
            avg(sla_location_conf.pre_cutoff) AS pre_cutoff,
            avg(sla_location_conf.post_cutoff) AS post_cutoff
           FROM public.sla_location_conf
          GROUP BY sla_location_conf.geo, sla_location_conf.warehouse_id, sla_location_conf.last_mile_id, sla_location_conf.province_id, sla_location_conf.district_id, sla_location_conf.ward_id) slc ON odn.warehouse_id::text = slc.warehouse_id::text AND odn.geo::text = slc.geo::text AND slc.province_id::text = cf.province AND slc.district_id::text = cf.district AND slc.ward_id::text = cf.subdistrict AND slc.last_mile_id::text = odn.carrier_id::text
     LEFT JOIN public.sla_vendor_conf svc ON odn.ffm_id::text = svc.partner_id::text AND odn.geo::text = svc.geo::text
      LEFT JOIN or_user ou ON oso.validate_by = ou.user_id and ou.user_type = 'validator' and oso.geo = ou.geo
     LEFT JOIN ( SELECT rc_job.id AS rescue_id,
            rc_job.do_id,
            rc_job.geo,
            rc_job.fist_assigned_date AS job_first_assign,
            f.user_name AS updater_name,
            rc_job.createdate AS job_date,
            cf_status.status_name,
            cf_substatus.substatus_name,
            cf_reason.status_name AS reason,
            cf_subreason.substatus_name AS sub_reason,
            f2.user_name AS cs_user_name
           FROM rc_rescue_job rc_job
             LEFT JOIN ( SELECT rc_status.geo,
                    rc_status.id,
                    rc_status.description,
                    rc_status.modifyby,
                    rc_status.modifydate,
                    rc_status.status,
                    rc_status.status_name,
                    rc_status.type,
                    rc_status.type_name
                   FROM rc_status
                  WHERE rc_status.type = 1) cf_status ON cf_status.status = rc_job.job_status AND cf_status.geo::text = rc_job.geo::text
             LEFT JOIN rc_substatus cf_substatus ON cf_substatus.substatus = rc_job.job_sub_status AND cf_substatus.status_id = cf_status.id AND cf_substatus.geo::text = cf_status.geo::text
             LEFT JOIN ( SELECT rc_status.geo,
                    rc_status.id,
                    rc_status.description,
                    rc_status.modifyby,
                    rc_status.modifydate,
                    rc_status.status,
                    rc_status.status_name,
                    rc_status.type,
                    rc_status.type_name
                   FROM rc_status
                  WHERE rc_status.type = 2) cf_reason ON cf_reason.status = rc_job.job_reason AND cf_reason.geo::text = rc_job.geo::text
             LEFT JOIN rc_substatus cf_subreason ON cf_subreason.substatus = rc_job.job_sub_reason AND cf_subreason.status_id = cf_reason.id AND cf_subreason.geo::text = cf_reason.geo::text
             LEFT JOIN or_user f2 ON rc_job.updateby = f2.user_id AND rc_job.geo::text = f2.geo::text
             LEFT JOIN ( SELECT or_user.geo,
                    or_user.user_id,
                    or_user.org_id,
                    or_user.user_type,
                    or_user.user_name,
                    or_user.password,
                    or_user.user_lock,
                    or_user.fullname,
                    or_user.email,
                    or_user.phone,
                    or_user.birthday,
                    or_user.modifyby,
                    or_user.modifydate,
                    or_user.home_phone_1,
                    or_user.home_phone_2,
                    or_user.personal_phone_1,
                    or_user.personal_phone_2,
                    or_user.work_mail,
                    or_user.personal_mail,
                    or_user.home_address,
                    or_user.last_status,
                    or_user.last_status_code,
                    or_user.last_status_message,
                    or_user.chat_id,
                    or_user.force_change_password,
                    or_user.failed_login_count,
                    or_user.password_update_time,
                    or_user.is_expired
                   FROM or_user
                  WHERE or_user.user_name::text ~~ '%cs%'::text) f ON rc_job.assigned = f.user_id AND rc_job.geo::text = f.geo::text) rc ON rc.do_id = odn.do_id and rc.geo = odn.geo
  WHERE cf.filters = 0
)
INSERT INTO dareport.data_master_raw_template_temp_test (lead_id,
	so_id,
	do_id,
	tracking_code,
	geo,
	org_id,
	country_code,
	etp_code,
	lead_date,
	so_date,
	do_date,
	lead_modify_date,
	so_modify_date,
	do_modify_date,
	"name",
	phone,
	sale_campaign,
	offer,
	network,
	pub,
	conversion_status,
	payout,
	max_po,
	so_amount,
	lead_status,
	first_call_status,
	so_status,
	postback_status,
	do_status,
	province,
	district,
	subdistrict,
	total_call,
	actual_call,
	lead_type,
	first_call_time,
	total_items,
	gift_items,
	assigned,
	creation_date,
	packed_time,
    shortname,
    agc_code,
    carrier,
    first_call_click,
	payment_method,
    firstdelivertime,
    warehouse_name,
    region,
    pre_cutoff,
    time_cutoff,
    closetime,
     delivery_packages_name,
     product_1,
     productcrosssell,
     FFMname,
     fresh_lead_id,
     reference_lead_id,
     fresh_org_id,
     rescue_id,
    job_first_assign,
    updater_name,
    job_date,
    status_name,
    substatus_name,
    reason,
    sub_reason,
    cs_user_name,
    qa_name,
    post_cutoff
)
select distinct * from new_data;

