create table {{ table_name }} (
    {% for column_name, column_type in column_schema %}
    "{{ column_name }}" {{ column_type }}{% if not loop.last %}, {% endif %}
    {% endfor %}
)
