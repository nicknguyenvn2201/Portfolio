with 
target as (
select
	*,
	fresh_daily_revenue_target + resell_daily_revenue_target total_daily_revenue_target,
	fresh_daily_revenue_target * fresh_working_days fresh_monthly_target,
	daily_lead_target * fresh_working_days fresh_monthly_lead_target,
	resell_daily_revenue_target * resell_working_days resell_monthly_target,
	(fresh_daily_revenue_target * fresh_working_days) + (resell_daily_revenue_target * resell_working_days) total_monthly_target
from
	dim_geo_tracking_target dgtt
where
	target_year = extract(year
from
	current_date)
	and target_month = extract(month
from
	current_date)
),
leads as (
select
	geo,
	sum(case when createdate::date = (current_date)::date then 1 else 0 end ) today_leads,
	sum(case when createdate::date = (current_date-1)::date then 1 else 0 end ) yesterday_leads,
	sum(case when lead_type = 'A' and createdate >= date_trunc('month', current_date) then 1 else 0 end) MTD_fresh_leads
from
	(SELECT  
	 case
		when geo ^@ 'VN' then 'VN'
		when geo ^@ 'TH' then 'TH'
		when geo ^@ 'ID' then 'ID'
		when geo ^@ 'MY' then 'MY'
		when geo ^@ 'PH' then 'PH'
		else geo
	end geo,
	createdate,
	lead_type,
	assigned,
	lead_status,
	lead_id
	FROM cl_fresh
	WHERE createdate >= current_date - 32
	and lead_type = 'A'
	) a
where
 case
		when lead_status = 4
		or (lead_status = 5
			and assigned = 0) then 1
		else 0
	end = 0
group by 1),
sale_orders as (
select
	case
		when oso.geo ^@ 'VN' then 'VN'
		when oso.geo ^@ 'TH' then 'TH'
		when oso.geo ^@ 'ID' then 'ID'
		when oso.geo ^@ 'MY' then 'MY'
		when oso.geo ^@ 'PH' then 'PH'
		else oso.geo
	end geo,
	sum(case when oso.createdate::date = (current_date)::date then oso.amount else 0 end) today_total_revenue,
	sum(case when lead_type = 'A' and oso.createdate::date = (current_date)::date then oso.amount else 0 end) today_fresh_revenue,
	sum(case when lead_type <> 'A' and oso.createdate::date = (current_date)::date then oso.amount else 0 end) today_resell_revenue,
	sum(case when oso.createdate between current_date - 1 and current_date then oso.amount else 0 end) yesterday_total_revenue,
	sum(case when lead_type = 'A' and oso.createdate between current_date - 1 and current_date then oso.amount else 0 end) yesterday_fresh_revenue,
	sum(case when lead_type <> 'A' and oso.createdate between current_date - 1 and current_date then oso.amount else 0 end) yesterday_resell_revenue,
	sum(case when oso.createdate >= date_trunc('month', current_date) then oso.amount else 0 end) MTD_total_revenue,
	sum(case when lead_type = 'A' and oso.createdate >= date_trunc('month', current_date) then oso.amount else 0 end) MTD_fresh_revenue,
	sum(case when lead_type <> 'A' and oso.createdate >= date_trunc('month', current_date) then oso.amount else 0 end) MTD_resell_revenue,
	sum(case when lead_type = 'A' and status = 357 then 1 else 0 end) fresh_delay_orders,
	sum(case when lead_type <> 'A' and status = 357 then 1 else 0 end) resell_delay_orders
from
	od_sale_order oso
left join cl_fresh cf on
	oso.lead_id = cf.lead_id
	and oso.geo = cf.geo
where
	oso.status in (43, 357)
		and oso.createdate >= date_trunc('month',
		current_date) - interval '1 day'
	group by 1
	),
delivery as (
select
	case
		when odn.geo ^@ 'VN' then 'VN'
		when odn.geo ^@ 'TH' then 'TH'
		when odn.geo ^@ 'ID' then 'ID'
		when odn.geo ^@ 'MY' then 'MY'
		when odn.geo ^@ 'PH' then 'PH'
		else odn.geo
	end geo,
	sum(case when odn.createdate::date = (current_date - 1)::date and odn.status in (51, 58, 54, 52, 66) then 1 else 0 end) d1_in_preparation,
	sum(case when odn.createdate::date = (current_date - 2)::date and odn.status in (51, 58, 54, 52, 66) then 1 else 0 end) d2_in_preparation,
	sum(case when odn.createdate::date = (current_date - 3)::date and odn.status in (51, 58, 54, 52, 66) then 1 else 0 end) d3_in_preparation,
	sum(case when odn.createdate < current_date - 3 and odn.status in (51, 58, 54, 52, 66) then 1 else 0 end) d4_in_preparation,
	sum(case when cf.lead_type = 'A' and odn.status = 65 then 1 else 0 end) fresh_pending,
	sum(case when cf.lead_type <> 'A' and odn.status = 65 then 1 else 0 end) resell_pending,
	coalesce(sum(case when odn.status = 59 and 
odn.createdate::date >= w0_start
then 1 else 0 end)::float / nullif(sum(case when odn.createdate::date >= w0_start then 1 else 0 end),
	0),
	0) w0_dr,
	sum(case when odn.status = 59 and odn.createdate::date >= w1_start and
odn.createdate::date <= w1_end
then 1 else 0 end)::float /
nullif(sum(case when odn.createdate::date >= w1_start and
odn.createdate::date <= w1_end
then 1 else 0 end),0) w1_dr,
	sum(case when odn.status = 59 and odn.createdate::date >= w2_start and
odn.createdate::date <= w2_end
then 1 else 0 end)::float /
nullif(sum(case when odn.createdate::date >= w2_start and
odn.createdate::date <= w2_end
then 1 else 0 end),0) w2_dr,
	sum(case when odn.status = 59 and odn.createdate::date >= w3_start and
odn.createdate::date <= w3_end
then 1 else 0 end)::float /
nullif(sum(case when odn.createdate::date >= w3_start and
odn.createdate::date <= w3_end
then 1 else 0 end),0) w3_dr,
	coalesce(sum(case when cf.lead_type = 'A' and odn.status = 59 and 
odn.createdate::date >= w0_start
then 1 else 0 end)::float /
nullif(sum(case when cf.lead_type = 'A' and odn.createdate::date >= w0_start then 1 else 0 end),
	0),
	0)
w0_fresh_dr,
	sum(case when cf.lead_type = 'A' and odn.status = 59 and odn.createdate::date >= w1_start and
odn.createdate::date <= w1_end
then 1 else 0 end)::float /
nullif(sum(case when cf.lead_type = 'A' and odn.createdate::date >= w1_start and
odn.createdate::date <= w1_end
then 1 else 0 end),0) 
w1_fresh_dr,
	sum(case when cf.lead_type = 'A' and odn.status = 59 and odn.createdate::date >= w2_start and
odn.createdate::date <= w2_end
then 1 else 0 end)::float /
nullif(sum(case when cf.lead_type = 'A' and odn.createdate::date >= w2_start and
odn.createdate::date <= w2_end
then 1 else 0 end),0)
w2_fresh_dr,
	sum(case when cf.lead_type = 'A' and odn.status = 59 and odn.createdate::date >= w3_start and
odn.createdate::date <= w3_end
then 1 else 0 end)::float /
nullif(sum(case when cf.lead_type = 'A' and odn.createdate::date >= w3_start and
odn.createdate::date <= w3_end
then 1 else 0 end),0) 
w3_fresh_dr,
	coalesce(sum(case when cf.lead_type <> 'A' and odn.status = 59 and 
odn.createdate::date >= w0_start
then 1 else 0 end)::float / nullif(
sum(case when cf.lead_type <> 'A' and odn.createdate::date >= w0_start then 1 else 0 end),
	0),
	0)
w0_resell_dr,
	sum(case when cf.lead_type <> 'A' and odn.status = 59 and odn.createdate::date >= w1_start and
odn.createdate::date <= w1_end
then 1 else 0 end)::float /
nullif(sum(case when cf.lead_type <> 'A' and odn.createdate::date >= w1_start and
odn.createdate::date <= w1_end
then 1 else 0 end),0)
w1_resell_dr,
	sum(case when cf.lead_type <> 'A' and odn.status = 59 and odn.createdate::date >= w2_start and
odn.createdate::date <= w2_end
then 1 else 0 end)::float /
nullif(sum(case when cf.lead_type <> 'A' and odn.createdate::date >= w2_start and
odn.createdate::date <= w2_end
then 1 else 0 end),0) 
w2_resell_dr,
	sum(case when cf.lead_type <> 'A' and odn.status = 59 and odn.createdate::date >= w3_start and
odn.createdate::date <= w3_end
then 1 else 0 end)::float /
nullif(sum(case when cf.lead_type <> 'A' and odn.createdate::date >= w3_start and
odn.createdate::date <= w3_end
then 1 else 0 end),0) 
w3_resell_dr
from
	(
	select
		createdate,
		geo,
		so_id,
		status,
		(date_trunc('week',
		CURRENT_TIMESTAMP + interval '1 day') - interval '1 day')::date w0_start,
		(date_trunc('week',
		CURRENT_TIMESTAMP + interval '1 day') + interval '5 day')::date w0_end,
		(date_trunc('week',
		CURRENT_TIMESTAMP + interval '1 day') - interval '1 day')::date - 7 w1_start,
		(date_trunc('week',
		CURRENT_TIMESTAMP + interval '1 day') + interval '5 day')::date -7 w1_end,
		(date_trunc('week',
		CURRENT_TIMESTAMP + interval '1 day') - interval '1 day')::date - 14 w2_start,
		(date_trunc('week',
		CURRENT_TIMESTAMP + interval '1 day') + interval '5 day')::date -14 w2_end,
		(date_trunc('week',
		CURRENT_TIMESTAMP + interval '1 day') - interval '1 day')::date - 21 w3_start,
		(date_trunc('week',
		CURRENT_TIMESTAMP + interval '1 day') + interval '5 day')::date -21 w3_end
	from
		od_do_new
	where
		createdate >= current_date - 30
	) odn
join (
	select
		geo,
		lead_id,
		so_id
	from
		od_sale_order
	where
		status <> 46) oso on
	oso.geo = odn.geo
	and oso.so_id = odn.so_id
left join cl_fresh cf on
	oso.geo = cf.geo
	and oso.lead_id = cf.lead_id
where
	odn.geo is not null
group by 1
)
select
	d.*,
	s.fresh_delay_orders,
	s.resell_delay_orders,
	t.daily_lead_target,
	l.today_leads,
	l.today_leads::float / t.daily_lead_target today_lead_runrate,
	l.yesterday_leads::float / t.daily_lead_target yesterday_lead_runrate,
	l.yesterday_leads,
	t.fresh_monthly_lead_target,
	l.MTD_fresh_leads,
	l.MTD_fresh_leads::float / t.fresh_monthly_lead_target mtd_lead_runrate,
	t.total_daily_revenue_target,
	t.fresh_daily_revenue_target,
	resell_daily_revenue_target,
	s.today_total_revenue,
	s.today_total_revenue / t.total_daily_revenue_target today_revenue_runrate,
	s.today_fresh_revenue,
	s.today_fresh_revenue / t.fresh_daily_revenue_target today_fresh_revenue_runrate,
	s.today_resell_revenue,
	s.today_resell_revenue / t.resell_daily_revenue_target today_resell_revenue_runrate,
	s.yesterday_total_revenue,
	s.yesterday_total_revenue / t.total_daily_revenue_target yesterday_revenue_runrate,
	s.yesterday_fresh_revenue,
	s.yesterday_fresh_revenue / t.fresh_daily_revenue_target yesterday_fresh_revenue_runrate,
	s.yesterday_resell_revenue,
	s.yesterday_resell_revenue / t.resell_daily_revenue_target yesterday_resell_revenue_runrate,
	s.MTD_total_revenue,
	t.total_monthly_target,
	t.fresh_monthly_target,
	t.resell_monthly_target,
	s.MTD_total_revenue / t.total_monthly_target total_MTD_revenue_runrate,
	s.MTD_fresh_revenue,
	s.MTD_fresh_revenue / t.fresh_monthly_target fresh_MTD_revenue_runrate,
	s.MTD_resell_revenue,
	s.MTD_resell_revenue / t.resell_monthly_target resell_MTD_revenue_runrate
from
	leads l
left join sale_orders s on
	l.geo = s.geo
left join delivery d on
	l.geo = d.geo
left join target t on
	t.geo = l.geo
where d.geo is not null and d.geo <> 'IN1'
