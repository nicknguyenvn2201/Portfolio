-- lol this is no longer needed. Keep for sql test template later
select *
from rep_sales__lead_backlog
where
    geo in ('{{ geos|join("', '") }}')
    and effective_date >= now()::date - interval '7' day  -- remove the earliest date since it's missing lead generated the day before
