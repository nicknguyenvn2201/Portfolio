select distinct
    affiliate_id, tdate.datum as "date", fob.opening_balance::int as opening_balance
from cl_fresh
cross join
    (
        select '2022-12-01'::date + sequence.day as datum  -- '2022-12-01' is starting date of current opening balance
        from generate_series(0, 3650) as sequence(day)
        where '2022-12-01'::date + sequence.day <= current_date
        group by sequence.day
    ) as tdate
left join fin_opening_balance fob on fob.partner = cl_fresh.affiliate_id
