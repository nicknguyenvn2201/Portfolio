select
   cm.lead_modify_date modifydate,
   cm.lead_date,
   cm.so_date,
   cm.total_call,
   cm.lead_id,
   cm.geo,
   cm.lead_status,
   cm.sale_campaign,
   cm.so_status,
   cm.so_amount,
   cm.do_status,
   ou.user_name,
   ot.name AS team,
   on_board_date,
   on_board_interval_months,
   f1_lead_id,f_type,f1_lead_date,f1_network,f1_offer,f1_geo,
case when lead_status ilike '%callback%' and (cr.duration = 0 or cr.duration is null) then 0 else 1 end lead_adj,
case when cr.duration > 0 then 1 else 0 end contactable_lead
from (select * from data_master_raw WHERE (lead_date >= current_date - 90 OR so_date >= current_date -90) 
and geo = 'VN3') cm
LEFT JOIN (SELECT geo,user_name,user_id from or_user WHERE user_type = 'agent') ou ON 
   cm.geo::text = ou.geo::text AND cm.assigned = ou.user_id
LEFT JOIN ( SELECT or_team_member.id,
            or_team_member.geo,
            or_team_member.user_id,
            or_team_member.team_id
           FROM or_team_member
          WHERE or_team_member.enabled = true) tm ON ou.user_id = tm.user_id AND ou.geo::text = tm.geo::text
LEFT JOIN ( SELECT or_team.geo,
            or_team.id,
            or_team.name
          FROM or_team
          WHERE or_team.enable = true) ot ON ot.id = tm.team_id AND ot.geo::text = tm.geo::text
left join (select geo, lead_id, sum(duration) duration from fact_cdr where geo = 'VN3' and createtime >= current_date -90 group by 1,2) cr on cm.lead_id = cr.lead_id and cm.geo = cr.geo
left join (select *,
(current_date - on_board_date)::float/30 on_board_interval_months
from dim_agent_on_board ) daob on daob.geo = cm.geo and daob.assigned = cm.assigned 
left join mv_f_type_vn3 mft on mft.geo = cm.geo and mft.lead_id = cm.lead_id
