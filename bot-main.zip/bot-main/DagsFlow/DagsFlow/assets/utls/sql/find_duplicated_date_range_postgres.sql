with
    date_table as (
        select
            generate_series(
                (select min({{ from_date_col }})::date from {{ model }}),
                (select max({{ to_date_col }})::date from {{ model }}),
                '1 day'::interval
            ) as date_to_check
    ),
    to_check_table as (select * from {{ model }}),
    map_check as (
        select date_to_check, {% if partitions %} {{ partitions }}, {% endif %} count(*)
        from date_table dte
        left join
            to_check_table chck
            on date_to_check between {{ from_date_col }} and {{ to_date_col }}
        where
            {{ from_date_col }} is not null  -- remove this if you also want to find gap
            {% if where %} and {{ where }} {% endif %}
        group by date_to_check {% if partitions %}, {{ partitions }} {% endif %}
        having count(*) > 1
        {% if order_by %} order by {{ order_by }} {% endif %}
    )
select *
from map_check
