insert into dareport.dim_default_payout (
  goal_id,
	offer_id,
	payout,
	is_default 	
) ( select distinct fanc."goal.id" as goal_id,
		fanc."offer.id" as offer_id,
		fp.payout,
		fp.is_default 
    from dareport.fct_affscale_network_conversion fanc 
    left join dareport.fact_payout fp on cast( fanc."goal.id" as int) = fp.goal_id
    where fp.is_default = 1
)