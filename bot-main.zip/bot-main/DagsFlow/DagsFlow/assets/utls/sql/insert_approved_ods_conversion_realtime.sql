insert
	into
	ods_affscale_conversion_realtime (
		createdate,
		lead_id,
		affiliate,
		sub_id1,
		offer,
		max_po,
		payout,
		profit,
		geo,
		transaction_id,
		advertiser
	)
(
	select
		added_timestamp as createdate,
		null as lead_id,
		"affiliate.id"::text || ' ' || "affiliate.value" as affiliate,
		sub_id1,
		"offer.id"::text || ' ' || "offer.value" as offer,
		revenue as max_po,
		payout,
		profit,
		upper(right(trim("offer.value"), 2)) as geo,
		transaction_id,
		"advertiser.id"::text || ' ' || "advertiser.value" as advertiser
	from
		fct_affscale_network_conversion_realtime
	where
		conversion_status = 'Approved'
		and "offer.value" <> 'VigasilCBDSS-TH (FOR TEST ONLY)' -- test case with illegal lead_id
	)
on conflict on constraint ods_affscale_conversion_realtime_pkey
do nothing
