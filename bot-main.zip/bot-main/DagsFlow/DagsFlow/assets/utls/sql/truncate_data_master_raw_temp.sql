DELETE FROM dareport.data_master_raw_temp 
WHERE (lead_id, geo) IN (
    SELECT cf.lead_id,
    cf.geo
   FROM ( SELECT cl_fresh.geo,
            cl_fresh.lead_id,
            cl_fresh.org_id,
            cl_fresh.cp_id,
            cl_fresh.lead_status,
            cl_fresh.createdate,
            cl_fresh.modifydate,
            cl_fresh.name,
            cl_fresh.phone,
            agc_id,
            agc_code,
            cl_fresh.affiliate_id,
            cl_fresh.prod_name,
            cl_fresh.first_call_status,
            cl_fresh.first_call_time,
            cl_fresh.lead_type,
            cl_fresh.subid1,
            cl_fresh.postback_status,
            cl_fresh.total_call,
            cl_fresh.actual_call,
            cl_fresh.click_id,
            cl_fresh.province,
            cl_fresh.district,
            cl_fresh.subdistrict,
            cl_fresh.assigned,
            first_call_click,
            case when lead_type = 'M' and affiliate_id is not null and cp_id in (521,4) then 1 else 0 end filters
           FROM cl_fresh_temp cl_fresh) cf
     LEFT JOIN ( SELECT od_sale_order.so_id,
            od_sale_order.lead_id,
            od_sale_order.geo,
            od_sale_order.amount,
            od_sale_order.status,
            od_sale_order.createdate,
            od_sale_order.modifydate,
            od_sale_order.creation_date,
            payment_method
           FROM od_sale_order_temp od_sale_order
          WHERE od_sale_order.status <> 46 ) oso ON cf.lead_id::text = oso.lead_id::text AND cf.geo::text = oso.geo::text
     LEFT JOIN ( SELECT od_so_item.geo,
            od_so_item.so_id,
            max(
                CASE
                    WHEN od_so_item.item_no = 1 THEN pp.name
                    ELSE NULL::character varying
                END::text) AS product_1,
            sum(od_so_item.quantity) AS total_items,
            sum(
                CASE
                    WHEN od_so_item.price = 0 THEN od_so_item.quantity
                    ELSE 0
                END) AS gift_items
           FROM od_so_item od_so_item
           LEFT JOIN pd_product pp ON od_so_item.prod_id = pp.prod_id AND od_so_item.geo::text = pp.geo::text
          GROUP BY od_so_item.geo, od_so_item.so_id) osi ON oso.so_id::text = osi.so_id::text AND osi.geo::text = oso.geo::text
     LEFT JOIN ( SELECT odn.do_id,
            odn.do_code,
            odn.tracking_code,
            odn.so_id,
            odn.geo,
            bp.shortname carrier,
            odn.createdate,
            odn.updatedate,
            odn.status,
            odn.packed_time,
            odn.firstdelivertime,
            odn.closetime,
            warehouse_shortname warehouse_name,
            dp.name delivery_packages_name,
            odn.warehouse_id,
            odn.ffm_id,
            odn.carrier_id,
            odn.package_name productcrosssell,
            b.shortname FFMname
           FROM od_do_new_temp odn 
           LEFT JOIN bp_partner bp on bp.pn_id::text = odn.carrier_id::text and bp.geo::text = odn.geo::text  
           LEFT JOIN bp_warehouse bw on odn.geo = bw.geo and odn.warehouse_id = bw.warehouse_id
           LEFT JOIN delivery_packages dp ON  odn.delivery_package_code = dp.code and odn.geo = dp.geo
           LEFT JOIN bp_partner b ON odn.FFM_id = b.pn_id and odn.geo = b.geo
          WHERE odn.updatedate >= current_date - 365) odn ON oso.so_id::text = odn.so_id::text AND odn.geo::text = oso.geo::text
     LEFT JOIN ( SELECT cf_synonym.geo,
            cf_synonym.synonym_id,
            cf_synonym.type,
            cf_synonym.name,
            cf_synonym.value,
            cf_synonym.dscr,
            cf_synonym.type_id,
            cf_synonym.localized_name
           FROM cf_synonym
          WHERE cf_synonym.type::text = 'lead status'::text) cf_lead ON cf_lead.geo::text = cf.geo::text AND cf.lead_status::text = cf_lead.value::text
     LEFT JOIN ( SELECT cf_synonym.geo,
            cf_synonym.synonym_id,
            cf_synonym.type,
            cf_synonym.name,
            cf_synonym.value,
            cf_synonym.dscr,
            cf_synonym.type_id,
            cf_synonym.localized_name
           FROM cf_synonym
          WHERE cf_synonym.type::text = 'lead status'::text) cf_lead_first ON cf_lead_first.geo::text = cf.geo::text AND cf.lead_status::text = cf_lead_first.value::text
     LEFT JOIN ( SELECT cf_synonym.geo,
            cf_synonym.synonym_id,
            cf_synonym.type,
            cf_synonym.name,
            cf_synonym.value,
            cf_synonym.dscr,
            cf_synonym.type_id,
            cf_synonym.localized_name
           FROM cf_synonym
          WHERE cf_synonym.type::text = 'sale order status'::text) cf_so ON cf_so.geo::text = oso.geo::text AND oso.status::text = cf_so.value::text
     LEFT JOIN ( SELECT cf_synonym.geo,
            cf_synonym.synonym_id,
            cf_synonym.type,
            cf_synonym.name,
            cf_synonym.value,
            cf_synonym.dscr,
            cf_synonym.type_id,
            cf_synonym.localized_name
           FROM cf_synonym
          WHERE cf_synonym.type::text = 'delivery order status'::text) cf_do ON cf_do.geo::text = odn.geo::text AND odn.status::text = cf_do.value::text
     LEFT JOIN cp_campaign cc ON cc.geo::text = cf.geo::text AND cc.cp_id::text = cf.cp_id::text
     LEFT JOIN fct_affscale_network_conversion fanc ON cf.click_id::text = fanc.transaction_id
     LEFT JOIN lc_province lp ON cf.province = lp.prv_id::text AND cf.geo::text = lp.geo::text
     LEFT JOIN lc_district ld ON cf.district = ld.dt_id::text AND cf.geo::text = ld.geo::text
     LEFT JOIN lc_subdistrict ls ON cf.subdistrict = ls.sdt_id::text AND cf.geo::text = ls.geo::text
     LEFT JOIN bp_partner p ON cf.agc_id = p.pn_id AND p.geo::text = cf.geo::text
     LEFT JOIN lc_region lr on lp.geo = lr.geo and lp.region_id = lr.region_id
     LEFT JOIN (select geo, warehouse_id, last_mile_id, province_id , district_id , ward_id ,avg(pre_cutoff) pre_cutoff, 
                       avg(post_cutoff) post_cutoff
                  from public.sla_location_conf 
                  group by 1,2,3,4,5,6) slc on odn.warehouse_id::text = slc.warehouse_id::text and odn.geo = slc.geo 
                                                                                               and slc.province_id::text = cf.province
                                                                                               and slc.district_id::text = cf.district::text
                                                                                               and slc.ward_id::text = cf.subdistrict::text
                                                                                               and slc.last_mile_id::text = odn.carrier_id::text
    LEFT JOIN public.sla_vendor_conf svc ON odn.ffm_id::text = svc.partner_id::text AND odn.geo::text = svc.geo::text
     where cf.filters = 0
);
