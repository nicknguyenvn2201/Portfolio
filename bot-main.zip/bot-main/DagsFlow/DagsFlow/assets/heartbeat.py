from dagster import (
    op,
    get_dagster_logger,
    graph,
    asset,
    MetadataValue,
    ScheduleDefinition,
    define_asset_job,
    AssetSelection,
)
from dagster import asset_check, AssetCheckResult, Output
import pandas as pd
from DagsFlow.assets.utls.func import (
    build_asset_with_blocking_check,
    extract_from_dwh,
    convert_utc_ts_to_local_tz,
)
from DagsFlow.assets.utls.sql import SqlStore
import os
from datetime import datetime
from DagsFlow.resources import telegram
import pandas as pd
from dateutil import tz
from DagsFlow.resources.postgres import PostgresConnection
import math

logger = get_dagster_logger()

# RESELL_GEO = ["VN3", "TH", "ID"]
RESELL_GEO = ["TH", "ID", "ID3"]
SKIP_GEO = ["VN"]
HEARTBEAT_MONITOR_INTERVAL = int(os.getenv("HEARTBEAT_MONITOR_INTERVAL") or "30")

FRESHNESS_RULES = [
    #["VN2", 60, 60],
    # ["VN3", math.inf, 120],
    ["VN4", 60, 60],
    ["TH", math.inf, 120],
    ["TH2", 60, 60],
    # ["ID", math.inf, 120],
    ["ID2", 60, 60],
    ["MY", 60, 60],
    ["ID3", math.inf, 120],
    ["PH", 1440, 1440],
]


def _find_diff(timestamp: datetime):
    return (datetime.now() - timestamp).total_seconds() / 60.0


def apply_freshness_rule(df: pd.DataFrame) -> pd.DataFrame:
    """
    For VN: skip
    For resell geo: every 2 hours, by modified date, working hours: 8am - 10pm
    For the rest every hour, by created date
    """
    df["is_stale"] = False
    for geo, create_interval, modify_interval in FRESHNESS_RULES:
        check_row = df.loc[df["geo"] == geo]
        if check_row.empty:
            continue
        df.loc[df["geo"] == geo, "is_stale"] = (
            check_row["min_since_last_create"] > create_interval
        ) | (check_row["min_since_last_update"] > modify_interval)
    df = df[df["is_stale"]]
    return df


@asset(group_name="heartbeat")
def oltp01__cl_fresh_heartbeat(oltp01_conn: PostgresConnection) -> Output[pd.DataFrame]:
    check_query = """
select geo, max(createdate) as last_created_time, max(modifydate) as last_modified_time
from cl_fresh
where geo is not null
group by geo
"""
    df = extract_from_dwh(check_query, oltp01_conn)
    return Output(
        value=df, metadata={"All Geos": MetadataValue.md(df.to_markdown(index=False))}
    )


@asset_check(asset=oltp01__cl_fresh_heartbeat)
def oltp01__cl_fresh_lead_freshness(
    df: pd.DataFrame,
    telebot_data: telegram.TelegramBot,
    telegram_chat: telegram.TelegramChat,
):
    df["min_since_last_create"] = df["last_created_time"].apply(_find_diff)
    df["min_since_last_update"] = df["last_modified_time"].apply(_find_diff)
    df = apply_freshness_rule(df)
    df = df[["geo", "last_created_time", "last_modified_time"]]
    if not df.empty:
        chat_id = telegram_chat.get_id("DATA_IT")
        telebot_data.send_message(
            chat_id,
            f"""cl\_fresh table in Read Write OLTP doesn't have new interactions from these geos:
    ```{df.to_string(index=False)}```
    """,
            parse_mode="MarkdownV2",
        )
    return AssetCheckResult(
        passed=df.empty,
        metadata={"Stale Geos": MetadataValue.md(df.to_markdown(index=False))},
    )


oltp01__cl_fresh_heartbeat = build_asset_with_blocking_check(
    oltp01__cl_fresh_heartbeat, checks=[oltp01__cl_fresh_lead_freshness]
)


@asset(group_name="heartbeat")
def oltp02__cl_fresh_heartbeat(oltp02_conn: PostgresConnection) -> Output[pd.DataFrame]:
    check_query = """
select geo, max(createdate) as last_created_time, max(modifydate) as last_modified_time
from cl_fresh
where geo is not null
group by geo
"""
    df = extract_from_dwh(check_query, oltp02_conn)
    return Output(
        value=df, metadata={"All Geos": MetadataValue.md(df.to_markdown(index=False))}
    )


@asset_check(asset=oltp02__cl_fresh_heartbeat)
def oltp02__cl_fresh_lead_freshness(
    df: pd.DataFrame,
    telebot_data: telegram.TelegramBot,
    telegram_chat: telegram.TelegramChat,
):
    df["min_since_last_create"] = df["last_created_time"].apply(_find_diff)
    df["min_since_last_update"] = df["last_modified_time"].apply(_find_diff)
    df = apply_freshness_rule(df)
    df = df[["geo", "last_created_time", "last_modified_time"]]
    if not df.empty:
        chat_id = telegram_chat.get_id("DATA_IT")
        telebot_data.send_message(
            chat_id,
            f"""cl\_fresh table in Read Only OLTP doesn't have new interactions from these geos:
    ```{df.to_string(index=False)}```
    """,
            parse_mode="MarkdownV2",
        )
    return AssetCheckResult(
        passed=df.empty,
        metadata={"Stale Geos": MetadataValue.md(df.to_markdown(index=False))},
    )


oltp02__cl_fresh_heartbeat = build_asset_with_blocking_check(
    oltp02__cl_fresh_heartbeat, checks=[oltp02__cl_fresh_lead_freshness]
)


@asset(group_name="heartbeat")
def oltp01__realtime_bd_master_2_heartbeat(
    oltp01_conn: PostgresConnection,
) -> Output[pd.Timestamp]:
    check_query = """
select last_refresh from realtime_bd_master_2 limit 1
"""
    df = extract_from_dwh(check_query, oltp01_conn)
    last_updated_at: pd.Timestamp = df.iloc[0, 0]
    last_updated_at = convert_utc_ts_to_local_tz(last_updated_at)
    return Output(
        value=last_updated_at,
        metadata={
            "Last Updated At": MetadataValue.text(str(last_updated_at)),
        },
    )


@asset_check(asset=oltp01__realtime_bd_master_2_heartbeat)
def oltp01__realtime_bd_master_2_freshness(
    last_updated_at: pd.Timestamp,
):
    minute_since_last_update = _find_diff(last_updated_at.replace(tzinfo=None))
    return AssetCheckResult(
        passed=minute_since_last_update < 15,
        metadata={
            "Minutes Since Last Update": MetadataValue.float(minute_since_last_update),
        },
    )


oltp01__realtime_bd_master_2_heartbeat = build_asset_with_blocking_check(
    oltp01__realtime_bd_master_2_heartbeat,
    checks=[oltp01__realtime_bd_master_2_freshness],
)


@asset(group_name="heartbeat")
def oltp01__leadstatus_bd_master_heartbeat(
    oltp01_conn: PostgresConnection,
) -> Output[pd.Timestamp]:
    check_query = """
select last_refresh from leadstatus_bd_master limit 1
"""
    df = extract_from_dwh(check_query, oltp01_conn)
    last_updated_at: pd.Timestamp = df.iloc[0, 0]
    last_updated_at = convert_utc_ts_to_local_tz(last_updated_at)
    return Output(
        value=last_updated_at,
        metadata={
            "Last Updated At": MetadataValue.text(str(last_updated_at)),
        },
    )


@asset_check(asset=oltp01__leadstatus_bd_master_heartbeat)
def oltp01__leadstatus_bd_master_freshness(
    last_updated_at: pd.Timestamp,
):
    minute_since_last_update = _find_diff(last_updated_at.replace(tzinfo=None))
    return AssetCheckResult(
        passed=minute_since_last_update < 45,
        metadata={
            "Minutes Since Last Update": MetadataValue.float(minute_since_last_update),
        },
    )


oltp01__leadstatus_bd_master_heartbeat = build_asset_with_blocking_check(
    oltp01__leadstatus_bd_master_heartbeat,
    checks=[oltp01__leadstatus_bd_master_freshness],
)


@op
def monitor_orchestrator_heartbeat_op(
    telebot_data: telegram.TelegramBot,
    telegram_chat: telegram.TelegramChat,
):
    chat_id = telegram_chat.get_id("ALERT")
    telebot_data.send_message(chat_id, "Orchestrator is still alive ...")


@graph
def monitor_orchestrator_heartbeat():
    monitor_orchestrator_heartbeat_op()


monitor_cl_fresh_freshness_job = define_asset_job(
    "monitor_cl_fresh_freshness_job",
    selection=AssetSelection.assets(
        oltp01__cl_fresh_heartbeat, oltp02__cl_fresh_heartbeat
    ),
)
monitor_orchestrator_heartbeat_job = monitor_orchestrator_heartbeat.to_job()
monitor_realtime_table_job = define_asset_job(
    "monitor_realtime_table_job",
    selection=AssetSelection.assets(
        oltp01__leadstatus_bd_master_heartbeat,
    ),
)


monitor_cl_fresh_freshness_schedule = ScheduleDefinition(
    job=monitor_cl_fresh_freshness_job,
    cron_schedule=[f"*/{HEARTBEAT_MONITOR_INTERVAL} 6-22/1 * * 1-5", "0 9,15 * * 0,6"],
    execution_timezone="Asia/Bangkok",
    tags={"dagster/priority": "3"},
)

monitor_orchestrator_heartbeat_schedule = ScheduleDefinition(
    job=monitor_orchestrator_heartbeat_job,
    cron_schedule="*/15 * * * *",
    execution_timezone="Asia/Bangkok",
    tags={"dagster/priority": "3"},
)
monitor_realtime_table_schedule = ScheduleDefinition(
    job=monitor_realtime_table_job,
    cron_schedule="*/15 * * * *",
    execution_timezone="Asia/Bangkok",
    tags={"dagster/priority": "3"},
)
