from dagster import asset, Config, define_asset_job, ScheduleDefinition, AssetSelection ##
from DagsFlow.assets.materialized_views import sale_master_k
from DagsFlow.assets.utls.func import extract_from_dwh
from DagsFlow.resources.postgres import PostgresConnection



# TH
class SaleReportTH(Config):
    io_format: str = "parquet"
    io_abs_path: str = r"Data team\Data Source - SALES\dataset_sale_report_TH.parquet"
    sql_query: str = "select * from sale_master_k where country_code = 'TH' "    


@asset(
    key_prefix=["sharepoint_dataset"],
    group_name="sharepoint_dataset",
    io_manager_key="dataneyu_storage",
    deps=[sale_master_k],
)
def Sale_reportTH(oltp01_conn: PostgresConnection, config: SaleReportTH):
    df = extract_from_dwh(config.sql_query, oltp01_conn, return_type="pandas")
    df = df.drop_duplicates()
    return df


sync_sale_report_TH_job = define_asset_job(
    name="sync_sale_report_TH_job",
    selection=AssetSelection.assets(Sale_reportTH),
)

sync_sale_report_TH_schedule = ScheduleDefinition(
    job=sync_sale_report_TH_job,
    cron_schedule="0 0 * * *",
    execution_timezone="Asia/Bangkok",
)
