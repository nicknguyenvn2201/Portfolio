from dataclasses import dataclass
import plotly.figure_factory as ff
import time
from threading import Thread
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
import psycopg2 as pg
import psycopg2.extras
import os  
from dagster import (
    asset,
    define_asset_job,
    ScheduleDefinition,
)
TIMEZONE = os.getenv("DAGSTER_TIMEZONE")


def convert(value):
    if pd.isnull(value):
        new = 0
    else:
        new = value
    return new


def catch_index_error(df):
    if len(df) == 0:
        return 0
    else:
        return df.iloc[0, 1]

def resell_vn():
    q = """
        -- BOT: Resell
        with today_resell as (
        select l.lead_id
        so_id,
        cf_so.name as so_status,
        date(oso.createdate) so_date,
        agent.fullname,
        cl_agent,
        assigned,
        case when lower(cl_agent) like '%tl%' then 'Fresh' 
            when lower(cl_agent) like '%cit2%' then 'CIT Ha Noi'
            when lower(cl_agent) like '%cit1%' or lower(cl_agent) like '%cit3%' then 'CIT HCM'
            else 'Others'
        end as team,
        coalesce(p.shortname,l.agc_code, 'LOYAL CUSTOMER') as sourcename,
        amount,
        cam."name" campaign,
        comment,
        oso.qa_note
        from od_sale_order oso
        left join (
            select lead_id,
                agc_id,
                agc_code,
                lead_type,
                cl.assigned,
                agent.fullname as cl_agent,
                comment
                --,agent_note as qa_note 
            from cl_fresh cl
            left join (
                select *
                from or_user ou
                where user_type = 'agent') as agent
            on cl.assigned = agent.user_id
            where lower(cl."name") not like '%test%'
            ) as l
        on oso.lead_id = l.lead_id
        left join (
            select *
            from cf_synonym cs
            where "type" = 'sale order status') as cf_so
        on oso.status = cf_so.value
        left join (
            select *
            from or_user ou
            where user_type = 'agent') as agent
        on oso.ag_id = agent.user_id
        left join bp_partner p on l.agc_id = p.pn_id
        left join cp_campaign cam on cam.cp_id = oso.cp_id
        where date(oso.createdate) = current_date
        and lead_type = 'M'
        and cf_so.name != 'cancel'
        and cam."name" not like 'Resell Cross HC Milk%'
        ),
        transform as (
        select *,
        case when substring(lower(sourcename),1,3) = 're_' then 'EXTERNAL' else 'INTERNAL' end as data_source,
--        case 
--        when lower(comment) like '%ycgl%' then 'unassigned' 
--        when lower(qa_note) like '%ycgl%' then 'unassigned'
--        else so_status end as finalorderstatus
        so_status as finalorderstatus
        from today_resell
        )
        select
        team,
        cl_agent,
        count(distinct case when data_source = 'INTERNAL' then so_id else null end) CIT,
        count(distinct case when data_source = 'EXTERNAL' then so_id else null end) CIT_RE,
        count(distinct so_id) TOTAL,
        round(sum(amount) / count(distinct so_id),0)::int as AOV,
        sum(amount)::int revenue
        from transform
        where lower(finalorderstatus) not in ('cancel', 'unassigned')
        group by team, cl_agent
        """
    q_dwh = """
-- BOT: Resell
        with today_resell as (
        select oso.geo, l.lead_id
        so_id,
        cf_so.name as so_status,
        date(oso.createdate) so_date,
        agent.fullname,
        cl_agent,
        assigned,
        case when oso.geo = 'VN2' and lower(agent) like 'resell%' then 'VN2 Fresh' 
        	when lower(agent) like '%tl%' then 'Fresh'
            when oso.geo = 'VN3' and lower(agent) like '%cit2%' then 'CIT Ha Noi'
            when oso.geo = 'VN3' and lower(agent) like '%cit1%' or lower(agent) like '%cit3%' or lower(agent) like '%cit4%' then 'CIT HCM'
            else 'Others'
        end as team,
        coalesce(p.shortname,l.agc_code, 'LOYAL CUSTOMER') as sourcename,
        amount,
        cam."name" campaign,
        comment,
        oso.qa_note
        from od_sale_order oso
        left join (
            select cl.geo,lead_id,
                agc_id,
                agc_code,
                lead_type,
                cl.assigned,
                agent.fullname as cl_agent,
        		agent.user_name as agent,
                comment
                --,agent_note as qa_note 
            from cl_fresh cl
            left join (
                select *
                from or_user ou
                where user_type = 'agent') as agent
            on cl.assigned = agent.user_id and cl.geo = agent.geo 
            	--and case when cl.geo = 'VN2' then 'VN' else cl.geo end = case when agent.geo = 'VN2' then 'VN' else agent.geo end
            where lower(cl."name") not like '%test%'
            ) as l
        on oso.lead_id = l.lead_id and oso.geo = l.geo
        	--and case when oso.geo = 'VN2' then 'VN' else oso.geo end = case when l.geo = 'VN2' then 'VN' else l.geo end
        left join (
            select *
            from cf_synonym cs
            where "type" = 'sale order status') as cf_so
        on oso.status = cf_so.value and oso.geo = cf_so.geo
        	--and case when oso.geo = 'VN2' then 'VN' else oso.geo end = case when cf_so.geo = 'VN2' then 'VN' else cf_so.geo end
        left join (
            select *
            from or_user ou
            where user_type = 'agent') as agent
        on oso.ag_id = agent.user_id and oso.geo = agent.geo
        	--and case when oso.geo = 'VN2' then 'VN' else oso.geo end = case when agent.geo = 'VN2' then 'VN' else agent.geo end
        left join bp_partner p on l.agc_id = p.pn_id and l.geo = p.geo
        	--and case when l.geo = 'VN2' then 'VN' else l.geo end = case when p.geo = 'VN2' then 'VN' else p.geo end
        left join cp_campaign cam on cam.cp_id = oso.cp_id and cam.geo = oso.geo
        	--and case when cam.geo = 'VN2' then 'VN' else cam.geo end = case when oso.geo = 'VN2' then 'VN' else oso.geo end
        where date(oso.createdate) = current_date
        and 
        lead_type = 'M'
        and cf_so.name != 'cancel'
        and cam."name" not like 'Resell Cross HC Milk%'
        and oso.geo in ('VN3','VN2','VN')
--        and lower(cl_agent) like '%cit2%'
        )
        ,
        transform as (
        select *,
        case when substring(lower(sourcename),1,3) = 're_' then 'EXTERNAL' else 'INTERNAL' end as data_source,
--        case 
--        when lower(comment) like '%ycgl%' then 'unassigned' 
--        when lower(qa_note) like '%ycgl%' then 'unassigned'
--        else so_status end as finalorderstatus
        so_status as finalorderstatus
        from today_resell
        )
        select
        team,
        cl_agent,
        count(distinct case when data_source = 'INTERNAL' then so_id else null end) CIT,
        count(distinct case when data_source = 'EXTERNAL' then so_id else null end) CIT_RE,
        count(distinct so_id) TOTAL,
        round(sum(amount) / count(distinct so_id),0)::int as AOV,
        sum(amount)::int revenue
        from transform
        where lower(finalorderstatus) not in ('cancel', 'unassigned') --and team = 'CIT Ha Noi'
        group by team, cl_agent
        """
    # df = run_query(q, 'vn')
    conn = pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG"))
    cur = conn.cursor()
    df = pd.read_sql_query(q_dwh,conn)
    conn.commit()
    df["target"] = 7500000
    group = df.groupby("team")["revenue"].sum().reset_index()
    text = f"""*Total Resell:* {convert(df["revenue"].sum()):0,.0f}
    \n*CIT HCM:* {catch_index_error(group[group["team"] == 'CIT HCM']):0,.0f}
    \n*CIT Ha Noi:* {catch_index_error(group[group["team"] == 'CIT Ha Noi']):0,.0f}
    \n*Fresh:* {catch_index_error(group[group["team"] == 'Fresh']):0,.0f}
    \n*Fresh VN2:* {catch_index_error(group[group["team"] == 'VN2 Fresh']):0,.0f}
    """

    # HCM table
    hcm = df[df["team"].str.contains("HCM")].drop(["team"], axis=1)
    hcm.sort_values(by="revenue", ascending=False, inplace=True)
    hcm["% target"] = round((hcm["revenue"] / hcm["target"]) * 100, 1)
    hcm[["aov", "revenue", "target"]] = hcm[["aov", "revenue", "target"]].applymap(
        "{:,.0f}".format
    )
    fig_hcm = ff.create_table(hcm)
    fig_hcm.update_layout(
        title_text="CIT HCM", autosize=False, margin=dict(l=5, r=5, t=50, b=10)
    )

    # HN table
    hn = df[df["team"].str.contains("Ha Noi")].drop(["team"], axis=1)
    hn.sort_values(by="revenue", ascending=False, inplace=True)
    hn["target"] = np.where(hn["cl_agent"] == "agentcit203", 5000000, 7000000)
    hn["% target"] = round((hn["revenue"] / hn["target"]) * 100, 1)
    hn[["aov", "revenue", "target"]] = hn[["aov", "revenue", "target"]].applymap(
        "{:,.0f}".format
    )
    fig_hn = ff.create_table(hn)
    fig_hn.update_layout(
        title_text="CIT Ha Noi", autosize=False, margin=dict(l=5, r=5, t=50, b=10)
    )
    cur.close()
    conn.close()
    return (
        text,
        fig_hcm.write_image("resell_hcm.png", scale=3),
        fig_hn.write_image("resell_hn.png", scale=3),
    )

# -----------------------------------------------------------------------------------------------------------


@asset(group_name="alert_auto_bot")
def send_resell_vn():
    if int(datetime.now().strftime("%H")) in range(8, 24):
        try:
            text, _, _ = resell_vn()
            time.sleep(60)
            time.sleep(30)
        except Exception as e:
            print(f"the bot is facing with error: {e}")
            time.sleep(15)


###-------------------------------------------------------------------------------------------------------------------------------------------------------

@asset(group_name="alert_auto_bot")
def refresh_fulldata_leadstatus():
    try:
        print("Start refreshing...")
        print("Establishing connection to DWH...")
        conn = pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG"))
        cur = conn.cursor()
        cur.execute("SET statement_timeout = 0")
        conn.commit()
        print("REFRESH MATERIALIZED VIEW leadstatus_bd_master_fulldata")
        cur.execute("REFRESH MATERIALIZED VIEW leadstatus_bd_master_fulldata")
        conn.commit()
        print("Finish REFRESHING leadstatus_bd_master_fulldata")
        cur.close()
        conn.close()
        print("-Finish refreshing leadstatus_bd_master_fulldata")
    except Exception as e:
        time.sleep(15)
    return


# mkt_data_vn
def load_mkt_data_vn():
    q = f"""
        select lead_id, createdate, cust_name, cust_phone, cust_age, cust_gender, cust_job, geo
        from mkt_data
        where createdate::date >= '2022-01-01' and (cust_age is not null or cust_gender is not null)
        and geo in ('VN', 'VN2')
            """
    conn = pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG"))
    cur = conn.cursor()
    data = pd.read_sql_query(q,conn)
    conn.commit()
    cur.close()
    conn.close()
    return data

@asset(group_name="alert_auto_bot")
def insert_realtime_mkt_data_vn():
    while True:
        try:
            print("Start loading realtime_mkt_data_vn...")
            full_agg = load_mkt_data_vn()
            print("Finish loading realtime_mkt_data_vn...")
            full_agg = full_agg.fillna(np.nan).replace([np.nan], [None])
            print("establishing connection to DWH...")
            conn = pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG"))
            cur = conn.cursor()
            cur.execute("SET statement_timeout = 0")
            conn.commit()
            print("deleting data in mkt_data_vn...")
            cur.execute("delete from mkt_data_vn")
            conn.commit()
            df_columns = list(full_agg)
            columns = (
                str(df_columns).replace("'", '"').replace("[", "").replace("]", "")
            )
            values = "VALUES({})".format(",".join(["%s" for _ in df_columns]))
            insert_stmt = "INSERT INTO {} ({}) {}".format(
                "mkt_data_vn", columns, values
            )

            # create INSERT INTO table (columns) VALUES('%s',...)
            cur = conn.cursor()
            psycopg2.extras.execute_batch(cur, insert_stmt, full_agg.values)
            conn.commit()
            cur.close()
            conn.close()
            print("Done")
            # bot.send_message(chat_id, text="mkt_data_vn is updated!")
            break
        except Exception as e:
            print(f"The bot is facing with error: {e}")
            # bot.send_message(
            #     chat_id, text=f"the bot is facing with error: {e}"
            # )
            time.sleep(15)
    return


@asset(group_name="alert_auto_bot")
def refresh_leadstatus_bd_master():
    while True:
        try:
            print("Start refreshing...")
            # bot.send_message(chat_id, text="Start REFRESHING leadstatus_bd_master...")
            print("Establishing connection to DWH...")
            conn = pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG"))
            cur = conn.cursor()
            cur.execute("SET statement_timeout = 0")
            conn.commit()

            print("REFRESH MATERIALIZED VIEW leadstatus_bd_master")
            cur.execute("refresh materialized view CONCURRENTLY leadstatus_bd_master with data")
            conn.commit()
            print("Finish REFRESHING leadstatus_bd_master")


            cur.close()
            conn.close()

            print("-Finish refreshing leadstatus_bd_master")
            # bot.send_message(chat_id, text="-Finish refreshing leadstatus_bd_master!")
            break
        except Exception as e:
            # print(f"The bot is facing with error: {e}")
            # bot.send_message(
            #     chat_id, text=f"the bot is facing with error: {e}"
            # )
            continue
            time.sleep(15)

    return


@asset(group_name="alert_auto_bot")
def refresh_leadstatus_sale_master():
    while True:
        try:
            print("Start refreshing...")
            # bot.send_message(chat_id, text="Start refreshing leadstatus_sale_master...")
            print("Establishing connection to DWH...")
            conn = pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG"))
            cur = conn.cursor()
            cur.execute("SET statement_timeout = 0")
            conn.commit()

            print("Refreshing leadstatus_sale_master")
            cur.execute("REFRESH MATERIALIZED VIEW leadstatus_sale_master")
            conn.commit()

            print("Finish refreshing leadstatus_sale_master")
            cur.close()
            conn.close()

            # bot.send_message(chat_id, text="Finish refreshing leadstatus_sale_master!")

            # data_length = count_realtime_ls_sm()
            # data_length = data_length.iloc[0]["count"]
            # bot.send_message(chat_id, text="length = " + str(data_length))
            break
        except Exception as e:
            # print(f"The bot is facing with error: {e}")
            # bot.send_message(
            #     chat_id, text=f"the bot is facing with error: {e}"
            # )
            time.sleep(15)

    return

# -------------------------------------------------------**************---------------------------------------------------------------
# schedule
# schedule.every(30).minutes.do(send_resell_vn)
# schedule.every(30).minutes.do(insert_realtime_mkt_data_vn)
auto_bot_send_resell_vn_and_insert_realtime_mkt_data_vn_job = define_asset_job(
    "auto_bot_send_resell_vn_and_insert_realtime_mkt_data_vn_job",
    selection=[
        send_resell_vn,
        insert_realtime_mkt_data_vn,
    ],
)

auto_bot_send_resell_vn_and_insert_realtime_mkt_data_vn_schedule = ScheduleDefinition(
    job=auto_bot_send_resell_vn_and_insert_realtime_mkt_data_vn_job,
    cron_schedule="30 * * * *",
    execution_timezone=TIMEZONE,
)


#schedule
# schedule.every(10).minutes.do(refresh_leadstatus_bd_master)
auto_bot_refresh_leadstatus_bd_master_job = define_asset_job(
    "auto_bot_refresh_leadstatus_bd_master_job",
    selection=[
        refresh_leadstatus_bd_master,
    ],
)

auto_bot_refresh_leadstatus_bd_master_schedule = ScheduleDefinition(
    job=auto_bot_refresh_leadstatus_bd_master_job,
    cron_schedule="*/10 * * * *",
    execution_timezone=TIMEZONE,
)


#schedule
# schedule.every(15).minutes.do(refresh_leadstatus_sale_master)
auto_bot_refresh_leadstatus_sale_master_job = define_asset_job(
    "auto_bot_refresh_leadstatus_sale_master_job",
    selection=[
        refresh_leadstatus_sale_master,
    ],
)

auto_bot_refresh_leadstatus_sale_master_schedule = ScheduleDefinition(
    job=auto_bot_refresh_leadstatus_sale_master_job,
    cron_schedule="*/15 * * * *",
    execution_timezone=TIMEZONE,
)


#schedule
# schedule.every().day.at("10:00").do(refresh_fulldata_leadstatus)
auto_bot_refresh_fulldata_leadstatus_job = define_asset_job(
    "auto_bot_refresh_fulldata_leadstatus_job",
    selection=[
        refresh_fulldata_leadstatus,
    ],
)

auto_bot_refresh_fulldata_leadstatus_schedule = ScheduleDefinition(
    job=auto_bot_refresh_fulldata_leadstatus_job,
    cron_schedule="0 10 * * *",
    execution_timezone=TIMEZONE,
)


#schedule
# schedule.every().day.at("19:30").do(refresh_fulldata_leadstatus)
auto_bot_refresh_fulldata_leadstatus_job_01 = define_asset_job(
    "auto_bot_refresh_fulldata_leadstatus_job_01",
    selection=[
        refresh_fulldata_leadstatus,
    ],
)

auto_bot_refresh_fulldata_leadstatus_schedule_01 = ScheduleDefinition(
    job=auto_bot_refresh_fulldata_leadstatus_job_01,
    cron_schedule="30 19 * * *",
    execution_timezone=TIMEZONE,
)









