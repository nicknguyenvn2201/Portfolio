from dagster import asset, Config, define_asset_job, ScheduleDefinition, AssetSelection
from DagsFlow.assets.materialized_views import forecast_snapshots
from DagsFlow.assets.utls.func import extract_from_dwh
from DagsFlow.resources.postgres import PostgresConnection
from datetime import date
from datetime import timedelta

class geo_leadcost_tracking(Config):
    io_format: str = "parquet"
    io_abs_path: str = (
        r"Data team\Data Source - GLOBAL\dataset_geo_leadcost_tracking.parquet"
    )
    sql_query: str = "select * from forecast_snapshot"


@asset(
    key_prefix=["sharepoint_dataset"],
    group_name="sharepoint_dataset",
    io_manager_key="dataneyu_storage",
    deps=[forecast_snapshots]
)
def geo_leadcost_tracking(oltp01_conn: PostgresConnection, config: geo_leadcost_tracking):
    df = extract_from_dwh(config.sql_query, oltp01_conn, return_type="pandas")
    return df


sync_dataset_geo_leadcost_tracking_job = define_asset_job(
    name="sync_dataset_geo_leadcost_tracking_job",
    selection=AssetSelection.assets(geo_leadcost_tracking),
)

sync_dataset_geo_leadcost_tracking_job_schedule = ScheduleDefinition(
    job=sync_dataset_geo_leadcost_tracking_job,
    cron_schedule="15 6,8,11,13,15,17,19,21 * * *",
    execution_timezone="Asia/Bangkok",
)
