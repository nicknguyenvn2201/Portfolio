from dagster import (
    asset,
    AssetExecutionContext,
    MetadataValue,
    define_asset_job,
    ScheduleDefinition,
    get_dagster_logger,
    AssetsDefinition,
    MaterializeResult,
)
from DagsFlow.resources.postgres import PostgresConnection
from DagsFlow.assets.utls.sql import SqlStore
from DagsFlow.assets.utls.func import (
    check_if_table_exist_base_layer,
    get_table_indexes_base_layer,
)
from pathlib import Path
from typing import Optional, Iterable
from dagster._core.definitions.asset_dep import CoercibleToAssetDep

logger = get_dagster_logger()
PATH_TO_SQL_STORE = Path(__file__).parent / "materialized_view_sql"



def create_table_asset_cit_performance_report(
    schema_name: str,
    table_name: str,
    description: str = "",
    incremental_query: str = "",
    sql_store: SqlStore = SqlStore(PATH_TO_SQL_STORE),
    deps: Optional[Iterable[CoercibleToAssetDep]] = None,
):
    select_view_query = sql_store.get(table_name).render()
    view_name = f"_{table_name}"

    @asset(
        name=table_name,
        compute_kind="postgres",
        metadata={
            "View Name": MetadataValue.text(view_name),
            "Raw SQL": MetadataValue.md(
                f"""**Raw SQL:**
```
{select_view_query}
```
"""
            ),
        },
        group_name="data_sale_master",
        description=description,
        deps=deps,
    )
    def _asset(
        context: AssetExecutionContext,
        oltp01_conn: PostgresConnection,
    ) -> MaterializeResult:
        with oltp01_conn.get_connection() as connection:
            with connection.cursor() as cursor:
                is_table_exist = check_if_table_exist_base_layer(cursor, schema_name, table_name)
                create_view_query = (
                    f"""create or replace view {schema_name}.{view_name} as ({select_view_query})"""
                )
                cursor.execute(create_view_query)
                logger.info("Staging view created or replaced")
                if is_table_exist:
                    logger.info("Table found. Deleting and inserting new data...")
                    delete_query = f"""delete from {schema_name}.{table_name}"""
                    cursor.execute(delete_query)
                    logger.info("Completed deleting old data")
                    indexes = get_table_indexes_base_layer(cursor, schema_name, table_name)
                    for index_name, index_def in indexes:
                        cursor.execute(f'drop index "{index_name}"')
                    logger.info("Dropped all indexes for better insertion")
                else:
                    logger.info("Table not found. Creating and inserting new data...")
                    create_table_query = (
                        f"""create table {schema_name}.{table_name} as select * from {schema_name}.{view_name}"""
                    )
                    cursor.execute(create_table_query)
                insert_query = f"""insert into {schema_name}.{table_name} select * from {schema_name}.{view_name}"""
                cursor.execute(insert_query)
                logger.info("Completed inserting new data")
                if is_table_exist:
                    for index_name, index_def in indexes:
                        cursor.execute(index_def)
                    logger.info("Completed recreating indexes")
                row_count = cursor.execute(
                    f"""select count(*) from {schema_name}.{table_name}"""
                ).fetchone()[0]
        return MaterializeResult(
            metadata={
                "Row Count": MetadataValue.int(int(row_count)),
            }
        )

    return _asset

def create_schedule_cit_performance_report(
    assets: list[AssetsDefinition], schedules: list[str], name: str = None
) -> ScheduleDefinition:
    if not name:
        name = str(assets[0].key[0][0])
    asset_job = define_asset_job(
        name="data_" + name + "_job",
        selection=assets,
    )
    return ScheduleDefinition(
        job=asset_job,
        name="data_" + name + "_schedule",
        cron_schedule=schedules,
        execution_timezone="Asia/Bangkok",
    )

data_cit_performance_report_job = create_table_asset_cit_performance_report(
    "dareport","cit_performance_report")

data_cit_performance_report_schedule = create_schedule_cit_performance_report(
    [data_cit_performance_report_job],
    ["0 5,7 * * *"],
    "cit_performance_report",
)


