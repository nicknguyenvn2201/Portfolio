from dagster import (
    asset,
    Output,
    AssetExecutionContext,
    MetadataValue,
    DailyPartitionsDefinition,
    get_dagster_logger,
    schedule,
    define_asset_job,
    ScheduleEvaluationContext,
    RunRequest,
    StaticPartitionsDefinition,
    MultiPartitionsDefinition,
    MultiPartitionKey,
)
import os
import psycopg as pg
import io
import requests as rq
import pandas as pd
from datetime import timedelta, date
import itertools
from DagsFlow.resources import telegram
from DagsFlow.assets.utls import func

logger = get_dagster_logger()
TIMEZONE = os.getenv("DAGSTER_TIMEZONE")
TARGET_TABLE = "dim_exchange_rate_test"

# Định nghĩa các phân vùng
daily_partitions_def = DailyPartitionsDefinition(
    start_date=str(date.today() - timedelta(days=25))[0:10],  # 30 ngày trước
    end_offset=1,
)
currency_partitions_def = StaticPartitionsDefinition(
    ["VND", "THB", "IDR", "MYR", "PHP", "INR"]
)
multi_partitions_def = MultiPartitionsDefinition(
    {"date": daily_partitions_def, "currency": currency_partitions_def}
)

def send_telegram_alert(message, token, chat_id):
    url = f'https://api.telegram.org/bot{token}/sendMessage'
    payload = {'chat_id': chat_id, 'text': message}
    response = rq.post(url, data=payload)
    return response.json()

@asset(partitions_def=multi_partitions_def)
def extract_exchange_rate_data_test(context: AssetExecutionContext) -> Output[pd.DataFrame]:
    currency, exchange_date = context.partition_key.split("|")
    logger.info(f"Querying exchange data on {exchange_date}")
    query_endpoint = f"http://api.exchangeratesapi.io/v1/{exchange_date}"
    params = {
        "access_key": "f758bfa2370fe2b5f1343ba17935492b",
        "symbols": "USD," + currency,
    }
    json_response = rq.get(query_endpoint, params=params).json()
    logger.info(json_response)
    df = pd.json_normalize(json_response["rates"]).transpose()
    usd_exchange_rate = df.loc[["USD"]][0][0]
    df["geo"] = df.index.str[:2]
    df["exchange"] = df[0] / usd_exchange_rate
    df["started_date"] = exchange_date
    df["ending_date"] = pd.to_datetime(exchange_date) + timedelta(days=180) if exchange_date == date.today().strftime("%Y-%m-%d") else exchange_date
    df = df[["geo", "exchange", "started_date", "ending_date"]].loc[[currency]]
    return Output(
        value=df,
        metadata={
            "Exchange Rate": MetadataValue.float(df["exchange"][0]),
        },
    )

@asset(partitions_def=multi_partitions_def, compute_kind="postgres")
def validate_and_load_data(
    context: AssetExecutionContext,
    extract_exchange_rate_data_test: pd.DataFrame,
    telebot_data: telegram.TelegramBot,
    telegram_chat: telegram.TelegramChat,
) -> None:
    chat_id = telegram_chat.get_id("BI_TEAM")
    df = extract_exchange_rate_data_test
    # data = {
    # 'geo': ['VND', 'THB', 'IDR', 'MYR', 'PHP'],
    # 'exchange': [11110.85455665, 1333330.7545678, 444110.5045678, 444446.503456, 5555582.002345678],
    # 'started_date': ['2021-09-12 00:00:00.000', '2021-09-12 00:00:00.000', '2021-09-12 00:00:00.000', '2021-09-12 00:00:00.000', '2021-09-12 00:00:00.000'],
    # 'ending_date': ['2025-03-11 00:00:00.000', '2025-03-11 00:00:00.000', '2025-03-11 00:00:00.000', '2025-03-11 00:00:00.000', '2025-03-11 00:00:00.000']
    # }
    # df = pd.DataFrame(data)
    currency, exchange_date = context.partition_key.split("|")
    geo = currency[:2]
    new_exchange = df["exchange"].values[0]
    
    df['ending_date'] = pd.to_datetime(df['ending_date'])
    
    with pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG")) as connection:
        query = f"""
        SELECT exchange, ending_date
        FROM {TARGET_TABLE}
        WHERE geo = '{geo}' AND ending_date <= '{exchange_date}'
        AND ending_date > '{pd.to_datetime(exchange_date) - timedelta(days=30)}'
        """
        old_data = pd.read_sql(query, connection)
    
    if old_data.empty:
        df.to_sql(TARGET_TABLE, con=connection, if_exists='append', index=False)
        logger.info("Data added successfully.")
        return

    ave = old_data['exchange'].mean()
    lower_bound = ave - 0.3 * ave
    upper_bound = ave + 0.3 * ave
    print('-------------------------------------------------------------------------------------')
    print(ave)
    print('-------------------------------------------------------------------------------------')
    print(lower_bound)
    print('-------------------------------------------------------------------------------------')
    print(upper_bound)
    print('-------------------------------------------------------------------------------------')

    if not (lower_bound <= new_exchange <= upper_bound):
        message = (f"Alert: New exchange rate ({new_exchange}) for {geo} is out of bounds "
                   f"({lower_bound} to {upper_bound}). Job failed.")
        telebot_data.send_message(chat_id, message)
        logger.error(message)
        raise Exception(message)
    else:
        with pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG")) as connection:
            with connection.cursor() as cursor:
                cursor.execute(
                    f"""delete from {TARGET_TABLE} where started_date = '{exchange_date}' and geo = '{geo}'"""
                )
                buffer = io.BytesIO()
                df.to_csv(buffer, index=False, encoding="utf-8")
                buffer.seek(0)
                with cursor.copy(f"COPY {TARGET_TABLE} FROM STDIN WITH CSV HEADER") as copy:
                    copy.write(buffer.read())
                func.check_duplicate_date_range_postgres(
                    cursor, f"{TARGET_TABLE}", "started_date", "ending_date", "geo"
                )
                logger.info("Data added successfully.")

refresh_exchange_rate_data_test_job = define_asset_job(
    "refresh_exchange_rate_data_test_job",
    selection=[extract_exchange_rate_data_test, validate_and_load_data],
    partitions_def=multi_partitions_def,
)

@schedule(
    job=refresh_exchange_rate_data_test_job,
    cron_schedule="0 9 * * *",
    execution_timezone=TIMEZONE,
)
def refresh_exchange_rate_data_test_schedule_yesterday(context: ScheduleEvaluationContext):
    currencies = currency_partitions_def.get_partition_keys()
    latest_dates = daily_partitions_def.get_partition_keys()[-2:-1]
    partitions = itertools.product(currencies, latest_dates)
    for partition in partitions:
        curr, dte = partition
        run_key = "|".join(partition)
        yield RunRequest(
            run_key=run_key,
            tags=multi_partitions_def.get_tags_for_partition_key(
                MultiPartitionKey({"partition/date": dte, "partition/currency": curr})
            ),
        )

@schedule(
    job=refresh_exchange_rate_data_test_job,
    cron_schedule="15 9 * * *",
    execution_timezone=TIMEZONE,
)
def refresh_exchange_rate_data_schedule_test_today(context: ScheduleEvaluationContext):
    currencies = currency_partitions_def.get_partition_keys()
    latest_dates = daily_partitions_def.get_partition_keys()[-1:]
    partitions = itertools.product(currencies, latest_dates)
    for partition in partitions:
        curr, dte = partition
        run_key = "|".join(partition)
        yield RunRequest(
            run_key=run_key,
            tags=multi_partitions_def.get_tags_for_partition_key(
                MultiPartitionKey({"partition/date": dte, "partition/currency": curr})
            ),
        )
