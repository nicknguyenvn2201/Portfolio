from dagster import (
    file_relative_path,
    get_dagster_logger,
    asset,
    AssetExecutionContext,
    MetadataValue,
    Config,
    define_asset_job,
    AssetSelection,
)
from pathlib import Path
import pandas as pd
from DagsFlow.resources.pbiservice import PBIClient
from DagsFlow.resources.msgraph import MSSiteClient
import io
import pytz
from datetime import datetime, time, date
from typing import Iterator, Optional
from dateutil.relativedelta import relativedelta, MO, TU, WE, TH, FR, SA, SU
from pydantic import Field

logger = get_dagster_logger()

shell_folder_path = Path(file_relative_path(__file__, "./shell_scripts"))


SOURCE_TIMEZONE = pytz.utc  # Source timezone (UTC)
TIMEZONE = pytz.timezone("Asia/Bangkok")  # Desired timezone (SE Asia Standard Time)


class PbiConfig(Config):
    io_format: str = "csv"


def _break_links_into_ids(links: Iterator[str]) -> Iterator[tuple[str, str]]:
    """
    Must be in format: https://app.powerbi.com/groups/<workspace_id>/reports/<report_id/whatever-dont-care
    """
    for link in links:
        url_components = link[8:].split("/")
        yield url_components[2], url_components[4]


def _convert_timezone(refresh_time: str) -> datetime:
    try:
        refresh = datetime.strptime(refresh_time, "%Y-%m-%dT%H:%M:%S.%fZ")
    except ValueError:
        refresh = datetime.strptime(refresh_time, "%Y-%m-%dT%H:%M:%SZ")
    refresh = SOURCE_TIMEZONE.localize(refresh)
    refresh = refresh.astimezone(TIMEZONE)
    refresh = refresh.strftime("%Y-%m-%d %H:%M:%S")
    return refresh


def _find_next_refresh_time(refresh_schedule: dict):
    # change weekday to number to compare
    weekday_to_number = {
        "Monday": 0,
        "Tuesday": 1,
        "Wednesday": 2,
        "Thursday": 3,
        "Friday": 4,
        "Saturday": 5,
        "Sunday": 6,
    }
    weekday_to_rel_date = {
        "Monday": MO,
        "Tuesday": TU,
        "Wednesday": WE,
        "Thursday": TH,
        "Friday": FR,
        "Saturday": SA,
        "Sunday": SU,
    }
    weekdays = refresh_schedule["days"]
    refresh_times = refresh_schedule["times"]
    current_day_number = datetime.now().weekday()
    current_time = datetime.now().strftime("%H:%M")
    weekday_numbers = [weekday_to_number[day] for day in weekdays]
    max_day_number = max(weekday_numbers)
    # change time to hour type
    current_time = datetime.strptime(current_time, "%H:%M")
    refresh_times: list[datetime] = [
        datetime.strptime(hour, "%H:%M") for hour in refresh_times
    ]
    refresh_times.sort()
    next_refresh_time = None

    # compare weekday first

    # if current day is greater than max weekday, revert back to min weekday and min hour
    if current_day_number > max_day_number:
        next_day_number = min(weekday_numbers)
        next_refresh_time = refresh_times[0]
        next_day = [
            day
            for day, number in weekday_to_number.items()
            if number == next_day_number
        ][0]
        return next_day, next_refresh_time.strftime("%H:%M")
    # else, compare to get the next weekday
    else:
        next_day_number = min(
            filter(lambda x: x >= current_day_number, weekday_numbers)
        )

    # compare hour
    for refresh_time in refresh_times:
        if current_time <= refresh_time:
            next_refresh_time = refresh_time
            break

    # if current time is greater than next refresh time within current day --> next_fresh_time is None --> get the next weekday in weekday_numbers, or revert back to min weekday
    if next_refresh_time is None:
        next_refresh_time = refresh_times[0]
        try:
            next_day_number = min(
                filter(lambda x: x > current_day_number, weekday_numbers)
            )
        except ValueError:
            next_day_number = min(weekday_numbers)

    next_day = [
        day for day, number in weekday_to_number.items() if number == next_day_number
    ][0]

    return datetime.combine(
        date.today() + relativedelta(weekday=weekday_to_rel_date[next_day]),
        time(hour=next_refresh_time.hour, minute=next_refresh_time.minute),
    )


def _find_last_refresh_time(refresh_history: dict) -> Optional[datetime]:
    if not refresh_history:
        return None
    last_refresh = max(
        refresh_history,
        key=lambda refresh: refresh["startTime"]
        if "endTime" not in refresh
        else refresh["endTime"],
    )
    last_refresh = (
        last_refresh["startTime"]
        if "endTime" not in last_refresh
        else last_refresh["endTime"]
    )
    last_refresh = _convert_timezone(last_refresh)
    return last_refresh


def _find_last_successful_refresh_time(refresh_history: dict) -> Optional[datetime]:
    if not refresh_history:
        return None
    successful_refresh = list(
        filter(lambda event: event["status"] == "Completed", refresh_history)
    )
    if not successful_refresh:
        return None
    successful_refresh = max(
        successful_refresh,
        key=lambda refresh: refresh["endTime"],
    )["endTime"]
    successful_refresh = _convert_timezone(successful_refresh)
    return successful_refresh


def _find_last_failed_refresh_time(refresh_history: dict) -> Optional[datetime]:
    if not refresh_history:
        return None
    failed_refresh = list(
        filter(lambda event: event["status"] == "Failed", refresh_history)
    )
    if not failed_refresh:
        return None
    failed_refresh = max(
        failed_refresh,
        key=lambda refresh: refresh["endTime"],
    )["endTime"]
    failed_refresh = _convert_timezone(failed_refresh)
    return failed_refresh


@asset(io_manager_key="dataneyu_storage")
def pbi_refresh_statistics(
    context: AssetExecutionContext,
    pbiclient: PBIClient,
    config: PbiConfig,
) -> pd.DataFrame:
    result = []
    workspaces = pbiclient.get_all_workspaces()
    for workspace in workspaces:
        workspace_id = workspace["id"]
        workspace_name = workspace["name"]
        if workspace_name in {"Admin monitoring"}:
            continue
        reports = pbiclient.get_reports_in_workspace(workspace_id)
        for report in reports:
            report_name = report["name"]
            dataset_id = report["datasetId"]
            logger.info(
                f"Processing report {report_name} in workspace {workspace_name}"
            )
            dataset = pbiclient.get_dataset_in_workspace(workspace_id, dataset_id)
            if not dataset["isRefreshable"]:
                logger.warn(f"Report is not refreshable. Skipping...")
                continue
            refresh_schedule = pbiclient.get_refresh_schedule(dataset_id)
            refresh_history = pbiclient.get_refresh_history(dataset_id, top=10)
            last_refresh = _find_last_refresh_time(refresh_history)
            successful_refresh = _find_last_successful_refresh_time(refresh_history)
            failed_refresh = _find_last_failed_refresh_time(refresh_history)
            if (
                refresh_schedule["enabled"]
                and refresh_schedule["times"]
                and refresh_schedule["days"]
            ):
                next_refresh = _find_next_refresh_time(refresh_schedule)
            else:
                logger.warn(f"Schedule is not enabled. Skipping...")
                next_refresh = None
            row_result = {
                "Workspace Name": workspace_name,
                "Report Title": report_name,
                "Report URL": report["webUrl"],
                "Time Zone": refresh_schedule["localTimeZoneId"],
                "Last Refresh": last_refresh,
                "Successful Refresh": successful_refresh,
                "Failed Refresh": failed_refresh,
                "Next Refresh": next_refresh,
            }
            result.append(row_result)
    df = pd.DataFrame(result)
    context.add_output_metadata(
        metadata={"Table": MetadataValue.md(df.to_markdown(index=False))}
    )
    return df


@asset
def process_pbi_stats(
    context: AssetExecutionContext,
    pbi_refresh_statistics: pd.DataFrame,
    config: PbiConfig,
) -> None:
    context.log.info(len(pbi_refresh_statistics))


gather_pbi_refresh_statistics_job = define_asset_job(
    name="gather_pbi_refresh_statistics_job",
    selection=AssetSelection.assets(pbi_refresh_statistics),
)
