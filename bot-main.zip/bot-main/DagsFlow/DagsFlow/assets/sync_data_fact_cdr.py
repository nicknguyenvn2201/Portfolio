import pandas as pd
import os
from dagster import (
    Config,
    get_dagster_logger,
    asset,
    AssetExecutionContext,
    MetadataValue,
    define_asset_job,
    DailyPartitionsDefinition,
    ScheduleDefinition,
    AssetSelection
)
import io
import psycopg as pg
from DagsFlow.assets.utls import func
from typing import Iterator
import requests as rq
from datetime import date
from datetime import timedelta
from pandas import DataFrame
import pyarrow as pa
from DagsFlow.assets.utls.func import (
    add_blocking_checks_to_asset,
    create_load_to_postgres_asset_db_master,
    create_download_from_sharepoint_asset_base_layer,
)

logger = get_dagster_logger()


class config_data_fact_cdr(Config):
    sql_query_delete: str = '''DELETE FROM dareport.fact_cdr
                                WHERE createtime >= CURRENT_DATE - 1;'''


@asset(group_name="data_fact_cdr")
def truncate_old_data_fact_cdr(config: config_data_fact_cdr):
    conn_details = pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG"))
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_delete)
    conn_details.commit()
    cursor.close()
    conn_details.close()


@asset(group_name="data_fact_cdr", deps=[truncate_old_data_fact_cdr])
def load_data_fact_cdr(context: AssetExecutionContext) -> None:
    target_table='"dareport"."data_fact_cdr"'
    templater = func.SqlStore()
    with pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG")) as connection:
        with connection.cursor() as cursor:
            insert_statement = templater.get("insert_data_fact_cdr").render()
            logger.info("Start inserting into target table")
            cursor.execute(insert_statement)
            logger.info("Completed inserting into target table")


sync_data_fact_cdr = define_asset_job(
    name="sync_data_fact_cdr",
    selection=AssetSelection.groups("data_fact_cdr"),
)

sync_data_fact_cdr_schedule = ScheduleDefinition(
    job=sync_data_fact_cdr,
    cron_schedule= "0 */6 * * *", 
    execution_timezone="Asia/Bangkok",
)


