from dagster import (
    asset,
    Output,
    AssetExecutionContext,
    MetadataValue,
    DailyPartitionsDefinition,
    get_dagster_logger,
    schedule,
    define_asset_job,
    ScheduleEvaluationContext,
    RunRequest,
    StaticPartitionsDefinition,
    MultiPartitionsDefinition,
    MultiPartitionKey,
)
import os
from pyarrow import Table
import psycopg as pg
from typing import Union
import io
import requests as rq
import pandas as pd
import os
from datetime import timedelta, date, datetime
import pytz
from DagsFlow.assets.utls import func
import itertools

logger = get_dagster_logger()
TIMEZONE = os.getenv("DAGSTER_TIMEZONE")
TARGET_TABLE = '"base_layer"."dim_exchange_rate"'
daily_partitions_def = DailyPartitionsDefinition(
    start_date="2023-08-19",
    end_offset=1,
)
currency_partitions_def = StaticPartitionsDefinition(
    ["VND", "THB", "IDR", "MYR", "PHP"]
)
multi_partitions_def = MultiPartitionsDefinition(
    {"date": daily_partitions_def, "currency": currency_partitions_def}
)


@asset(partitions_def=multi_partitions_def)
def extract_exchange_rate_data_base_layer(context: AssetExecutionContext) -> Output[pd.DataFrame]:
    """
    Endpoint: http://api.exchangeratesapi.io/v1/{endpoint}

    Documentation: https://exchangeratesapi.io/documentation/
    """
    currency, exchange_date = context.partition_key.split("|")
    logger.info(f"Querying exchange data on {exchange_date}")
    query_endpoint = f"http://api.exchangeratesapi.io/v1/{exchange_date}"
    params = {
        "access_key": "f758bfa2370fe2b5f1343ba17935492b",
        "symbols": "USD," + currency,
    }
    json_response = rq.get(
        query_endpoint,
        params=params,
    ).json()
    logger.info(json_response)
    df = pd.json_normalize(json_response["rates"])
    df = df.transpose()
    usd_exchange_rate = df.loc[["USD"]][0][0]
    df["geo"] = df.index.str[:2]
    df["exchange"] = df[0] / usd_exchange_rate
    df["started_date"] = exchange_date
    if exchange_date == date.today().strftime("%Y-%m-%d"):
        df["ending_date"] = pd.to_datetime(exchange_date) + timedelta(days=180)
    else:
        df["ending_date"] = exchange_date
    df = df[
        [
            "geo",
            "exchange",
            "started_date",
            "ending_date",
        ]
    ].loc[[currency]]
    print(df)
    return Output(
        value=df,
        metadata={
            "Exchange Rate": MetadataValue.float(df["exchange"][0]),
        },
    )


@asset(partitions_def=multi_partitions_def, compute_kind="postgres")
def load_exchange_rate_data_base_layer(
    context: AssetExecutionContext,
    extract_exchange_rate_data_base_layer: pd.DataFrame,
) -> None:
    df = extract_exchange_rate_data_base_layer
    currency, exchange_date = context.partition_key.split("|")
    geo = currency[:2]
    with pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG_DB_MASTER")) as connection:
        with connection.cursor() as cursor:
            cursor.execute(
                f"""delete from {TARGET_TABLE} where started_date = '{exchange_date}' and geo = '{geo}'"""
            )
            buffer = io.BytesIO()
            df.to_csv(buffer, index=False, encoding="utf-8")
            buffer.seek(0)
            with cursor.copy(f"COPY {TARGET_TABLE} FROM STDIN WITH CSV HEADER") as copy:
                copy.write(buffer.read())
            func.check_duplicate_date_range_postgres(
                cursor, f"{TARGET_TABLE}", "started_date", "ending_date", "geo"
            )


refresh_exchange_rate_data_job_base_layer = define_asset_job(
    "refresh_exchange_rate_data_job_base_layer",
    selection=[extract_exchange_rate_data_base_layer, load_exchange_rate_data_base_layer],
    partitions_def=multi_partitions_def,
)


@schedule(
    job=refresh_exchange_rate_data_job_base_layer,
    cron_schedule="10 0 * * *",  # cron_schedule="0 9 * * *"
    execution_timezone=TIMEZONE,
)
def refresh_exchange_rate_data_schedule_yesterday_base_layer(context: ScheduleEvaluationContext):
    currencies = currency_partitions_def.get_partition_keys()
    latest_dates = daily_partitions_def.get_partition_keys()[-2:-1]
    partitions = itertools.product(currencies, latest_dates)
    for partition in partitions:
        curr, dte = partition
        run_key = "|".join(partition)
        yield RunRequest(
            run_key=run_key,
            tags=multi_partitions_def.get_tags_for_partition_key(
                MultiPartitionKey({"partition/date": dte, "partition/currency": curr})
            ),
        )


@schedule(
    job=refresh_exchange_rate_data_job_base_layer,
    cron_schedule="25 0 * * *", # cron_schedule="15 9 * * *"
    execution_timezone=TIMEZONE,
)
def refresh_exchange_rate_data_schedule_today_base_layer(context: ScheduleEvaluationContext):
    currencies = currency_partitions_def.get_partition_keys()
    latest_dates = daily_partitions_def.get_partition_keys()[-1:]
    partitions = itertools.product(currencies, latest_dates)
    for partition in partitions:
        curr, dte = partition
        run_key = "|".join(partition)
        yield RunRequest(
            run_key=run_key,
            tags=multi_partitions_def.get_tags_for_partition_key(
                MultiPartitionKey({"partition/date": dte, "partition/currency": curr})
            ),
        )
