from dagster import (
    asset,
    AssetExecutionContext,
    MetadataValue,
    define_asset_job,
    ScheduleDefinition,
    get_dagster_logger,
    AssetsDefinition,
    MaterializeResult,
    schedule, ResourceDefinition, Field, op, job,ConfigurableResource
)
import threading
import psycopg as pg
from DagsFlow.resources.postgres import PostgresConnection
from DagsFlow.assets.utls.sql import SqlStore
from DagsFlow.assets.utls.func import (
    check_if_table_exists,
    get_table_indexes,
)
from DagsFlow.assets import user_input as user_input_assets
from DagsFlow.assets.affscale_api import ods_affscale_conversion
from DagsFlow.assets.pub_ads_roi import load_pub_ads_roi_to_postgres
from DagsFlow.assets.exchangerate_api import load_exchange_rate_data
from pathlib import Path
from typing import Optional, Iterable,List
from dagster._core.definitions.asset_dep import CoercibleToAssetDep

logger = get_dagster_logger()
PATH_TO_SQL_STORE = Path(__file__).parent / "materialized_view_sql"


def _refresh_materialize_view(
    cursor: pg.Cursor, view_name: str, with_data: bool = False
) -> int:
    if with_data:
        sql_refresh = f"""
refresh materialized view concurrently {view_name} with data
"""
    else:
        sql_refresh = f"""
refresh materialized view {view_name}
"""
    sql_count = f"""
select count(*) from {view_name}
"""
    logger.info(f"Refreshing materialized view {view_name}")
    cursor.execute(sql_refresh)
    logger.info(f"Completed refreshing materialized view {view_name}")
    row_count = cursor.execute(sql_count).fetchone()[0]
    return int(row_count)


def create_refreshable_table_asset(
    table_name: str,
    description: str = "",
    incremental_query: str = "",
    sql_store: SqlStore = SqlStore(PATH_TO_SQL_STORE),
    deps: Optional[Iterable[CoercibleToAssetDep]] = None,
):
    select_view_query = sql_store.get(table_name).render()
    view_name = f"_dagster_staging__{table_name}"

    @asset(
        name=table_name,
        compute_kind="postgres",
        metadata={
            "View Name": MetadataValue.text(view_name),
            "Raw SQL": MetadataValue.md(
                f"""**Raw SQL:**
```
{select_view_query}
```
"""
            ),
        },
        group_name="pg_materialized_view",
        description=description,
        deps=deps,
    )
    def _asset(
        context: AssetExecutionContext,
        oltp01_conn: PostgresConnection,
    ) -> MaterializeResult:
        with oltp01_conn.get_connection() as connection:
            with connection.cursor() as cursor:
                is_table_exist = check_if_table_exists(cursor, table_name)
                create_view_query = (
                    f"""create or replace view {view_name} as ({select_view_query})"""
                )
                cursor.execute(create_view_query)
                logger.info("Staging view created or replaced")
                if is_table_exist:
                    logger.info("Table found. Deleting and inserting new data...")
                    delete_query = f"""delete from {table_name}"""
                    cursor.execute(delete_query)
                    logger.info("Completed deleting old data")
                    indexes = get_table_indexes(cursor, table_name)
                    for index_name, index_def in indexes:
                        cursor.execute(f'drop index "{index_name}"')
                    logger.info("Dropped all indexes for better insertion")
                else:
                    logger.info("Table not found. Creating and inserting new data...")
                    create_table_query = (
                        f"""create table {table_name} as select * from {view_name}"""
                    )
                    cursor.execute(create_table_query)
                insert_query = f"""insert into {table_name} select * from {view_name}"""
                cursor.execute(insert_query)
                logger.info("Completed inserting new data")
                if is_table_exist:
                    for index_name, index_def in indexes:
                        cursor.execute(index_def)
                    logger.info("Completed recreating indexes")
                row_count = cursor.execute(
                    f"""select count(*) from {table_name}"""
                ).fetchone()[0]
        return MaterializeResult(
            metadata={
                "Row Count": MetadataValue.int(int(row_count)),
            }
        )

    return _asset


def create_refreshable_table_asset_db_master(
    table_name: str,
    description: str = "",
    incremental_query: str = "",
    sql_store: SqlStore = SqlStore(PATH_TO_SQL_STORE),
    deps: Optional[Iterable[CoercibleToAssetDep]] = None,
):
    select_view_query = sql_store.get(table_name).render()
    view_name = f"_dagster_staging__{table_name}"

    @asset(
        name=table_name,
        compute_kind="postgres",
        metadata={
            "View Name": MetadataValue.text(view_name),
            "Raw SQL": MetadataValue.md(
                f"""**Raw SQL:**
```
{select_view_query}
```
"""
            ),
        },
        group_name="pg_materialized_view",
        description=description,
        deps=deps,
    )
    def _asset(
        context: AssetExecutionContext,
        oltp03_conn: PostgresConnection,
    ) -> MaterializeResult:
        with oltp03_conn.get_connection() as connection:
            with connection.cursor() as cursor:
                is_table_exist = check_if_table_exists(cursor, table_name)
                create_view_query = (
                    f"""create or replace view {view_name} as ({select_view_query})"""
                )
                cursor.execute(create_view_query)
                logger.info("Staging view created or replaced")
                if is_table_exist:
                    logger.info("Table found. Deleting and inserting new data...")
                    delete_query = f"""delete from {table_name}"""
                    cursor.execute(delete_query)
                    logger.info("Completed deleting old data")
                    indexes = get_table_indexes(cursor, table_name)
                    for index_name, index_def in indexes:
                        cursor.execute(f'drop index "{index_name}"')
                    logger.info("Dropped all indexes for better insertion")
                else:
                    logger.info("Table not found. Creating and inserting new data...")
                    create_table_query = (
                        f"""create table {table_name} as select * from {view_name}"""
                    )
                    cursor.execute(create_table_query)
                insert_query = f"""insert into {table_name} select * from {view_name}"""
                cursor.execute(insert_query)
                logger.info("Completed inserting new data")
                if is_table_exist:
                    for index_name, index_def in indexes:
                        cursor.execute(index_def)
                    logger.info("Completed recreating indexes")
                row_count = cursor.execute(
                    f"""select count(*) from {table_name}"""
                ).fetchone()[0]
        return MaterializeResult(
            metadata={
                "Row Count": MetadataValue.int(int(row_count)),
            }
        )

    return _asset


def create_refresh_mv_asset(
    materialized_view_name: str,
    asset_name: str = None,
    with_data: bool = False,
    deps: Optional[Iterable[CoercibleToAssetDep]] = None,
):
    @asset(
        name=f"materialized_view_{asset_name or materialized_view_name}",
        compute_kind="postgres",
        group_name="pg_materialized_view",
        deps=deps,
    )
    def _asset(context: AssetExecutionContext, oltp01_conn: PostgresConnection):
        with oltp01_conn.get_connection() as connection:
            with connection.cursor() as cursor:
                row_count = _refresh_materialize_view(
                    cursor, materialized_view_name, with_data
                )
                context.add_output_metadata({"Row Count": MetadataValue.int(row_count)})

    return _asset


def create_refresh_mv_asset_db_master(
    materialized_view_name: str,
    asset_name: str = None,
    with_data: bool = False,
    deps: Optional[Iterable[CoercibleToAssetDep]] = None,
):
    @asset(
        name=f"materialized_view_{asset_name or materialized_view_name}",
        compute_kind="postgres",
        group_name="pg_materialized_view",
        deps=deps,
    )
    def _asset(context: AssetExecutionContext, oltp03_conn: PostgresConnection):
        with oltp03_conn.get_connection() as connection:
            with connection.cursor() as cursor:
                row_count = _refresh_materialize_view(
                    cursor, materialized_view_name, with_data
                )
                context.add_output_metadata({"Row Count": MetadataValue.int(row_count)})

    return _asset

def create_refresh_schedule(
    assets: list[AssetsDefinition], 
    schedules: list[str], 
    name: str = None
) -> ScheduleDefinition:
    # Set the name if not provided
    if not name:
        name = str(assets[0].key[0][0])

    # Define the asset job based on the provided assets
    asset_job = define_asset_job(
        name="refresh_" + name + "_job",
        selection=assets
    )

    # Create and return the schedule definition
    return ScheduleDefinition(
        job=asset_job,
        name="refresh_" + name + "_schedule",
        cron_schedule=schedules,
        execution_timezone="Asia/Bangkok",
    )


cdm_dim_dr_forecast_by_date = create_refreshable_table_asset(
    "cdm_dim_dr_forecast_by_date", deps=[load_pub_ads_roi_to_postgres]
)

cdm_dim_dr_forecast_resell = create_refreshable_table_asset(
    "cdm_dim_dr_forecast_resell"
)

daniel_dr_report_adhoc = create_refreshable_table_asset("daniel_dr_report_adhoc")

forecast_snapshots = create_refreshable_table_asset("forecast_snapshot")

sale_master_k = create_refreshable_table_asset("sale_master_k")

fact_fin_rockbay_lead = create_refreshable_table_asset("fact_fin_rockbay_lead")

mart_bd_master = create_refresh_mv_asset_db_master("mart_bd_master")

cs_vn_report = create_refreshable_table_asset("cs_vn_report")

cs_vn_report = create_refreshable_table_asset("qa_master")

mv_f_type_vn3 = create_refresh_mv_asset("mv_f_type_vn3")

mv_vn3_report_realtime = create_refresh_mv_asset("vn3_report_realtime",deps=[mv_f_type_vn3])

vn3_report = create_refreshable_table_asset("vn3_report",deps = [mv_f_type_vn3])

mv_adhoc_bod_log = create_refresh_mv_asset("adhoc_bod_log")

dim_geo_org_id = create_refreshable_table_asset("dim_geo_org_id")

fact__lead_sales_delivery = create_refreshable_table_asset(
    "fact__lead_sales_delivery", deps=[dim_geo_org_id, ods_affscale_conversion]
)

mart_fin__raw_lead_life_cycle = create_refreshable_table_asset(
    "mart_fin__raw_lead_life_cycle",
    deps=[fact__lead_sales_delivery],
)

mart_logistics__delivery_status = create_refreshable_table_asset(
    "mart_logistics__delivery_status",
    deps=[fact__lead_sales_delivery],
)

mart_sales__lead_backlog = create_refreshable_table_asset(
    "mart_sales__lead_backlog",
    deps=[fact__lead_sales_delivery],
)

fact__item_with_cost = create_refreshable_table_asset(
    "fact__item_with_cost",
    deps=[fact__lead_sales_delivery],
)

fact__lead_dr_final = create_refreshable_table_asset(
    "fact__lead_dr_final",
    deps=[
        fact__lead_sales_delivery,
        cdm_dim_dr_forecast_by_date,
        cdm_dim_dr_forecast_resell,
    ],
)

stg_dim__enrich_salary_cost = create_refreshable_table_asset(
    "stg_dim__enrich_salary_cost",
    deps=[
        fact__lead_sales_delivery,
        fact__lead_dr_final,
        user_input_assets.load_dim_finance_salary_cost,
        load_exchange_rate_data,
    ],
)


fact__lead_salary_cost = create_refreshable_table_asset(
    "fact__lead_salary_cost",
    deps=[
        fact__lead_sales_delivery,
        stg_dim__enrich_salary_cost,
    ],
)


mart_fin__agg_lead_life_cycle = create_refreshable_table_asset(
    "mart_fin__agg_lead_life_cycle",
    deps=[
        fact__item_with_cost,
        fact__lead_sales_delivery,
        mart_fin__raw_lead_life_cycle,
    ],
)


mv_fcr_raw = create_refresh_mv_asset("fcr_raw")

mv_indo_qa_tracking = create_refresh_mv_asset("indo_qa_tracking")

mv_sale_master = create_refresh_mv_asset("v_sale_master", "sale_master")

mv_keitaro = create_refresh_mv_asset("mv_keitaro")

mv_keitaro_cis = create_refresh_mv_asset("mv_keitaro_cis")

mv_keitaro_ttm = create_refresh_mv_asset("mv_keitaro_ttm")

dim_agent_on_board = create_refreshable_table_asset(
    "dim_agent_on_board"
)

cl_fresh_vn3_table = create_refreshable_table_asset(
    "cl_fresh_vn3"
)

dim_agent_team_table = create_refreshable_table_asset(
    "dim_agent_team"
)

od_sale_order_realtime_table = create_refreshable_table_asset(
    "realtime_od_sale_order"
)

cl_fresh_realtime_table = create_refreshable_table_asset(
    "realtime_cl_fresh"
)

cdr_realtime_table = create_refreshable_table_asset(
    "cdr_realtime"
)

cdr_realtime_mv = create_refresh_mv_asset(
    "cdr_realtime_mv", with_data=True,deps=[cdr_realtime_table]
)

resell_dr_forecast_table = create_refreshable_table_asset(
    "resell_dr_forecast"
)

mv_bd_master = create_refresh_mv_asset(
    "bd_master", with_data=True, deps=[cdm_dim_dr_forecast_by_date]
)

realtime_cl_fresh_table = create_refreshable_table_asset(
    "cl_fresh_realtime"
)

realtime_od_sale_order_table = create_refreshable_table_asset(
    "od_sale_order_realtime"
)

mv_cl_fresh_realtime = create_refresh_mv_asset(
    "cl_fresh_realtime_mv", with_data=True, deps=[cl_fresh_realtime_table]
)

mv_od_sale_order_realtime = create_refresh_mv_asset(
    "od_sale_order_realtime_mv", with_data=True, deps=[cl_fresh_realtime_table]
)

realtime_od_do_new_table = create_refreshable_table_asset(
    "od_do_new_realtime"
)

mv_realtime_bd_master = create_refresh_mv_asset(
    "realtime_bd_master", with_data=True,deps=[realtime_cl_fresh_table]
)

realtime_bd_master_table = create_refreshable_table_asset(
    "realtime_bd_master_table",deps=[mv_realtime_bd_master]
)
mv_agent_perf = create_refresh_mv_asset(
    "agent_performance_data", with_data=False
)
mv_leadstatus_bd_master = create_refresh_mv_asset(
    "leadstatus_bd_master", with_data=True,deps=[realtime_cl_fresh_table]
)
mv_first_call_attempt_tracking= create_refresh_mv_asset(
    "first_call_attempt_tracking", with_data=True
)

mv_f_type= create_refresh_mv_asset(
    "mv_f_type"
)

mv_productivity_revenue= create_refresh_mv_asset(
    "mv_productivity_revenue",deps=[mv_f_type]
)

mv_retention_report= create_refresh_mv_asset(
    "retention_report"
)

mv_session= create_refresh_mv_asset(
    "mv_session",deps=[mv_f_type]
)

mv_session_vn3= create_refresh_mv_asset(
    "mv_session_vn3",deps=[mv_f_type]
)

mv_productivity_tracking= create_refresh_mv_asset(
    "mv_productivity_tracking",deps=[mv_session_vn3]
)

finance_daily_view = create_refreshable_table_asset(
    "finance_daily_view", deps=[ods_affscale_conversion]
)

mkt_budget_control = create_refreshable_table_asset(
    "mkt_budget_control", deps=[finance_daily_view]
)

budget_control_table = create_refreshable_table_asset(
    "budget_control", deps=[mv_bd_master]
)

mart_fin__perf_report = create_refreshable_table_asset(
    "mart_fin__perf_report",
    deps=[
        mv_bd_master,
        user_input_assets.load_dim_finance_plan_figure,
        user_input_assets.load_dim_lead_cost_rev_plan,
        user_input_assets.load_cpl_target,
        user_input_assets.load_dim_finance_markup,
    ],
)

mart_fin__pnl_report = create_refreshable_table_asset(
    "mart_fin__pnl_report",
    deps=[
        fact__lead_sales_delivery,
        fact__lead_salary_cost,
        mart_fin__perf_report,
        user_input_assets.load_dim_finance_plan_figure,
        user_input_assets.load_dim_fin_commission,
        user_input_assets.load_dim_finance_bd_logistics_cost,
        user_input_assets.load_dim_finance_tel_cost,
    ],
)


mv_indo_qa_tracking_schedule = create_refresh_schedule(
    [mv_indo_qa_tracking], ["0 8-22/2 * * *"]
)

mv_keitaro_schedule = create_refresh_schedule(
    [mv_keitaro,mv_keitaro_cis, mv_keitaro_ttm], ["5 9,20 * * *"]
)

mv_bd_master_schedule = create_refresh_schedule(
    [mv_bd_master,budget_control_table], ["30 5,8,10,14,18,20 * * *", "30 12 * * *"]
)
#mv_realtime_bd_master_schedule = create_refresh_schedule(
#    [mv_realtime_bd_master, realtime_bd_master_table], ["*/10 * * * *"]
#)
#mv_leadstatus_bd_master_schedule = create_refresh_schedule(
#    [mv_leadstatus_bd_master], ["*/10 * * * *"]
#)
mv_agent_perf_schedule = create_refresh_schedule(
    [mv_agent_perf], ["30 9,11,13,15,17,19,21,23 * * *"]
)
mv_first_call_attempt_tracking_schedule = create_refresh_schedule(
    [mv_first_call_attempt_tracking], ["*/6 * * * *"]
)
mv_sale_master_schedule = create_refresh_schedule([mv_sale_master], ["35 */3 * * *"])  #"50 9-23 * * *" #35 9-23 * * *

mkt_budget_control_schedule = create_refresh_schedule(
    [mkt_budget_control], ["30 7 * * *"]
)

cdm_dim_dr_forecast_schedule = create_refresh_schedule(
    [cdm_dim_dr_forecast_by_date, resell_dr_forecast_table],
    ["30 1 * * *"],  ## ##
    "cdm_dim_dr_forecast",
)
daniel_dr_report_adhoc_schedule = create_refresh_schedule(
    [daniel_dr_report_adhoc], ["30 5 * * *"]
)
forecast_snapshot_schedule = create_refresh_schedule(
    [forecast_snapshots], ["0 6,8,11,13,15,17,19,21 * * *"]
)
dim_agent_team_table_schedule = create_refresh_schedule(
    [dim_agent_team_table,dim_agent_on_board], ["0 22 * * *"]
)
sale_master_schedule = create_refresh_schedule([sale_master_k], ["30 11 * * *"])

fin_rockbay_schedule = create_refresh_schedule([fact_fin_rockbay_lead], ["30 11 * * *"])

mart_bd_master_schedule = create_refresh_schedule([mart_bd_master], ["00 16 * * *"])

cs_vn_report_schedule = create_refresh_schedule([cs_vn_report], ["45 5,11,15,19 * * *"])

vn3_report_schedule = create_refresh_schedule([
        vn3_report,
        mv_f_type_vn3
    ],
    ["0 2,22 * * *"],
    "vn3_report",)

cs_vn_report_schedule = create_refresh_schedule(
    [cs_vn_report], ["40 8,11,15,19 * * *"]
)  # ["45 5,11,15,19 * * *"]

refresh_realtime_bd_schedule = create_refresh_schedule(
    [
        realtime_cl_fresh_table,
        realtime_od_sale_order_table,
        realtime_od_do_new_table,
        mv_realtime_bd_master, 
        realtime_bd_master_table,
        mv_leadstatus_bd_master
    ],
    ["17,47 * * * *"],
    # ["*/30 * * * *"],
    "realtime_bd",
)

refresh_productivity_tracking_schedule = create_refresh_schedule(
    [
        mv_retention_report,
        mv_f_type,
        mv_productivity_revenue,
        mv_session,
        mv_session_vn3, 
        mv_productivity_tracking
    ],
    ["0 5 * * *"],
    "productivity_tracking",
)

refresh_realtime_cdr_schedule = create_refresh_schedule(
    [
        cdr_realtime_table,
        mv_f_type_vn3,
        cdr_realtime_mv,
        cl_fresh_realtime_table,
        cl_fresh_vn3_table,
        od_sale_order_realtime_table,
        mv_cl_fresh_realtime,
        mv_od_sale_order_realtime,
        mv_vn3_report_realtime
    ],
    ["*/10 8-21 * * *"],
    "realtime_vn3",
)

refresh_base_fact_tables_schedule = create_refresh_schedule(
    [
        dim_geo_org_id,
        fact__lead_sales_delivery,
        #fact__item_with_cost,
    ],
    ["0 2 * * *"], #"0 6,11,15,18 * * *","30 20 * * *"
    "base_fact_tables",
)

refresh_aux_fact_tables_schedule = create_refresh_schedule(
    [
        fact__lead_dr_final,
        stg_dim__enrich_salary_cost,
        fact__lead_salary_cost,
        mart_fin__raw_lead_life_cycle,
        mart_fin__agg_lead_life_cycle,
        mart_fin__perf_report,
        mart_fin__pnl_report,
    ],
    ["0 7 * * *"],
    "aux_fact_tables",
)

refresh_adhoc_views_schedule = create_refresh_schedule(
    [
        mv_adhoc_bod_log
    ],
    ["0 2 * * *"], #"0 6,11,15,18 * * *","30 20 * * *"
    "adhoc_views",
)

finance_daily_view_schedule = create_refresh_schedule(
    [
        finance_daily_view,
    ],
    ["0 0 * * *"],
    "finance_daily_view",
)
