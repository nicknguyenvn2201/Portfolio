import pandas as pd
import os
from dagster import (
    Config,
    get_dagster_logger,
    asset,
    AssetExecutionContext,
    MetadataValue,
    Output,
    define_asset_job,
    ScheduleEvaluationContext,
    RunRequest,
    schedule,
    DailyPartitionsDefinition,
    RetryPolicy,
    ScheduleDefinition,
    AssetSelection
)
import io
import psycopg as pg
from DagsFlow.assets.utls import func
from typing import Iterator
import requests as rq
from datetime import date
from datetime import timedelta
from pandas import DataFrame
import pyarrow as pa
from DagsFlow.assets.utls.func import (
    add_blocking_checks_to_asset,
    create_load_to_postgres_asset_db_master,
    create_download_from_sharepoint_asset_base_layer,
)

logger = get_dagster_logger()

START_OF_HISTORY = str(date.today()- timedelta(days = 1))[0:10] #"2022-01-01"
time_partitions = DailyPartitionsDefinition(start_date=START_OF_HISTORY, end_offset=1)
TIMEZONE = os.getenv("DAGSTER_TIMEZONE")


class config_bd_master(Config):
    sql_query_truncate: str = "TRUNCATE mart_layer.bd_master;"


@asset(group_name="bd_master_mart_layer")
def truncate_old_data_bd_master(config: config_bd_master):
    conn_details = pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG_DB_MASTER"))
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_truncate)
    conn_details.commit()
    cursor.close()
    conn_details.close()


@asset(group_name="bd_master_mart_layer", deps=[truncate_old_data_bd_master])
def load_data_bd_master_mart_layer(context: AssetExecutionContext) -> None:
    target_table='"mart_layer"."dim_bd_aov_target"'
    templater = func.SqlStore()
    with pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG_DB_MASTER")) as connection:
        with connection.cursor() as cursor:
            insert_statement = templater.get("bd_master_mart_layer").render()
            logger.info("Start inserting into target table")
            cursor.execute(insert_statement)
            logger.info("Completed inserting into target table")
            new_row_count = cursor.execute(
                f"select count(*) from {target_table}"
            ).fetchone()
            context.add_output_metadata(
                metadata={"New Row Count": MetadataValue.int(new_row_count[0])}
            )


sync_data_bd_master_mart_layer = define_asset_job(
    name="sync_data_bd_master_mart_layer",
    selection=AssetSelection.groups("bd_master_mart_layer"),
)

sync_data_bd_master_schedule = ScheduleDefinition(
    job=sync_data_bd_master_mart_layer,
    cron_schedule= "30 1 * * *", # cron_schedule= ["0 6,8,10,14,18,20 * * *", "30 12 * * *"]
    execution_timezone="Asia/Bangkok",
)


