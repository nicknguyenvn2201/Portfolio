import os
from dagster_dbt import (
    DbtCliClientResource,
)
from dagster import (
    asset,
    get_dagster_logger,
    Output,
    MetadataValue,
    AssetExecutionContext,
    define_asset_job,
    AssetSelection,
    ScheduleDefinition,
)
from pyarrow import Table
import pandas as pd
from DagsFlow.resources import telegram
from DagsFlow.assets.utls.func import extract_from_dwh
from DagsFlow.assets.materialized_views import mart_logistics__delivery_status
from DagsFlow.resources.postgres import PostgresConnection
import pandas as pd

logger = get_dagster_logger()


def make_delivery_status_report(df: pd.DataFrame) -> str:
    do_this_month = df["total_order"][0]
    do_last_month = df["total_order"][1]
    dr_this_month = df["delivered"][0] / df["total_order"][0]
    dr_last_month = df["delivered"][1] / df["total_order"][1]
    new_this_month = df["new_order"][0]
    new_last_month = df["new_order"][1]
    pending_this_month = df["pending"][0]
    pending_last_month = df["pending"][1]
    instransit_last_month = df["intransit"][1]
    delivering_last_month = df["delivering"][1]
    new_delay_this_month = df["new_order_delay"][0]
    pending_delay_this_month = df["pending_delay"][0]
    instransit_this_month = df["intransit"][0]
    delivering_this_month = df["delivering"][0]
    ongoing_this_month = df["ongoing"][0]
    ongoing_last_month = df["ongoing"][1]
    ongoing_ratio_this_month = ongoing_this_month / do_this_month
    ongoing_ratio_last_month = ongoing_last_month / do_last_month
    text = f"""Last Month:
  \- ***DO:*** {do_last_month:0,.0f} \| ***DR:*** {dr_last_month*100:0,.1f}%
  \- ***Ongoing DO:*** {ongoing_ratio_last_month*100:0,.1f}%
MTD Statistics:
  \- ***DO:*** {do_this_month:0,.0f} \| ***DR:*** {dr_this_month*100:0,.1f}%
  \- ***Pending WH DO:*** {new_this_month:0,.0f} \| ***Delay:*** {new_delay_this_month:0,.0f}
  \- ***Pending TMS DO:*** {pending_this_month:0,.0f} \| ***Delay:*** {pending_delay_this_month:0,.0f}
  \- ***Intransit DO:*** {instransit_this_month:0,.0f} \| ***Delivering DO:*** {delivering_this_month:0,.0f}
  \- ***Ongoing DO:*** {ongoing_ratio_this_month*100:0,.1f}%
""".replace(
        ".", "\."
    )
    return text


@asset(
    group_name="report_logistics",
    deps=["mart_logistics__delivery_status"],
)
def dataset_mtd_delivery_status(
    context: AssetExecutionContext, oltp01_conn: PostgresConnection
) -> Output[pd.DataFrame]:
    copy_query = "select * from mart_logistics__delivery_status"
    df = extract_from_dwh(copy_query, oltp01_conn)
    return Output(
        value=df, metadata={"Dataset": MetadataValue.md(df.to_markdown(index=False))}
    )


@asset(
    group_name="report_logistics",
)
def report_mtd_logistics_id(
    context: AssetExecutionContext,
    dataset_mtd_delivery_status: pd.DataFrame,
    telebot_data: telegram.TelegramBot,
    telegram_chat: telegram.TelegramChat,
) -> None:
    chat_id = telegram_chat.get_id("LOGISTICS_ID")
    df = dataset_mtd_delivery_status
    df = df[df["geo"].isin(["ID", "ID2","ID3"])].iloc[:, 1:]
    df = (
        df.groupby(
            by=["delivery_date"],
        )
        .sum()
        .sort_index(ascending=False)
    )
    logger.info(df.to_markdown())
    text = make_delivery_status_report(df)
    telebot_data.send_message(chat_id, text, parse_mode="MarkdownV2")


@asset(
    group_name="report_logistics",
)
def report_mtd_logistics_ph(
    context: AssetExecutionContext,
    dataset_mtd_delivery_status: pd.DataFrame,
    telebot_data: telegram.TelegramBot,
    telegram_chat: telegram.TelegramChat,
) -> None:
    chat_id = telegram_chat.get_id("LOGISTICS_PH")
    df = dataset_mtd_delivery_status
    df = df[df["geo"].isin(["PH"])].iloc[:, 1:]
    df = (
        df.groupby(
            by=["delivery_date"],
        )
        .sum()
        .sort_index(ascending=False)
    )
    logger.info(df.to_markdown())
    text = make_delivery_status_report(df)
    telebot_data.send_message(chat_id, text, parse_mode="MarkdownV2")


generate_report_logistics_id_job = define_asset_job(
    name="generate_report_logistics_id",
    selection=AssetSelection.assets(
        mart_logistics__delivery_status,
        dataset_mtd_delivery_status,
        report_mtd_logistics_id
     
    ),
)

daily_logistics_report_schedule = ScheduleDefinition(
    job=generate_report_logistics_id_job,
    cron_schedule="0 8,9,11,15,18,23 * * *",
    execution_timezone="Asia/Bangkok",
)
