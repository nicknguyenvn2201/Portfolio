import pandas as pd
import os
from dagster import (
    Config,
    get_dagster_logger,
    asset,
    AssetExecutionContext,
    MetadataValue,
    define_asset_job,
    DailyPartitionsDefinition,
    ScheduleDefinition,
    AssetSelection
)
import io
import psycopg as pg
from DagsFlow.assets.utls import func
from typing import Iterator
import requests as rq
from datetime import date
from datetime import timedelta
from pandas import DataFrame
import pyarrow as pa
from DagsFlow.assets.utls.func import (
    add_blocking_checks_to_asset,
    create_load_to_postgres_asset_db_master,
    create_download_from_sharepoint_asset_base_layer,
)

logger = get_dagster_logger()


class config_data_master_agg(Config):
    sql_query_delete: str = "TRUNCATE dareport.data_master_agg;"


@asset(group_name="data_master_agg")
def truncate_old_data_master_agg(config: config_data_master_agg):
    conn_details = pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG"))
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_delete)
    conn_details.commit()
    cursor.close()
    conn_details.close()


@asset(group_name="data_master_agg", deps=[truncate_old_data_master_agg])
def load_data_master_agg(context: AssetExecutionContext) -> None:
    target_table='"dareport"."data_master_agg"'
    templater = func.SqlStore()
    with pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG")) as connection:
        with connection.cursor() as cursor:
            insert_statement = templater.get("data_master_agg").render()
            logger.info("Start inserting into target table")
            cursor.execute(insert_statement)
            logger.info("Completed inserting into target table")


sync_data_master_agg = define_asset_job(
    name="sync_data_master_agg",
    selection=AssetSelection.groups("data_master_agg"),
)

sync_data_master_agg_schedule = ScheduleDefinition(
    job=sync_data_master_agg,
    cron_schedule= "45 3 * * *", 
    execution_timezone="Asia/Bangkok",
)


