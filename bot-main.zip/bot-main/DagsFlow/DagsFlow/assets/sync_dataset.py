from dagster import asset, Config, define_asset_job, ScheduleDefinition, AssetSelection
from DagsFlow.assets.materialized_views import mkt_budget_control
from DagsFlow.assets.utls.func import extract_from_dwh
from DagsFlow.resources.postgres import PostgresConnection


class MktBudgetControl(Config):
    io_format: str = "csv"
    io_abs_path: str = (
        r"BD - Finance\agg_storage\mkt_budget_control\mkt_budget_control.csv"
    )
    sql_query: str = "select * from mkt_budget_control"  ##


@asset(
    key_prefix=["sharepoint_dataset"],
    group_name="sharepoint_dataset",
    io_manager_key="dataneyu_storage",
    deps=[mkt_budget_control],
)
def mkt_budget_control(oltp01_conn: PostgresConnection, config: MktBudgetControl):
    df = extract_from_dwh(config.sql_query, oltp01_conn, return_type="pandas")
    return df


sync_mkt_budget_control_job = define_asset_job(
    name="sync_mkt_budget_control_job",
    selection=AssetSelection.assets(mkt_budget_control),
)

sync_mkt_budget_control_schedule = ScheduleDefinition(
    job=sync_mkt_budget_control_job,
    cron_schedule="0 0 * * *",
    execution_timezone="Asia/Bangkok",
)
