import pandas as pd
import os
from dagster import (
    Config,
    get_dagster_logger,
    asset,
    AssetExecutionContext,
    MetadataValue,
    define_asset_job,
    DailyPartitionsDefinition,
    ScheduleDefinition,
    AssetSelection
)
import io
import psycopg as pg
from DagsFlow.assets.utls import func
from typing import Iterator
import requests as rq
from datetime import date
from datetime import timedelta
from pandas import DataFrame
import pyarrow as pa
from DagsFlow.assets.utls.func import (
    add_blocking_checks_to_asset,
    create_load_to_postgres_asset_db_master,
    create_download_from_sharepoint_asset_base_layer,
)

logger = get_dagster_logger()


class config_dim_default_payout(Config):
    sql_query_truncate: str = "TRUNCATE dareport.dim_default_payout;"


@asset(group_name="dim_default_payout")
def truncate_old_data_dim_default_payout(config: config_dim_default_payout):
    conn_details = pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG"))
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_truncate)
    conn_details.commit()
    cursor.close()
    conn_details.close()


@asset(group_name="dim_default_payout", deps=[truncate_old_data_dim_default_payout])
def load_data_dim_default_payout(context: AssetExecutionContext) -> None:
    target_table='"dareport"."dim_default_payout"'
    templater = func.SqlStore()
    with pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG")) as connection:
        with connection.cursor() as cursor:
            insert_statement = templater.get("dim_default_payout").render()
            logger.info("Start inserting into target table")
            cursor.execute(insert_statement)
            logger.info("Completed inserting into target table")
            new_row_count = cursor.execute(
                f"select count(*) from {target_table}"
            ).fetchone()
            context.add_output_metadata(
                metadata={"New Row Count": MetadataValue.int(new_row_count[0])}
            )


sync_data_dim_default_payout = define_asset_job(
    name="sync_data_dim_default_payout",
    selection=AssetSelection.groups("dim_default_payout"),
)

sync_data_dim_default_payout_schedule = ScheduleDefinition(
    job=sync_data_dim_default_payout,
    cron_schedule= "0 2 * * *", 
    execution_timezone="Asia/Bangkok",
)


