import pandas as pd
import os
from dagster import (
    Config,
    get_dagster_logger,
    asset,
    AssetExecutionContext,
    MetadataValue,
    define_asset_job,
    DailyPartitionsDefinition,
    ScheduleDefinition,
    AssetSelection
)
import io
import psycopg as pg
from DagsFlow.assets.utls import func
from typing import Iterator
import requests as rq
from datetime import date
from datetime import timedelta
from pandas import DataFrame
import pyarrow as pa
from DagsFlow.assets.utls.func import (
    add_blocking_checks_to_asset,
    create_load_to_postgres_asset_db_master,
    create_download_from_sharepoint_asset_base_layer,
)

logger = get_dagster_logger()


class config_data_master_raw(Config):
    sql_query_delete: str = "TRUNCATE dareport.data_master_raw;"


@asset(group_name="data_master_raw")
def truncate_old_data_master_raw(config: config_data_master_raw):
    conn_details = pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG"))
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_delete)
    conn_details.commit()
    cursor.close()
    conn_details.close()


@asset(group_name="data_master_raw", deps=[truncate_old_data_master_raw])
def load_data_master_raw(context: AssetExecutionContext) -> None:
    target_table='"dareport"."data_master_raw"'
    templater = func.SqlStore()
    with pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG")) as connection:
        with connection.cursor() as cursor:
            insert_statement = templater.get("data_master_raw").render()
            logger.info("Start inserting into target table")
            cursor.execute(insert_statement)
            logger.info("Completed inserting into target table")


sync_data_master_raw = define_asset_job(
    name="sync_data_master_raw",
    selection=AssetSelection.groups("data_master_raw"),
)

sync_data_master_raw_schedule = ScheduleDefinition(
    job=sync_data_master_raw,
    cron_schedule= "0 * * * *", 
    execution_timezone="Asia/Bangkok",
)


