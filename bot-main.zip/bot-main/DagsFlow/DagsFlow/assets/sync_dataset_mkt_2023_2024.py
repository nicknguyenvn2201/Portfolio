from dagster import asset, Config, define_asset_job, ScheduleDefinition, AssetSelection
# from DagsFlow.assets.materialized_views import mkt_budget_control
from DagsFlow.assets.utls.func import extract_from_dwh
from DagsFlow.resources.postgres import PostgresConnection

# # month 10/2023  
# class mktBudgetControl_10_2023(Config):
#     io_format: str = "csv"
#     io_abs_path: str = (
#         r"Data team\Power BI (backup)\fin__mkt_10_1023_to_12_2024\fin__mkt_10_2023.csv"
#     )
    
#     sql_query: str = '''select *
#                         from mart_fin__mkt_monitoring
#                         where DATE("Lead Createdate") between '2023-10-01' and '2023-10-31' '''


# @asset(
#     key_prefix=["sharepoint_dataset"],
#     group_name="sharepoint_dataset",
#     io_manager_key="dataneyu_storage"
# )
# def mkt_budget_control_10_2023(oltp01_conn: PostgresConnection, config: mktBudgetControl_10_2023):
#     df = extract_from_dwh(config.sql_query, oltp01_conn, return_type="pandas")
#     return df

# #========================================================================================================
# # month 11/2023 
# class mktBudgetControl_11_2023(Config):
#     io_format: str = "csv"
#     io_abs_path: str = (
#         r"Data team\Power BI (backup)\fin__mkt_10_1023_to_12_2024\fin__mkt_11_2023.csv"
#     )
    
#     sql_query: str = '''select *
#                         from mart_fin__mkt_monitoring
#                         where DATE("Lead Createdate") between '2023-11-01' and '2023-11-30' '''


# @asset(
#     key_prefix=["sharepoint_dataset"],
#     group_name="sharepoint_dataset",
#     io_manager_key="dataneyu_storage"
# )
# def mkt_budget_control_11_2023(oltp01_conn: PostgresConnection, config: mktBudgetControl_11_2023):
#     df = extract_from_dwh(config.sql_query, oltp01_conn, return_type="pandas")
#     return df

# #========================================================================================================
# # month  12/2023
# class mktBudgetControl_12_2023(Config):
#     io_format: str = "csv"
#     io_abs_path: str = (
#         r"Data team\Power BI (backup)\fin__mkt_10_1023_to_12_2024\fin__mkt_12_2023.csv"
#     )
    
#     sql_query: str = '''select *
#                         from mart_fin__mkt_monitoring
#                         where DATE("Lead Createdate") between '2023-12-01' and '2023-12-31' '''


# @asset(
#     key_prefix=["sharepoint_dataset"],
#     group_name="sharepoint_dataset",
#     io_manager_key="dataneyu_storage"
# )
# def mkt_budget_control_12_2023(oltp01_conn: PostgresConnection, config: mktBudgetControl_12_2023):
#     df = extract_from_dwh(config.sql_query, oltp01_conn, return_type="pandas")
#     return df

# #========================================================================================================
# # month  1/2024
# class mktBudgetControl_1_2024(Config):
#     io_format: str = "csv"
#     io_abs_path: str = (
#         r"Data team\Power BI (backup)\fin__mkt_10_1023_to_12_2024\fin__mkt_01_2024.csv"
#     )
    
#     sql_query: str = '''select *
#                         from mart_fin__mkt_monitoring
#                         where DATE("Lead Createdate") between '2024-01-01' and '2024-01-31' '''


# @asset(
#     key_prefix=["sharepoint_dataset"],
#     group_name="sharepoint_dataset",
#     io_manager_key="dataneyu_storage"
# )
# def mkt_budget_control_01_2024(oltp01_conn: PostgresConnection, config: mktBudgetControl_1_2024):
#     df = extract_from_dwh(config.sql_query, oltp01_conn, return_type="pandas")
#     return df

# #========================================================================================================
# # month  2/2024
# class mktBudgetControl_02_2024(Config):
#     io_format: str = "csv"
#     io_abs_path: str = (
#         r"Data team\Power BI (backup)\fin__mkt_10_1023_to_12_2024\fin__mkt_02_2024.csv"
#     )
    
#     sql_query: str = '''select *
#                         from mart_fin__mkt_monitoring
#                         where DATE("Lead Createdate") between '2024-02-01' and '2024-02-29' '''


# @asset(
#     key_prefix=["sharepoint_dataset"],
#     group_name="sharepoint_dataset",
#     io_manager_key="dataneyu_storage"
# )
# def mkt_budget_control_02_2024(oltp01_conn: PostgresConnection, config: mktBudgetControl_02_2024):
#     df = extract_from_dwh(config.sql_query, oltp01_conn, return_type="pandas")
#     return df

# #========================================================================================================
# # month 3/2024 
# class mktBudgetControl_03_2024(Config):
#     io_format: str = "csv"
#     io_abs_path: str = (
#         r"Data team\Power BI (backup)\fin__mkt_10_1023_to_12_2024\fin__mkt_03_2024.csv"
#     )
    
#     sql_query: str = '''select *
#                         from mart_fin__mkt_monitoring
#                         where DATE("Lead Createdate") between '2024-03-01' and '2024-03-31' '''


# @asset(
#     key_prefix=["sharepoint_dataset"],
#     group_name="sharepoint_dataset",
#     io_manager_key="dataneyu_storage"
# )
# def mkt_budget_control_03_2024(oltp01_conn: PostgresConnection, config: mktBudgetControl_03_2024):
#     df = extract_from_dwh(config.sql_query, oltp01_conn, return_type="pandas")
#     return df

# #========================================================================================================
# # month  4/2024
# class mktBudgetControl_04_2024(Config):
#     io_format: str = "csv"
#     io_abs_path: str = (
#         r"Data team\Power BI (backup)\fin__mkt_10_1023_to_12_2024\fin__mkt_04_2024.csv"
#     )
    
#     sql_query: str = '''select *
#                         from mart_fin__mkt_monitoring
#                         where DATE("Lead Createdate") between '2024-04-01' and '2024-04-30' '''


# @asset(
#     key_prefix=["sharepoint_dataset"],
#     group_name="sharepoint_dataset",
#     io_manager_key="dataneyu_storage"
# )
# def mkt_budget_control_04_2024(oltp01_conn: PostgresConnection, config: mktBudgetControl_04_2024):
#     df = extract_from_dwh(config.sql_query, oltp01_conn, return_type="pandas")
#     return df

# #========================================================================================================
# # month  5/2024
# class mktBudgetControl_05_2024(Config):
#     io_format: str = "csv"
#     io_abs_path: str = (
#         r"Data team\Power BI (backup)\fin__mkt_10_1023_to_12_2024\fin__mkt_05_2024.csv"
#     )
    
#     sql_query: str = '''select *
#                         from mart_fin__mkt_monitoring
#                         where DATE("Lead Createdate") between '2024-05-01' and '2024-05-31' '''


# @asset(
#     key_prefix=["sharepoint_dataset"],
#     group_name="sharepoint_dataset",
#     io_manager_key="dataneyu_storage"
# )
# def mkt_budget_control_05_2024(oltp01_conn: PostgresConnection, config: mktBudgetControl_05_2024):
#     df = extract_from_dwh(config.sql_query, oltp01_conn, return_type="pandas")
#     return df

#========================================================================================================
# month  6/2024
class mktBudgetControl_06_2024(Config):
    io_format: str = "csv"
    io_abs_path: str = (
        r"Data team\Power BI (backup)\fin__mkt_10_1023_to_12_2024\fin__mkt_06_2024.csv"
    )
    
    sql_query: str = '''select *
                        from mart_fin__mkt_monitoring
                        where DATE("Lead Createdate") between '2024-06-01' and '2024-06-30' '''


@asset(
    key_prefix=["sharepoint_dataset"],
    group_name="sharepoint_dataset",
    io_manager_key="dataneyu_storage"
)
def mkt_budget_control_06_2024(oltp01_conn: PostgresConnection, config: mktBudgetControl_06_2024):
    df = extract_from_dwh(config.sql_query, oltp01_conn, return_type="pandas")
    return df

#========================================================================================================
# month  7/2024
class mktBudgetControl_07_2024(Config):
    io_format: str = "csv"
    io_abs_path: str = (
        r"Data team\Power BI (backup)\fin__mkt_10_1023_to_12_2024\fin__mkt_07_2024.csv"
    )
    
    sql_query: str = '''select *
                        from mart_fin__mkt_monitoring
                        where DATE("Lead Createdate") between '2024-07-01' and '2024-07-31' '''


@asset(
    key_prefix=["sharepoint_dataset"],
    group_name="sharepoint_dataset",
    io_manager_key="dataneyu_storage"
)
def mkt_budget_control_07_2024(oltp01_conn: PostgresConnection, config: mktBudgetControl_07_2024):
    df = extract_from_dwh(config.sql_query, oltp01_conn, return_type="pandas")
    return df

#========================================================================================================
# month  8/2024
class mktBudgetControl_08_2024(Config):
    io_format: str = "csv"
    io_abs_path: str = (
        r"Data team\Power BI (backup)\fin__mkt_10_1023_to_12_2024\fin__mkt_08_2024.csv"
    )
    
    sql_query: str = '''select *
                        from mart_fin__mkt_monitoring
                        where DATE("Lead Createdate") between '2024-08-01' and '2024-08-31' '''


@asset(
    key_prefix=["sharepoint_dataset"],
    group_name="sharepoint_dataset",
    io_manager_key="dataneyu_storage"
)
def mkt_budget_control_08_2024(oltp01_conn: PostgresConnection, config: mktBudgetControl_08_2024):
    df = extract_from_dwh(config.sql_query, oltp01_conn, return_type="pandas")
    return df

#========================================================================================================
# month  9/2024
class mktBudgetControl_09_2024(Config):
    io_format: str = "csv"
    io_abs_path: str = (
        r"Data team\Power BI (backup)\fin__mkt_10_1023_to_12_2024\fin__mkt_09_2024.csv"
    )
    
    sql_query: str = '''select *
                        from mart_fin__mkt_monitoring
                        where DATE("Lead Createdate") between '2024-09-01' and '2024-09-30' '''


@asset(
    key_prefix=["sharepoint_dataset"],
    group_name="sharepoint_dataset",
    io_manager_key="dataneyu_storage"
)
def mkt_budget_control_09_2024(oltp01_conn: PostgresConnection, config: mktBudgetControl_09_2024):
    df = extract_from_dwh(config.sql_query, oltp01_conn, return_type="pandas")
    return df

#========================================================================================================
# month  10/2024
class mktBudgetControl_10_2024(Config):
    io_format: str = "csv"
    io_abs_path: str = (
        r"Data team\Power BI (backup)\fin__mkt_10_1023_to_12_2024\fin__mkt_10_2024.csv"
    )
    
    sql_query: str = '''select *
                        from mart_fin__mkt_monitoring
                        where DATE("Lead Createdate") between '2024-10-01' and '2024-10-31' '''


@asset(
    key_prefix=["sharepoint_dataset"],
    group_name="sharepoint_dataset",
    io_manager_key="dataneyu_storage"
)
def mkt_budget_control_10_2024(oltp01_conn: PostgresConnection, config: mktBudgetControl_10_2024):
    df = extract_from_dwh(config.sql_query, oltp01_conn, return_type="pandas")
    return df

#========================================================================================================
# month  11/2024
class mktBudgetControl_11_2024(Config):
    io_format: str = "csv"
    io_abs_path: str = (
        r"Data team\Power BI (backup)\fin__mkt_10_1023_to_12_2024\fin__mkt_11_2024.csv"
    )
    
    sql_query: str = '''select *
                        from mart_fin__mkt_monitoring
                        where DATE("Lead Createdate") between '2024-11-01' and '2024-11-30' '''


@asset(
    key_prefix=["sharepoint_dataset"],
    group_name="sharepoint_dataset",
    io_manager_key="dataneyu_storage"
)
def mkt_budget_control_11_2024(oltp01_conn: PostgresConnection, config: mktBudgetControl_11_2024):
    df = extract_from_dwh(config.sql_query, oltp01_conn, return_type="pandas")
    return df

#========================================================================================================
# month  12/2024
class mktBudgetControl_12_2024(Config):
    io_format: str = "csv"
    io_abs_path: str = (
        r"Data team\Power BI (backup)\fin__mkt_10_1023_to_12_2024\fin__mkt_12_2024.csv"
    )
    
    sql_query: str = '''select *
                        from mart_fin__mkt_monitoring
                        where DATE("Lead Createdate") between '2024-12-01' and '2024-12-31' '''


@asset(
    key_prefix=["sharepoint_dataset"],
    group_name="sharepoint_dataset",
    io_manager_key="dataneyu_storage"
)
def mkt_budget_control_12_2024(oltp01_conn: PostgresConnection, config: mktBudgetControl_12_2024):
    df = extract_from_dwh(config.sql_query, oltp01_conn, return_type="pandas")
    return df
#========================================================================================================
# month  01/2025
class mktBudgetControl_01_2025(Config):
    io_format: str = "csv"
    io_abs_path: str = (
        r"Data team\Power BI (backup)\fin__mkt_10_1023_to_12_2024\fin__mkt_01_2025.csv"
    )
    
    sql_query: str = '''select *
                        from mart_fin__mkt_monitoring
                        where DATE("Lead Createdate") between '2025-01-01' and '2025-01-31' '''


@asset(
    key_prefix=["sharepoint_dataset"],
    group_name="sharepoint_dataset",
    io_manager_key="dataneyu_storage"
)
def mkt_budget_control_01_2025(oltp01_conn: PostgresConnection, config: mktBudgetControl_01_2025):
    df = extract_from_dwh(config.sql_query, oltp01_conn, return_type="pandas")
    return df

#========================================================================================================
# month  02/2025
class mktBudgetControl_02_2025(Config):
    io_format: str = "csv"
    io_abs_path: str = (
        r"Data team\Power BI (backup)\fin__mkt_10_1023_to_12_2024\fin__mkt_02_2025.csv"
    )
    
    sql_query: str = '''select *
                        from mart_fin__mkt_monitoring
                        where DATE("Lead Createdate") between '2025-02-01' and '2025-02-28' '''


@asset(
    key_prefix=["sharepoint_dataset"],
    group_name="sharepoint_dataset",
    io_manager_key="dataneyu_storage"
)
def mkt_budget_control_02_2025(oltp01_conn: PostgresConnection, config: mktBudgetControl_02_2025):
    df = extract_from_dwh(config.sql_query, oltp01_conn, return_type="pandas")
    return df

#========================================================================================================
# month  03/2025
class mktBudgetControl_03_2025(Config):
    io_format: str = "csv"
    io_abs_path: str = (
        r"Data team\Power BI (backup)\fin__mkt_10_1023_to_12_2024\fin__mkt_03_2025.csv"
    )
    
    sql_query: str = '''select *
                        from mart_fin__mkt_monitoring
                        where DATE("Lead Createdate") between '2025-03-01' and '2025-03-31' '''


@asset(
    key_prefix=["sharepoint_dataset"],
    group_name="sharepoint_dataset",
    io_manager_key="dataneyu_storage"
)
def mkt_budget_control_03_2025(oltp01_conn: PostgresConnection, config: mktBudgetControl_03_2025):
    df = extract_from_dwh(config.sql_query, oltp01_conn, return_type="pandas")
    return df
#========================================================================================================
# month  04/2025
class mktBudgetControl_04_2025(Config):
    io_format: str = "csv"
    io_abs_path: str = (
        r"Data team\Power BI (backup)\fin__mkt_10_1023_to_12_2024\fin__mkt_04_2025.csv"
    )
    
    sql_query: str = '''select *
                        from mart_fin__mkt_monitoring
                        where DATE("Lead Createdate") between '2025-04-01' and '2025-04-30' '''


@asset(
    key_prefix=["sharepoint_dataset"],
    group_name="sharepoint_dataset",
    io_manager_key="dataneyu_storage"
)
def mkt_budget_control_04_2025(oltp01_conn: PostgresConnection, config: mktBudgetControl_04_2025):
    df = extract_from_dwh(config.sql_query, oltp01_conn, return_type="pandas")
    return df

#========================================================================================================
# month  05/2025
class mktBudgetControl_05_2025(Config):
    io_format: str = "csv"
    io_abs_path: str = (
        r"Data team\Power BI (backup)\fin__mkt_10_1023_to_12_2024\fin__mkt_05_2025.csv"
    )
    
    sql_query: str = '''select *
                        from mart_fin__mkt_monitoring
                        where DATE("Lead Createdate") between '2025-05-01' and '2025-05-31' '''


@asset(
    key_prefix=["sharepoint_dataset"],
    group_name="sharepoint_dataset",
    io_manager_key="dataneyu_storage"
)
def mkt_budget_control_05_2025(oltp01_conn: PostgresConnection, config: mktBudgetControl_05_2025):
    df = extract_from_dwh(config.sql_query, oltp01_conn, return_type="pandas")
    return df

#========================================================================================================
# month  06/2025
class mktBudgetControl_06_2025(Config):
    io_format: str = "csv"
    io_abs_path: str = (
        r"Data team\Power BI (backup)\fin__mkt_10_1023_to_12_2024\fin__mkt_06_2025.csv"
    )
    
    sql_query: str = '''select *
                        from mart_fin__mkt_monitoring
                        where DATE("Lead Createdate") between '2025-06-01' and '2025-06-30' '''


@asset(
    key_prefix=["sharepoint_dataset"],
    group_name="sharepoint_dataset",
    io_manager_key="dataneyu_storage"
)
def mkt_budget_control_06_2025(oltp01_conn: PostgresConnection, config: mktBudgetControl_06_2025):
    df = extract_from_dwh(config.sql_query, oltp01_conn, return_type="pandas")
    return df

#========================================================================================================
# month  07/2025
class mktBudgetControl_07_2025(Config):
    io_format: str = "csv"
    io_abs_path: str = (
        r"Data team\Power BI (backup)\fin__mkt_10_1023_to_12_2024\fin__mkt_07_2025.csv"
    )
    
    sql_query: str = '''select *
                        from mart_fin__mkt_monitoring
                        where DATE("Lead Createdate") between '2025-07-01' and '2025-07-31' '''


@asset(
    key_prefix=["sharepoint_dataset"],
    group_name="sharepoint_dataset",
    io_manager_key="dataneyu_storage"
)
def mkt_budget_control_07_2025(oltp01_conn: PostgresConnection, config: mktBudgetControl_07_2025):
    df = extract_from_dwh(config.sql_query, oltp01_conn, return_type="pandas")
    return df

#========================================================================================================
# month  08/2025
class mktBudgetControl_08_2025(Config):
    io_format: str = "csv"
    io_abs_path: str = (
        r"Data team\Power BI (backup)\fin__mkt_10_1023_to_12_2024\fin__mkt_08_2025.csv"
    )
    
    sql_query: str = '''select *
                        from mart_fin__mkt_monitoring
                        where DATE("Lead Createdate") between '2025-08-01' and '2025-08-31' '''


@asset(
    key_prefix=["sharepoint_dataset"],
    group_name="sharepoint_dataset",
    io_manager_key="dataneyu_storage"
)
def mkt_budget_control_08_2025(oltp01_conn: PostgresConnection, config: mktBudgetControl_08_2025):
    df = extract_from_dwh(config.sql_query, oltp01_conn, return_type="pandas")
    return df

#========================================================================================================
# month  09/2025
class mktBudgetControl_09_2025(Config):
    io_format: str = "csv"
    io_abs_path: str = (
        r"Data team\Power BI (backup)\fin__mkt_10_1023_to_12_2024\fin__mkt_09_2025.csv"
    )
    
    sql_query: str = '''select *
                        from mart_fin__mkt_monitoring
                        where DATE("Lead Createdate") between '2025-09-01' and '2025-09-30' '''


@asset(
    key_prefix=["sharepoint_dataset"],
    group_name="sharepoint_dataset",
    io_manager_key="dataneyu_storage"
)
def mkt_budget_control_09_2025(oltp01_conn: PostgresConnection, config: mktBudgetControl_09_2025):
    df = extract_from_dwh(config.sql_query, oltp01_conn, return_type="pandas")
    return df

#========================================================================================================
# month  10/2025
class mktBudgetControl_10_2025(Config):
    io_format: str = "csv"
    io_abs_path: str = (
        r"Data team\Power BI (backup)\fin__mkt_10_1023_to_12_2024\fin__mkt_10_2025.csv"
    )
    
    sql_query: str = '''select *
                        from mart_fin__mkt_monitoring
                        where DATE("Lead Createdate") between '2025-10-01' and '2025-10-31' '''


@asset(
    key_prefix=["sharepoint_dataset"],
    group_name="sharepoint_dataset",
    io_manager_key="dataneyu_storage"
)
def mkt_budget_control_10_2025(oltp01_conn: PostgresConnection, config: mktBudgetControl_10_2025):
    df = extract_from_dwh(config.sql_query, oltp01_conn, return_type="pandas")
    return df

#========================================================================================================
# month  11/2025
class mktBudgetControl_11_2025(Config):
    io_format: str = "csv"
    io_abs_path: str = (
        r"Data team\Power BI (backup)\fin__mkt_10_1023_to_12_2024\fin__mkt_11_2025.csv"
    )
    
    sql_query: str = '''select *
                        from mart_fin__mkt_monitoring
                        where DATE("Lead Createdate") between '2025-11-01' and '2025-11-30' '''


@asset(
    key_prefix=["sharepoint_dataset"],
    group_name="sharepoint_dataset",
    io_manager_key="dataneyu_storage"
)
def mkt_budget_control_11_2025(oltp01_conn: PostgresConnection, config: mktBudgetControl_11_2025):
    df = extract_from_dwh(config.sql_query, oltp01_conn, return_type="pandas")
    return df

#========================================================================================================
# month  12/2025
class mktBudgetControl_12_2025(Config):
    io_format: str = "csv"
    io_abs_path: str = (
        r"Data team\Power BI (backup)\fin__mkt_10_1023_to_12_2024\fin__mkt_12_2025.csv"
    )
    
    sql_query: str = '''select *
                        from mart_fin__mkt_monitoring
                        where DATE("Lead Createdate") between '2025-12-01' and '2025-12-31' '''


@asset(
    key_prefix=["sharepoint_dataset"],
    group_name="sharepoint_dataset",
    io_manager_key="dataneyu_storage"
)
def mkt_budget_control_12_2025(oltp01_conn: PostgresConnection, config: mktBudgetControl_12_2025):
    df = extract_from_dwh(config.sql_query, oltp01_conn, return_type="pandas")
    return df


#=========================================================================================================
#schedule
sync_mkt_2023_2024_budget_control_job = define_asset_job(
    name="sync_mkt_2023_2024_budget_control_job",
    selection=AssetSelection.assets(
                                    # mkt_budget_control_10_2023,
                                    # mkt_budget_control_11_2023,
                                    # mkt_budget_control_12_2023,
                                    # mkt_budget_control_01_2024,
                                    # mkt_budget_control_02_2024,
                                    # mkt_budget_control_03_2024,
                                    # mkt_budget_control_04_2024,
                                    # mkt_budget_control_05_2024,
                                    mkt_budget_control_06_2024,
                                    mkt_budget_control_07_2024,
                                    mkt_budget_control_08_2024,
                                    mkt_budget_control_09_2024,
                                    mkt_budget_control_10_2024,
                                    mkt_budget_control_11_2024,
                                    mkt_budget_control_12_2024,
                                    mkt_budget_control_01_2025,
                                    mkt_budget_control_02_2025,
                                    mkt_budget_control_03_2025,
                                    mkt_budget_control_04_2025,
                                    mkt_budget_control_05_2025,
                                    mkt_budget_control_06_2025,
                                    mkt_budget_control_07_2025,
                                    mkt_budget_control_08_2025,
                                    mkt_budget_control_09_2025,
                                    mkt_budget_control_10_2025,
                                    mkt_budget_control_11_2025,
                                    mkt_budget_control_12_2025
                                    ),
)

sync_mkt_2023_2024_budget_control_schedule = ScheduleDefinition(
    job=sync_mkt_2023_2024_budget_control_job,
    cron_schedule="0 5 * * *",
    execution_timezone="Asia/Bangkok",
)
