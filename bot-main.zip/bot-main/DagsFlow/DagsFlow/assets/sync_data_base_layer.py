from dagster import Config, define_asset_job, ScheduleDefinition, AssetSelection 
import psycopg2
import os
from dotenv import load_dotenv
from dagster import (
    asset,
    ScheduleDefinition,
    define_asset_job,
    AssetSelection,
)
import pandas as pd
from DagsFlow.assets.utls.func import (
    extract_from_dwh,
)
from DagsFlow.resources import telegram
import pandas as pd
from DagsFlow.resources.postgres import PostgresConnection

#load value in .env
load_dotenv()

# query slq
class sync_data_base_layer(Config):
    sql_query_truncate_or_user: str = "TRUNCATE base_layer.or_user;"
    sql_query_insert_or_user: str = "insert into base_layer.or_user select * from oltp_public.or_user;"

    sql_query_truncate_cl_fresh: str = "TRUNCATE base_layer.cl_fresh;"
    sql_query_insert_cl_fresh: str = "insert into base_layer.cl_fresh select * from oltp_public.cl_fresh;"

    sql_query_truncate_od_sale_order: str = "TRUNCATE base_layer.od_sale_order;"
    sql_query_insert_od_sale_order: str = "insert into base_layer.od_sale_order select * from oltp_public.od_sale_order;"

    sql_query_truncate_od_do_new: str = "TRUNCATE base_layer.od_do_new;"
    sql_query_insert_od_do_new: str = "insert into base_layer.od_do_new select * from oltp_public.od_do_new;"

    sql_query_truncate_od_so_item: str = "TRUNCATE base_layer.od_so_item;"
    sql_query_insert_od_so_item: str = "insert into base_layer.od_so_item select * from oltp_public.od_so_item;"

    sql_query_truncate_cf_synonym: str = "TRUNCATE base_layer.cf_synonym;"
    sql_query_insert_cf_synonym: str = "insert into base_layer.cf_synonym select * from oltp_public.cf_synonym;"

    sql_query_truncate_bp_partner: str = "TRUNCATE base_layer.bp_partner;"
    sql_query_insert_bp_partner: str = "insert into base_layer.bp_partner select * from oltp_public.bp_partner;"

    sql_query_truncate_cp_campaign: str = "TRUNCATE base_layer.cp_campaign;"
    sql_query_insert_cp_campaign: str = "insert into base_layer.cp_campaign select * from oltp_public.cp_campaign;"

    sql_query_truncate_lead_traffics: str = "TRUNCATE base_layer.lead_traffics;"
    sql_query_insert_lead_traffics: str = "insert into base_layer.lead_traffics select * from oltp_public.lead_traffics;"

    sql_query_truncate_ar_mrps: str = "TRUNCATE base_layer.ar_mrps;"
    sql_query_insert_ar_mrps: str = "insert into base_layer.ar_mrps select * from oltp_public.ar_mrps;"

    sql_query_truncate_lead_mrps: str = "TRUNCATE base_layer.lead_mrps;"
    sql_query_insert_lead_mrps: str = "insert into base_layer.lead_mrps select * from oltp_public.lead_mrps;"

    sql_query_truncate_pd_product: str = "TRUNCATE base_layer.pd_product;"
    sql_query_insert_pd_product: str = "insert into base_layer.pd_product select * from oltp_public.pd_product;"

    sql_query_truncate_or_team: str = "TRUNCATE base_layer.or_team;"
    sql_query_insert_or_team: str = "insert into base_layer.or_team select * from oltp_public.or_team;"

    sql_query_truncate_rc_rescue_job: str = "TRUNCATE base_layer.rc_rescue_job;"
    sql_query_insert_rc_rescue_job: str = "insert into base_layer.rc_rescue_job select * from oltp_public.rc_rescue_job;"

    sql_query_truncate_rc_status: str = "TRUNCATE base_layer.rc_status;"
    sql_query_insert_rc_status: str = "insert into base_layer.rc_status select * from oltp_public.rc_status;"

    sql_query_truncate_rc_substatus: str = "TRUNCATE base_layer.rc_substatus;"
    sql_query_insert_rc_substatus: str = "insert into base_layer.rc_substatus select * from oltp_public.rc_substatus;"

    sql_query_truncate_lc_province: str = "TRUNCATE base_layer.lc_province;"
    sql_query_insert_lc_province: str = "insert into base_layer.lc_province select * from oltp_public.lc_province;"

    sql_query_truncate_or_team_member: str = "TRUNCATE base_layer.or_team_member;"
    sql_query_insert_or_team_member: str = "insert into base_layer.or_team_member select * from oltp_public.or_team_member;"

    sql_query_truncate_actual_max_po_tracking: str = "TRUNCATE base_layer.actual_max_po_tracking;"
    sql_query_insert_actual_max_po_tracking: str = "insert into base_layer.actual_max_po_tracking select * from oltp_public.actual_max_po_tracking;"

    sql_query_truncate_lc_district: str = "TRUNCATE base_layer.lc_district;"
    sql_query_insert_lc_district: str = "insert into base_layer.lc_district select * from oltp_public.lc_district;"

    sql_query_truncate_lc_subdistrict: str = "TRUNCATE base_layer.lc_subdistrict;"
    sql_query_insert_lc_subdistrict: str = "insert into base_layer.lc_subdistrict select * from oltp_public.lc_subdistrict;"

    sql_query_truncate_bp_warehouse: str = "TRUNCATE base_layer.bp_warehouse;"
    sql_query_insert_bp_warehouse: str = "insert into base_layer.bp_warehouse select * from oltp_public.bp_warehouse;"

    sql_query_truncate_od_do_status_timestamp: str = "TRUNCATE base_layer.od_do_status_timestamp;"
    sql_query_insert_od_do_status_timestamp: str = "insert into base_layer.od_do_status_timestamp select * from oltp_public.od_do_status_timestamp;"



oltp03_conn = os.getenv("PG_LIBPQ_CONN_CONFIG_DB_MASTER")

#---------------------------START-----------------------------------

@asset(group_name="sync_data_base_layer")
def truncate_table_or_user(config: sync_data_base_layer):
    conn_details = psycopg2.connect(oltp03_conn)
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_truncate_or_user)
    conn_details.commit()
    cursor.close()
    conn_details.close()

@asset(group_name="sync_data_base_layer", deps=[truncate_table_or_user])
def insert_new_data_table_or_user(config: sync_data_base_layer):
    conn_details = psycopg2.connect(oltp03_conn)
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_insert_or_user)
    conn_details.commit()
    cursor.close()
    conn_details.close()

#------------------------------------------------------------------

@asset(group_name="sync_data_base_layer")
def truncate_table_cl_fresh(config: sync_data_base_layer):
    conn_details = psycopg2.connect(oltp03_conn)
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_truncate_cl_fresh)
    conn_details.commit()
    cursor.close()
    conn_details.close()

@asset(group_name="sync_data_base_layer", deps=[truncate_table_cl_fresh])
def insert_new_data_table_cl_fresh(config: sync_data_base_layer):
    conn_details = psycopg2.connect(oltp03_conn)
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_insert_cl_fresh)
    conn_details.commit()
    cursor.close()
    conn_details.close()

#------------------------------------------------------------------

@asset(group_name="sync_data_base_layer")
def truncate_table_od_sale_order(config: sync_data_base_layer):
    conn_details = psycopg2.connect(oltp03_conn)
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_truncate_od_sale_order)
    conn_details.commit()
    cursor.close()
    conn_details.close()

@asset(group_name="sync_data_base_layer", deps=[truncate_table_od_sale_order])
def insert_new_data_table_od_sale_order(config: sync_data_base_layer):
    conn_details = psycopg2.connect(oltp03_conn)
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_insert_od_sale_order)
    conn_details.commit()
    cursor.close()
    conn_details.close()


#------------------------------------------------------------------

@asset(group_name="sync_data_base_layer")
def truncate_table_od_do_new(config: sync_data_base_layer):
    conn_details = psycopg2.connect(oltp03_conn)
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_truncate_od_do_new)
    conn_details.commit()
    cursor.close()
    conn_details.close()

@asset(group_name="sync_data_base_layer", deps=[truncate_table_od_do_new])
def insert_new_data_table_od_do_new(config: sync_data_base_layer):
    conn_details = psycopg2.connect(oltp03_conn)
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_insert_od_do_new)
    conn_details.commit()
    cursor.close()
    conn_details.close()


#------------------------------------------------------------------

@asset(group_name="sync_data_base_layer")
def truncate_table_od_so_item(config: sync_data_base_layer):
    conn_details = psycopg2.connect(oltp03_conn)
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_truncate_od_so_item)
    conn_details.commit()
    cursor.close()
    conn_details.close()

@asset(group_name="sync_data_base_layer", deps=[truncate_table_od_so_item])
def insert_new_data_table_od_so_item(config: sync_data_base_layer):
    conn_details = psycopg2.connect(oltp03_conn)
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_insert_od_so_item)
    conn_details.commit()
    cursor.close()
    conn_details.close()


#------------------------------------------------------------------

@asset(group_name="sync_data_base_layer")
def truncate_table_cf_synonym(config: sync_data_base_layer):
    conn_details = psycopg2.connect(oltp03_conn)
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_truncate_cf_synonym)
    conn_details.commit()
    cursor.close()
    conn_details.close()

@asset(group_name="sync_data_base_layer", deps=[truncate_table_cf_synonym])
def insert_new_data_table_cf_synonym(config: sync_data_base_layer):
    conn_details = psycopg2.connect(oltp03_conn)
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_insert_cf_synonym)
    conn_details.commit()
    cursor.close()
    conn_details.close()

#------------------------------------------------------------------

@asset(group_name="sync_data_base_layer")
def truncate_table_bp_partner(config: sync_data_base_layer):
    conn_details = psycopg2.connect(oltp03_conn)
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_truncate_bp_partner)
    conn_details.commit()
    cursor.close()
    conn_details.close()

@asset(group_name="sync_data_base_layer", deps=[truncate_table_bp_partner])
def insert_new_data_table_bp_partner(config: sync_data_base_layer):
    conn_details = psycopg2.connect(oltp03_conn)
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_insert_bp_partner)
    conn_details.commit()
    cursor.close()
    conn_details.close()

#------------------------------------------------------------------
    
@asset(group_name="sync_data_base_layer")
def truncate_table_cp_campaign(config: sync_data_base_layer):
    conn_details = psycopg2.connect(oltp03_conn)
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_truncate_cp_campaign)
    conn_details.commit()
    cursor.close()
    conn_details.close()

@asset(group_name="sync_data_base_layer", deps=[truncate_table_cp_campaign])
def insert_new_data_table_cp_campaign(config: sync_data_base_layer):
    conn_details = psycopg2.connect(oltp03_conn)
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_insert_cp_campaign)
    conn_details.commit()
    cursor.close()
    conn_details.close()

#------------------------------------------------------------------
    
@asset(group_name="sync_data_base_layer")
def truncate_table_lead_traffics(config: sync_data_base_layer):
    conn_details = psycopg2.connect(oltp03_conn)
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_truncate_lead_traffics)
    conn_details.commit()
    cursor.close()
    conn_details.close()

@asset(group_name="sync_data_base_layer", deps=[truncate_table_lead_traffics])
def insert_new_data_table_lead_traffics(config: sync_data_base_layer):
    conn_details = psycopg2.connect(oltp03_conn)
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_insert_lead_traffics)
    conn_details.commit()
    cursor.close()
    conn_details.close()

#------------------------------------------------------------------
    
@asset(group_name="sync_data_base_layer")
def truncate_table_ar_mrps(config: sync_data_base_layer):
    conn_details = psycopg2.connect(oltp03_conn)
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_truncate_ar_mrps)
    conn_details.commit()
    cursor.close()
    conn_details.close()

@asset(group_name="sync_data_base_layer", deps=[truncate_table_ar_mrps])
def insert_new_data_table_ar_mrps(config: sync_data_base_layer):
    conn_details = psycopg2.connect(oltp03_conn)
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_insert_ar_mrps)
    conn_details.commit()
    cursor.close()
    conn_details.close()

#------------------------------------------------------------------
    
@asset(group_name="sync_data_base_layer")
def truncate_table_lead_mrps(config: sync_data_base_layer):
    conn_details = psycopg2.connect(oltp03_conn)
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_truncate_lead_mrps)
    conn_details.commit()
    cursor.close()
    conn_details.close()

@asset(group_name="sync_data_base_layer", deps=[truncate_table_lead_mrps])
def insert_new_data_table_lead_mrps(config: sync_data_base_layer):
    conn_details = psycopg2.connect(oltp03_conn)
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_insert_lead_mrps)
    conn_details.commit()
    cursor.close()
    conn_details.close()

#------------------------------------------------------------------
    
@asset(group_name="sync_data_base_layer")
def truncate_table_pd_product(config: sync_data_base_layer):
    conn_details = psycopg2.connect(oltp03_conn)
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_truncate_pd_product)
    conn_details.commit()
    cursor.close()
    conn_details.close()

@asset(group_name="sync_data_base_layer", deps=[truncate_table_pd_product])
def insert_new_data_table_pd_product(config: sync_data_base_layer):
    conn_details = psycopg2.connect(oltp03_conn)
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_insert_pd_product)
    conn_details.commit()
    cursor.close()
    conn_details.close()

#------------------------------------------------------------------
    
@asset(group_name="sync_data_base_layer")
def truncate_table_or_team(config: sync_data_base_layer):
    conn_details = psycopg2.connect(oltp03_conn)
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_truncate_or_team)
    conn_details.commit()
    cursor.close()
    conn_details.close()

@asset(group_name="sync_data_base_layer", deps=[truncate_table_or_team])
def insert_new_data_table_or_team(config: sync_data_base_layer):
    conn_details = psycopg2.connect(oltp03_conn)
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_insert_or_team)
    conn_details.commit()
    cursor.close()
    conn_details.close()

#------------------------------------------------------------------
    
@asset(group_name="sync_data_base_layer")
def truncate_table_rc_rescue_job(config: sync_data_base_layer):
    conn_details = psycopg2.connect(oltp03_conn)
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_truncate_rc_rescue_job)
    conn_details.commit()
    cursor.close()
    conn_details.close()

@asset(group_name="sync_data_base_layer", deps=[truncate_table_rc_rescue_job])
def insert_new_data_table_rc_rescue_job(config: sync_data_base_layer):
    conn_details = psycopg2.connect(oltp03_conn)
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_insert_rc_rescue_job)
    conn_details.commit()
    cursor.close()
    conn_details.close()

#------------------------------------------------------------------
    
@asset(group_name="sync_data_base_layer")
def truncate_table_rc_status(config: sync_data_base_layer):
    conn_details = psycopg2.connect(oltp03_conn)
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_truncate_rc_status)
    conn_details.commit()
    cursor.close()
    conn_details.close()

@asset(group_name="sync_data_base_layer", deps=[truncate_table_rc_status])
def insert_new_data_table_rc_status(config: sync_data_base_layer):
    conn_details = psycopg2.connect(oltp03_conn)
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_insert_rc_status)
    conn_details.commit()
    cursor.close()
    conn_details.close()

#------------------------------------------------------------------
    
@asset(group_name="sync_data_base_layer")
def truncate_table_rc_substatus(config: sync_data_base_layer):
    conn_details = psycopg2.connect(oltp03_conn)
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_truncate_rc_substatus)
    conn_details.commit()
    cursor.close()
    conn_details.close()

@asset(group_name="sync_data_base_layer", deps=[truncate_table_rc_substatus])
def insert_new_data_table_rc_substatus(config: sync_data_base_layer):
    conn_details = psycopg2.connect(oltp03_conn)
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_insert_rc_substatus)
    conn_details.commit()
    cursor.close()
    conn_details.close()

#------------------------------------------------------------------
    
@asset(group_name="sync_data_base_layer")
def truncate_table_lc_province(config: sync_data_base_layer):
    conn_details = psycopg2.connect(oltp03_conn)
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_truncate_lc_province)
    conn_details.commit()
    cursor.close()
    conn_details.close()

@asset(group_name="sync_data_base_layer", deps=[truncate_table_lc_province])
def insert_new_data_table_lc_province(config: sync_data_base_layer):
    conn_details = psycopg2.connect(oltp03_conn)
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_insert_lc_province)
    conn_details.commit()
    cursor.close()
    conn_details.close()

#------------------------------------------------------------------
    
@asset(group_name="sync_data_base_layer")
def truncate_table_or_team_member(config: sync_data_base_layer):
    conn_details = psycopg2.connect(oltp03_conn)
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_truncate_or_team_member)
    conn_details.commit()
    cursor.close()
    conn_details.close()

@asset(group_name="sync_data_base_layer", deps=[truncate_table_or_team_member])
def insert_new_data_table_or_team_member(config: sync_data_base_layer):
    conn_details = psycopg2.connect(oltp03_conn)
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_insert_or_team_member)
    conn_details.commit()
    cursor.close()
    conn_details.close()

#------------------------------------------------------------------
    
@asset(group_name="sync_data_base_layer")
def truncate_table_actual_max_po_tracking(config: sync_data_base_layer):
    conn_details = psycopg2.connect(oltp03_conn)
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_truncate_actual_max_po_tracking)
    conn_details.commit()
    cursor.close()
    conn_details.close()

@asset(group_name="sync_data_base_layer", deps=[truncate_table_actual_max_po_tracking])
def insert_new_data_table_actual_max_po_tracking(config: sync_data_base_layer):
    conn_details = psycopg2.connect(oltp03_conn)
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_insert_actual_max_po_tracking)
    conn_details.commit()
    cursor.close()
    conn_details.close()

#------------------------------------------------------------------
    
@asset(group_name="sync_data_base_layer")
def truncate_table_lc_district(config: sync_data_base_layer):
    conn_details = psycopg2.connect(oltp03_conn)
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_truncate_lc_district)
    conn_details.commit()
    cursor.close()
    conn_details.close()

@asset(group_name="sync_data_base_layer", deps=[truncate_table_lc_district])
def insert_new_data_table_lc_district(config: sync_data_base_layer):
    conn_details = psycopg2.connect(oltp03_conn)
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_insert_lc_district)
    conn_details.commit()
    cursor.close()
    conn_details.close()


#------------------------------------------------------------------
    
@asset(group_name="sync_data_base_layer")
def truncate_table_lc_subdistrict(config: sync_data_base_layer):
    conn_details = psycopg2.connect(oltp03_conn)
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_truncate_lc_subdistrict)
    conn_details.commit()
    cursor.close()
    conn_details.close()

@asset(group_name="sync_data_base_layer", deps=[truncate_table_lc_subdistrict])
def insert_new_data_table_lc_subdistrict(config: sync_data_base_layer):
    conn_details = psycopg2.connect(oltp03_conn)
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_insert_lc_subdistrict)
    conn_details.commit()
    cursor.close()
    conn_details.close()

#------------------------------------------------------------------
    
@asset(group_name="sync_data_base_layer")
def truncate_table_bp_warehouse(config: sync_data_base_layer):
    conn_details = psycopg2.connect(oltp03_conn)
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_truncate_bp_warehouse)
    conn_details.commit()
    cursor.close()
    conn_details.close()

@asset(group_name="sync_data_base_layer", deps=[truncate_table_bp_warehouse])
def insert_new_data_table_bp_warehouse(config: sync_data_base_layer):
    conn_details = psycopg2.connect(oltp03_conn)
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_insert_bp_warehouse)
    conn_details.commit()
    cursor.close()
    conn_details.close()

#------------------------------------------------------------------
    
@asset(group_name="sync_data_base_layer")
def truncate_table_od_do_status_timestamp(config: sync_data_base_layer):
    conn_details = psycopg2.connect(oltp03_conn)
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_truncate_od_do_status_timestamp)
    conn_details.commit()
    cursor.close()
    conn_details.close()

@asset(group_name="sync_data_base_layer", deps=[truncate_table_od_do_status_timestamp])
def insert_new_data_table_od_do_status_timestamp(config: sync_data_base_layer):
    conn_details = psycopg2.connect(oltp03_conn)
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_insert_od_do_status_timestamp)
    conn_details.commit()
    cursor.close()
    conn_details.close()


#------------------------End----------------------------------


sync_data_base_layer_job = define_asset_job(
    name="sync_data_base_layer",
    selection=AssetSelection.groups("sync_data_base_layer"),
)

sync_or_user_schedule = ScheduleDefinition(
    job=sync_data_base_layer_job,
    cron_schedule="0 * * * *", # cron_schedule="0 * * * *"
    execution_timezone="Asia/Bangkok"
)

