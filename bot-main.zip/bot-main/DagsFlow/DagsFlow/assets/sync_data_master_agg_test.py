import pandas as pd
import os
from dagster import (
    Config,
    get_dagster_logger,
    asset,
    AssetExecutionContext,
    MetadataValue,
    define_asset_job,
    DailyPartitionsDefinition,
    ScheduleDefinition,
    AssetSelection
)
import io
import psycopg as pg
from DagsFlow.assets.utls import func
from typing import Iterator
import requests as rq
from datetime import date
from datetime import timedelta
from pandas import DataFrame
import pyarrow as pa
from DagsFlow.assets.utls.func import (
    add_blocking_checks_to_asset,
    create_load_to_postgres_asset_db_master,
    create_download_from_sharepoint_asset_base_layer,
)

logger = get_dagster_logger()


@asset(group_name="data_master_agg_test")
def load_data_master_agg_test(context: AssetExecutionContext) -> None:
    target_table='"dareport"."data_master_agg_test_v1"'
    templater = func.SqlStore()
    with pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG")) as connection:
        with connection.cursor() as cursor:
            insert_statement = templater.get("data_master_agg_test").render()
            logger.info("Start inserting into target table")
            cursor.execute(insert_statement)
            logger.info("Completed inserting into target table")


sync_data_master_agg_test = define_asset_job(
    name="sync_data_master_agg_test",
    selection=AssetSelection.groups("data_master_agg_test"),
)

sync_data_master_agg_test_schedule = ScheduleDefinition(
    job=sync_data_master_agg_test,
    cron_schedule= "0 2 * * *", 
    execution_timezone="Asia/Bangkok",
)


