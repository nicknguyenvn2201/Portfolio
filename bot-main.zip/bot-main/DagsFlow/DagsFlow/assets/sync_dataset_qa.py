from dagster import asset, Config, define_asset_job, ScheduleDefinition, AssetSelection
# from DagsFlow.assets.materialized_views import mkt_budget_control
from DagsFlow.assets.utls.func import extract_from_dwh
from DagsFlow.resources.postgres import PostgresConnection

# limit 20
class MktBudgetControl_limit_20(Config):
    io_format: str = "parquet"
    io_abs_path: str = (
        r"Data team\Power BI (backup)\[DATA] Test sharepoint csv\fin__mkt_limit_20.parquet"
    )
    sql_query: str = '''select *
                        from mart_fin__mkt_monitoring
                        where DATE("Lead Createdate") between '2023-10-01' and '2024-12-31' limit 20 '''
    

@asset(
    key_prefix=["sharepoint_dataset"],
    group_name="sharepoint_dataset",
    io_manager_key="dataneyu_storage"
)
def mkt_budget_control_limit_20(oltp01_conn: PostgresConnection, config: MktBudgetControl_limit_20):
    df = extract_from_dwh(config.sql_query, oltp01_conn, return_type="pandas")
    return df

#limit 1 month
class MktBudgetControl_1_month(Config):
    io_format: str = "parquet"
    io_abs_path: str = (
        r"Data team\Power BI (backup)\[DATA] Test sharepoint csv\fin__mkt_1_month.parquet"
    )
    sql_query: str = '''select *
                        from mart_fin__mkt_monitoring
                        where DATE("Lead Createdate") between '2024-05-01' and '2024-05-31' '''
    

@asset(
    key_prefix=["sharepoint_dataset"],
    group_name="sharepoint_dataset",
    io_manager_key="dataneyu_storage"
)
def mkt_budget_control_1_month(oltp01_conn: PostgresConnection, config: MktBudgetControl_1_month):
    df = extract_from_dwh(config.sql_query, oltp01_conn, return_type="pandas")
    return df

# schedule
sync_mkt_limit_job = define_asset_job(
    name="sync_mkt_limit_job",
    selection=AssetSelection.assets(mkt_budget_control_limit_20, mkt_budget_control_1_month),
)

sync_mkt_limit_schedule = ScheduleDefinition(
    job=sync_mkt_limit_job,
    cron_schedule="0 3 * * *",
    execution_timezone="Asia/Bangkok",
)
