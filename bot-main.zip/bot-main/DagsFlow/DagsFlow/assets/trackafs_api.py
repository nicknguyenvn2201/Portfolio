from dagster import (
    asset,
    Output,
    AssetExecutionContext,
    MetadataValue,
    WeeklyPartitionsDefinition,
    get_dagster_logger,
    schedule,
    define_asset_job,
    ScheduleEvaluationContext,
    RunRequest,
    DailyPartitionsDefinition,
    ScheduleDefinition,
)
import os
from pyarrow import Table
import psycopg as pg
import io
import requests as rq
import pandas as pd
import os
from datetime import timedelta, date, datetime
from dateutil.relativedelta import relativedelta, WE
from DagsFlow.assets.utls.func import extract_from_dwh
from DagsFlow.assets.utls.sql import SqlStore
import connectorx as cx
import numpy as np
from DagsFlow.resources.postgres import PostgresConnection

logger = get_dagster_logger()
TIMEZONE = os.getenv("DAGSTER_TIMEZONE")
MB_WEEKDAY_START = WE

weekly_partitions_def = WeeklyPartitionsDefinition(
    start_date="2023-06-15",
    day_offset=3,
    end_offset=1,
)


def _get_mb_data_from_api(date_s: str, date_e: str) -> dict:
    params = {
        "page": "Campaigns",
        "user_group": "all",
        "status": 1,
        "group": "all",
        "traffic_source": "all",
        # "timezone": "+7:00", remove timezone for expanded range
        "api_key": os.getenv("TRACKAFS_API_KEY"),
        "date": 12,
        "date_s": date_s,
        "date_e": date_e,
    }
    json_response = rq.get(
        r"https://trackafs.com/01dvl.php",
        params=params,
    ).json()
    return json_response


def _find_mb_year(date_value: datetime) -> int:
    return (date_value + relativedelta(weekday=MB_WEEKDAY_START(-1))).isocalendar().year


def _find_mb_week(date_value: datetime) -> int:
    return (date_value + relativedelta(weekday=MB_WEEKDAY_START(-1))).isocalendar().week


@asset(partitions_def=weekly_partitions_def, group_name="dataset_media_buyer")
def extract_mb_data(context: AssetExecutionContext) -> Output[pd.DataFrame]:
    """
    API Doc: https://docs.binom.org/api.php

    Documentation: https://kiwi-eco.atlassian.net/wiki/spaces/~6360bc5bb7b39379d720fbec/pages/289079297/Media+Buyer+Report#Binom-Campaigns%3A
    """
    date_start, date_end = context.partition_time_window
    date_end = date_end - timedelta(days=6)
    logger.info(
        f"Querying data from {date_start.strftime('%Y-%m-%d')} to {date_end.strftime('%Y-%m-%d')}"
    )
    json_response = _get_mb_data_from_api(
        date_s=date_start.strftime("%Y-%m-%d"),
        date_e=date_end.strftime("%Y-%m-%d"),
    )
    df = pd.json_normalize(json_response)
    df["create_date"] = pd.to_datetime(df["create_date"], unit="s")
    df["start_date"] = pd.to_datetime(df["start_date"], unit="s")
    df["date_start"] = pd.to_datetime(date_start).strftime("%Y-%m-%d")
    df["date_end"] = pd.to_datetime(date_end).strftime("%Y-%m-%d")
    df["year"] = _find_mb_year(date_start)
    df["mb_week"] = _find_mb_week(date_start)
    total_lead = int(sum(df["leads"].astype("Int64")))
    return Output(
        value=df,
        metadata={
            "Lead Count": MetadataValue.int(total_lead),
            "Sample": MetadataValue.md(df.head(5).to_markdown(index=False)),
        },
    )


@asset(
    partitions_def=weekly_partitions_def,
    compute_kind="postgres",
    group_name="dataset_media_buyer",
)
def load_mb_data(
    context: AssetExecutionContext,
    extract_mb_data: pd.DataFrame,
) -> None:
    df = extract_mb_data
    date_start, date_end = context.partition_time_window
    year = date_start.year
    week = date_start.isocalendar().week
    with pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG")) as connection:
        with connection.cursor() as cursor:
            cursor.execute(
                f"delete from mb_data where year = {year} and mb_week = {week}"
            )
            buffer = io.BytesIO()
            df.to_csv(buffer, index=False, encoding="utf-8")
            buffer.seek(0)
            with cursor.copy(f"COPY mb_data FROM STDIN WITH CSV HEADER") as copy:
                copy.write(buffer.read())
            total_new_lead = cursor.execute(
                f"select sum(leads) from mb_data where year = {year} and mb_week = {week}"
            ).fetchone()[0]
            context.add_output_metadata(
                metadata={"New Lead Count": MetadataValue.int(total_new_lead)}
            )


refresh_mb_data_job = define_asset_job(
    "refresh_mb_data_job",
    selection=[extract_mb_data, load_mb_data],
    partitions_def=weekly_partitions_def,
)


@schedule(
    job=refresh_mb_data_job,
    cron_schedule="0 8,22 * * *",
    execution_timezone=TIMEZONE,
)
def refresh_mb_data_schedule(context: ScheduleEvaluationContext):
    partitions = weekly_partitions_def.get_partition_keys()[-2:]
    for partition in partitions:
        yield RunRequest(run_key=partition, partition_key=partition)


daily_partitions_def = DailyPartitionsDefinition(
    start_date=str(date.today()- timedelta(days = 30))[0:10],
    end_offset=1,
)


@asset(partitions_def=daily_partitions_def, group_name="dataset_media_buyer")
def extract_mb_data_daily(context: AssetExecutionContext) -> Output[pd.DataFrame]:
    """
    API Doc: https://docs.binom.org/api.php

    Documentation: https://kiwi-eco.atlassian.net/wiki/spaces/~6360bc5bb7b39379d720fbec/pages/289079297/Media+Buyer+Report#Binom-Campaigns%3A
    """
    date_start, _ = context.partition_time_window
    logger.info(f"Querying data on {date_start.strftime('%Y-%m-%d')}")
    json_response = _get_mb_data_from_api(
        date_s=date_start.strftime("%Y-%m-%d"),
        date_e=date_start.strftime("%Y-%m-%d"),
    )
    df = pd.json_normalize(json_response)
    df["create_date"] = pd.to_datetime(df["create_date"], unit="s")
    df["start_date"] = pd.to_datetime(df["start_date"], unit="s")
    df["date_start"] = pd.to_datetime(date_start).strftime("%Y-%m-%d")
    df["date_end"] = pd.to_datetime(date_start).strftime("%Y-%m-%d")
    df["year"] = _find_mb_year(date_start)
    df["mb_week"] = _find_mb_week(date_start)
    total_lead = int(sum(df["leads"].astype("Int64")))
    return Output(
        value=df,
        metadata={
            "Lead Count": MetadataValue.int(total_lead),
            "Sample": MetadataValue.md(df.head(5).to_markdown(index=False)),
        },
    )


@asset(
    partitions_def=daily_partitions_def,
    compute_kind="postgres",
    group_name="dataset_media_buyer",
)
def load_mb_data_daily(
    context: AssetExecutionContext,
    extract_mb_data_daily: pd.DataFrame,
) -> None:
    df = extract_mb_data_daily
    date_start, _ = context.partition_time_window
    date_start = date_start.strftime("%Y-%m-%d")
    with pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG")) as connection:
        with connection.cursor() as cursor:
            cursor.execute(
                f"delete from mb_data_daily where date_start = '{date_start}'"
            )
            buffer = io.BytesIO()
            df.to_csv(buffer, index=False, encoding="utf-8")
            buffer.seek(0)
            with cursor.copy(f"COPY mb_data_daily FROM STDIN WITH CSV HEADER") as copy:
                copy.write(buffer.read())
            total_new_lead = cursor.execute(
                f"select sum(leads) from mb_data_daily where date_start = '{date_start}'"
            ).fetchone()[0]
            context.add_output_metadata(
                metadata={"New Lead Count": MetadataValue.int(total_new_lead)}
            )


refresh_mb_data_daily_job = define_asset_job(
    "refresh_mb_data_daily_job",
    selection=[extract_mb_data_daily, load_mb_data_daily],
    partitions_def=daily_partitions_def,
)


@schedule(
    job=refresh_mb_data_daily_job,
    cron_schedule="50 12 * * *",
    execution_timezone=TIMEZONE,
)
def refresh_mb_data_daily_schedule(context: ScheduleEvaluationContext):
    partitions = daily_partitions_def.get_partition_keys()[-5:]
    for partition in partitions:
        yield RunRequest(run_key=partition, partition_key=partition)


@asset(compute_kind="postgres", group_name="dataset_media_buyer")
def extract_mb_current_data(oltp01_conn: PostgresConnection) -> Output[pd.DataFrame]:
    templater = SqlStore()
    get_query = templater.get("get_mb_current_data").render()
    df = extract_from_dwh(get_query, oltp01_conn, return_type="pandas")
    df["current_date"] = date.today()
    return Output(value=df, metadata={"Row Count": MetadataValue.int(len(df))})


@asset(group_name="dataset_media_buyer")
def extract_mb_historical_data(oltp01_conn: PostgresConnection) -> Output[pd.DataFrame]:
    df = extract_from_dwh(
        "select * from dim_mb_initial_stage group by 1,2,3,4,5,6,7,8",
        oltp01_conn,
        return_type="pandas",
    )
    return Output(
        value=df, metadata={"Input": MetadataValue.md(df.to_markdown(index=False))}
    )


@asset(compute_kind="numpy", group_name="dataset_media_buyer")
def process_mb_data(
    extract_mb_current_data: pd.DataFrame, extract_mb_historical_data: pd.DataFrame
) -> Output[pd.DataFrame]:
    # extract data

    df = extract_mb_current_data
    df_pre = extract_mb_historical_data

    # separate auto and manual data

    df_manual = df[~df["stage"].isnull()]
    df_auto = df[df["stage"].isnull()]

    # filter out stopped campaigns

    df_auto = df_auto.loc[df_auto["status"] != "stop"]

    # select continued campaigns

    df_continue = (
        df_auto.loc[
            (df_auto["current_status"] == "continue") | (df_auto["new_camp"] == 1)
        ]
        .loc[~df_auto["current_stage_start"].isnull()]
        .loc[~df_auto["current_category"].isnull()]
    )
    # process data to prepare for stage and status calculations

    df_continue["current_stage_start"] = df_continue["current_stage_start"].apply(
        lambda x: pd.to_datetime(x)
    )

    df_continue = df_continue.loc[
        df_continue["date_start"] >= df_continue["current_stage_start"]
    ]

    df_continue["duration"] = 1

    df_continue["current_stage"] = np.where(
        df_continue["new_camp"] == 1, 1, df_continue["current_stage"]
    )

    df_continue["current_status"] = np.where(
        df_continue["new_camp"] == 1, "continue", df_continue["current_status"]
    )

    df_continue = (
        df_continue.groupby(
            [
                "id",
                "current_stage",
                "start_",
                "current_category",
                "current_status",
                "current_stage_start",
            ]
        )
        .agg(
            {
                "cost": "sum",
                "duration": "sum",
                "profit": "sum",
                "current_budget": "mean",
            }
        )
        .reset_index()
    )

    df_continue["roi"] = df_continue["profit"] / df_continue["cost"]

    # stage processing

    df_continue["stage"] = np.where(
        (
            (df_continue["cost"] >= df_continue["current_budget"])
            | (df_continue["duration"] >= 14)
        )
        & (df_continue["roi"] >= 0)
        & (df_continue["current_stage"] == "3"),
        "Scale",
        np.where(
            (
                (df_continue["cost"] >= df_continue["current_budget"])
                | (df_continue["duration"] >= 14)
            )
            & (df_continue["roi"] < 0)
            & (df_continue["current_stage"] == "3"),
            "WL",
            np.where(
                df_continue["current_stage"] == "WL",
                "WL",
                np.where(
                    (
                        (df_continue["cost"] >= df_continue["current_budget"])
                        | (df_continue["duration"] >= 14)
                    )
                    & (df_continue["roi"] >= -0.8)
                    & (df_continue["current_stage"] == "1"),
                    "2",
                    np.where(
                        (
                            (df_continue["cost"] >= df_continue["current_budget"])
                            | (df_continue["duration"] >= 14)
                        )
                        & (df_continue["roi"] < -0.8)
                        & (df_continue["current_stage"] == "1"),
                        "1",
                        np.where(
                            (
                                (df_continue["cost"] >= df_continue["current_budget"])
                                | (df_continue["duration"] >= 14)
                            )
                            & (df_continue["roi"] >= -0.2)
                            & (df_continue["current_stage"] == "2"),
                            "3",
                            np.where(
                                (
                                    (
                                        df_continue["cost"]
                                        >= df_continue["current_budget"]
                                    )
                                    | (df_continue["duration"] >= 14)
                                )
                                & (df_continue["roi"] < -0.2)
                                & (df_continue["current_stage"] == "2"),
                                "WL",
                                np.where(
                                    (
                                        (
                                            df_continue["cost"]
                                            >= df_continue["current_budget"]
                                        )
                                        | (df_continue["duration"] >= 14)
                                    )
                                    & (df_continue["roi"] >= 0)
                                    & (df_continue["current_stage"] == "Scale"),
                                    "Scale",
                                    np.where(
                                        (
                                            (
                                                df_continue["cost"]
                                                >= df_continue["current_budget"]
                                            )
                                            | (df_continue["duration"] >= 14)
                                        )
                                        & (df_continue["roi"] < 0)
                                        & (df_continue["current_stage"] == "Scale"),
                                        "WL",
                                        df_continue["current_stage"],
                                    ),
                                ),
                            ),
                        ),
                    ),
                ),
            ),
        ),
    )

    # status processing

    df_continue["status"] = np.where(
        (df_continue["stage"] != df_continue["current_stage"])
        & ~df_continue["current_stage"].isin(["WL", "1"]),
        "continue",
        np.where(
            (df_continue["stage"] == df_continue["current_stage"])
            & (df_continue["stage"] == "1"),
            "stop",
            np.where(
                (df_continue["stage"] == df_continue["current_stage"])
                & (df_continue["stage"] == "WL")
                & (df_continue["roi"] < -0.3),
                "stop",
                np.where(
                    (df_continue["stage"] == df_continue["current_stage"])
                    & (df_continue["stage"] == "WL")
                    & (df_continue["roi"] >= -0.3)
                    & (df_continue["roi"] < 0),
                    "pause",
                    np.where(
                        (df_continue["stage"] == df_continue["current_stage"])
                        & (df_continue["stage"] == "WL")
                        & (df_continue["roi"] >= 0),
                        "continue",
                        "continue",
                    ),
                ),
            ),
        ),
    )

    # final processing

    df_continue["stage_start"] = df_continue.apply(
        lambda row: date.today()
        if (
            (row["status"] != row["current_status"])
            | (row["stage"] != row["current_stage"])
        )
        else row["current_stage_start"],
        axis=1,
    )

    df_continue["name"] = None

    df_continue = df_continue[
        [
            "id",
            "name",
            "start_",
            "stage",
            "stage_start",
            "status",
            "current_category",
            "current_budget",
        ]
    ]

    df_continue.rename(
        columns={
            "id": "cp_id",
            "start_": "start",
            "stage_start": "start_of_current_stage",
            "current_category": "category",
            "current_budget": "budget",
            "stage": "current_stage",
        },
        inplace=True,
    )

    df_manual["name"] = None

    df_manual = df_manual[
        [
            "id",
            "name",
            "start_",
            "current_stage",
            "current_stage_start",
            "status",
            "current_category",
            "current_budget",
        ]
    ]

    df_manual.rename(
        columns={
            "id": "cp_id",
            "start_": "start",
            "current_stage_start": "start_of_current_stage",
            "current_category": "category",
            "current_budget": "budget",
        },
        inplace=True,
    )

    df_current = pd.concat([df_continue, df_manual])

    df_current = pd.concat([df_current, df_pre.loc[df_pre["status"] == "stop"]])

    return Output(
        value=df_current,
        metadata={"Output": MetadataValue.md(df_current.to_markdown(index=False))},
    )


@asset(compute_kind="postgres", group_name="dataset_media_buyer")
def update_mb_initial_stage(
    context: AssetExecutionContext,
    process_mb_data: pd.DataFrame,
) -> None:
    df = process_mb_data
    df[["cp_id", "budget"]] = df[["cp_id", "budget"]].astype("Int64")
    df[["start", "start_of_current_stage"]] = df[
        ["start", "start_of_current_stage"]
    ].astype("date32[pyarrow]")
    with pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG")) as connection:
        with connection.cursor() as cursor:
            cursor.execute(f"truncate table dim_mb_initial_stage")
            buffer = io.BytesIO()
            df.to_csv(buffer, index=False, encoding="utf-8")
            buffer.seek(0)
            with cursor.copy(
                f"COPY dim_mb_initial_stage FROM STDIN WITH CSV HEADER"
            ) as copy:
                copy.write(buffer.read())


update_mb_initial_stage_job = define_asset_job(
    "update_mb_initial_stage_job",
    selection=[
        extract_mb_current_data,
        extract_mb_historical_data,
        process_mb_data,
        update_mb_initial_stage,
    ],
)

update_mb_initial_stage_schedule = ScheduleDefinition(
    job=update_mb_initial_stage_job,
    cron_schedule=["30 22 * * *"],
    execution_timezone="Asia/Bangkok",
)
