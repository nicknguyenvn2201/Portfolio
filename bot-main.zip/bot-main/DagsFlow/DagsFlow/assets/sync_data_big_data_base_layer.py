from dagster import Config, define_asset_job, ScheduleDefinition, AssetSelection 
import psycopg2
import os
from dotenv import load_dotenv
from dagster import (
    asset,
    ScheduleDefinition,
    define_asset_job,
    AssetSelection,
)
import pandas as pd
from DagsFlow.assets.utls.func import (
    extract_from_dwh,
)
from DagsFlow.resources import telegram
import pandas as pd
from DagsFlow.resources.postgres import PostgresConnection

#load value in .env
load_dotenv()

# query slq
class sync_data_big_data_base_layer(Config):
    sql_query_truncate_rc_activity: str = "TRUNCATE base_layer.rc_activity;"
    sql_query_insert_rc_activity: str = "insert into base_layer.rc_activity select * from oltp_public.rc_activity;"


oltp03_conn = os.getenv("PG_LIBPQ_CONN_CONFIG_DB_MASTER")

#---------------------------START-----------------------------------
    
@asset(group_name="sync_data_big_data_base_layer")
def truncate_table_rc_activity(config: sync_data_big_data_base_layer):
    conn_details = psycopg2.connect(oltp03_conn)
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_truncate_rc_activity)
    conn_details.commit()
    cursor.close()
    conn_details.close()

@asset(group_name="sync_data_big_data_base_layer", deps=[truncate_table_rc_activity])
def insert_new_data_table_rc_activity(config: sync_data_big_data_base_layer):
    conn_details = psycopg2.connect(oltp03_conn)
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_insert_rc_activity)
    conn_details.commit()
    cursor.close()
    conn_details.close()

#------------------------End----------------------------------


sync_data_big_data_base_layer_job = define_asset_job(
    name="sync_data_big_data_base_layer",
    selection=AssetSelection.groups("sync_data_big_data_base_layer"),
)

sync_data_big_data_base_layer_job_schedule = ScheduleDefinition(
    job=sync_data_big_data_base_layer_job,
    cron_schedule="10 0 * * *", # cron_schedule="0 0 * * *"
    execution_timezone="Asia/Bangkok",
)

