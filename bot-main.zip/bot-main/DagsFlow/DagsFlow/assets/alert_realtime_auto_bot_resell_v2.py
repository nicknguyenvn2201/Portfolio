from datetime import datetime
import psycopg2 as pg
import os    
import time                                              
from dagster import (
    asset,
    define_asset_job,
    ScheduleDefinition,
)
TIMEZONE = os.getenv("DAGSTER_TIMEZONE")

@asset(group_name="realtime_auto_bot_v2")
def refresh_realtime_bd_master_2():
    print("Start refreshing...")
    print("Establishing connection to DWH...")
    conn = pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG"))
    cur = conn.cursor()
    cur.execute("SET statement_timeout = 0")
    conn.commit()
    print("REFRESH MATERIALIZED VIEW realtime_bd_master_2_temp") 
    cur.execute("REFRESH MATERIALIZED VIEW new_urgent_temp_temp")
    cur.execute("refresh materialized view CONCURRENTLY realtime_bd_master_2_temp with data")
    conn.commit()
    print("Finish REFRESHING realtime_bd_master_2_temp")
    cur.close()
    conn.close()
    print("-Finish refreshing realtime_bd_master_2_temp")




refresh_realtime_bd_master_job_v2 = define_asset_job(
    "refresh_realtime_bd_master_v2_job",
    selection=[
        refresh_realtime_bd_master_2,
    ],
)

refresh_realtime_bd_master_v2_schedule = ScheduleDefinition(
    job=refresh_realtime_bd_master_job_v2,
    cron_schedule="*/2 * * * *",
    execution_timezone=TIMEZONE,
    tags={"dagster/priority": "3"},
)


