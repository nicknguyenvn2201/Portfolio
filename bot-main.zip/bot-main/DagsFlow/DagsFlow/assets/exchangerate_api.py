from dagster import (
    asset,
    Output,
    AssetExecutionContext,
    MetadataValue,
    DailyPartitionsDefinition,
    get_dagster_logger,
    schedule,
    define_asset_job,
    ScheduleEvaluationContext,
    RunRequest,
    StaticPartitionsDefinition,
    MultiPartitionsDefinition,
    MultiPartitionKey,
)
import os
from pyarrow import Table
import psycopg as pg
from typing import Union
import io
import requests as rq
import pandas as pd
import os
from datetime import timedelta, date, datetime
import pytz
from DagsFlow.assets.utls import func
import itertools

logger = get_dagster_logger()
TIMEZONE = os.getenv("DAGSTER_TIMEZONE")
TARGET_TABLE = "dim_exchange_rate"
daily_partitions_def = DailyPartitionsDefinition(
    start_date=str(date.today()- timedelta(days = 25))[0:10], # days = 3
    end_offset=1,
)
currency_partitions_def = StaticPartitionsDefinition(
    ["VND", "THB", "IDR", "MYR", "PHP", "INR"]
)
multi_partitions_def = MultiPartitionsDefinition(
    {"date": daily_partitions_def, "currency": currency_partitions_def}
)


@asset(partitions_def=multi_partitions_def)
def extract_exchange_rate_data(context: AssetExecutionContext) -> Output[pd.DataFrame]:
    """
    Endpoint: http://api.exchangeratesapi.io/v1/{endpoint}

    Documentation: https://exchangeratesapi.io/documentation/
    """
    currency, exchange_date = context.partition_key.split("|")
    logger.info(f"Querying exchange data on {exchange_date}")
    query_endpoint = f"http://api.exchangeratesapi.io/v1/{exchange_date}"
    params = {
        "access_key": "f758bfa2370fe2b5f1343ba17935492b",
        "symbols": "USD," + currency,
    }
    json_response = rq.get(
        query_endpoint,
        params=params,
    ).json()
    logger.info(json_response)
    df = pd.json_normalize(json_response["rates"])
    df = df.transpose()
    usd_exchange_rate = df.loc[["USD"]][0][0]
    df["geo"] = df.index.str[:2]
    df["exchange"] = df[0] / usd_exchange_rate
    df["started_date"] = exchange_date
    print("exchange_date is:", exchange_date)
    if exchange_date == date.today().strftime("%Y-%m-%d"):
        df["ending_date"] = pd.to_datetime(exchange_date) + timedelta(days=180)
    else:
        df["ending_date"] = exchange_date
    df = df[
        [
            "geo",
            "exchange",
            "started_date",
            "ending_date",
        ]
    ].loc[[currency]]
    print("df is", df)
    return Output(
        value=df,
        metadata={
            "Exchange Rate": MetadataValue.float(df["exchange"][0]),
        },
    )


@asset(partitions_def=multi_partitions_def, compute_kind="postgres")
def load_exchange_rate_data(
    context: AssetExecutionContext,
    extract_exchange_rate_data: pd.DataFrame,
) -> None:
    df = extract_exchange_rate_data
    currency, exchange_date = context.partition_key.split("|")
    geo = currency[:2]
    with pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG")) as connection:
        with connection.cursor() as cursor:
            cursor.execute(
                f"""delete from {TARGET_TABLE} where started_date = '{exchange_date}' and geo = '{geo}'"""
            )
            buffer = io.BytesIO()
            df.to_csv(buffer, index=False, encoding="utf-8")
            buffer.seek(0)
            with cursor.copy(f"COPY {TARGET_TABLE} FROM STDIN WITH CSV HEADER") as copy:
                copy.write(buffer.read())
            func.check_duplicate_date_range_postgres(
                cursor, f"{TARGET_TABLE}", "started_date", "ending_date", "geo"
            )


refresh_exchange_rate_data_job = define_asset_job(
    "refresh_exchange_rate_data_job",
    selection=[extract_exchange_rate_data, load_exchange_rate_data],
    partitions_def=multi_partitions_def,
)


@schedule(
    job=refresh_exchange_rate_data_job,
    cron_schedule="0 9 * * *",
    execution_timezone=TIMEZONE,
)
def refresh_exchange_rate_data_schedule_yesterday(context: ScheduleEvaluationContext):
    currencies = currency_partitions_def.get_partition_keys()
    latest_dates = daily_partitions_def.get_partition_keys()[-2:-1]
    partitions = itertools.product(currencies, latest_dates)
    for partition in partitions:
        curr, dte = partition
        run_key = "|".join(partition)
        yield RunRequest(
            run_key=run_key,
            tags=multi_partitions_def.get_tags_for_partition_key(
                MultiPartitionKey({"partition/date": dte, "partition/currency": curr})
            ),
        )


@schedule(
    job=refresh_exchange_rate_data_job,
    cron_schedule="15 9 * * *",
    execution_timezone=TIMEZONE,
)
def refresh_exchange_rate_data_schedule_today(context: ScheduleEvaluationContext):
    currencies = currency_partitions_def.get_partition_keys()
    latest_dates = daily_partitions_def.get_partition_keys()[-1:]
    partitions = itertools.product(currencies, latest_dates)
    for partition in partitions:
        curr, dte = partition
        run_key = "|".join(partition)
        yield RunRequest(
            run_key=run_key,
            tags=multi_partitions_def.get_tags_for_partition_key(
                MultiPartitionKey({"partition/date": dte, "partition/currency": curr})
            ),
        )
