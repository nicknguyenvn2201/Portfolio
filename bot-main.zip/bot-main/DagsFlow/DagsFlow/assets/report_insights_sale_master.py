import pandas as pd
import os
from dagster import (
    Config,
    get_dagster_logger,
    asset,
    AssetExecutionContext,
    MetadataValue,
    Output,
    define_asset_job,
    ScheduleEvaluationContext,
    RunRequest,
    schedule,
    DailyPartitionsDefinition,
    RetryPolicy,
    ScheduleDefinition,
    AssetSelection
)
import io
import psycopg as pg
from DagsFlow.assets.utls import func
from typing import Iterator
import requests as rq
from datetime import date
from datetime import timedelta
from pandas import DataFrame
import pyarrow as pa
from DagsFlow.assets.utls.func import (
    add_blocking_checks_to_asset,
    create_load_to_postgres_asset_db_master,
    create_download_from_sharepoint_asset_base_layer,
)

logger = get_dagster_logger()

START_OF_HISTORY = str(date.today()- timedelta(days = 1))[0:10] #"2022-01-01"
time_partitions = DailyPartitionsDefinition(start_date=START_OF_HISTORY, end_offset=1)
TIMEZONE = os.getenv("DAGSTER_TIMEZONE")


class config_bd_master(Config):
    sql_query_truncate: str = "TRUNCATE insights_layer.fact_insights_sale_master;"


@asset(group_name="bd_master_sale_master")
def truncate_old_data_sale_master(config: config_bd_master):
    conn_details = pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG_DB_MASTER"))
    cursor = conn_details.cursor()
    cursor.execute(config.sql_query_truncate)
    conn_details.commit()
    cursor.close()
    conn_details.close()


@asset(group_name="bd_master_sale_master", deps=[truncate_old_data_sale_master])
def load_data_sale_master(context: AssetExecutionContext) -> None:
    target_table='"insights_layer"."fact_insights_sale_master"'
    templater = func.SqlStore()
    with pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG_DB_MASTER")) as connection:
        with connection.cursor() as cursor:
            insert_statement = templater.get("fact_insights_sale_master").render()
            logger.info("Start inserting into target table")
            cursor.execute(insert_statement)
            logger.info("Completed inserting into target table")
            new_row_count = cursor.execute(
                f"select count(*) from {target_table}"
            ).fetchone()
            context.add_output_metadata(
                metadata={"New Row Count": MetadataValue.int(new_row_count[0])}
            )


sync_data_sale_master = define_asset_job(
    name="report_insights_sale_master",
    selection=AssetSelection.groups("bd_master_sale_master"),
)

sync_data_sale_master_schedule = ScheduleDefinition(
    job=sync_data_sale_master,
    cron_schedule= "0 1 * * *", # cron_schedule= ["50 9-22 * * *"]
    execution_timezone="Asia/Bangkok",
)


