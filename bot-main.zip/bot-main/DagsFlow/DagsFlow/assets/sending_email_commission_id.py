import pandas as pd
import os
from dagster import (
    get_dagster_logger,
    asset,
    AssetExecutionContext,
    define_asset_job,
    ScheduleDefinition,
    AssetSelection
)
import psycopg as pg
from datetime import date
import numpy as np
import pandas as pd
import os
from dateutil.relativedelta import *
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from pathlib import Path

logger = get_dagster_logger()

path = Path(__file__).parent / "email_list"

def send_mail_commission(recipient,ccRecipient, subject, message, lastmonth_month, prev_lastmonth_month):  
    username = os.getenv("EMAIL_USERNAME_CONN_CONFIG")
    password = os.getenv("EMAIL_PASSWORD_CONN_CONFIG")
    
    msg = MIMEMultipart()
    msg['From'] = username
    msg['To'] = ', '.join(recipient) 
    msg["Cc"] = ', '.join(ccRecipient) 
    msg['Subject'] = subject
    msg.attach(MIMEText(message, 'plain'))

    file_path = path / f'Indo Sales Order Data_{lastmonth_month}.xlsx'
    with open(file_path, "rb") as file:
        part = MIMEBase('application', "octet-stream")
        part.set_payload(file.read())
        encoders.encode_base64(part)
        part.add_header('Content-Disposition', f'attachment; filename="{file_path.name}"')
        msg.attach(part)

    file_path2 = path / f'AR Data_{lastmonth_month}.xlsx'
    with open(file_path2, "rb") as file:
        part2 = MIMEBase('application', "octet-stream")
        part2.set_payload(file.read())
        encoders.encode_base64(part2)
        part2.add_header('Content-Disposition', f'attachment; filename="{file_path2.name}"')
        msg.attach(part2)

    file_path3 = path / f'Rescue Commission_{lastmonth_month}.xlsx'
    with open(file_path3, "rb") as file:
        part3 = MIMEBase('application', "octet-stream")
        part3.set_payload(file.read())
        encoders.encode_base64(part3)
        part3.add_header('Content-Disposition', f'attachment; filename="{file_path3.name}"')
        msg.attach(part3)

    file_path_prev = path / f'Indo Sales Order Data_{prev_lastmonth_month}.xlsx'
    with open(file_path_prev, "rb") as file:
        part_prev = MIMEBase('application', "octet-stream")
        part_prev.set_payload(file.read())
        encoders.encode_base64(part_prev)
        part_prev.add_header('Content-Disposition', f'attachment; filename="{file_path_prev.name}"')
        msg.attach(part_prev)

    file_path2_prev = path / f'AR Data_{prev_lastmonth_month}.xlsx'
    with open(file_path2_prev, "rb") as file:
        part2_prev = MIMEBase('application', "octet-stream")
        part2_prev.set_payload(file.read())
        encoders.encode_base64(part2_prev)
        part2_prev.add_header('Content-Disposition', f'attachment; filename="{file_path2_prev.name}"')
        msg.attach(part2_prev)

    file_path3_prev = path / f'Rescue Commission_{prev_lastmonth_month}.xlsx'
    with open(file_path3_prev, "rb") as file:
        part3_prev = MIMEBase('application', "octet-stream")
        part3_prev.set_payload(file.read())
        encoders.encode_base64(part3_prev)
        part3_prev.add_header('Content-Disposition', f'attachment; filename="{file_path3_prev.name}"')
        msg.attach(part3_prev)


    try:
        logger.info(f'Sending email to {", ".join(recipient)} with subject "{subject}".')

        all_recipients = recipient + ccRecipient
        mailServer = smtplib.SMTP('smtp-mail.outlook.com', 587)
        mailServer.ehlo()
        mailServer.starttls()
        mailServer.ehlo()
        mailServer.login(username, password)
        mailServer.sendmail(username, all_recipients, msg.as_string())
        mailServer.close()

        logger.info('Email sent successfully.')

    except Exception  as e:
        logger.error(f"Error sending email: {str(e)}")

def read_emails_commission_from_file(file_path):
    with open(file_path, 'r') as file:
        return [line.strip() for line in file if line.strip()]


def ar_data_extract(month):
    q_indo = f"""
-- AR Fresh Commision
    with full_merge as (
    select l.lead_id, l.geo, l.org_id, l.assigned,
    lead_type,
    oso.so_id,
    date(l.createdate) as lead_date,
    cf_lead.name as lead_status,
    date(oso.createdate) as so_date,
    cf_so.name as so_status,
    odn.do_id,
    odn.tracking_code,
    date(odn.createdate) as do_date,
    date(odn.updatedate) as do_updatedate,
    odn.status as do_status_id,
    cf_do.name as do_status,
    case when odn.status = 59 then 1 else 0 end as is_delivered,
    lead_owner,
    ou.user_name as so_owner,
    case when coalesce(lead_owner, ou.fullname) like 'agentbk%' then 'Fresh'
        when coalesce(lead_owner, ou.fullname) like 'agent%' then 'CIT'
    else 'Others' end as agent_type,
    coalesce(affiliate_id, concat('No PubID - ', coalesce(p.shortname,l.agc_code, 'LOYAL CUSTOMER'))) affiliate_id,
    coalesce(p.shortname,l.agc_code, 'LOYAL CUSTOMER') as sourcename,
    amount,
    prod_name,
    l.cp_id,
    cpname,
    cat."FIN camp" as cpsubcat,
    case when lead_type = 'A' then 'Fresh' else 'Resell' end as cpcat
    from (
        select 
        	cl.org_id,
        	cl.geo,
        	lead_id,
            cl.createdate,
            agc_id,
            agc_code,
            assigned,
            lead_type,
            lead_status,
            affiliate_id,
            cam.name as cpname,
            cl.cp_id,
            agent.user_name as lead_owner,
            prod_name 
        from cl_fresh cl
        left join (
            select *
            from or_user ou
            where user_type = 'agent') as agent
        on cl.assigned = agent.user_id and cl.geo = agent.geo
        left join cp_campaign cam on cam.cp_id = cl.cp_id and cam.geo = cl.geo
        where cl.geo ^@ 'ID'
        and cl.cp_id <> 504
        ) as l
    left join od_sale_order oso
    on oso.lead_id = l.lead_id and oso.geo = l.geo
    left join (
        select so_id, geo,
        do_id,
        right(replace(customer_phone,'.',''), 11) phone,
        tracking_code,
        createdate,
        updatedate,
        status
        from od_do_new) odn
    on oso.so_id = odn.so_id and oso.geo = odn.geo
    left join (
        select *
        from cf_synonym cs
        where "type" = 'lead status') as cf_lead
    on l.lead_status = cf_lead.value and l.geo = cf_lead.geo
    left join (
        select *
        from cf_synonym cs
        where "type" = 'sale order status') as cf_so
    on oso.status = cf_so.value and oso.geo = cf_so.geo
    left join (
        select *
        from cf_synonym
        where type = 'delivery order status'
        ) as cf_do
    on odn.status = cf_do.value and odn.geo = cf_do.geo
    left join (
        select *
        from or_user ou
        where user_type = 'agent') as ou
    on oso.ag_id = ou.user_id and oso.geo = ou.geo
    left join bp_partner p on l.agc_id = p.pn_id and l.geo = p.geo
    left join cdm_dim_product_cat cat on lower(cat.product_name) = lower(l.prod_name) and cat.geo = l.geo
        )
    select org_id, assigned, lead_owner, cpcat, cpname,
    count (distinct case when lower(lead_status) = 'approved' then lead_id else null end) as approved_count,
    count (distinct lead_id) as lead_count,
    count (distinct so_id) as so_count,
    count (distinct do_id) as do_count,
    count (distinct case when lower(lead_status) = 'approved' and lower(so_status) in ('validated', 'delay') and do_status_id = 59 then do_id else null end) as delivered_count,
    (count (distinct case when lower(lead_status) = 'approved' then lead_id else null end)) / (count(distinct lead_id))::float as ar
    from full_merge
    where date_trunc('month', lead_date) = '{month}'
    and lead_type = 'A'
    group by 1,2,3,4,5
    """
    conn = pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG"))
    cur = conn.cursor()
    indo = pd.read_sql_query(q_indo,conn)
    conn.commit()
    cur.close()
    conn.close()

    return indo

def extract_rescue_commission(month):
    q_commission = f"""
WITH cte_raw AS (
select
    split_part(f.user_name,'@',1) AS cs_agent_name,
    rc_job.fist_assigned_date job_first_assign,
    to_char(rc_job.fist_assigned_date,'Month') month_year,
	rc_job.id rc_job_id,
    d.name status_transport,
    CASE
		when lower (cf_status.status_name) in ('new', 'urgent') then 'Incomplete'
        WHEN lower(cf_status.status_name) = 'follow up' AND lower(cf_substatus.substatus_name) = 'resend to customer, notify 3pl' THEN 'Rescued'
		WHEN lower(cf_status.status_name) = 'follow up' AND lower(cf_substatus.substatus_name) = 'uncontactable' THEN 'Uncontactable'
        WHEN lower(cf_status.status_name) = 'follow up' AND lower(cf_substatus.substatus_name) like 'wrong info%mation' THEN 'Failed'-- change "failed"
		WHEN lower(cf_status.status_name) = 'forwarded' AND lower(cf_substatus.substatus_name) like 'forward% to sale, customer reject' THEN 'Failed'
		WHEN lower(cf_status.status_name) = 'forwarded' AND lower(cf_substatus.substatus_name) = 'forwarded to logistics, logistics mistake' THEN 'Rescued'
		WHEN lower(cf_status.status_name) = 'forwarded' AND lower(cf_substatus.substatus_name) = 'back to cs' THEN 'Not in use'
		WHEN lower(cf_status.status_name) = 'resend' AND lower(cf_substatus.substatus_name) = 'resend, validator approve' THEN 'Rescued'
		WHEN lower(cf_status.status_name) = 'resend' AND lower(cf_substatus.substatus_name) = 'resend, validator cancel' THEN 'Not in use'
		WHEN lower(cf_status.status_name) = 'resend' AND lower(cf_substatus.substatus_name) = 'resend, waiting validator' THEN 'Rescued'
		WHEN lower(cf_status.status_name) = 'closed' AND lower(cf_substatus.substatus_name) = 'uncontactable' THEN 'Uncontactable'
		WHEN lower(cf_status.status_name) = 'closed' AND lower(cf_substatus.substatus_name) = 'rescue success' THEN 'Rescued'
		WHEN lower(cf_status.status_name) = 'closed' AND lower(cf_substatus.substatus_name) like 'waiting to confirm 3pl%' THEN 'Rescued'
		WHEN lower(cf_status.status_name) = 'closed' AND lower(cf_substatus.substatus_name) LIKE 'sale can%t rescue' THEN 'Failed'
		WHEN lower(cf_status.status_name) = 'closed' AND cf_substatus.substatus_name IS NULL THEN 'Uncontactable'
		ELSE NULL
	END AS rescue_status_mapping
FROM (select * from rc_rescue_job where geo ^@ 'ID') AS rc_job
left join (select * from od_do_new where geo ^@ 'ID') odn on odn.so_id = rc_job.so_id and odn.geo = rc_job.geo
left join (select * from cf_synonym where geo ^@ 'ID' and type = 'delivery order status') d on odn.status = d.value and odn.geo = d.geo
left join (select * from or_user where geo ^@ 'ID') f on rc_job.assigned = f.user_id and rc_job.geo = f.geo 
left join (select * from rc_status where type = 1 and geo ^@ 'ID') cf_status  on cf_status.status = rc_job.job_status and cf_status.geo = rc_job.geo
left join  (select * from rc_substatus where geo ^@ 'ID') cf_substatus on cf_substatus.substatus = rc_job.job_sub_status and cf_substatus.status_id = cf_status.id and cf_substatus.geo = cf_status.geo
left join (select * from rc_status where type = 2 and geo ^@ 'ID') cf_reason  on cf_reason.status = rc_job.job_reason and cf_reason.geo = rc_job.geo
left join  (select * from rc_substatus where geo ^@ 'ID') cf_subreason on cf_subreason.substatus = rc_job.job_sub_reason and cf_subreason.status_id = cf_reason.id and cf_subreason.geo = cf_reason.geo
WHERE f.user_name LIKE '%cs%'
AND is_pre_delivery = false

)
   select 
    cs_agent_name,
    month_year,
    rc_job_id,
    status_transport,
    rescue_status_mapping
   from cte_raw
   where date_trunc('month',job_first_assign) = '{month}'
    """
    # commission = run_query(q_commission, 'team')
    conn = pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG"))
    cur = conn.cursor()
    commission = pd.read_sql_query(q_commission,conn)
    conn.commit()
    cur.close()
    conn.close()
    return commission

def extract_data(month):
    q = f"""
-- Auto Monthly Email
    with full_merge as (
    select l.lead_id, l.geo, l.org_id, l.assigned,
    lead_type,
    oso.so_id,
    date(l.createdate) as lead_date,
    cf_lead.name as lead_status,
    date(oso.createdate) as so_date,
    cf_so.name as so_status,
    odn.do_id,
    odn.tracking_code,
    date(odn.createdate) as do_date,
    date(odn.updatedate) as do_updatedate,
    odn.status as do_status_id,
    cf_do.name as do_status,
    case when odn.status = 59 then 1 else 0 end as is_delivered,
    lead_owner,
    ou.user_name as so_owner,
    case when coalesce(lead_owner, ou.fullname) like 'agentbk%' then 'Fresh'
        when coalesce(lead_owner, ou.fullname) like 'agent%' then 'CIT'
    else 'Others' end as agent_type,
    coalesce(affiliate_id, concat('No PubID - ', coalesce(p.shortname,l.agc_code, 'LOYAL CUSTOMER'))) affiliate_id,
    coalesce(p.shortname,l.agc_code, 'LOYAL CUSTOMER') as sourcename,
    osi.no_quantity,
    amount,
    prod_name,
    l.cp_id,
    cpname,
    cat."FIN camp" as cpsubcat,
    case when lead_type = 'A' then 'Fresh' else 'Resell' end as cpcat
    from (
        select 
        	cl.org_id,
        	cl.geo,
        	lead_id,
            cl.createdate,
            agc_id,
            agc_code,
            assigned,
            lead_type,
            lead_status,
            affiliate_id,
            cam.name as cpname,
            cl.cp_id,
            agent.user_name as lead_owner,
            prod_name 
        from cl_fresh cl
        left join (
            select *
            from or_user ou
            where user_type = 'agent') as agent
        on cl.assigned = agent.user_id and cl.geo = agent.geo
        left join cp_campaign cam on cam.cp_id = cl.cp_id and cam.geo = cl.geo
        where cl.geo ^@ 'ID'
        and cl.cp_id <> 504
        ) as l
    left join od_sale_order oso
    on oso.lead_id = l.lead_id and oso.geo = l.geo
    left join (
        select so_id, geo,
        do_id,
        right(replace(customer_phone,'.',''), 11) phone,
        tracking_code,
        createdate,
        updatedate,
        status
        from od_do_new) odn
    on oso.so_id = odn.so_id and oso.geo = odn.geo
    left join (
	    select geo, so_id, sum(quantity) as no_quantity 
		from od_so_item
		where geo = 'ID'
		group by geo, so_id) osi
	on osi.so_id = oso.so_id and osi.geo = oso.geo
    left join (
        select *
        from cf_synonym cs
        where "type" = 'lead status') as cf_lead
    on l.lead_status = cf_lead.value and l.geo = cf_lead.geo
    left join (
        select *
        from cf_synonym cs
        where "type" = 'sale order status') as cf_so
    on oso.status = cf_so.value and oso.geo = cf_so.geo
    left join (
        select *
        from cf_synonym
        where type = 'delivery order status'
        ) as cf_do
    on odn.status = cf_do.value and odn.geo = cf_do.geo
    left join (
        select *
        from or_user ou
        where user_type = 'agent') as ou
    on oso.ag_id = ou.user_id and oso.geo = ou.geo
    left join bp_partner p on l.agc_id = p.pn_id and l.geo = p.geo
    left join cdm_dim_product_cat cat on lower(cat.product_name) = lower(l.prod_name) and cat.geo = l.geo
    )
    select org_id, so_id, assigned, lead_owner, so_owner, do_id, lead_id, amount, lead_status, so_status, do_status_id, do_status, is_delivered, lead_type, do_date, do_updatedate, cp_id, cpcat, cpsubcat, cpname, no_quantity
    from full_merge
    where so_status in ('validated', 'delay')
    and date_trunc('month', so_date) = '{month}'
    order by so_date 
    """
    # df = run_query(q, geo = 'team')
    conn = pg.connect(os.getenv("PG_LIBPQ_CONN_CONFIG"))
    cur = conn.cursor()
    df = pd.read_sql_query(q,conn)
    conn.commit()
    cur.close()
    conn.close()
    df['Is_Reseller'] = np.where(df.no_quantity >= 100, 1, 0)
    return df

@asset(group_name="send_commission_email_id")
def sending_email_commission_id(context: AssetExecutionContext) -> None:
    today = date.today() 
    lastmonth_date = (today.replace(day=1) + relativedelta(months=-2)).strftime("%Y-%m-%d")
    lastmonth_month = (today.replace(day=1) + relativedelta(months=-2)).strftime("%b-%y")
    prev_lastmonth_date = (today.replace(day=1) + relativedelta(months=-3)).strftime("%Y-%m-%d")
    prev_lastmonth_month = (today.replace(day=1) + relativedelta(months=-3)).strftime("%b-%y")

    #extract month-2 data
    df = extract_data(lastmonth_date)
    df.to_excel(os.path.join(path, f"Indo Sales Order Data_{lastmonth_month}.xlsx"))  
    logger.info("Complete run extrac_data")

    df2 = ar_data_extract(lastmonth_date)
    df2.to_excel(os.path.join(path, f"AR Data_{lastmonth_month}.xlsx"))
    logger.info("Complete run ar_data_extrac")
    
    df3 = extract_rescue_commission(lastmonth_date)
    df3.to_excel(os.path.join(path, f"Rescue Commission_{lastmonth_month}.xlsx"))
    logger.info("Complete run extrac_rescue_commission")

    #extract month-3 data
    df_prev = extract_data(prev_lastmonth_date)
    df_prev.to_excel(os.path.join(path, f"Indo Sales Order Data_{prev_lastmonth_month}.xlsx"))  
    logger.info("Complete run extrac_data")

    df2_prev = ar_data_extract(prev_lastmonth_date)
    df2_prev.to_excel(os.path.join(path, f"AR Data_{prev_lastmonth_month}.xlsx"))
    logger.info("Complete run ar_data_extrac")
    
    df3_prev = extract_rescue_commission(prev_lastmonth_date)
    df3_prev.to_excel(os.path.join(path, f"Rescue Commission_{prev_lastmonth_month}.xlsx"))
    logger.info("Complete run extrac_rescue_commission")
    
    #send mail
    path_to = path / "ToCommissionMonthly_ID.txt"
    recipient = read_emails_commission_from_file(path_to)
    path_cc = path / "CcCommissionMonthly_ID.txt"
    ccRecipient = read_emails_commission_from_file(path_cc)
    
    subject = f'Indonesia Commission Raw Data for {lastmonth_month} and {prev_lastmonth_month}'
    message = '''Dear all,
    Please find attached to this email the Excel file of Indonesia Sales data & AR Data for the month.
    Thanks & Best Regards,'''
    send_mail_commission(recipient,ccRecipient, subject, message, lastmonth_month, prev_lastmonth_month)


send_email_commission_id_jobs = define_asset_job(
    name="send_email_commission_id_jobs",
    selection=AssetSelection.groups("send_commission_email_id"),
)

send_email_commission_id_schedule = ScheduleDefinition(
    job=send_email_commission_id_jobs,
    cron_schedule= "0 6 1 * *", 
    execution_timezone="Asia/Bangkok",
)

