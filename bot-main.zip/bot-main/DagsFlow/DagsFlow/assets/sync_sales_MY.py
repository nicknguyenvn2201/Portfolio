from dagster import asset, Config, define_asset_job, ScheduleDefinition, AssetSelection ##
from DagsFlow.assets.materialized_views import sale_master_k
from DagsFlow.assets.utls.func import extract_from_dwh
from DagsFlow.resources.postgres import PostgresConnection



# MY
class SaleReportMY(Config):
    io_format: str = "parquet"
    io_abs_path: str = r"Data team\Data Source - SALES\dataset_sale_report_MY.parquet"
    sql_query: str =  "select * from sale_master_k where country_code = 'MY' "  


@asset(
    key_prefix=["sharepoint_dataset"],
    group_name="sharepoint_dataset",
    io_manager_key="dataneyu_storage",
    deps=[sale_master_k],
)
def Sale_reportMY(oltp01_conn: PostgresConnection, config: SaleReportMY):
    df = extract_from_dwh(config.sql_query, oltp01_conn, return_type="pandas")
    df = df.drop_duplicates()
    return df


sync_sale_report_MY_job = define_asset_job(
    name="sync_sale_report_MY_job",
    selection=AssetSelection.assets(Sale_reportMY),
)

sync_sale_report_MY_schedule = ScheduleDefinition(
    job=sync_sale_report_MY_job,
    cron_schedule="0 0 * * *",
    execution_timezone="Asia/Bangkok",
)
