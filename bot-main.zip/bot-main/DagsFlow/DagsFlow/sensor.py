from dagster import (
    run_failure_sensor,
    RunFailureSensorContext,
    get_dagster_logger,
    sensor,
    RunRequest,
    SensorEvaluationContext,
    JobDefinition,
)
from DagsFlow.resources import telegram
from telebot.types import Update, Message
from DagsFlow.assets.report_bod import generate_report_bod_daily_summary_job
from DagsFlow.assets.cs_data_extractor import cs_data_extractor_job
from time import sleep

logger = get_dagster_logger()


@run_failure_sensor(minimum_interval_seconds=300)
def telegram_on_run_failure(
    context: RunFailureSensorContext,
    telebot_data: telegram.TelegramBot,
    telegram_chat: telegram.TelegramChat,
):
    bot = telebot_data
    chat_id = telegram_chat.get_id("BI_TEAM")
    for failure in context.get_step_failure_events():
        message = f"""<b>{failure.event_specific_data.error.cls_name}</b> error encounter in <b>{failure.job_name}</b> job at <b>{failure.step_key}</b> step"""
        bot.send_message(chat_id, text=message, parse_mode="html")
        sleep(5)


def request_job(job: JobDefinition, *unique_keys: str) -> RunRequest:
    run_key = "_".join([job.name] + list(unique_keys))
    return RunRequest(
        run_key=run_key,
        job_name=job.name,
    )


@sensor(jobs=[generate_report_bod_daily_summary_job], minimum_interval_seconds=60)
def telebot_data_keyphrase_trigger_sensor(
    context: SensorEvaluationContext,
    telebot_data: telegram.TelegramBot,
    telegram_chat: telegram.TelegramChat,
):
    bot = telebot_data.get_bot()
    # limit updates to 10 latest message for faster and more reliable retrieveal
    # fine tune this parameters with minimum_interval_seconds
    updates = bot.get_updates(offset=-10, limit=10, allowed_updates=["message"])
    last_trigger = int(context.cursor) if context.cursor else 0
    cursors = []
    for update in updates[::-1]:
        message: Message = update.message
        # store cursors to find latest in the updates
        cursor = message.date
        cursors.append(cursor)
        if cursor <= last_trigger:
            continue
        # trigger if and only if key phrase is detected in allowed chat group
        # start of copy-paste template
        if int(message.chat.id) == telegram_chat.get_id(
            "ALL_GEO_TARGET_TRACKING"
        ) and message.text.lower() in ["refresh"]:
            # acknowledge user command
            bot.reply_to(message, "Refreshing all geo target tracking report ...")
            # KEY FUNCTION: this will trigger the job
            yield request_job(generate_report_bod_daily_summary_job, str(message.date))
            # skip further checks
            continue
            # end of copy-paste template
    # move cursor to latest message, otherwise sensor will keep triggering old commands
    context.update_cursor(str(max(cursors)))


@sensor(jobs=[cs_data_extractor_job], minimum_interval_seconds=60)
def telebot_data_extractor_trigger_sensor(
    context: SensorEvaluationContext,
    telebot_data: telegram.TelegramBot,
    telegram_chat: telegram.TelegramChat,
):
    bot = telebot_data.get_bot()
    # limit updates to 10 latest message for faster and more reliable retrieveal
    # fine tune this parameters with minimum_interval_seconds
    updates = bot.get_updates(offset=-10, limit=10, allowed_updates=["message"])
    last_trigger = int(context.cursor) if context.cursor else 0
    cursors = []
    for update in updates[::-1]:
        message: Message = update.message
        # store cursors to find latest in the updates
        if message.content_type != 'sticker':
            cursor = message.date
            cursors.append(cursor)
            # print(message.content_type)
            # print("---------------------------------------------------------------------------------------")
            # print(message.text)
            if cursor <= last_trigger:
                continue
            # trigger if and only if key phrase is detected in allowed chat group
            # start of copy-paste template
            if int(message.chat.id) == telegram_chat.get_id(
                "DATA_EXTRACTOR"
            ) and message.text in [None]:
                break
            if int(message.chat.id) == telegram_chat.get_id(
                "DATA_EXTRACTOR"
            ) and message.text.lower() in ["/update"]:
                # acknowledge user command
                bot.reply_to(message, "I received your request, please wait..")
                
                try:
                    # Trigger the job
#                     yield RunRequest(run_key=str(message.date))
                    yield request_job(cs_data_extractor_job, str(message.date))
    
                    bot.reply_to(message, "Successfully updating AMs and Pubs.")
        
                except Exception as e:
                    error_message = f"The bot has problem: {e}"
                    logger.error(error_message)
                    bot.reply_to(message, error_message)
                finally:
                    break  # Stop processing further messages for this command
                
    # move cursor to latest message, otherwise sensor will keep triggering old commands
    context.update_cursor(str(max(cursors)))


