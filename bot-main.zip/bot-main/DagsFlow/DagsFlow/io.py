from dagster import (
    ConfigurableIOManager,
    OutputContext,
    InputContext,
    get_dagster_logger,
    MetadataValue,
    MultiPartitionKey,
)
from pydantic import Field
from dagster._seven.temp_dir import get_system_temp_directory
import pandas as pd
from typing import Any, Union, Optional, TypeVar
from pathlib import Path
from pyarrow import Table
import pyarrow.parquet as pq
import psycopg as pg
from typing_extensions import Literal
import pickle
import pyarrow.csv as ps
import pandas as pd
from DagsFlow.resources.msgraph import MSSiteClient
import io

T = TypeVar("T")
logger = get_dagster_logger()


def read_csv(_path):
    return pd.read_csv(_path)

def read_excel(_path):
    return pd.read_excel(_path)


def write_csv(_path, _obj: Union[Table, pd.DataFrame]):
    if isinstance(_obj, Table):
        ps.write_csv(_obj, _path)
    elif isinstance(_obj, pd.DataFrame):
        _obj.to_csv(_path)
    else:
        raise NotImplementedError("%s writer is not implemented.", type(_obj))

def write_excel(_path, _obj: Union[Table, pd.DataFrame]):
    if isinstance(_obj, Table):
        ps.write_excel(_obj, _path)
    elif isinstance(_obj, pd.DataFrame):
        _obj.to_excel(_path)
    else:
        raise NotImplementedError("%s writer is not implemented.", type(_obj))

def read_parquet(
    _path, process_engine: Literal["arrow", "pandas"]
) -> Union[Table, pd.DataFrame]:
    if process_engine == "arrow":
        return pq.read_table(_path)
    elif process_engine == "pandas":
        return pd.read_parquet(_path)


def write_parquet(_path, _obj: Union[Table, pd.DataFrame]):
    if isinstance(_obj, Table):
        pq.write_table(_obj, _path, row_group_size=512 * 1024)
    elif isinstance(_obj, pd.DataFrame):
        _obj: pd.DataFrame
        _obj.to_parquet(_path)


def _get_op_config(
    context: Union[InputContext, OutputContext], key: str
) -> Optional[str]:
    if not context.step_context.op_config:
        logger.debug("Op config is empty")
        return None
    return context.step_context.op_config.get(key)


def _get_resources_config(
    context: Union[InputContext, OutputContext], key: str, default_value: T
) -> T:
    if op_config := _get_op_config(context, key):
        return op_config
    else:
        return default_value


class SharepointIOManager(ConfigurableIOManager):
    """
    Handle DataFrame object only
    """

    base_io_folder: str
    base_io_format: str = "pickle"
    msgraph_client: MSSiteClient

    def _get_io_format(self, context: Union[InputContext, OutputContext]) -> str:
        io_format = _get_resources_config(context, "io_format", self.base_io_format)
        if io_format not in {"parquet", "pickle", "csv","excel"}:
            raise NotImplementedError(f"{io_format} format is not supported")
        return io_format

    def _get_io_abs_path(self, context: Union[InputContext, OutputContext]) -> str:
        return _get_resources_config(context, "io_abs_path", None)

    def _get_path(self, context: Union[InputContext, OutputContext]) -> str:
        if abs_path := self._get_io_abs_path(context):
            if context.has_asset_partitions:
                raise NotImplementedError(
                    "Absolute path cannot be used with multi-partitioned assets"
                )
            return abs_path
        base_folder = (
            _get_resources_config(context, "io_folder", self.base_io_folder) + "/"
        )
        io_format = self._get_io_format(context)
        if context.has_asset_partitions:
            if isinstance(context.asset_partition_key, MultiPartitionKey):
                asset_partition_key = list(
                    context.asset_partition_key.keys_by_dimension.values()
                )
            else:
                asset_partition_key = [context.asset_partition_key]
            path = (
                "/".join(context.asset_key.path + asset_partition_key) + f".{io_format}"
            )
        else:
            path = "/".join(context.asset_key.path) + f".{io_format}"
        return base_folder + path

    def handle_output(self, context: OutputContext, df: pd.DataFrame) -> None:
        io_format = self._get_io_format(context)
        if not isinstance(df, pd.DataFrame):
            raise NotImplementedError("Only pandas DataFrame input is supported")
        buffer = io.BytesIO()
        if io_format == "parquet":
            df.to_parquet(buffer, index=False)
        elif io_format == "pickle":
            df.to_pickle(buffer)
        elif io_format == "csv":
            df.to_csv(buffer, index=False)
        elif io_format == "excel":
            df.to_excel(buffer, index=False)
        output_metadata = self.msgraph_client.upload_item(
            buffer,
            self._get_path(context),
        )
        context.add_output_metadata(
            {
                "Sharepoint Metadata": MetadataValue.json(output_metadata),
                "Link": output_metadata["webUrl"],
            }
        )

    def load_input(self, context: InputContext) -> pd.DataFrame:
        io_format = self._get_io_format(context)
        file = self.msgraph_client.get_item_content(
            path_to_item=self._get_path(context)
        )
        file = io.BytesIO(file)
        file.seek(0)
        if io_format == "parquet" and file.read(4) != b"PAR1":
            raise ValueError("PAR1 not found for parquet file")
        file.seek(0)
        if io_format == "parquet":
            return pd.read_parquet(file, dtype_backend="pyarrow")
        elif io_format == "pickle":
            return pd.read_pickle(file)
        elif io_format == "csv":
            return pd.read_csv(file, dtype_backend="pyarrow")
        elif io_format == "excel":
            return pd.read_excel(file, dtype_backend="pyarrow")


class LocalFileIoManager(ConfigurableIOManager):
    base_path: str = get_system_temp_directory()
    file_extension: str

    @property
    def _base_path(self):
        return self.base_path

    @property
    def _file_extension(self):
        return self.file_extension

    def _get_path(self, context: Union[InputContext, OutputContext]) -> Path:
        key = Path(context.asset_key.path[-1])
        if context.has_asset_partitions:
            start, end = context.asset_partitions_time_window
            dt_format = "%Y-%m-%d"
            partition_str = start.strftime(dt_format)
            return Path(self._base_path, key, f"{partition_str}.{self._file_extension}")
        return Path(self._base_path, f"{key}.{self._file_extension}")


class CsvIOManager(LocalFileIoManager):
    file_extension = "csv"

    def handle_output(self, context: OutputContext, obj):
        path = self._get_path(context)
        path.parent.mkdir(parents=True, exist_ok=True)
        write_csv(path, obj)
        context.add_output_metadata({"path": path})

    def load_input(self, context: InputContext):
        return read_csv(self._get_path(context))
    
class ExcelIOManager(LocalFileIoManager):
    file_extension = "xlsx"

    def handle_output(self, context: OutputContext, obj):
        path = self._get_path(context)
        path.parent.mkdir(parents=True, exist_ok=True)
        write_excel(path, obj)
        context.add_output_metadata({"path": path})

    def load_input(self, context: InputContext):
        return read_excel(self._get_path(context))

class ArrowParquetIOManager(
    LocalFileIoManager,
):
    file_extension = "pq"

    def handle_output(self, context: OutputContext, obj):
        path = self._get_path(context)
        path.parent.mkdir(parents=True, exist_ok=True)
        write_parquet(path, obj)
        context.add_output_metadata({"path": path})

    def load_input(self, context: InputContext):
        return read_parquet(self._get_path(context), "arrow")


class PandasParquetIOManager(
    LocalFileIoManager,
):
    file_extension = "pq"

    def handle_output(self, context: OutputContext, obj):
        path = self._get_path(context)
        path.parent.mkdir(parents=True, exist_ok=True)
        write_parquet(path, obj)
        context.add_output_metadata({"path": path})

    def load_input(self, context: InputContext):
        return read_parquet(self._get_path(context), "pandas")
