from dagster import DagsterInstance, materialize, EnvVar
from DagsFlow.resources.postgres import PostgresConnection

from DagsFlow.assets.pub_ads_roi import (
    pub_ads_roi_agg_vn,
    pub_ads_roi_agg_my,
    pub_ads_roi_agg_ph,
    pub_ads_roi_agg_id,
    pub_ads_roi_agg_vn2,
    pub_ads_roi_agg_vn4,
    pub_ads_roi_agg_th,
    pub_ads_roi_agg_th2,
    pub_ads_roi_agg_all,
    load_pub_ads_roi_to_postgres,
)


def test_flow():
    with DagsterInstance.ephemeral() as instance:
        resources = {
            "oltp01_conn": PostgresConnection(
                libpq_conn=EnvVar("PG_LIBPQ_CONN_CONFIG"),
            ),
        }
        result = materialize(
            [
                pub_ads_roi_agg_vn,
                pub_ads_roi_agg_my,
                pub_ads_roi_agg_ph,
                pub_ads_roi_agg_id,
                pub_ads_roi_agg_vn2,
                pub_ads_roi_agg_vn4,
                pub_ads_roi_agg_th,
                pub_ads_roi_agg_th2,
                pub_ads_roi_agg_all,
                load_pub_ads_roi_to_postgres,
            ],
            instance=instance,
            resources=resources,
        )
        pass
