from dagster import (
    DagsterInstance,
    materialize,
    EnvVar,
    build_init_resource_context,
    build_resources,
)
from DagsFlow.resources import telegram, msgraph, postgres, pbiservice


def test_pbiclient():
    with DagsterInstance.ephemeral() as instance:
        with build_resources(
            {
                "pbiclient": pbiservice.PBIClient(
                    username=EnvVar("PBI_USERNAME"),
                    password=EnvVar("PBI_PASSWORD"),
                ),
            },
            instance=instance,
        ) as resources:
            pbiclient: pbiservice.PBIClient = resources.pbiclient
            workspaces = pbiclient.get_all_workspaces()
            assert len(workspaces) != 0
        pass


def test_postgres_connection():
    with DagsterInstance.ephemeral() as instance:
        with build_resources(
            {
                "test_conn": postgres.PostgresConnection(
                    libpq_conn=EnvVar("PG_LIBPQ_CONN_CONFIG"),
                )
            },
            instance=instance,
        ) as resources:
            test_conn: postgres.PostgresConnection = resources.test_conn
            with test_conn.get_connection() as connection:
                with connection.cursor() as cursor:
                    result = cursor.execute("select 1 as test").fetchone()[0]
                    assert result == 1
        pass


def test_telegram_bot():
    with DagsterInstance.ephemeral() as instance:
        with build_resources(
            {
                "telebot_data": telegram.TelegramBot(
                    bot_token=EnvVar("TELEGRAM_BOT_TOKEN_DATA")
                ),
            },
            instance=instance,
        ) as resources:
            telebot_data: telegram.TelegramBot = resources.telebot_data
            bot_user = telebot_data.get_bot().get_me()
            assert bot_user.first_name == "Data Team (Auto)"


def test_msgraph_client():
    with DagsterInstance.ephemeral() as instance:
        with build_resources(
            {
                "dataneyu_client": msgraph.MSSiteClient(
                    tenant_id=EnvVar("AZURE_TENANT_ID"),
                    client_id=EnvVar("AZURE_CLIENT_ID"),
                    client_secret=EnvVar("AZURE_CLIENT_SECRET"),
                    site_id="1b783fae-9880-4600-b18e-7e5f04e77c6d",  # either site_id or site_name must be declared, and site_id is preferred
                    site_name="DATANEYU",  # since site_name will incur an extra API hit to get site_id for each job
                ),
            },
            instance=instance,
        ) as resources:
            dataneyu_client: msgraph.MSSiteClient = resources.dataneyu_client
            found_metadata = dataneyu_client.get_item_metadata(
                path_to_item="Finance Cost Input/Assumption_Input.xlsx"
            )
            assert "webUrl" in found_metadata
            not_found_metadata = dataneyu_client.get_item_metadata(path_to_item="abc")
            assert "error" in not_found_metadata
