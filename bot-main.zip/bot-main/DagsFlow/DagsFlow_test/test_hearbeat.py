from DagsFlow.assets.heartbeat import apply_freshness_rule, _find_diff
import pandas as pd
from datetime import datetime, timedelta
import pytest
import logging
from freezegun import freeze_time


@freeze_time("2023-07-17 09:12:53")
def test_fresh_data():
    df = pd.DataFrame(
        [
            ["VN", datetime(2022, 1, 1, 1, 1, 1), datetime(2022, 1, 1, 1, 1, 1)],
            [
                "VN2",
                datetime.now() - timedelta(hours=1.0),
                datetime.now() - timedelta(hours=0.8),
            ],
            [
                "ID",
                datetime.now() - timedelta(hours=0.8),
                datetime.now() - timedelta(hours=0.5),
            ],
            [
                "TH",
                datetime.now() - timedelta(hours=0.8),
                datetime.now() - timedelta(hours=0.5),
            ],
        ],
        columns=["geo", "last_created_time", "last_modified_time"],
    )
    df["min_since_last_create"] = df["last_created_time"].apply(_find_diff)
    df["min_since_last_update"] = df["last_modified_time"].apply(_find_diff)
    df: pd.DataFrame = apply_freshness_rule(df)
    assert df.empty


@freeze_time("2023-07-17 09:12:53")
def test_stale_resell():
    df = pd.DataFrame(
        [
            [
                "VN3",
                datetime.now() - timedelta(hours=2.3),
                datetime.now() - timedelta(hours=2.1),
            ],
            [
                "TH",
                datetime.now() - timedelta(hours=1.8),
                datetime.now() - timedelta(hours=1.5),
            ],
        ],
        columns=["geo", "last_created_time", "last_modified_time"],
    )
    df["min_since_last_create"] = df["last_created_time"].apply(_find_diff)
    df["min_since_last_update"] = df["last_modified_time"].apply(_find_diff)
    df: pd.DataFrame = apply_freshness_rule(df)
    assert not df.empty
    assert len(df) == 1


@freeze_time("2023-07-17 22:30:53")
def test_stale_others():
    df = pd.DataFrame(
        [
            [
                "VN2",
                datetime.now() - timedelta(hours=1.3),
                datetime.now() - timedelta(hours=1.1),
            ],
            [
                "ID",
                datetime.now() - timedelta(hours=0.9),
                datetime.now() - timedelta(hours=0.7),
            ],
        ],
        columns=["geo", "last_created_time", "last_modified_time"],
    )
    df["min_since_last_create"] = df["last_created_time"].apply(_find_diff)
    df["min_since_last_update"] = df["last_modified_time"].apply(_find_diff)
    df: pd.DataFrame = apply_freshness_rule(df)
    assert not df.empty
    assert len(df) == 1


@freeze_time("2023-07-17 09:12:53")
def test_late_fresh_not_trigger_resell_geo():
    df = pd.DataFrame(
        [
            ["VN", datetime(2022, 1, 1, 1, 1, 1), datetime(2022, 1, 1, 1, 1, 1)],
            [
                "VN2",
                datetime.now() - timedelta(hours=1.0),
                datetime.now() - timedelta(hours=0.8),
            ],
            [
                "ID",
                datetime.now() - timedelta(hours=5),
                datetime.now() - timedelta(hours=0.5),
            ],
            [
                "TH",
                datetime.now() - timedelta(hours=0.8),
                datetime.now() - timedelta(hours=0.5),
            ],
        ],
        columns=["geo", "last_created_time", "last_modified_time"],
    )
    df["min_since_last_create"] = df["last_created_time"].apply(_find_diff)
    df["min_since_last_update"] = df["last_modified_time"].apply(_find_diff)
    df: pd.DataFrame = apply_freshness_rule(df)
    assert df.empty
