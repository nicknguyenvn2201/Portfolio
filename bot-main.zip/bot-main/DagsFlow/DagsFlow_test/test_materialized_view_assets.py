from dagster import DagsterInstance, EnvVar, materialize, build_resources
from DagsFlow.resources.postgres import PostgresConnection
from DagsFlow.assets.materialized_views import SqlStore, create_refreshable_table_asset
from pathlib import Path
from pytest import LogCaptureFixture
from psycopg.errors import UndefinedTable


def test_new_table(caplog: LogCaptureFixture):
    with DagsterInstance.ephemeral() as instance:
        with build_resources(
            {
                "oltp01_conn": PostgresConnection(
                    libpq_conn=EnvVar("PG_LIBPQ_CONN_CONFIG"),
                ),
            },
            instance=instance,
        ) as resources:
            pg_conn: PostgresConnection = resources.oltp01_conn
            with pg_conn.get_connection() as conn:
                with conn.cursor() as cur:
                    try:
                        cur.execute("drop table test_table")
                    except UndefinedTable:
                        pass
            path_to_sql_store = Path(__file__).parent / "materialized_view_assets_sql"
            asset = create_refreshable_table_asset(
                "test_table", sql_store=SqlStore(path_to_sql_store)
            )
            result = materialize(
                [asset],
                instance=instance,
                resources=resources._original_resource_dict,
            )
            assert "Table not found" in caplog.text
            assert "Completed recreating indexes" not in caplog.text


def test_existing_table(caplog: LogCaptureFixture):
    with DagsterInstance.ephemeral() as instance:
        resources = {
            "oltp01_conn": PostgresConnection(
                libpq_conn=EnvVar("PG_LIBPQ_CONN_CONFIG"),
            ),
        }
        path_to_sql_store = Path(__file__).parent / "materialized_view_assets_sql"
        asset = create_refreshable_table_asset(
            "test_table", sql_store=SqlStore(path_to_sql_store)
        )
        result = materialize(
            [asset],
            instance=instance,
            resources=resources,
        )
        assert "Table found" in caplog.text
        assert "Completed recreating indexes" in caplog.text
