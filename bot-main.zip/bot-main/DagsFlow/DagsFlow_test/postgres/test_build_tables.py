import DagsFlow.assets.utls.func as asset_utls
import pytest
import pyarrow as pa
import psycopg as pg
from datetime import date


@pytest.fixture
def pa_table() -> pa.Table:
    return pa.table(
        [
            ["VN", "VN", "TH", "MY"],
            [1, 2, None, 4],
            [
                date(2023, 12, 31),
                date(2022, 6, 30),
                date(1970, 1, 1),
                date(2050, 12, 31),
            ],
        ],
        schema=pa.schema(
            [("country", "string"), ("numbers", "int8"), ("1st_date", "date32")]
        ),
    )


@pytest.fixture
def pg_conn():
    return "host=localhost port=54321 dbname=postgres user=postgres password=admin"


def test_reset_then_insert_table_not_exists(pa_table, pg_conn):
    with pg.connect(pg_conn) as connection:
        with connection.cursor() as cursor:
            cursor.execute("DROP TABLE new_table")
        connection.commit()
        asset_utls.pg_reset_then_insert(connection, pa_table, "new_table")
        with connection.cursor() as cursor:
            cursor.execute("SELECT * FROM new_table")
            assert cursor.fetchone() == ("VN", 1, date(2023, 12, 31))
            assert cursor.fetchone() == ("VN", 2, date(2022, 6, 30))
            cursor.execute("SELECT count(*) FROM new_table")
            assert cursor.fetchone() == (4,)
            cursor.execute('SELECT "1st_date" FROM new_table')
            assert cursor.fetchone() == (date(2023, 12, 31),)


def test_reset_then_insert_table_exists(pa_table, pg_conn):
    with pg.connect(pg_conn) as connection:
        with connection.cursor() as cursor:
            cursor.execute("DROP TABLE old_table")
            cursor.execute(
                """CREATE TABLE IF NOT EXISTS old_table (
                        country text,
                        numbers int8,
                        "1st_date" date
                )"""
            )
        connection.commit()
        asset_utls.pg_reset_then_insert(connection, pa_table, "old_table")
        with connection.cursor() as cursor:
            cursor.execute("SELECT * FROM old_table")
            assert cursor.fetchone() == ("VN", 1, date(2023, 12, 31))
            assert cursor.fetchone() == ("VN", 2, date(2022, 6, 30))
            cursor.execute("SELECT count(*) FROM old_table")
            assert cursor.fetchone() == (4,)
            cursor.execute('SELECT "1st_date" FROM old_table')
            assert cursor.fetchone() == (date(2023, 12, 31),)
