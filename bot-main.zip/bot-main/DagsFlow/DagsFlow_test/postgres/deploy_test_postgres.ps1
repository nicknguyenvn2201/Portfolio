$ErrorActionPreference = 'Stop'
docker pull postgres
docker run --name "test-postgres" -p 2345:5432 -e POSTGRES_PASSWORD=admin -d postgres 