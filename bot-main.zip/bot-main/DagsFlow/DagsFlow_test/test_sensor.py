from DagsFlow.sensor import telebot_data_keyphrase_trigger_sensor
from DagsFlow.resources import telegram
from dagster import build_sensor_context, EnvVar, DagsterInstance


def test_telegram_sensor():
    with DagsterInstance.ephemeral() as instance:
        context = build_sensor_context(instance=instance)
        sensor_result = list(
            telebot_data_keyphrase_trigger_sensor(
                context,
                telebot_data=telegram.TelegramBot(
                    bot_token=EnvVar("TELEGRAM_BOT_TOKEN_DATA")
                ),
                telegram_chat=telegram.TelegramChat(
                    all_chat_id={
                        "ALL_GEO_TARGET_TRACKING": -1001945984108,
                    }
                ),
            )
        )
        pass
